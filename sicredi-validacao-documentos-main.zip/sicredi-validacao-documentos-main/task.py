from dotenv import load_dotenv
load_dotenv()
from shutil import rmtree
from app.modules.sharepoint import SharePointClient
import app.utils.arquives as arquive
from app.modules.pipeline.errors import ColetorErrosSharePoint, ColetorErrosNulo
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, wait, TimeoutError as FutTimeout
import os, time, atexit, sys
from datetime import datetime, UTC
import concurrent.futures as cf
from app.utils.logger import LoggerManager
from app.utils.registry import consultar_infos_processo
from app.utils.threads import run_with_timeout
from app.utils.helpers import normalize
log = LoggerManager(__name__)  # logger do módulo (task)
import locale
for loc in ("pt_BR.UTF-8", "pt_BR.utf8", "pt_BR", ""):
    try:
        locale.setlocale(locale.LC_ALL, loc)
        break
    except Exception:
        continue
from app.modules.supabase import SupabaseClient

# === Parâmetros de paralelismo ===
MAX_COOPS_PARALELAS = int(os.getenv("MAX_COOPS_PARALELAS", "3"))
MAX_PROCESSOS_SIMULTANEOS = int(os.getenv("MAX_PROCESSOS_SIMULTANEOS", "5"))

COOP_EXECUTOR = ThreadPoolExecutor(max_workers=MAX_COOPS_PARALELAS)
PIPELINE_EXECUTOR = ThreadPoolExecutor(max_workers=MAX_PROCESSOS_SIMULTANEOS)

atexit.register(lambda: COOP_EXECUTOR.shutdown(wait=False))
atexit.register(lambda: PIPELINE_EXECUTOR.shutdown(wait=False))

# ---- budgets (ajuste via env se quiser) ----
DOWNLOAD_TIMEOUT_S      = int(os.getenv("DOWNLOAD_TIMEOUT_S", "90"))   # por operação de download
EXTRACT_TIMEOUT_S       = int(os.getenv("EXTRACT_TIMEOUT_S", "90"))    # extração (subprocesso)

BASE_DIR = Path(__file__).resolve().parent
OUT_DIR = BASE_DIR / "output"
OUT_DIR.mkdir(parents=True, exist_ok=True)
ROBO_NAME = os.getenv("ROBO_NAME", "robo_default")
supabase = SupabaseClient()

# SHAREPOINT
secret = {
    "clientId": os.getenv('SHAREPOINT_CLIENT_ID'),
    "clientSecret": os.getenv('SHAREPOINT_CLIENT_SECRET'),
    "tenantId": os.getenv('SHAREPOINT_TENANT_ID'),
    "authority": os.getenv('SHAREPOINT_AUTHORITY'),
    "scope": os.getenv('SHAREPOINT_SCOPE'),
    "sharepointUrl": os.getenv('SHAREPOINT_URL')
}

ctx = SharePointClient(secret)
site_id = ctx.search_sites('grupometa', 'servicos-sicredi')

def recuperar_processos_pendentes_do_robo():
    registros = supabase.select("processos", {
        "status": "EM_ANDAMENTO",
        "robo": ROBO_NAME
    })
    return registros or []

def tentar_pegar_processo(coop, colaborador, processo):
    """
    Tenta marcar o processo como EM_ANDAMENTO para este robô.

    Retornos:
      - True  -> ganhou a corrida e deve processar
      - False -> outro robô está processando
      - None  -> erro de banco
    """
    # ------------------------------
    # 1) Consulta inicial
    # ------------------------------
    try:
        registros = supabase.select("processos", {
            "processo": processo,
            "cooperativa": coop,
            "colaborador": colaborador
        })
    except Exception as e:
        log.error(f"❌ ERRO BANCO ao consultar processo {processo}: {e}")
        return None

    registro = registros[0] if registros else None

    # Se já existe e está em andamento:
    if registro and registro.get("status") == "EM_ANDAMENTO":
        dono = registro.get("robo")
        if dono == ROBO_NAME:
            log.info(f"♻️ Retomando processo pendente {processo} do próprio robô.")
            return True
        else:
            log.info(f"⛔ Processo {processo} já em andamento por {dono}.")
            return False

    # ------------------------------
    # 2) Tenta marcar como EM_ANDAMENTO
    # ------------------------------
    try:
        supabase.upsert(
            "processos",
            {
                "processo": processo,
                "cooperativa": coop,
                "colaborador": colaborador,
                "status": "EM_ANDAMENTO",
                "robo": ROBO_NAME,
                "updated_at": datetime.now(UTC).isoformat(),
            },
            on_conflict=["processo", "cooperativa", "colaborador"],
        )
    except Exception as e:
        log.error(f"❌ ERRO BANCO ao registrar processo {processo}: {e}")
        return None

    # ------------------------------
    # 3) READ-BACK obrigatório
    # garante estado real do banco
    # ------------------------------
    try:
        final = supabase.select("processos", {
            "processo": processo,
            "cooperativa": coop,
            "colaborador": colaborador
        })
        final = final[0] if final else None
    except Exception as e:
        log.error(f"❌ ERRO BANCO ao confirmar dono do processo {processo}: {e}")
        return None

    if not final:
        log.error(f"⚠ ERRO: banco retornou nenhum registro após upsert!")
        return None

    dono_final = final.get("robo")

    if dono_final != ROBO_NAME:
        log.info(f"⛔ Corrida perdida: processo {processo} ficou com {dono_final}.")
        return False

    # ------------------------------
    # 🟢 Só chega aqui se REALMENTE ganhou a linha
    # ------------------------------
    return True

def atualizar_status(processo, cooperativa, colaborador, status):
    supabase.update_fields(
        "processos",
        {
            "processo": processo,
            "cooperativa": cooperativa,
            "colaborador": colaborador,
        },
        {
            "status": status,
            "robo": ROBO_NAME,
            "updated_at": datetime.now(UTC).isoformat()
        }
    )

def processar_cooperativa(coop):
    coop_name = str(coop["name"])
    # Paths/folders específicos da coop
    coop_base = f"{caminho_sharepoint}/{coop_name}"
    pasta_monitorada  = f"{coop_base}/PASTA_MONITORADA"
    pasta_resultados  = f"{coop_base}/PASTA_RESULTADOS"
    pasta_processados = f"{coop_base}/PROCESSADOS"
    pasta_logs = f"{pasta_processados}/REGISTROS"
    infos_sp = f"{coop_base}/infos_processes.xlsx"
    regras_sp = f"{coop_base}/REGRAS.xlsx"
    informacoes_rpa = None
    planilhas_configuradas = False
    log.info(f"==================== COOPERATIVA: {coop_name} ====================")
    try:
        log.debug("Listando arquivos da pasta monitorada...")
        monitorada_children = ctx.search_folder_children(site_id, pasta_monitorada) or []

        # 🔒 Evita validar pastas indevidas
        monitorada_children = [
            item for item in monitorada_children
            if not any(b in item["name"].upper() for b in ("PASTA_MONITORADA", "PASTA_RESULTADOS", "PROCESSADOS"))
        ]

        if not monitorada_children:
            log.info("📂 Nenhum item válido na pasta monitorada.")
        else:
            # 🔽 Importa a parte pesada só quando há processo a ser executado
            from app.modules.pipeline.by_process import by_process
            pipelines = []
            log.info(f"Itens encontrados na pasta monitorada: {len(monitorada_children)}")
            resultados_existentes = {
                normalize(ctx.clean_sharepoint_name(item["name"]))
                for item in ctx.search_folder_children(site_id, pasta_resultados) or []
                if "folder" in item
            }

            for item in monitorada_children:
                name = str(item["name"])
                if name.upper().startswith("ERRO"):
                    log.debug(f"⏭ Item '{name}' ignorado (prefixo ERRO).")
                    continue

                # este timestamp é do item da pasta monitorada
                horario_ultima_modificacao = item.get("lastModifiedDateTime")

               
                if horario_ultima_modificacao:
                    horario_processo = datetime.fromisoformat(horario_ultima_modificacao.replace("Z", "+00:00"))
                else:
                    horario_processo = None

                if not planilhas_configuradas: #Uma única vez por coop
                    # Planilha de regras (lida em memória, sem download)
                    log.debug("Configurando planilha de regras...")
                    regras_url = ctx.search_file_data(site_id, regras_sp)
                    book = ctx.read_workbook(regras_url)

                    # Infos do RPA (se existir)
                    log.debug("Configurando planilha de infos_processes.xlsx")
                    try:
                        infos_url = ctx.search_file_data(site_id, infos_sp)
                        if infos_url:
                            informacoes_rpa = ctx.read_workbook(infos_url)  # dict {sheet: DataFrame}
                    except Exception: pass
                    
                    planilhas_configuradas = True

                # ---- pipeline do processo ----
                def _pipeline(item=item, name=name, horario_processo=horario_processo):
                    book_local=book
                    raw_name = name if "folder" in item else os.path.splitext(name)[0]
                    
                    # 🌟 novo: pasta de saída por COOP e por processo
                    process_folder = raw_name              # <= processo continua puro
                    local_proc = OUT_DIR / coop_name / raw_name
                    log.debug(f"Process folder: {process_folder}, local_proc:{local_proc}")
                    arquive.excluir_pasta(local_proc, OUT_DIR)
                    nome_proc_normalizado = normalize(ctx.clean_sharepoint_name(process_folder))
                    if normalize(f"{nome_proc_normalizado}_resultado") in resultados_existentes:
                        log.debug(f"⏭  Processo '{process_folder}' já possui resultado. Pulando.")
                        return

                    # responsável
                    colaborador = ctx.responsavel_do_item(site_id, pasta_monitorada, item) or ""
                    if colaborador and colaborador.strip() != '':
                        partes = colaborador.split()
                        colaborador = f"{partes[0]} {partes[-1]}" if len(partes) >= 2 else partes[0] #Primeiro e ultimo nome se não só o primeiro
                    else:
                        colaborador = "DESCONHECIDO"
                    coletor_erros = ColetorErrosSharePoint(ctx, site_id, item) if ctx else ColetorErrosNulo()

                    status = tentar_pegar_processo(coop_name, colaborador, process_folder)
                    if status is False:
                        log.info(f"⛔ Processo {process_folder} já está em andamento por outro robô. Pulando.")
                        return
                    elif status is None:
                        log.error(f"Erro ao verificar o processo no supabase.")
                        try: coletor_erros.marcar("ERRO BANCO - ")
                        except Exception: pass
                        return

                    log.info(f"⬇️  Iniciando processo: {process_folder}")
                    # 1) DOWNLOAD
                    log.info(f"📥 [1/3] Baixando arquivos do processo '{process_folder}'...")
                    # ===========================
                    # RETRY DA LISTAGEM DE ARQUIVOS
                    # SE O PROCESSO FOI ANEXADO HÁ < 60s
                    # ===========================
                    caminho_proc_sp = f"{pasta_monitorada}/{process_folder}"
                    # calcula quanto tempo faz que o processo foi anexado
                    if horario_processo:
                        delta_seg = (datetime.now(UTC) - horario_processo).total_seconds()
                    else:
                        delta_seg = 9999  # se não tem horário, assume antigo

                    # faz retry somente se o processo for MUITO recente (< 1 min)
                    if delta_seg < 60:
                        log.info(f"⏳ Processo '{process_folder}' anexado há {delta_seg:.1f}s — aplicando retry da listagem.")
                        for _ in range(2):  # total 3 tentativas
                            time.sleep(1.0)
                            nova_lista = ctx.search_folder_children(site_id, caminho_proc_sp) or []
                            nomes = [a["name"] for a in nova_lista]
                            log.debug(f"Retry listagem -> {len(nova_lista)} itens: {nomes}")
                    else:
                        log.debug("Processo antigo — nenhum retry necessário.")

                    t0 = time.monotonic()
                    try:
                        if "folder" in item:
                            run_with_timeout(
                                ctx.download_tree_parallel, DOWNLOAD_TIMEOUT_S,
                                site_id, f"{pasta_monitorada}/{process_folder}", local_proc,
                                use_process=False
                            )
                        elif "folder" not in item and (item.get("name", "").lower().endswith(".zip")):
                            run_with_timeout(
                                ctx.download_and_extract_zip, DOWNLOAD_TIMEOUT_S,
                                site_id, f"{pasta_monitorada}/{name}", local_proc
                            )
                        else:
                            run_with_timeout(
                                ctx.download_file_by_path, DOWNLOAD_TIMEOUT_S,
                                site_id, f"{pasta_monitorada}/{name}", os.path.join(local_proc, name)
                            )

                        log.info(f"✅ Download concluído em {time.monotonic()-t0:.1f}s")
                    except FutTimeout:
                        log.error(f"⌛ Timeout ({DOWNLOAD_TIMEOUT_S}s) no download de '{process_folder}'. Seguindo com o que tiver.")
                        try: coletor_erros.marcar("ERRO TIMEOUT DOWNLOAD - ")
                        except Exception: pass
                        return
                    except Exception as e:
                        log.error(f"⚠ Erro no download de '{process_folder}': {e}. Seguindo fluxo mesmo assim.")
                        coletor_erros.marcar("ERRO DOWNLOAD - ")
                        return

                    # 2) EXTRAÇÃO se houver .zip/.rar
                    log.info(f"🗜️ [2/3] Extraindo arquivos compactados (se houver)...")
                    try:
                        if os.path.exists(local_proc):
                            if arquive.has_archives(local_proc):
                                try:
                                    run_with_timeout(
                                        arquive.extract_archives_recursive, EXTRACT_TIMEOUT_S,
                                        base_dir=local_proc, max_depth=5, delete_archives=True,
                                        use_process=True
                                    )
                                    log.info("✅ Extração concluída")
                                except FutTimeout:
                                    log.error(f"⌛ Timeout ({EXTRACT_TIMEOUT_S}s) na extração. Seguindo sem extrair mais.")
                                    coletor_erros.marcar("ERRO ZIP - ")
                                    return
                            else:
                                log.debug("↪️  Nenhum .zip/.rar encontrado — pulando extração.")
                        else:
                            log.error(f"⚠ Caminho do processo local não encontrado!")
                            try: coletor_erros.marcar("ERRO PROCESSO - ")
                            except Exception: pass
                            return
                    except Exception as e:
                        log.error(f"⚠ Falha na etapa de extração: {e}. Seguindo.")
                        coletor_erros.marcar("ERRO ZIP - ")
                        return

                    # 3) VALIDAR
                    informacoes_processo = {"colaborador": colaborador, "cooperativa": coop_name}
                    # ===========================
                    # CAPTURA DIRETA DA PASTA NO SHAREPOINT (SEM FUNÇÃO)
                    # ===========================

                    informacoes_processo = {
                        "colaborador": colaborador,
                        "cooperativa": coop_name
                    }
                    try:
                        # Caminho da pasta do processo no SharePoint
                        caminho_proc_sp = f"{pasta_monitorada}/{process_folder}"
                        itens = ctx.search_folder_children(site_id, caminho_proc_sp) or []

                        qtd_docs = len(itens)

                        # Horário mais antigo = horário aproximado de anexação
                        horario_anexado = None
                        for item in itens:
                            ts = item.get("lastModifiedDateTime")
                            if ts:
                                dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                                if horario_anexado is None or dt < horario_anexado:
                                    horario_anexado = dt

                        # → FORMATAÇÃO BONITA: dd/mm/aaaa HH:MM:SS
                        def formatar(dt):
                            return dt.astimezone().strftime("%d/%m/%Y %H:%M:%S") if dt else None

                        informacoes_processo["Quantidade De Documentos Na Pasta"] = qtd_docs
                        informacoes_processo["Horario Que Foi Anexado O Processo Na Pasta"] = formatar(horario_anexado)
                        informacoes_processo["Horario De Início Do Robo"] = formatar(datetime.now(UTC))

                        log.info(
                            f"📌 Pasta '{process_folder}': "
                            f"{qtd_docs} arquivos | "
                            f"anexado em {informacoes_processo['Horario Que Foi Anexado O Processo Na Pasta']} | "
                            f"início do robô {informacoes_processo['Horario De Início Do Robo']}"
                        )

                    except Exception as e:
                        log.error(f"⚠ Erro ao coletar infos da pasta: {e}")


                    if informacoes_rpa:
                        dados_rpa = consultar_infos_processo(informacoes_rpa, process_folder)
                        if dados_rpa:
                            log.debug(f"Informações do processo {process_folder} encontradas!")
                            log.debug(f"Dados encontrados {dados_rpa}")
                            informacoes_processo.update(dados_rpa)
                        else:
                            log.debug(f"Não foi encontrado informações do RPA para o processo {process_folder}")

                    if not arquive.possui_arquivos(Path(local_proc)):
                        log.error(f"⚠ Processo '{process_folder}' não possui arquivos válidos. Pulando.")
                        coletor_erros.marcar("ERRO SEM ARQUIVOS - ")
                        return

                    log.info(f"🧪 [3/3] Iniciando validação (by_process) em: {local_proc}")
                    # dentro do _pipeline em task.py
                    try:
                        by_process(
                            local_proc,
                            informacoes_processo,
                            caminho_planilha_regras=book_local,
                            coletor_erros=coletor_erros,
                        )
                        atualizar_status(process_folder, coop_name, colaborador, "CONCLUIDO")
                    except Exception as e:
                        atualizar_status(process_folder, coop_name, colaborador, "ERRO")
                        log.error(f"⚠ by_process falhou em '{process_folder}': {e}")
                        try: coletor_erros.marcar("ERRO PROCESSO - ")
                        except Exception: pass
                        return


                    # 4) UPLOAD
                    log.info("Enviando os resultados para o sharepoint")
                    try:
                        ctx.ensure_folder_path(site_id, pasta_resultados)
                        enviados = ctx.upload_results_bundle(site_id, pasta_resultados, process_folder, output_dir=str(OUT_DIR))
                        if not enviados:
                            coletor_erros.marcar("ERRO PROCESSO - ")
                    except Exception as e:
                        log.error(f"⚠ Falha no upload de '{process_folder}': {e}")
                        coletor_erros.marcar("ERRO UPLOAD RESULTADOS - ")

                    # 5) LIMPEZA local
                    log.info("Limpando resultados locais")
                    if os.path.exists(local_proc):
                        try:
                            rmtree(local_proc)
                        except Exception:
                            pass

                    log.info(f"Finalizando para o item {name}")

                # Enfileira no executor da cooperativa
                pipelines.append(PIPELINE_EXECUTOR.submit(_pipeline))

            # Espera todos os processos dessa cooperativa
            pendentes = set(pipelines)
            while pendentes:
                done, pendentes = wait(pendentes, timeout=15)
                for f in done:
                    try:
                        f.result()
                    except Exception as e:
                        log.error(f"⚠ Pipeline falhou: {e}")

        # Mover itens antigos para PROCESSADOS
        log.info("🚚 Movendo itens antigos para PROCESSADOS...")
        #if "teste" not in coop_name.lower():
        try:
            run_with_timeout(
                ctx.move_items_older_than, 120,  # timeout_s = 120s
                site_id=site_id,
                coop_base=coop_base,
                hours=2,
                use_process=False  # opcional (padrão)
            )
            log.info("✅ Mover arquivos antigos -> OK")
        except cf.TimeoutError:
            log.error("⌛ Timeout (120s) em move_items_older_than. Pulando etapa nesta coop.")
        except Exception as e:
            log.error(f"⚠ Erro em move_items_older_than: {e}")


    except Exception as e:
        log.error(f"❌ Falha ao processar cooperativa {coop_name}: {e}")
    finally:
        log.info(f"🏁 Finalizado processamento da cooperativa {coop_name}")


if __name__ == "__main__":
    log.info("==================== INICIANDO O SCRIPT ====================")

    # Pasta base (todas as cooperativas)
    # caminho_sharepoint = '06. Excelência Operacional/AUTOMACOES/Cooperativas'
    # caminho_sharepoint = '06. Excelência Operacional/AUTOMACOES/Testes/coops'
    caminho_sharepoint = '06. Excelência Operacional/AUTOMACOES/Testes/coops2'
    #Lista de prioridades por cooperativa
    PRIORIDADES = {
        "GERAL": 1, 
        "810": 2,
        "821": 3,
        "804": 4,
        "TESTE": 5
    }
    # Lista cooperativas (apenas pastas)
    cooperativas = [c for c in (ctx.search_folder_children(site_id, caminho_sharepoint) or []) if "folder" in c]

    # Ordena pela prioridade, quem não tiver prioridade vai pro final (9999)
    cooperativas = sorted(
        cooperativas,
        key=lambda c: PRIORIDADES.get(c["name"].upper(), 9999)
    )
    coops_names = [c["name"] for c in cooperativas]
    log.info(f"🔎 Cooperativas encontradas (ordenadas por prioridade): {coops_names}")

    # Dispara TODAS as cooperativas em paralelo
    futures = [COOP_EXECUTOR.submit(processar_cooperativa, coop) for coop in cooperativas]

    wait(futures, timeout=1200)
    log.info("==================== SCRIPT FINALIZADO ====================")
    os._exit(0)
    # reinicia o processo Python do zero (memória limpa)
    #time.sleep(30)  # espera  antes de reiniciar o ciclo
    #os.execl(sys.executable, sys.executable, *sys.argv)
