
from typing import Dict, List, Tuple
import re
from app.utils.helpers import normalize
from datetime import date

def identificar_subtitulos_por_hierarquia(componentes: List[Tuple[str, float]]) -> Dict[Tuple[str, float], List[Tuple[str, float]]]:
    hierarchy = {}
    nivel_de_cada_item = {}
    etapa = 1

    for nome, valor in componentes:
        nivel_de_cada_item[(nome, valor)] = 0
        hierarchy[(nome, valor)] = []  # Garante que todos já existam na hierarquia
    
    def atualizar_niveis_recursivamente(campo, novo_nivel):
        """Atualiza o nível do campo e de todos os seus descendentes."""
        nivel_de_cada_item[campo] = novo_nivel
        for filho in hierarchy.get(campo, []):
            atualizar_niveis_recursivamente(filho, novo_nivel + 1)
    def encontrar_pai_do_campo(campo, hierarchy):
        for pai, filhos in hierarchy.items():
            if campo in filhos:
                return pai
        return None
    def is_ultimo_filho(campo, hierarchy):
        """Permite validar filhos apenas se o campo for o último filho do seu pai.
        Nó sem pai (raiz) pode validar normalmente."""
        pai = encontrar_pai_do_campo(campo, hierarchy)
        if not pai:
            return True  # nós raiz podem procurar filhos
        filhos = hierarchy.get(pai, [])
        return bool(filhos) and filhos[-1] == campo
    
    hierarquias_anteriores = []
    campos_totais = ['totalativo', 'totalpassivo', 'totalcirculante', 'totalnaocirculante', 'totalpatrimonio', 'totaldoativo', 'totaldopassivo']
    contagem = 0
    while True:
        novos_pares = 0
        
        for idx_pai, (nome_pai, valor_pai) in enumerate(componentes):
            # Analisa nome_pai como possível PAI 
            nivel_pai = nivel_de_cada_item.get((nome_pai, valor_pai), 0)
            # ⚠️ Se esse campo já possui muitos filhos, não deve receber novos subtítulos
            # 🔍 Impede que um campo que pertence a um grupo grande tente ser pai
            pai_do_campo = encontrar_pai_do_campo((nome_pai, valor_pai), hierarchy)
            if pai_do_campo and not is_ultimo_filho((nome_pai, valor_pai), hierarchy):
                continue    
            if pai_do_campo:
                filhos_do_pai = hierarchy[pai_do_campo]
                if len(filhos_do_pai) >= 10:
                    # '{nome_pai}' pertence a um grupo com muitos itens. Não tentará subtítulos.
                    continue
            if hierarchy.get((nome_pai, valor_pai)):
                # '{nome_pai}' já tem filhos mapeados. Não vai procurar novos filhos.
                continue
            filhos_confirmados = []

            def esta_abaixo_na_hierarquia(nome_valor_pai, nome_valor_filho, hierarquia_atual):
                filhos_desse = hierarquia_atual.get(nome_valor_pai, [])
                for f in filhos_desse:
                    if f == nome_valor_filho or esta_abaixo_na_hierarquia(f, nome_valor_filho, hierarquia_atual):
                        return True
                return False
            primeiro_caso = True
            for nivel_atual in range(nivel_pai + 1):
                filhos = []
                soma = 0.0
                segundo_cenario_encontrado = False
                filhos_alternativa, soma_alternativa = [], 0.0
                for idx_filho in range(idx_pai + 1, len(componentes)):
                    nome_filho, valor_filho = componentes[idx_filho]
                    filho_tuple = (nome_filho, valor_filho)
                    nivel_filho = nivel_de_cada_item.get(filho_tuple, 0)
                    if contagem >= 800000: #Segurança
                        return
                    contagem +=1
                    if nivel_filho != nivel_atual or nivel_filho > nivel_pai:
                        continue
                    if esta_abaixo_na_hierarquia((nome_pai, valor_pai), filho_tuple, hierarchy):
                        continue
                    campo_total_encontrado = False
                    for campo_total in campos_totais:
                        campo_total = re.sub(r"\([^)]*\)", "", normalize(campo_total)).replace(" ", "").replace("-", "").strip()
                        if campo_total in normalize(nome_filho).replace(" ",""):
                            campo_total_encontrado = True
                            break
                    if campo_total_encontrado:
                        continue  
                    eh_negativo_pelo_nome = "(-" in nome_filho.replace(" ", "").lower()

                    # Cenário 1: valor original

                    # Cenário 2: valor com sinal invertido SE nome indicar "(-)"
                    if eh_negativo_pelo_nome and primeiro_caso:
                        primeiro_caso = False
                        valor_invertido = -valor_filho if valor_filho > 0 else abs(valor_filho)
                        segundo_cenario_encontrado = True
                        filhos_alternativa = filhos.copy()
                        filhos_alternativa.append((nome_filho, valor_invertido))
                        soma_alternativa = soma + valor_invertido

                    elif segundo_cenario_encontrado:
                        if eh_negativo_pelo_nome: #caso tenha mais um campo que seja negativo pelo campo)
                            valor_invertido = -valor_filho if valor_filho > 0 else abs(valor_filho)
                        else:
                            valor_invertido = valor_filho
                        soma_alternativa += valor_invertido
                        filhos_alternativa.append(filho_tuple)
                    filhos.append(filho_tuple)
                    soma += valor_filho

                    if abs(round(soma, 2) - round(valor_pai, 2)) <= 0.02:
                        # ➕ Soma parcial é igual ao valor do pai.
                        break
                    elif abs(round(soma_alternativa, 2) - round(valor_pai, 2)) <= 0.02:
                        # ➕ Soma alternativa é igual ao valor do pai.
                        break

                if abs(round(soma, 2) - round(valor_pai, 2)) <= 0.02 and filhos:
                    # Soma válida encontrada!
                    filhos_confirmados = filhos
                    break
                elif abs(round(soma_alternativa, 2) - round(valor_pai, 2)) <= 0.02 and filhos:
                    # Substitui valores dos filhos com sinal invertido
                    filhos_confirmados = filhos_alternativa

                    # Apaga os campos originais que foram invertidos
                    for idx, (nome_filho, valor_corrigido) in enumerate(filhos_alternativa):
                        nome_original = nome_filho
                        valor_original = -valor_corrigido  # sinal invertido

                        campo_original = (nome_original, valor_original)
                        if campo_original in hierarchy:
                            #Remove campo duplicado
                            del hierarchy[campo_original]
                        if campo_original in nivel_de_cada_item:
                            del nivel_de_cada_item[campo_original]

                    break


            if filhos_confirmados:
                # Subtitulos encontrados para nome_pai
                for filho in filhos_confirmados:
                    # Verifica se o filho já tem um pai anterior
                    pai_anterior = encontrar_pai_do_campo(filho, hierarchy)

                    if pai_anterior:
                        # Se o novo pai for descendente do pai anterior, então troca a paternidade
                        if esta_abaixo_na_hierarquia(pai_anterior, (nome_pai, valor_pai), hierarchy):
                            hierarchy[pai_anterior].remove(filho)
                            # Remove filho filho[0] como filho de pai_anterior[0] pois agora pertence a nome_pai
                        else:
                            # filho[0] já pertence a pai_anterior[0] e '{nome_pai}' não é descendente. Ignora
                            continue  # ignora filho para não duplicar

                    hierarchy.setdefault((nome_pai, valor_pai), []).append(filho)
                    atualizar_niveis_recursivamente(filho, nivel_pai + 1)

                novos_pares += 1

        if len(hierarquias_anteriores) >= 5:
            # Hierarquia estável após 5 ciclos. Encerra
            break
        else:
            # Hierarquia igual detectada. Armazenando e continuando mais uma etapa.
            hierarquias_anteriores.append(hierarchy.copy())
        etapa += 1
    return hierarchy

def interpretar_valor_bruto(valor_bruto: str, grupo: str, valores_em_milhares: bool = False) -> float:
    """
    Recebe um valor como 'R$ 1.000,00 D', '395.991,73 C', '-2.000,00', '(5.000,00)', etc.
    Interpreta corretamente o sinal e retorna o float.
    """
    if not valor_bruto:
        return 0.0

    # ✅ Remover prefixo 'R$', espaços, ajustar vírgulas e pontos
    valor_bruto = valor_bruto.upper().replace("R$", "").replace(" ", "").replace(".", "").replace(",", ".")

    # Extrair valor numérico e sufixo (D, C, etc.)
    match = re.match(r"[-(]?([\d\.]+(?:,\d{2})?)\)?\s*([DCRB]*)", valor_bruto, re.IGNORECASE)
    if not match:
        # Valor não reconhecido pela regex
        return 0.0

    numero_str, sufixo = match.groups()
    try:
        valor = float(numero_str)
    except ValueError:
        # Erro ao converter número
        return 0.0

    negativo = False

    # Regras visuais
    if valor_bruto.startswith("-") or valor_bruto.startswith("(") or valor_bruto.endswith("-"):
        negativo = True

    # Regras de sufixo
    sufixo = sufixo.upper()
    grupo = grupo.lower()

    if sufixo in ["D", "DB"]:
        if "passivo" in grupo or "patrimônio" in grupo:
            negativo = True
    elif sufixo in ["C", "CR"]:
        if "ativo" in grupo:
            negativo = True

    resultado = -valor if negativo else valor

    # 🆕 Multiplica por 1000 se estiver em milhares
    if valores_em_milhares:
        resultado *= 1000

    return resultado

def primeiro_e_ultimo_mes_do_periodo_str(periodo_str: str) -> date | None:
        """
        Extrai o primeiro e o último mm/aaaa do período.
        Casos:
        - '01/2024 a 12/2024'  -> (01/2024, 12/2024)
        - '01/2024-03/2025'    -> (01/2024, 03/2025)
        - '2024'               -> (01/2024, 12/2024)
        - '03/2025'            -> (03/2025, 03/2025)
        """
        s = (periodo_str or "").strip()
        if not s:
            return None, None

        # apenas ano
        m_ano = re.fullmatch(r"(\d{4})", s)
        if m_ano:
            try:
                ano = int(m_ano.group(1))
                return date(ano, 1, 1), date(ano, 12, 1)
            except Exception:
                return None, None

        # captura todos mm/aaaa; pega o primeiro e o último
        pares = re.findall(r"(\d{2})/(\d{4})", s)
        if pares:
            try:
                mm1, aa1 = map(int, pares[0])
                mm2, aa2 = map(int, pares[-1])
                return date(aa1, mm1, 1), date(aa2, mm2, 1)
            except Exception:
                return None, None

        return None, None
    