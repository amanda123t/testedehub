from typing import Any, Dict, List, Optional
from app.utils.APIs.api_receita import Receita
from app.utils.APIs.api_crc import CRC
from app.utils.helpers import normalize, similar
from app.utils.logger import LoggerManager
from app.utils import format_br
import re, unicodedata


class Apis:
    """
    Classe intermediária entre os validadores e as APIs externas (Receita e CRC).
    Agora sem cache manual — o cache é global dentro de cada módulo (api_receita/api_crc).
    """

    def __init__(self):
        self.log = LoggerManager(__name__)
        self.cnpjs_consultados: List[str] = []
        self.contadores_consultados: List[str] = []
    
    # -------------------------------------------------------------------------
    # CRC / CFC
    # -------------------------------------------------------------------------
    def buscar_dados_crc(self, contador: dict) -> Optional[Dict[str, Any]]:
        """Consulta o CRC no CFC (usa cache global automático)."""
        try:
            cpf_raw = format_br.digits(contador.get("cpf") or contador.get("CPF") or "")
            nome_raw = normalize(contador.get("nome") or contador.get("Nome") or "")
            cache_key = cpf_raw or nome_raw

            self.log.debug(f"Consultando CRC para: {cache_key}")
            resp = CRC().get_situacao_contador(contador)
            if not resp:
                self.log.warning(f"⚠ Nenhum dado retornado do CRC para {cache_key}")
            self.contadores_consultados.append({cache_key: resp})
            return resp

        except Exception as e:
            self.log.error(f"⚠ Erro ao consultar CRC: {e}")
            return None

    # -------------------------------------------------------------------------
    # RECEITA FEDERAL
    # -------------------------------------------------------------------------
    def buscar_dados_receita(self, cnpj: str) -> Optional[Dict[str, Any]]:
        """Consulta dados do CNPJ na Receita (usa cache global automático)."""
        try:
            cnpj_digits = format_br.digits(cnpj)
            if not cnpj_digits:
                return None

            self.log.debug(f"Consultando Receita para CNPJ {cnpj_digits}...")
            dados_receita = Receita().get_cnpj(cnpj_digits)
            if not dados_receita or (isinstance(dados_receita, dict) and dados_receita.get('status') in ['ERROR', False]):
                self.log.warning(f"⚠ Nenhum dado retornado da Receita para {cnpj_digits}.")
                return None
            self.cnpjs_consultados.append({cnpj_digits: dados_receita})
            return dados_receita

        except Exception as e:
            self.log.error(f"⚠ Erro ao consultar Receita: {e}")
            return None

    def validar_situacao_cnpj(self, cnpj: str) -> list[str]:
        """Valida a situação cadastral do CNPJ na Receita."""
        cnpj = format_br.digits(cnpj) or "SEM CNPJ"
        try:
            dados = self.buscar_dados_receita(cnpj)
            if not dados:
                return ["✘ Dados do CNPJ não encontrados na Receita!"]

            situacao = (dados.get("situacao") or "").upper()
            if situacao == "ATIVA":
                return ["✔ CNPJ está ativo na Receita!"]
            elif situacao:
                return [f"✘ CNPJ está {situacao} na Receita!"]
            return ["✘ Situação do CNPJ não encontrada!"]

        except Exception as e:
            self.log.error(f"⚠ Erro ao validar situação do CNPJ: {e}")
            return ["✘ ERRO NA CONSULTA"]

    # -------------------------------------------------------------------------
    # ANÁLISE DE NOME DE ASSOCIADO / RAZÃO SOCIAL
    # -------------------------------------------------------------------------
    def _gerar_variacoes_nome(self, nome: str) -> list[str]:
        """Gera variações possíveis do nome para comparação com o Nome Empresarial."""
        partes = nome.split()
        variacoes = set()

        # Nome completo
        variacoes.add("".join(partes))

        # Iniciais ignorando palavras pequenas
        iniciais = "".join(p[0] for p in partes if len(p) > 3)
        variacoes.add(iniciais)

        # Iniciais incluindo todas as palavras
        iniciais_completas = "".join(p[0] for p in partes)
        variacoes.add(iniciais_completas)

        # Nome sem preposições
        sem_preposicoes = [p for p in partes if p.lower() not in {"de", "da", "do", "dos", "das"}]
        variacoes.add("".join(sem_preposicoes))
        variacoes.add("".join(p[0] for p in sem_preposicoes))

        # Nome abreviado até o último sobrenome
        if len(partes) > 1:
            ultimo_sobrenome = partes[-1]
            variacoes.add("".join(p[0] for p in partes[:-1]) + ultimo_sobrenome)

        return list(variacoes)

    def validar_associado_em_cnpj(self, cnpj: str, nome_associado: str) -> tuple[bool, dict | None, str]:
        """
        Verifica se o nome do associado aparece no QSA ou no Nome Empresarial.
        Retorna (ok, dados_receita, fonte).
        """
        nome_associado = (nome_associado or "").strip()
        if not nome_associado:
            return (False, None)

        dados_r = self.buscar_dados_receita(cnpj)
        if not dados_r:
            return (False, None)

        alvo_norm = normalize(nome_associado).replace(" ", "").replace(".", "")
        qsa_list = dados_r.get("qsa") or []
        nomes_qsa = []
        # --- 1) QSA ---
        for ent in qsa_list:
            n_qsa = normalize(ent.get("nome") or "").replace(" ", "").replace(".", "")
            nomes_qsa.append(n_qsa)
            if (
                alvo_norm == n_qsa
                or alvo_norm in n_qsa
                or n_qsa in alvo_norm
                or similar(alvo_norm, n_qsa) > 0.86
            ):
                self.log.debug("✔ Nome encontrado no QSA.")
                return (True, dados_r)
        if not nomes_qsa:
            # --- 2) Nome Empresarial ---
            nome_empresarial = (dados_r.get("nome") or "").strip()
            if nome_empresarial:
                ne_norm = normalize(nome_empresarial).replace(" ", "").replace(".", "")
                if (
                    alvo_norm in ne_norm
                    or ne_norm in alvo_norm
                    or similar(alvo_norm, ne_norm) > 0.70
                ):
                    self.log.debug("✔ Nome encontrado no nome empresarial.")
                    return (True, dados_r)

                for v in self._gerar_variacoes_nome(nome_associado):
                    v_norm = normalize(v).replace(".", "").replace(" ", "")
                    nome_empresa = ne_norm[:max(len(v_norm), 4)]
                    if (
                        v_norm in nome_empresa
                        or nome_empresa in v_norm
                        or similar(v_norm, nome_empresa) >= 0.80
                    ):
                        return (True, dados_r)

        return (False, dados_r)

    # -------------------------------------------------------------------------
    # PORTE DA EMPRESA
    # -------------------------------------------------------------------------
    def capturar_porte_receita(self, cnpj: str) -> str:
        """
        Retorna o porte padronizado a partir do CNPJ consultando a Receita.

        Saídas possíveis:
        - "MEI"
        - "MEI - CAMINHONEIRO"
        - "MICRO EMPRESA"
        - "EPP"
        - "DEMAIS"

        Regras especiais para MEI (mantidas):
        - A Receita muitas vezes traz "MICRO EMPRESA" para MEI.
        - Consideramos MEI se (e somente se) o porte base for MICRO e:
            (a) o Nome Empresarial contiver os 8 primeiros dígitos do CNPJ; ou
            (b) o Nome Empresarial terminar com 11 dígitos (CPF).
        """
        try:
            cnpj_digits = format_br.digits(cnpj)
            if not cnpj_digits:
                return "DEMAIS"

            dados_r = self.buscar_dados_receita(cnpj_digits)
            if not dados_r:
                return "DEMAIS"

            # --- Porte base normalizado
            porte_raw = (dados_r.get("porte") or "").strip()
            porte_norm = unicodedata.normalize("NFKD", porte_raw).encode("ASCII", "ignore").decode("ASCII").upper()
            porte_norm = porte_norm.replace("-", " ").replace("  ", " ").strip()

            if "EPP" in porte_norm or "EMPRESA DE PEQUENO PORTE" in porte_norm:
                porte_base = "EPP"
            elif "MICRO" in porte_norm or "MEI" in porte_norm:
                # algumas fontes já trazem "MEI" explícito; tratamos como base "MICRO EMPRESA"
                porte_base = "MICRO EMPRESA"
            else:
                porte_base = "DEMAIS"

            # --- Heurísticas para MEI (apenas se base == MICRO EMPRESA)
            is_mei = False
            if porte_base == "MICRO EMPRESA":
                nome_emp = (dados_r.get("nome") or dados_r.get("nome_empresarial") or "").strip()
                nome_norm = unicodedata.normalize("NFKD", nome_emp).encode("ASCII", "ignore").decode("ASCII")
                nome_upper = nome_norm.upper()
                nome_alnum = re.sub(r"[^A-Z0-9]", "", nome_upper)

                cnpj8 = cnpj_digits[:8]
                cnpj6 = cnpj_digits[:6]
                contem_cnpj8 = cnpj8 in nome_alnum
                contem_cnpj6 = cnpj6 in nome_alnum
                nome_digits = format_br.digits(nome_upper or "")
                termina_cpf_11 = bool(re.search(r"\d{11}$", nome_digits))

                if contem_cnpj8 or termina_cpf_11 or contem_cnpj6:
                    is_mei = True

            # --- Regra do MEI Caminhoneiro (apenas se MEI e nas PRINCIPAIS constar transporte/transportadora)
            if is_mei:
                principais = dados_r.get("atividade_principal") or []
                # junta os textos das principais (normalmente vem 1 item)
                txt_principais = " ".join([(p.get("text") or "") for p in principais])
                txt_norm = unicodedata.normalize("NFKD", txt_principais).encode("ASCII", "ignore").decode("ASCII").upper()

                # cobre "TRANSPORTE", "TRANSPORTES", "TRANSPORTADORA", etc. (qualquer variação que comece por TRANSPORT)
                if "TRANSPORTADORA" in txt_norm or re.search(r"\bTRANSPORT", txt_norm):
                    return "MEI - CAMINHONEIRO"
                return "MEI"

            return porte_base

        except Exception as e:
            print(f"ERRO {e}")
            self.log.debug(f"⚠ Erro em capturar_porte_receita: {e}")
            return None
    
    def validar_socios_e_contadores(self,
        socios_raw, contador_raw, cnpj: str
    ) -> tuple[list[dict], list[dict], list[dict], list[dict]]:
        """
        Normaliza e corrige as listas de sócios e contador vindas da IA.

        Retorna:
            (socios_confirmados, contadores_confirmados, socios_nao_confirmados, contadores_nao_confirmados)

        Regras:
        - CONTADOR com situação aceita no CFC (ATIVO/ATIVA/REGULAR) => CONTADOR.
        - CONTADOR sem CFC aceito, mas consta no QSA => vira SÓCIO.
        - SÓCIO que consta no QSA => SÓCIO.
        - SÓCIO que não consta no QSA, mas tem CFC ATIVO => vira CONTADOR.
        - Não consta no QSA nem no CFC => vai para NÃO CONFIRMADOS (sem duplicar).
        Prioridade: processa o CONTADOR primeiro; se a mesma pessoa aparecer nas duas listas,
        o papel encontrado primeiro prevalece.
        """

        # ------------ helpers ------------
        def _nome(d: dict) -> str:
            if not isinstance(d, dict): return ""
            return (d.get("Nome") or d.get("Nome:") or d.get("nome") or d.get("nome:") or "").strip()

        def _cpf(d: dict) -> str:
            if not isinstance(d, dict): return ""
            return format_br.digits(d.get("CPF") or d.get("CPF:") or d.get("cpf") or d.get("cpf:") or "") or ""

        def _crc(d: dict) -> str:
            if not isinstance(d, dict): return ""
            return (d.get("CRC") or d.get("CRC:") or d.get("crc") or d.get("crc:") or "").strip()

        def _ok_cfc(dados_crc) -> bool:
            if not isinstance(dados_crc, dict): return False
            regs = dados_crc.get("data")
            if not isinstance(regs, list) or not regs: return False
            aceit = {"ATIVO", "ATIVA", "REGULAR"}
            return any(str(r.get("SituacaoCadastral") or "").strip().upper() in aceit for r in regs)

        def _consta_qsa(cnpj_num: str, nome: str) -> bool:
            ok_qsa, _dados_r = self.validar_associado_em_cnpj(cnpj_num, nome or "")
            return bool(ok_qsa)

        def _key(cpf: str, nome: str) -> str:
            return cpf or (nome.upper() if nome else "")

        def _has_ident(nome: str, cpf: str, crc: str | None = None) -> bool:
            return bool((nome and nome.strip()) or (cpf and cpf.strip()) or (crc and crc.strip()))
        
        # ------------ estado ------------
        cnpj_num = format_br.digits(cnpj) if cnpj else ""

        socios_conf: list[dict] = []
        cont_conf: list[dict] = []

        seen_cpf: set[str] = set()
        seen_nome: set[str] = set()

        # mapas p/ NAO confirmados (evita duplicar e permite remover se virar confirmado depois)
        socios_nao_map: dict[str, dict] = {}
        cont_nao_map: dict[str, dict] = {}

        # ------------ 1) CONTADOR (prioridade) ------------
        if isinstance(contador_raw, dict):
            nome_c, cpf_c, crc_c = _nome(contador_raw), _cpf(contador_raw), _crc(contador_raw)
            key = _key(cpf_c, nome_c)

            if _has_ident(nome_c, cpf_c, crc_c):
                # consulta CFC só se houver algum identificador
                resp_crc = self.buscar_dados_crc(contador_raw)
                dados_crc = (resp_crc or {}).get("dados", [])
                ativo_cfc = _ok_cfc(dados_crc if isinstance(dados_crc, dict) else {})

                if ativo_cfc:
                    if key and (cpf_c not in seen_cpf) and (nome_c.upper() not in seen_nome):
                        cont_conf.append({"Nome": nome_c, "CPF": cpf_c, "CRC": crc_c})
                        if cpf_c: seen_cpf.add(cpf_c)
                        if nome_c: seen_nome.add(nome_c.upper())
                    # limpa de NAO confirmados se estava lá
                    cont_nao_map.pop(key, None); socios_nao_map.pop(key, None)
                else:
                    # sem CFC aceito -> tenta QSA como SÓCIO
                    if nome_c and _consta_qsa(cnpj_num, nome_c):
                        if key and (cpf_c not in seen_cpf) and (nome_c.upper() not in seen_nome):
                            socios_conf.append({"Nome": nome_c, "CPF": cpf_c})
                            if cpf_c: seen_cpf.add(cpf_c)
                            if nome_c: seen_nome.add(nome_c.upper())
                        cont_nao_map.pop(key, None); socios_nao_map.pop(key, None)
                    else:
                        # não confirmado (só adiciona se não existe em nenhum NAO-map)
                        if key and (key not in cont_nao_map) and (key not in socios_nao_map) \
                        and (cpf_c not in seen_cpf) and (nome_c.upper() not in seen_nome):
                            cont_nao_map[key] = {"Nome": nome_c, "CPF": cpf_c, "CRC": crc_c}
            # else: sem identificador útil -> ignora silenciosamente

        # ------------ 2) SÓCIOS ------------
        if isinstance(socios_raw, list):
            for socio in socios_raw:
                if not isinstance(socio, dict): 
                    continue

                nome_s, cpf_s = _nome(socio), _cpf(socio)
                key = _key(cpf_s, nome_s)

                # se já confirmado pelo passo do contador (dedupe), pula
                if (cpf_s and cpf_s in seen_cpf) or (nome_s and nome_s.upper() in seen_nome):
                    continue

                # 2.1) tenta QSA (como SÓCIO)
                if nome_s and _consta_qsa(cnpj_num, nome_s):
                    if key and (cpf_s not in seen_cpf) and (nome_s.upper() not in seen_nome):
                        socios_conf.append({"Nome": nome_s, "CPF": cpf_s})
                        if cpf_s: seen_cpf.add(cpf_s)
                        if nome_s: seen_nome.add(nome_s.upper())
                    socios_nao_map.pop(key, None); cont_nao_map.pop(key, None)
                    continue

                # 2.2) tenta CFC (como CONTADOR) — só se houver identificador
                if _has_ident(nome_s, cpf_s):
                    resp_crc_s = self.buscar_dados_crc({"Nome": nome_s, "CPF": cpf_s})
                    dados_crc_s = (resp_crc_s or {}).get("dados") if isinstance(resp_crc_s, dict) else None
                    if _ok_cfc(dados_crc_s if isinstance(dados_crc_s, dict) else {}):
                        if key and (cpf_s not in seen_cpf) and (nome_s.upper() not in seen_nome):
                            cont_conf.append({"Nome": nome_s, "CPF": cpf_s, "CRC": _crc(socio)})
                            if cpf_s: seen_cpf.add(cpf_s)
                            if nome_s: seen_nome.add(nome_s.upper())
                        socios_nao_map.pop(key, None); cont_nao_map.pop(key, None)
                        continue

                # 2.3) não confirmado (evita duplicar entre as duas listas de NAO)
                if key and (key not in socios_nao_map) and (key not in cont_nao_map) \
                and (cpf_s not in seen_cpf) and (nome_s.upper() not in seen_nome):
                    socios_nao_map[key] = {"Nome": nome_s, "CPF": cpf_s}

        # ------------ retorno ------------
        return socios_conf, cont_conf, list(socios_nao_map.values()), list(cont_nao_map.values())
