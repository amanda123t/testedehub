import re
import fitz
import statistics
from app.utils.helpers import normalize_no_space

from functools import lru_cache

@lru_cache(None)
def normalize_cached(s: str):
    return normalize_no_space(s)

def _looks_value(s: str) -> bool:
    VAL_RE = re.compile(r'^(R\$)?\s*[\(\-]?\s*\d{1,3}(\.\d{3})*,\d{2}\s*(DB|CR)?\s*\)?$')
    return bool(VAL_RE.match(s.strip()))

def _join_tokens(tokens):
    # Junta tokens com espaço simples, preservando ordem visual
    return " ".join(t for t in tokens if t and t.strip())

VAL_ONLY = re.compile(r'^[\(\)0-9\.\, \-]+$')  # ex.: "0,00", "(242.716,57)"

def filter_out_dre_items(items):
    # (opcional) filtro pós-itens
    BAD_NORMS = []  

    out = []
    for it in items:
        nome = (it.get("Nome","") or "").strip()
        nome_norm = normalize_cached(nome)
        if not nome or VAL_ONLY.match(nome):
            continue
        if any(b in nome_norm for b in BAD_NORMS):
            continue
        out.append(it)
    return out

# EXTRAIR TABELAS DO PDF
def extract_balance_items_two_columns(pdf_path: str, y_tol: float = 2.5):
    # termos que disparam o corte (sem espaços)
    DRE_KEYS = [
        #"DEMONSTRAÇÃODORESULTADODOEXERCÍCIO","DEMONSTRACAODORESULTADODOEXERCICIO",
        "DEMONSTRAÇÃODERESULTADOS","DEMONSTRACAODERESULTADOS",
        "DEMONSTRATIVODERESULTADOS","DEMONSTRATIVODORESULTADO",
        "RENDAOPERACIONALBRUTA","RECEITAOPERACIONALBRUTA","RECEITABRUTA"
    ]
    DRE_KEYS_NORM = [normalize_cached(k) for k in DRE_KEYS]

    doc = fitz.open(pdf_path)
    items = []
    found_stop_in_this_page = False
    for page in doc:
        # === 1) palavras (com bbox) e linhas visuais
        words = page.get_text("words", sort=True)
        if not words:
            continue

        lines = []
        current = []
        last_y = None
        for (x0, y0, x1, y1, txt, *_rest) in words:
            if not txt.strip():
                continue
            if last_y is None or abs(y0 - last_y) <= y_tol:
                current.append({"x0": x0, "x1": x1, "y0": y0, "txt": txt})
                last_y = y0 if last_y is None else (last_y + y0) / 2.0
            else:
                lines.append(current)
                current = [{"x0": x0, "x1": x1, "y0": y0, "txt": txt}]
                last_y = y0
        if current:
            lines.append(current)

        # === 2) detecta início do DRE (mesmo se vier E S P A Ç A D O)
        dre_y_start = None
        for ln in lines:
            tokens_norm = [normalize_cached(t["txt"]) for t in ln]
            joined_norm = "".join(tokens_norm)
            if any(key in joined_norm for key in DRE_KEYS_NORM):
                dre_y_start = sum(t["y0"] for t in ln) / len(ln)
                found_stop_in_this_page = True
                break
        # se achou DRE nesta página, já finaliza aqui (não lê as próximas páginas)
        if found_stop_in_this_page:
            break            
        # === 3) corta as linhas abaixo do DRE, se encontrado
        if dre_y_start is not None:
            lines = [ln for ln in lines if (sum(t["y0"] for t in ln) / len(ln)) < dre_y_start]
            if not lines:
                # nada antes do DRE nesta página
                # como achamos DRE, não devemos processar páginas seguintes
                break

        # === 4) calcula gutter com base nos valores (acima do DRE)
        value_centers = []
        for ln in lines:
            for t in ln:
                if _looks_value(t["txt"]):
                    cx = (t["x0"] + t["x1"]) / 2.0
                    value_centers.append(cx)
        if value_centers:
            if len(value_centers) >= 6:
                gutter_x = sum(value_centers[:6]) / 6
            else:
                gutter_x = sum(value_centers) / len(value_centers)

        # === 5) extrai pares por linha (esq=Ativo / dir=Passivo)
        i = 0
        while i < len(lines):
            ln_sorted = lines[i]  # já está ordenado se words estiver ordenado

            left_tokens, right_tokens = [], []
            if gutter_x is None:
                left_tokens = [t["txt"] for t in ln_sorted]
            else:
                for t in ln_sorted:
                    ((left_tokens if ((t["x0"] + t["x1"]) / 2.0) <= gutter_x else right_tokens)
                    .append(t["txt"]))

            def _emit_from_side(tokens, tipo_label: str):
                if not tokens:
                    return None, False
                # mesma linha
                value_idx = None
                for idx in reversed(range(len(tokens))):
                    if _looks_value(tokens[idx]):
                        value_idx = idx
                        break
                if value_idx is not None:
                    nome = _join_tokens(tokens[:value_idx]).strip()
                    val  = tokens[value_idx].strip()
                    if nome and val:
                        if "," in val and not val.startswith("R$"):
                            val = f"R$ {val}"
                        return {"Nome": nome, "Valor:": val, "Tipo": tipo_label}, False
                # próxima linha (valor sozinho)
                if i + 1 < len(lines):
                    nxt_sorted = sorted(lines[i+1], key=lambda t: t["x0"])
                    nxt_side = []
                    if gutter_x is None:
                        nxt_side = [t["txt"] for t in nxt_sorted]
                    else:
                        for t in nxt_sorted:
                            ((nxt_side if ((t["x0"] + t["x1"]) / 2.0) <= gutter_x else nxt_side)
                            .append(t["txt"]))
                    if len(nxt_side) == 1 and _looks_value(nxt_side[0]):
                        nome = _join_tokens(tokens).strip()
                        val  = nxt_side[0].strip()
                        if nome and val:
                            if "," in val and not val.startswith("R$"):
                                val = f"R$ {val}"
                            return {"Nome": nome, "Valor:": val, "Tipo": tipo_label}, True
                return None, False

            left_item, use_next_l = _emit_from_side(left_tokens, "Ativo")
            if left_item: items.append(left_item)

            right_item, use_next_r = _emit_from_side(right_tokens, "Passivo")
            if right_item: items.append(right_item)

            i += 2 if (use_next_l or use_next_r) else 1

    # === 6) filtro pós-itens (qualquer sobra de DRE)
    items = filter_out_dre_items(items)

    # normalização final R$
    for it in items:
        v = it.get("Valor:", "").strip()
        if v and "," in v and not v.startswith("R$"):
            it["Valor:"] = f"R$ {v}"
    return items

def _nome_de_balanco(dados: dict) -> str:
    """
    Mesma heurística do fluxo antigo para descobrir o nome em Balanço.
    """
    try:
        nome = dados.get("Nome:") or dados.get("Nome") or dados.get("nome:") or dados.get("nome")
        if nome:
            return nome
    except Exception:
        pass
    balancos = dados.get("Balanços") or dados.get("Balancos") or {}
    if isinstance(balancos, dict) and balancos:
        _, bloco = next(iter(balancos.items()))
        return bloco.get("Nome:") or bloco.get("Nome") or "DESCONHECIDO"
    if isinstance(balancos, list) and balancos and isinstance(balancos[0], dict):
        return balancos[0].get("Nome:") or balancos[0].get("Nome") or "DESCONHECIDO"
    return "DESCONHECIDO"

def extrair_dados_principais_balanco(dados:dict) -> str:
    balancos = dados.get("Balanços") or dados.get("Balancos") or {}
    if isinstance(balancos, dict) and balancos:
        _, bloco = next(iter(balancos.items()))
    if isinstance(balancos, list) and balancos and isinstance(balancos[0], dict):
        bloco = balancos[0]
    nome = _nome_de_balanco(dados)
    cnpj = dados.get("CNPJ") or dados.get("CNPJ:") or dados.get("cnpj:") or dados.get("cnpj") or ""
    contador = dados.get("Contador:") or dados.get("Contador") or dados.get("contador:") or dados.get("contador") or {}
    socios = dados.get("Sócios:") or dados.get("Sócios") or dados.get("sócios:") or dados.get("sócios") or dados.get("socios") or dados.get("socios:") or []
    data_encerramento = bloco.get("Data de Referência:") or bloco.get("Data de Referência")
    texto_dados_principais = f'---- DADOS PRINCIPAIS ------ \n NOME DA EMPRESA: {nome}, \n CNPJ: {cnpj} \n DATA DE ENCERRAMENTO: {data_encerramento}\n CONTADOR: {contador} \n SÓCIOS: {socios}\n ---------------------------\n'
    return texto_dados_principais
