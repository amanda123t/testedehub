from typing import Dict, Any
from app.validators.base import ValidadorBase
from app.utils.helpers import normalize
from app.validators.registro import registrar_validador  
from app.validators.helpers.pj import identificar_subtitulos_por_hierarquia, interpretar_valor_bruto
from decimal import Decimal
import json
from collections import defaultdict
from difflib import SequenceMatcher
import re, os
from pathlib import Path
from app.utils.APIs.api_crc import CRC

PROJECT_ROOT = Path(__file__).resolve().parents[3]  
OUT_DIR = PROJECT_ROOT / "output"
OUT_DIR.mkdir(parents=True, exist_ok=True)

@registrar_validador("balanço", "balanco", "balanco patrimonial", "balanço patrimonial", "bp")
class ValidadorBalanco(ValidadorBase):
    def validar(self) -> bool:
        self.log.info("Iniciando validação do balanço...")
        self.nomes_patrimonio = ['passivopatrimonio', 'totalpatrimonioliquido', 'totalpatrimonio', 'patrimonio', 'patrimonioliquido', 'patrimoniosocial', '(-)patrimonio', '(-)patrimonioliquido', '(-)patrimoniosocial']
        self.nomes_nao_circulantes = ["naocirculante", "exigivelalprazo", "exigivelacprazo", "nao-circulante", "realizavelalongoprazo", "permanente", "exigivelalongoprazo"]
        self.nomes_circulante = ["circulante", "curtoprazo", "realizavelacurtoprazo"]
        self.nomes_titulos_ignorados = ['ativo', 'ativo-mp449/2008', 'passivoepatrimonioliquido', 'passivo+patrimonio', 'passivo+patrimoniosocial', 'passivo+patrimonioliquido', 'ativototal', 'passivo', 'passivo-mp449/2008', 'passivo', 'passivototal', 'totaldoativo', 'totaldopassivo', 'totaldopassivoepatrimonioliquido', 'totaldopassivoedopatrimonioliquido', 'totaldopassivo+patrimonioliquido', 'totaldopassivo+patrimonio', 'totalpassivo', 'totalgeraldopassivo', 'totalgeraldoativo', 'totalgeral', 'totalgeraldopatrimonioliquido', 'totalativo', 'valortotaldoativo', 'valortotaldopassivo', 'total']

        self.nomes_ativo_circulante = ['totalativocirculante', 'totalativo-circulante', 'ativocirculante', 'ativo-circulante', 'ativocurto', 'ativorealizavelacurtoprazo']
        self.nomes_ativo_nao_circulante = ['totalativonaocirculante', 'totalativonao-circulante', 'ativorealizavelalongoprazo', 'ativonaocirculante','ativonaocirculante(2)', 'ativo-nao-circulante', 'ativopermanente']
        self.nomes_passivo_circulante = ['totalpassivocirculante', 'totalpassivo-circulante', 'passivocirculante', 'passivo-circulante', 'passivoexigivelacurtoprazo', 'exigivelacurtoprazo', 'obrigacoesacurtoprazo']
        self.nomes_passivo_nao_circulante = ['totalpassivonaocirculante', 'totalpassivonao-circulante', 'passivonaocirculante', 'passivo-nao-circulante', 'passivoexigivelalprazo', 'exigivelalprazo', 'exigivelalongoprazo', 'passivorealizavelalongoprazo', 'passivorealizaveldelongoprazo', 'exigiveldelongoprazo']

        self.campos_conhecidos_balanco_ativo = [
            "obrigacoes", "obrigaçoes", "despesas", "despesas pagas antecipadamente", "despesas antecipadas", "outros créditos", "provisões","provisao",
            "transferencias", "adiantamentos", "adiantamento", "encargos", "estoque","estoques", 'imposto', 'investimentos', 'outros creditos',"amortizacao",  
            "disponível", "imobilizado", "caixa", "ativo", "intangivel", "contas a pagar", "debitos", "contratos", "credores", "credores diversos", 
            "contas projetos", "provisoes", "circulante", "nao circulante", "permanente", "curto prazo", "longo prazo", "ativo"
        ]
        self.campos_conhecidos_balanco_passivo = [
            "fornecedores", "patrimonio liquido", "capital subscrito", "obrigacoes", "obrigaçoes", "despesas", "despesas pagas antecipadamente", "despesas antecipadas",
            "empréstimos", "outros passivos", "provisões","provisao", "lucros acumulados","prejuizos acumulados", "lucros ou prejuizos acumulados", "transferencias", 
            "demais obrigacoes","impostos", "salarios", "pro-labore", "tributos e impostos", "tributos", "passivo", "patrimonio",
            "financiamentos", "empréstimos e financiamentos", "encargos", 'imposto', "amortizacao", "contas a pagar", "debitos", "trabalhistas", "contratos",
            "credores", "credores diversos", "contas projetos", "provisoes", "circulante", "nao circulante", "patrimonio", "curto prazo", "longo prazo", "passivo"
        ]
        self.campos_sem_subtitulos_passivo = ['fornecedores', 'duplicatas']
        self.campos_sem_subtitulos_ativo = ['imobilizado', 'estoques', 'intangivel', 'clientes', 'duplicatas']

        self.campos_ativo_circulante = {"Caixa e Bancos": 5,"Aplicações Financeiras": 6,"Clientes": 9,"Duplicatas Descontadas": 10,"Provisão para Dev. Duvidosos": 11,"Impostos a Recuperar": 13,"Adiantamentos a Fornecedores": 14,"Despesas Antecipadas": 15,"Títulos e Valores mobiliários": 16,"Outros créditos": 17,"Estoques de Matéria-Prima": 19,"Empréstimos a ligadas de curto prazo": 24}
        self.campos_ativo_nao_circulante = {"Clientes": 27,"Provisão para Dev. Duvidosos": 28,"Investimentos no ARLP": 29,"Adiantamento a fornec. de longo prazo": 30,"Empréstimos a ligadas de longo prazo": 32,"Outros ativos realizáveis a longo prazo": 33,"Participações em Interligadas/controladas": 36,"Outros participações/Investimentos no AP": 37,"Provisão para Perdas": 38,"Bens Imóveis": 40,"Bens Móveis": 41,"Deprec./Amortização Acum.": 42,"Outros ativos permanentes": 43,"Diferido": 45,"Amortização Acumulada": 46}
        self.campos_passivo_circulante = {"Empréstimos e Financiamentos de curto prazo": 51,"Dividendos e Participações a pagar": 52,"Provisões para Impostos": 53,"Debêntures de curto prazo": 54,"Fornecedores": 57,"Dívidas com Interligadas de curto prazo": 58,"Salários e Encargos": 59,"Tributos e Impostos": 60,"Adiantamentos de Clientes": 61,"Provisões para contingências de curto prazo": 62,"Outros passivos circulantes": 63}
        self.campos_passivo_nao_circulante = {"Empréstimos e Financiamentos de longo prazo": 65,"Impostos parcelados de longo prazo": 66,"Fornecedores": 67,"Debêntures de longo prazo": 68,"Dívidas com ligadas de longo prazo": 69,"Provisões para contingências de longo prazo": 70,"Outros passivos de longo prazo": 71,"Resultado de ex. futuros": 73,"Participações de minoritários": 74}
        self.campos_patrimonio_liquido = {"Capital Subscrito": 77,"Capital a Integralizar": 78,"Reservas de Capital": 80,"Reservas de Reavaliação": 81,"Reservas de Lucros (Sobras)": 82,"Outras reservas": 83,"Lucros Acumulados": 85,"Prejuízos Acumulados": 86}
        self.mapeamento_ativo_circ = {"bancos": ("Caixa e Bancos", 5),"banco": ("Caixa e Bancos", 5),"caixa": ("Caixa e Bancos", 5), "bancos conta movimento": ("Caixa e Bancos", 5),"duplicatas a receber": ("Clientes", 9),"contas a receber do AC": ("Clientes", 9),"contas a receber": ("Clientes", 9),"tributos a recuperar": ("Impostos a Recuperar", 13),"estoque": ("Estoques de Matéria-Prima", 19)}
        self.mapeamento_ativo_ncirc = {"intangivel": ("Outros ativos permanentes", 43), "imobilizado em andamento": ("Outros ativos permanentes", 43), "investimentos":("Investimentos no ARLP", 29),"intangível":("Outros ativos permanentes", 43),"software":("Outros ativos permanentes", 43),"depreciações":("Deprec./Amortização Acum.", 42),"veículos": ("Bens Móveis", 41),"máquinas": ("Bens Móveis", 41),"equipamentos": ("Bens Móveis", 41),"ferramentas": ("Bens Móveis", 41),"depreciação acumulada": ("Deprec./Amortização Acum.", 42),"moveis": ("Bens Móveis", 41),"moveis e utensilios": ("Bens Móveis", 41)}
        self.mapeamento_passivo_circ = { "obrigações tributárias": ("Tributos e Impostos", 60),"parcelamentos tributários": ("Tributos e Impostos", 60),"obrigações fiscais": ("Tributos e Impostos", 60), "obrigações trabalhista e previdenciária": ("Salários e Encargos", 59),"obrigações trabalhistas": ("Salários e Encargos", 59),"obrigações com o pessoal": ("Salários e Encargos", 59),"obrigações sociais": ("Salários e Encargos", 59), "outras obrigações": ("Outros passivos circulantes", 63)}
        self.mapeamento_passivo_ncirc = {"obrigações tributárias": ("Impostos parcelados de longo prazo", 66), "parcelamento": ("Impostos parcelados de longo prazo", 66)}
        self.mapeamento_pl = {"capital social": ("Capital Subscrito", 77)}
        self.balanco_resumido = self.to_bool(self.comprovantes.balanco_resumido) is True
        self.log.debug(f"Balanço resumido nas regras: {self.comprovantes.balanco_resumido}")
        self.log.debug(f"Balanço resumido?: {self.balanco_resumido}")
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de Balanço encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.context = " ".join(self.context) if isinstance(self.context, list) else self.context
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_balanco_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )
    
    def validar_balanco_individual(self):
        self.valores_em_milhares = any(keyword in normalize(self.context) for keyword in ['valores em milhares', 'x1000', 'valores em milhares de reais', 'em milhares de reais', 'valor em milhares', 'valores em milhares'])

        self.campos_sem_grupo = []
        houve_erro_em_algum_ano = False  # <- fora do loop

        if "Balanços" in self.doc:
            dados_por_ano = self.doc["Balanços"]
        else:
            dados_por_ano = {"Único": self.doc}  # mantém compatibilidade com IA antiga

        self.nome_documento = (self.extrair_nome_documento(self.doc) or '').upper()
        self.cnpj = self.extrair_valor(self.doc, False, "CNPJ:", "CNPJ", "cnpj:", "cnpj") or "SEM CNPJ"
        self.data_referencia = self.extrair_valor(dados_por_ano, False, "Data de Referência:", "Data de Referência", "Data de referência:", "Data de referência")
        
        socios_raw = self.extrair_valor(self.doc, False, "Sócios:", "Sócios", "socios:", "socios") or []
        contador_raw = self.extrair_valor(self.doc, False, "Contador:", "Contador", "contador:", "contador") or {}
        self.log.debug(f"Sócios extraídos: {socios_raw}")
        self.log.debug(f"Contador extraído: {contador_raw}")

        socios_ok, contadores_ok, socios_nao_confirmados, contadores_nao_confirmados = self.apis.validar_socios_e_contadores(socios_raw, contador_raw, self.cnpj)
        self.log.debug("Ajustando a lista de sócios e contadores...")
        self.log.debug(f"Sócios confirmados: {socios_ok}")
        self.log.debug(f"Contadores confirmados: {contadores_ok}")
        if socios_nao_confirmados:
            self.log.warning(f"⚠️ Sócios não confirmados: {socios_nao_confirmados}")
        if contadores_nao_confirmados:
            self.log.warning(f"⚠️ Contadores não confirmados: {contadores_nao_confirmados}")
    
            # Atualiza os dados originais com os sócios e contadores confirmados
        self.doc["Sócios:"] = socios_ok
        self.doc["Contador:"] = (contadores_ok[0] if contadores_ok else {}) 
        socios_ok = self.doc.get("Sócios:") or self.doc.get("Socios:") or []
        contador_dict = self.doc.get("Contador:") or {}
        contadores_ok = [contador_dict] if contador_dict else []

        contador = self.extrair_valor(self.doc, False, "Contador:", "Contador", "contador:", "contador") or {}
        self.contador = str(self.extrair_valor(contador, False, "Nome:", "Nome", "nome:", "nome") or "")
        self.crc_contador = self.extrair_valor(contador, False, "CRC:", "CRC", "crc:", "crc") or ""      
        
        
        output_data = [["Documento lido:", self.file]]
        output_data.append(["Nome:", self.nome_documento.upper()])
        output_data.append(["CNPJ:", self.cnpj])
        output_data.append(["Data de Referência:", self.data_referencia])
        dados_mua_geral = {
            "CNPJ": self.cnpj, 
            "Nome_Empresa": self.nome_documento.upper(),
            "Anos": {}
        }

        self.data_base = self.doc
        anos = []
        for ano, dados_ano in dados_por_ano.items():
            self.log.debug(f"\n📅 Iniciando validação do balanço para o ano {ano}...\n")
            self.doc = dados_ano  # <- redefine os dados para este ano
            self.ano_atual = ano
            # guarda só “YYYY”
            if re.fullmatch(r"\d{4}", str(ano)):
                anos.append(str(ano))
            output_data_ano = []
            output_data_ano.append([])
            output_data_ano.append(["-" * 70, ""])  # linha separadora
            output_data_ano.append([f"-> BALANÇO {self.ano_atual}:", ""])

            #Captura os totais e exibe
            ativo_total_doc,passivo_total_doc, patrimonio_total_doc = self.get_totais()
                
            output_data_ano.append(["Ativo Total:", self.format_br.formatar_moeda_br(ativo_total_doc)])
            output_data_ano.append(["Passivo Total:", self.format_br.formatar_moeda_br(passivo_total_doc)])
            output_data_ano.append(["Patrimônio Líquido:", self.format_br.formatar_moeda_br(patrimonio_total_doc)])
            output_data_ano.append([])

            totais_por_campo = {}
            primeira_tentativa = True
            output_final, totais_final, erro_balanco_final, msgs_erro_balanco_final = [],[],[],[]
            for i in range(2):
                try:
                    # Primeira tentativa SEM remover subtítulos
                    output_data_ano, totais_por_campo, erro_balanco, msgs_erro_balanco = self.__validate_balanco(
                        output_data_ano, {}, 
                        retirar_subtitulos_desnecessarios=False,
                        # 👇 passa os totais do doc pra somar dentro
                        ativo_total_doc=ativo_total_doc,
                        passivo_total_doc=passivo_total_doc,
                        patrimonio_total_doc=patrimonio_total_doc
                    )

                    # Se der erro, tenta novamente com a flag ativada
                    if erro_balanco:
                        self.log.debug("⚠️ Tentando nova validação com remoção de subtítulos desnecessários...")
                        if primeira_tentativa:
                            output_final, totais_final, erro_balanco_final, msgs_erro_balanco_final = output_data_ano, totais_por_campo, erro_balanco, msgs_erro_balanco
                            primeira_tentativa = False
                        output_data_ano = [["-" * 70, ""],
                                    [f"-> BALANÇO {ano}:", ""],       
                                    ["Ativo Total:", self.format_br.formatar_valor(ativo_total_doc)],
                                    ["Passivo Total:", self.format_br.formatar_valor(passivo_total_doc)],
                                    ["Patrimônio Líquido:", self.format_br.formatar_valor(patrimonio_total_doc)],
                                    []]

                        output_data_ano, totais_por_campo, erro_balanco, msgs_erro_balanco = self.__validate_balanco(
                            output_data_ano, {}, 
                            retirar_subtitulos_desnecessarios=True,
                            ativo_total_doc=ativo_total_doc,
                            passivo_total_doc=passivo_total_doc,
                            patrimonio_total_doc=patrimonio_total_doc
                        )
                        if erro_balanco:
                            if primeira_tentativa:
                                self.log.debug("Iniciando extração dos valores manualmente!")
                                resultado = self.extrair_campos_e_valores(self.context.replace("*", "").replace("#", ""))
                                self.log.debug("🔍 Campos e valores extraídos manualmente!")
                                #self.log.debug(resultado)
                                # 6. Substitui os dados da IA para a nova lista
                                data = self.substituir_componentes_por_lista_nova(self.data_base, resultado) # NOVO DATA COM OS COMPONENTES AJUSTADOS!!
                                self.log.debug("🔍 Novo data ajustado:")
                                self.log.debug(data)
                                output_data_ano = [["-" * 70, ""],
                                    [f"-> BALANÇO {ano}:", ""],       
                                    ["Ativo Total:", self.format_br.formatar_valor(ativo_total_doc)],
                                    ["Passivo Total:", self.format_br.formatar_valor(passivo_total_doc)],
                                    ["Patrimônio Líquido:", self.format_br.formatar_valor(patrimonio_total_doc)],
                                    []]
                                for ano_b in data["Balanços"]:
                                    if str(ano_b) == str(self.ano_atual):
                                        self.doc = data["Balanços"][ano_b]
                                        break
                                else:
                                    self.log.debug(f"Erro ao capturar os componentes do ano: {self.ano_atual}, encerrando...")
                                    output_data_ano, totais_por_campo, erro_balanco, msgs_erro_balanco = output_final, totais_final, erro_balanco_final, msgs_erro_balanco_final
                                    houve_erro_em_algum_ano = True
                                    break
                            else:
                                output_data_ano, totais_por_campo, erro_balanco, msgs_erro_balanco = output_final, totais_final, erro_balanco_final, msgs_erro_balanco_final
                                houve_erro_em_algum_ano = True
                                break
                        else:
                            self.log.info("✅ Validação bem-sucedida após remover subtítulos desnecessários.")
                            break
                    else:
                        self.log.info("✅ Validação bem-sucedida na primeira tentativa.")
                        break
                except Exception as e:
                    self.log.error(f"✘ Erro durante validação: {e}")
                    output_data_ano.append(["✘ Erro durante validação:", str(e)])
                    erro_balanco, msgs_erro_balanco = True, []
                    

            # --- REGISTRO NO PDF ---
            if erro_balanco:
                output_data_ano.append([])
                output_data_ano.append(["✘ ERRO NA VALIDAÇÃO DO BALANÇO"])
                for msg in msgs_erro_balanco:
                    output_data_ano.append([msg])
                self.log.error("✘ ERRO NA VALIDAÇÃO DO BALANÇO REGISTRADO NO PDF.")

            output_data_ano.append([])
            output_data_ano.append(["CAMPOS PARA LANÇAMENTO NO MUA:", ""])
            for (campo, codigo), valor in sorted(totais_por_campo.items(), key=lambda x: x[0][1]):
                valor_formatado = self.format_br.formatar_valor(valor)
                output_data_ano.append([f"{campo}:", valor_formatado])

            # Preencher dados gerais se ainda não estiverem definidos
            if not dados_mua_geral["CNPJ"]:
                dados_mua_geral["CNPJ"] = self.doc.get("CNPJ:", "").strip()
            if not dados_mua_geral["Nome_Empresa"]:
                dados_mua_geral["Nome_Empresa"] = self.nome_documento.strip()

            # Adiciona os dados deste ano
            dados_mua_geral["Anos"][str(self.ano_atual)] = {
                "Ano:": self.ano_atual,
                "Campos_Lancamento": [
                    {
                        "Campo_Sistema": codigo,
                        "Campo_Nome": campo,
                        "Valor": self.format_br.formatar_valor(valor)
                    }
                    for (campo, codigo), valor in sorted(totais_por_campo.items(), key=lambda x: x[0][1])
                ]
            }

            output_data_ano.append([])
            output_data.extend(output_data_ano)

            self.log.info("VALIDAÇÃO DO BALANÇO FINALIZADA!")
         #
        safe_name = re.sub(r'[^\w\-]', '_', self.file.replace(".pdf", ""))
        caminho_json = os.path.join(OUT_DIR, f'dados_mua_{safe_name}.json')
        with open(caminho_json, 'w', encoding='utf-8') as f:
            json.dump(dados_mua_geral, f, ensure_ascii=False, indent=2)

        self.output_json_path = caminho_json
        
        contadores_totais = contadores_ok + contadores_nao_confirmados
        socios_totais = socios_ok + socios_nao_confirmados
        if contadores_totais:
            output_data.append(["Contador:"])
            for contador_item in contadores_totais:
                for item in contador_item:
                    if contador_item[item]:
                        output_data.append([item, contador_item[item]])

        if socios_totais:
            output_data.append(["Sócios:"])
            for socio in socios_totais:
                for item in socio:
                    if socio[item]:
                        output_data.append([item, socio[item]])

        #------------ VALIDAÇÕES RECEITA FEDERAL -------------:
        validar_situacao_receita = getattr(getattr(self, "comprovantes", None), "validar_situacao_do_cnpj_balanco", True)
        validar_situacao_receita = self.to_bool(validar_situacao_receita) is not False
        if validar_situacao_receita:
            if self.validar_cnpj(self.cnpj) is True:
                output_data.append(self.apis.validar_situacao_cnpj(self.cnpj))
            else:
                output_data.append(["✘ CNPJ inválido ou não encontrado no documento"])

        # ------------ VALIDAÇÃO ASSINATURAS DO DOCUMENTO (pós-validar_socios_e_contadores) -------------
        validar_assinaturas = getattr(getattr(self, "comprovantes", None), "validar_assinaturas_balanco", True)
        validar_assinaturas = self.to_bool(validar_assinaturas) is not False
        self.log.debug(f"context recebido: {self.context}")
        if validar_assinaturas:
            eh_balanco_speed = any(keyword in normalize(self.context) for keyword in ['sistema publico de escrituracao digital', 'este relatorio foi gerado pelo sistema publico', 'este documento e parte integrante de escrituracao', 'cuja autenticacao se comprova pelo recibo de numero', 'digital – sped', 'numero de ordem do livro'])
            if eh_balanco_speed:
                output_data.append([f"✔ Documento não possui assinaturas, foi emitido pelo Sistema Público de Escrituração Digital – Sped."])
            else:
                try:
                    tem_representante = bool(socios_ok)
                    tem_contador = bool(contadores_ok)

                    if tem_representante and tem_contador:
                        # mensagem principal
                        nome_rep = ((socios_ok[0].get("Nome") or socios_ok[0].get("Nome:") or "").strip())
                        nome_cont = ((contadores_ok[0].get("Nome") or contadores_ok[0].get("Nome:") or "").strip())
                        output_data.append([f"✔ Documento assinado pelo representante {nome_rep.split(' ')[0]} e pelo contador {nome_cont.split(' ')[0]}."])

                        # detalhes de QSA: para cada sócio
                        for s in socios_ok:
                            ns = (s.get("Nome") or s.get("Nome:") or "").strip()
                            output_data.append([f"✔ Sócio '{ns}' consta no QSA da empresa."])

                        # detalhes de CRC: para cada contador
                        for c in contadores_ok:
                            nc = (c.get("Nome") or c.get("Nome:") or "").strip()
                            # já verificado na resolução; aqui apenas informamos
                            output_data.append([f"✔ Contador '{nc}' com CRC ativo no CFC."])

                    elif (not tem_representante) and (not tem_contador):
                        if self.validar_cnpj(self.cnpj) is False:
                            if socios_nao_confirmados and contadores_nao_confirmados:
                                output_data.append(["✘ CNPJ inválido ou não encontrado, não foi possível validar o representante no QSA da empresa e o contador que assinou o documento não foi localizado no CFC."])
                            elif socios_nao_confirmados and (not contadores_nao_confirmados):
                                output_data.append(["✘ CNPJ inválido ou não encontrado, não foi possível validar o representante no QSA da empresa e não foi encontrado a identificação do contador no documento."])
                            elif (not socios_nao_confirmados) and contadores_nao_confirmados:
                                output_data.append(["✘ Contador que assinou não consta no CFC e não foi localizada a identificação do representante no documento."])
                            else:
                                output_data.append(["✘ Não foi possível identificar o representante nem o contador no documento."])
                        else:
                            if socios_nao_confirmados and contadores_nao_confirmados:
                                output_data.append(["✘ Documento assinado pelo representante e contador porém o representante não consta no QSA e o contador não consta no CFC."])
                            elif socios_nao_confirmados and (not contadores_nao_confirmados):
                                output_data.append(["✘ Representante que assinou não consta no QSA, nem no CFC e não foi localizada a identificação do contador no documento."])
                            elif (not socios_nao_confirmados) and contadores_nao_confirmados:
                                output_data.append(["✘ Contador que assinou não consta no CFC, nem no QSA e não foi localizada a identificação do representante no documento."])
                            else:
                                output_data.append(["✘ Não foi possível identificar o representante nem o contador no documento."])

                    elif tem_contador and (not tem_representante):
                        # contador correto (CFC)
                        cont = contadores_ok[0]
                        nome_cont = (cont.get("Nome") or cont.get("Nome:") or "").strip()
                        output_data.append([f"✔ Contador '{nome_cont}' com CRC ativo no CFC."])

                        if not self.validar_cnpj(self.cnpj):
                            output_data.append(["✘ CNPJ inválido ou não encontrado, não foi possível validar o QSA da empresa."])
                        else:
                            # precisa ser também sócio para aceitar assinatura única
                            ok_qsa, _dados_r = self.apis.validar_associado_em_cnpj(self.cnpj, (nome_cont or "").strip())
                            if ok_qsa:
                                output_data.append([f"✔ Contador '{nome_cont}' também consta no QSA da empresa."])
                                output_data.append([f"✔ Assinatura única aceita (contador também é representante, consta no QSA)."])
                            else:
                                if socios_nao_confirmados:
                                    output_data.append([f"✘ Representante que assinou não consta no QSA da empresa."])
                                else:
                                    output_data.append([f"✘ Não foi localizada a identificação do representante (contador também não consta no QSA)."])

                    else:  # tem_representante e não tem_contador
                        # representantes corretos (QSA)
                        for s in socios_ok:
                            ns = (s.get("Nome") or s.get("Nome:") or "").strip()
                            output_data.append([f"✔ Representante '{ns}' consta no QSA da empresa."])

                        # checa se algum representante possui CRC ativo (usa 's', não 'contador')
                        representante_com_crc_ativo = None
                        for s in socios_ok:
                            nome = (s.get("Nome") or s.get("Nome:") or "").strip()
                            cpf  = self.format_br.digits(s.get("CPF") or s.get("CPF:") or "")
                            try:
                                resp = self.apis.buscar_dados_crc({"Nome": nome, "CPF": cpf})
                            except Exception:
                                resp = None
                            dados = (resp or {}).get("dados") if isinstance(resp, dict) else None
                            regs = (dados or {}).get("data") if isinstance(dados, dict) else None
                            if isinstance(regs, list):
                                for r in regs:
                                    sit = str(r.get("SituacaoCadastral") or "").strip().upper()
                                    if sit in {"ATIVO", "ATIVA", "REGULAR"}:
                                        representante_com_crc_ativo = nome
                                        break
                            if representante_com_crc_ativo:
                                break

                        if representante_com_crc_ativo:
                            output_data.append([f"✔ Representante '{representante_com_crc_ativo}' possui CRC ativo no CFC."])
                            output_data.append(["✔ Assinatura única aceita (representante com CRC ativo)."])
                        else:   
                            if contadores_nao_confirmados:
                                # havia contador informado mas NÃO ativo no CFC
                                output_data.append(["✘ Contador informado foi identificado, mas não possui CRC ativo no CFC."])
                            else:
                                # nenhum contador identificado no documento
                                output_data.append(["✘ Não foi localizada a assinatura/identificação do contador."])

                            # deixa explícito que nenhum representante tem CRC ativo p/ assinatura única
                            output_data.append(["✘ Nenhum representante possui CRC ativo no CFC para assinar como contador."])
                except Exception as e:
                    self.log.error(f"✘ Erro ao validar assinaturas: {e}")
                    output_data.append(["✘ Erro ao validar assinaturas do documento"])

        if anos:
            # dedup + sort numérico
            anos = sorted(set(anos), key=int)
            self.periodo_documento = self.format_br.formatar_anos(anos)

        # 5) Regras (planilha > fallback)
        regras: Dict[str, Any] = {}
        if getattr(self, "regras_mua", None):
            nomes = ["balance", "balanço", "balanco", "balanço patrimonial"]
            regras = self.regras_mua.get_doc(nomes)

        linhas_regras = self.exibir_regras_doc(regras)
        output_data.extend(linhas_regras)
        row = self._nome_validation_row()
        if row:
            output_data.append(row)    
        self.sections.append((self.type_name, output_data))
        return not houve_erro_em_algum_ano # retorna False se houver erro    

    def get_totais(self):
        ativo_total_doc = interpretar_valor_bruto(str(self.doc.get("Ativo Total:", 0)), "ativo", self.valores_em_milhares)
        passivo_total_doc = interpretar_valor_bruto(str(self.doc.get("Passivo Total:", 0)), "passivo", self.valores_em_milhares)
        patrimonio_total_doc = interpretar_valor_bruto(str(self.doc.get("Patrimônio Líquido:", 0)), "patrimônio", self.valores_em_milhares)
        componentes_passivo_pl = self.get_valor_aproximado(
            self.doc, 
            "Componentes do Passivo e Patrimônio Líquido:"
        )

        if patrimonio_total_doc == 0:
            for item in componentes_passivo_pl:
                nome = self.extrair_valor(item,  False, "Nome", "Nome:", "nome", "nome:") 
                valor = self.extrair_valor(item, True, "Valor", "Valor:", "valor", "valor:")
                if nome and valor:
                    for nome_pat in self.nomes_patrimonio:
                        nome_pat = normalize(nome_pat).replace(" ", "")
                        nome = normalize(nome).replace("=", "").replace(" ", "").replace("-","").replace("(","").replace(")","").strip()
                        #self.log.debug(f'validando {nome} com {nome_pat}')
                        if nome.startswith(nome_pat):
                            patrimonio_total_doc = interpretar_valor_bruto(str(valor), "patrimônio", self.valores_em_milhares)
                            return ativo_total_doc, passivo_total_doc, patrimonio_total_doc
            self.log.debug("campo do patrimonio não encontrado, tentando 2° validação...")
            for item in componentes_passivo_pl:
                nome = self.extrair_valor(item,  False, "Nome", "Nome:", "nome", "nome:") 
                valor = self.extrair_valor(item, True, "Valor", "Valor:", "valor", "valor:")
                if nome and valor:
                    for nome_pat in self.nomes_patrimonio:
                        nome_pat = normalize(nome_pat).replace(" ", "")
                        nome = normalize(nome).replace("=", "").replace(" ", "").replace("-","").replace("(","").replace(")","").strip()
                        if nome in nome_pat or nome_pat in nome:
                            patrimonio_total_doc = interpretar_valor_bruto(str(valor), "patrimônio", self.valores_em_milhares)
                            if patrimonio_total_doc == passivo_total_doc:
                                patrimonio_total_doc = 0
                                self.log.debug("Valor do patrimônio encontrado é igual ao passivo total, desconsiderando...")
                            return ativo_total_doc, passivo_total_doc, patrimonio_total_doc
        return ativo_total_doc, passivo_total_doc, patrimonio_total_doc

    def get_valor_aproximado(self, dados: dict, chave_desejada: str, padrao: list = None):
        chave_normalizada = normalize(chave_desejada)
        for chave in dados:
            if normalize(chave) == chave_normalizada:
                return dados[chave]
        return padrao if padrao is not None else []

    def encontrar_campo_mua_balanco(
        self,
        nome_item: str,
        grupo: str,
        permitir_fallback: bool = True,
        valor_item: float = None  # 🆕 valor usado para determinar lucro/prejuízo
    ) -> tuple[str, int]:
        grupo = normalize(grupo).replace(" ", '')
        nome_item = normalize(nome_item).replace("(-)", "").strip()
        nome_item_normalizado = nome_item.replace("//","").replace("\\","").replace('/', '').replace(" ", "").strip()
        if getattr(self, "balanco_resumido", False):
            if any(p in grupo for p in self.nomes_ativo_circulante):
                return "Caixa e Bancos", 5
            elif any(p in grupo for p in self.nomes_ativo_nao_circulante):
                return "Outros ativos realizáveis a longo prazo", 33
            elif any(p in grupo for p in self.nomes_passivo_circulante):
                return "Fornecedores", 57
            elif any(p in grupo for p in self.nomes_passivo_nao_circulante):
                return "Outros passivos de longo prazo", 71
            elif any(p in grupo for p in self.nomes_patrimonio):
                # Patrimônio Líquido: sem atalho; segue fluxo normal de mapeamento
                pass
            else:
                # ---------- CASO SEM GRUPO IDENTIFICADO ----------
                self.log.debug(f"⚠️ Campo '{nome_item}' não identificado no grupo '{grupo}'.")

                # 1) Pistas por "grupo" sintético
                if "grupoativo" in grupo:
                    return "Outros ativos realizáveis a longo prazo", 33
                if "grupopassivo" in grupo:
                    return "Outros passivos de longo prazo", 71

                # 2) Inferir pelo nome do item
                ni = nome_item.replace(" ", "")

                # 👉 Patrimônio Líquido: seguir fluxo NORMAL (sem atalho e sem fallback fixo)
                if any(p in ni for p in ["patrimonioliquido","capital","reservas","lucros","prejuizos","resultado"]):
                    campos_base = self.campos_patrimonio_liquido
                    mapeamento_direto = self.mapeamento_pl
                    # importante: não forçar fallback para lucros acumulados no modo resumido
                    fallback = ("Campo não identificado", 0)
                    # (deixa seguir o restante da função com matching/mapeamento normal)

                # Ativo/Passivo com/sem subgrupo → atalhos resumidos
                elif "ativocirculante" in ni:
                    return "Caixa e Bancos", 5
                elif "ativonaocirculante" in ni or "ativolongoprazo" in ni or "ativonãocirculante" in ni:
                    return "Outros ativos realizáveis a longo prazo", 33
                elif "passivocirculante" in ni:
                    return "Fornecedores", 57
                elif "passivonaocirculante" in ni or "passivolongoprazo" in ni or "passivonãocirculante" in ni:
                    return "Outros passivos de longo prazo", 71
                elif "ativo" in ni:
                    return "Outros ativos realizáveis a longo prazo", 33
                elif "passivo" in ni:
                    return "Outros passivos de longo prazo", 71
                else:
                    return None, 0
    
        # ⚠️ Regra especial para lucros/prejuízos acumulados
        if nome_item_normalizado in {
            "lucrosouprejuizosacumulados",
            "lucrosprejuizosacumulados",
            "lucroseprejuizosacumulados",
            "lucrosacumulados",
            "lucrosprejuizos acumulados",
            "lucrosprejuízos",
            "prejuizosacumulados",
            "prejuízosacumulados",
            "(-) prejuizos acumulados",
            "resultadosacumulados",
            "resultadosdoexercício",
            "resultadodoexercício"
        }:
            if valor_item is not None:
                if valor_item < 0:
                    self.log.debug('valor negativo, lançando em prejuizos acumulados')
                    return "(-) Prejuízos Acumulados", 86
                else:
                    self.log.debug('valor positivo, lançando em lucros acumulados')
                    return "Lucros Acumulados", 85
        if any(p in grupo for p in self.nomes_ativo_circulante):
            campos_base = self.campos_ativo_circulante
            mapeamento_direto = self.mapeamento_ativo_circ
            fallback = ("Outros créditos", 17)

        elif any(p in grupo for p in self.nomes_ativo_nao_circulante):
            campos_base = self.campos_ativo_nao_circulante
            mapeamento_direto = self.mapeamento_ativo_ncirc
            fallback = ("Outros ativos realizáveis a longo prazo", 33)

        elif any(p in grupo for p in self.nomes_passivo_circulante):
            campos_base = self.campos_passivo_circulante
            mapeamento_direto = self.mapeamento_passivo_circ
            fallback = ("Outros passivos circulantes", 63)

        elif any(p in grupo for p in self.nomes_passivo_nao_circulante):
            campos_base = self.campos_passivo_nao_circulante
            mapeamento_direto = self.mapeamento_passivo_ncirc
            fallback = ("Outros passivos de longo prazo", 71)

        elif any(p in grupo for p in self.nomes_patrimonio):
            campos_base = self.campos_patrimonio_liquido
            mapeamento_direto = self.mapeamento_pl
            fallback = ("Lucros Acumulados", 85)

        else:
            if "grupoativo" in grupo:
                campos_base = {**self.campos_ativo_circulante, **self.campos_ativo_nao_circulante}
                mapeamento_direto = {**self.mapeamento_ativo_circ, **self.mapeamento_ativo_ncirc}
                fallback = ("Outros ativos realizáveis a longo prazo", 33)

            elif "grupopassivo" in grupo:
                campos_base = {
                    **self.campos_passivo_circulante,
                    **self.campos_passivo_nao_circulante,
                    **self.campos_patrimonio_liquido
                }
                mapeamento_direto = {
                    **self.mapeamento_passivo_circ,
                    **self.mapeamento_passivo_ncirc,
                    **self.mapeamento_pl
                }
                fallback = ("Outros passivos de longo prazo", 71)

            else:
                campos_base = {}
                mapeamento_direto = {}
                fallback = ("Campo não identificado", 0)

            self.log.debug(f"⚠️ Campo '{nome_item}' não identificado no grupo '{grupo}'.")


        for chave, (campo, codigo) in mapeamento_direto.items():
            chave_normalizada = normalize(chave)
            if chave_normalizada in nome_item or nome_item in chave_normalizada:
                return campo, codigo

        melhor_campo = None
        melhor_codigo = None
        melhor_score = 0
        CAMPOS_RESTRITOS_SEM_FALLBACK = {
            "Outros créditos",
            "Outros ativos realizáveis a longo prazo",
            "Outros passivos circulantes",
            "Outros passivos de longo prazo",
        }

        for nome_sistema, codigo in campos_base.items():
            nome_sistema_lower = normalize(nome_sistema)
            if nome_item in nome_sistema_lower or nome_sistema_lower in nome_item:
                if not permitir_fallback and nome_sistema in CAMPOS_RESTRITOS_SEM_FALLBACK:
                    self.log.debug(f"⚠️ Campo '{nome_sistema}' bloqueado para uso sem fallback.")
                    continue
                return nome_sistema, codigo
            score = SequenceMatcher(None, nome_item, nome_sistema_lower).ratio()
            if score > melhor_score:
                melhor_score = score
                melhor_campo = nome_sistema
                melhor_codigo = codigo

        if melhor_score >= 0.8:
            if not permitir_fallback and melhor_campo in CAMPOS_RESTRITOS_SEM_FALLBACK:
                self.log.debug(f"⚠️ Campo '{melhor_campo}' bloqueado para uso sem fallback.")
                return None, 0
            return melhor_campo, melhor_codigo
        elif permitir_fallback:
            if "imobilizado" in normalize(nome_item):
                self.log.debug("🛠️ Campo 'Imobilizado' com fallback → redirecionando para 'Bens Imóveis'")
                return "Bens Imóveis", 40  # 🔁 Ajuste o código conforme sua estrutura
            return fallback
        else:
            return None, 0

    def retirar_subtitulos_desnecessarios(self, dicionario):
        for chave_grupo, lista_componentes in dicionario.items():
            if not isinstance(lista_componentes, list):
                continue
            chave_grupo_norm = chave_grupo.lower()
            if 'ativo' in chave_grupo_norm or 'passivo' in chave_grupo_norm:
                self.log.debug(f"\n🧹 Verificando subtítulos desnecessários no grupo: {chave_grupo}")
                novos_componentes = []
                ignorar = False
                campo_inicial = ""
                i = 0
                while i < len(lista_componentes):
                    item = lista_componentes[i]
                    nome = self.extrair_valor(item,  False, "Nome", "Nome:", "nome", "nome:")
                    nome_norm = normalize(nome)
                    self.log.debug(f"🔍 Analisando campo: {nome} ({nome_norm}) - {'Ignorando' if ignorar else 'Mantendo'}")
                    if not ignorar: 
                        if 'ativo' in chave_grupo_norm:
                            campos_sem_subtitulos = self.campos_sem_subtitulos_ativo
                            campos_conhecidos_balanco = self.campos_conhecidos_balanco_ativo
                        elif 'passivo' in chave_grupo_norm:
                            campos_sem_subtitulos = self.campos_sem_subtitulos_passivo
                            campos_conhecidos_balanco = self.campos_conhecidos_balanco_passivo
                        for campo_base in campos_sem_subtitulos:
                            campo_base_norm = normalize(campo_base).replace(" ", "")
                            if campo_base_norm in nome_norm:
                                self.log.debug(f"🔍 Iniciando exclusão após campo: {nome}")
                                ignorar = True
                                campo_inicial = campo_base
                                novos_componentes.append(item)  # mantém o campo de início
                                break
                        else:
                            novos_componentes.append(item)
                            i += 1
                            continue
                    else:
                        valor_str = self.extrair_valor(item, True, "Valor", "Valor:", "valor", "valor:")
                        try:
                            valor_float = interpretar_valor_bruto(str(valor_str), chave_grupo, self.valores_em_milhares)
                        except ValueError:
                            valor_float = 0.0

                        encontrou_limite = any(
                            re.search(rf'\b{re.escape(campo_known)}\b', nome_norm) and valor_float != 0
                            for campo_known in campos_conhecidos_balanco
                            if campo_known != campo_inicial
                        )

                        if encontrou_limite:
                            self.log.debug(f"✅ Campo de encerramento encontrado: {nome}")
                            novos_componentes.append(item)
                            ignorar = False
                            # ⚠️ Não avança o índice, pois queremos revalidar esse campo no modo "não ignorar"
                            continue
                        else:
                            self.log.debug(f"🗑️ Removido subtítulo: {nome}({nome_norm})")
                            i += 1
                            continue
                    i += 1
                dicionario[chave_grupo] = novos_componentes
        self.log.debug("\n✅ Remoção de subtítulos desnecessários finalizado.\n")
        return dicionario

    def __validate_balanco(self, output_data, totais_por_campo, retirar_subtitulos_desnecessarios = False,
                                ativo_total_doc=None, passivo_total_doc=None, patrimonio_total_doc=None):

        grupos_com_valores = {
            "componentes do ativo circulante:": "Ativo Circulante:",
            "componentes do ativo nao circulante:": "Ativo Não Circulante:",
            "componentes do passivo circulante:": "Passivo Circulante:",
            "componentes do passivo nao circulante:": "Passivo Não Circulante:",
            "componentes do patrimônio líquido:": "Patrimônio Líquido:"
        }
        self.lancamentos_por_grupo = {"ativo": [], "passivo": [], "pl": []}
        self.campos_salvos_ativo = []
        self.campos_salvos_passivo = []
        # 🧠 Corrige valores zerados de grupos principais buscando TOTAL equivalente
        self.log.debug("\n🔍 Iniciando correção de valores zerados com base em campos TOTAL ...\n")
        # Para cada grupo (ex: Componentes do Ativo, etc.)
        for chave_grupo, lista_componentes in self.doc.items():
            if not isinstance(lista_componentes, list):
                continue

            self.log.debug(f"📂 Grupo de componentes: {chave_grupo}")

            for i, item in enumerate(lista_componentes):
                nome = self.extrair_valor(item, False, "Nome", "Nome:", "nome", "nome:")
                valor = self.extrair_valor(item, True, "Valor", "Valor:", "valor", "valor:")
                nome_norm = normalize(nome).replace(" ", "")
                valor_str = str(valor).strip()

                if valor_str in ["", "0", "0,00", "0.00"]:
                    nome_base = nome_norm  # agora usamos o nome do próprio campo
                    substituido = False

                    for j, outro_item in enumerate(lista_componentes):
                        nome_total = self.extrair_valor(outro_item, False,  "Nome", "Nome:", "nome", "nome:")
                        valor_total = self.extrair_valor(outro_item, True, "Valor", "Valor:", "valor", "valor:")
                        nome_total_norm = normalize(nome_total).replace(" ", "")

                        if (
                            nome_total_norm.startswith("total" + nome_base)
                            or nome_total_norm.startswith("totaldo" + nome_base)
                            or nome_total_norm.startswith("total" + nome_base.replace("do", ""))
                        ):
                            self.log.debug(f"🔁 Substituindo '{nome}' com valor '{valor}' pelo valor de '{nome_total}': {valor_total}")
                            chave_valor = next((k for k in item.keys() if normalize(k).startswith("valor")), "Valor:")
                            item[chave_valor] = valor_total
                            lista_componentes.pop(j)
                            substituido = True
                            break

                    if not substituido:
                        self.log.debug(f"🚫 Nenhum TOTAL correspondente encontrado para: {nome_norm}")

        self.log.debug("\n✅ Correção de valores zerados concluída.\n")

        # 🚫 Remover subtítulos desnecessários de campos conhecidos que não possuem filhos (como FORNECEDORES)
        #retirar_subtitulos_desnecessarios = True 
        if retirar_subtitulos_desnecessarios:
            self.doc = self.retirar_subtitulos_desnecessarios(self.doc)
            
         #
        for grupo, value in self.doc.items():
            self.log.debug("=" * 60)
            self.log.debug(f"🔎 Analisando grupo: {grupo}")

            # 👉 Se o grupo for de componentes e tiver valor total correspondente, exibe antes
            grupo_normalizado = normalize(grupo)
            if grupo_normalizado in grupos_com_valores:
                self.log.debug(f"🔍 Encontrado grupo normalizado: {grupo_normalizado}")
                nome_total = grupos_com_valores[grupo_normalizado]
                self.log.debug(f"🔍 Nome total correspondente: {nome_total}")
                valor_raw = self.doc.get(nome_total)
                self.log.debug(f"🔍 Valor bruto encontrado: {valor_raw}")
                if valor_raw is not None:
                    try:
                        valor_float = interpretar_valor_bruto(str(valor_raw), grupo, self.valores_em_milhares)
                        valor_formatado = self.format_br.formatar_valor(valor_float)
                    except:
                        valor_formatado = str(valor_raw)
                    #output_data.append([nome_total.replace(":", ""), valor_formatado])
            #else:
                self.log.debug(f"⚠️ Grupo '{grupo}' não corresponde a nenhum grupo conhecido. Ignorando...")
            if isinstance(value, list):
                componentes_grupo = []
                for item in value:
                    nome = self.extrair_valor(item,  False, "Nome", "Nome:", "nome", "nome:") #aqui
                    valor = self.extrair_valor(item, True, "Valor", "Valor:", "valor", "valor:")
                    if nome and valor:
                        nome = normalize(nome).replace(".","").replace(";","").replace(":","").replace("=","").replace(">","").replace("<","").replace("*","").strip()
                        nome_norm = nome.replace(" ", "")
                        valor = valor.replace("£", "").strip()
                        #self.log.debug(f"Nome normalizado: {nome}")
                        # Verifica se o nome está na lista de ignorados
                        if nome_norm in self.nomes_titulos_ignorados:
                            self.log.debug(f"⚠️ Ignorando nome '{nome}' por estar na lista de ignorados.")
                            continue
                        try:
                            possui_c_ou_d = False
                            if 'c' in str(valor.lower()) or 'd' in str(valor.lower()):
                                possui_c_ou_d = True
                            valor = interpretar_valor_bruto(str(valor), grupo, self.valores_em_milhares)
                            #if not possui_c_ou_d and valor > 0 and "(-" in nome.replace(" ", "").lower():
                            #    valor = -valor
                            # ✅ Regra fixa para tornar depreciação negativa
                            if not possui_c_ou_d:
                                palavras_depreciacao = ["deprec", "deprecia", "depreciacao", "depreciação","amortizacao", "amortização", "amort."]
                                if any(p in nome for p in palavras_depreciacao) and valor > 0:
                                    self.log.debug(f"⚠️ Valor ajustado para negativo: {nome.strip()} → de {valor} para {-valor}")
                                    valor = -valor
                            if valor != 0:
                                componentes_grupo.append((nome, valor))
                        except:
                            continue
                    else:
                        self.log.debug('Nome ou valor não encontrado')
                if not componentes_grupo:
                    continue  # ✘ pula esse grupo, pois está vazio!
                        
                output_data.append([grupo])        
                # ✅ Remove duplicatas exatas com mesmo nome e valor
                ocorrencias = defaultdict(int)
                vistos = set()
                componentes_grupo_renomeado = []

                for nome, valor in componentes_grupo:
                    nome_norm = normalize(nome)
                    ocorrencias[nome_norm] += 1
                    novo_nome = nome
                    if ocorrencias[nome_norm] > 1:
                        self.log.debug(f"🔄 Nome duplicado detectado: '{nome}' renomeado para '{nome} ({ocorrencias[nome_norm]})'")
                        novo_nome = f"{nome} ({ocorrencias[nome_norm]})"
                    componentes_grupo_renomeado.append((novo_nome, valor))

                # Substitui a lista original por completo
                componentes_grupo = componentes_grupo_renomeado
                # Detectar subtítulos dentro do grupo
                hierarquia = {}
                usados = set()
                pendentes = {}

                # Validação iterativa até esgotar
                usados_nomes_total = set()
                hierarquia_final = {}


                etapa = 1
                # 👉 Substitui o loop antigo inteiro por uma única chamada
                componentes_simples = [(nome, valor) for _, (nome, valor) in enumerate(componentes_grupo)]
                hierarquia_final = identificar_subtitulos_por_hierarquia(componentes_simples)

                # Após a criação da hierarquia_final
                campos_em_hierarquia = set()
                for pai, filhos in hierarquia_final.items():
                    campos_em_hierarquia.add(pai)
                    campos_em_hierarquia.update(filhos)
                
                # Adiciona campos isolados que não foram associados a ninguém
                for nome, valor in componentes_simples:
                    if (nome, valor) in campos_em_hierarquia:
                        continue

                    # Verifica se o mesmo nome com valor invertido está na hierarquia
                    valor_invertido = -valor
                    if (nome, valor_invertido) in campos_em_hierarquia:
                        self.log.debug(f"🔁 Campo {nome} com valor {valor} ignorado pois já existe versão com valor invertido.")
                        continue

                    self.log.debug(f"📥 Campo isolado detectado e incluído como topo: {nome} ({valor})")
                    hierarquia_final[(nome, valor)] = []


                # 🧹 REMOVE CAMPOS-RAIZ COMO ATIVO CIRCULANTE, PASSIVO NÃO CIRCULANTE ETC. SE ESTIVEREM SEM FILHOS
                
                titulos_com_filhos = ['circulante', 'naocirculante','totalcirculante', 'totalnaocirculante', 'totalcirculante(2)', 'totalnaocirculante']
                def _norm(t: str) -> str:
                    # mesmo normalizador que você já usa
                    return re.sub(r"\([^)]*\)", "", normalize(t)).replace(" ", "").replace("-", "").replace("total", "").strip()

                def _eh_titulo_estrutural(nome_norm: str) -> bool:
                    return (
                        nome_norm in self.nomes_ativo_circulante or
                        nome_norm in self.nomes_ativo_nao_circulante or
                        nome_norm in self.nomes_passivo_circulante or
                        nome_norm in self.nomes_passivo_nao_circulante or
                        nome_norm in self.nomes_patrimonio or
                        nome_norm in titulos_com_filhos
                    )

                def _deve_remover(chave, visitados=None) -> bool:
                    # Remove se: (a) é título estrutural e não tem filhos, OU
                    # (b) é título estrutural e tem exatamente 1 filho que é estrutural
                    #     e que também deveria ser removido (cadeia unária de estruturais).
                    if visitados is None: visitados = set()
                    if chave in visitados:  # proteção contra ciclos acidentais
                        return True
                    visitados.add(chave)

                    nome, _ = chave
                    nome_norm = _norm(nome)
                    if not _eh_titulo_estrutural(nome_norm):
                        return False

                    filhos = hierarquia_final.get(chave, [])
                    if not filhos:
                        return True

                    if len(filhos) == 1:
                        filho = filhos[0]
                        filho_norm = _norm(filho[0])
                        if _eh_titulo_estrutural(filho_norm):
                            return _deve_remover(filho, visitados)

                    return False

                # Coleta e remove
                campos_para_remover = []
                for chave in list(hierarquia_final.keys()):
                    if _deve_remover(chave):
                        self.log.debug(f"🗑️ Removendo título estrutural sem conteúdo: {chave[0]}")
                        campos_para_remover.append(chave)

                for chave in campos_para_remover:
                    hierarquia_final.pop(chave, None)
                


                # Impressão da hierarquia
                self.log.debug("🧭 ESTRUTURA HIERÁRQUICA IDENTIFICADA:")
                todos_filhos = set(filho for filhos in hierarquia_final.values() for filho in filhos)
                todos_pais = set(hierarquia_final.keys())
                todos_nomes = todos_pais | todos_filhos
                topo = [nome for nome in todos_nomes if nome not in todos_filhos]

                def imprimir_hierarquia(nome, nivel=0):
                    indent = "   " * nivel
                    self.log.debug(f"{indent}- {nome}")
                    for filho in hierarquia_final.get(nome, []):
                        imprimir_hierarquia(filho, nivel + 1)

                vistos = set()
                for nome in topo:
                    if nome not in vistos:
                        imprimir_hierarquia(nome)
                        vistos.add(nome)

                # --- Cálculo do total dos campos isolados (não são filhos e não têm filhos) ---
                todos_filhos = set(filho for filhos in hierarquia_final.values() for filho in filhos)
                todos_pais = set(hierarquia_final.keys())
                todos_nomes = todos_pais | todos_filhos

                # Lista de (nome, valor) dos campos isolados
                campos_isolados = [
                    (nome, valor)
                    for (nome, valor) in todos_nomes
                    if (nome, valor) not in todos_filhos and len(hierarquia_final.get((nome, valor), [])) == 0
                ]

                total_isolados = sum(valor for (_, valor) in campos_isolados)

                if campos_isolados:
                    self.log.debug(f"💰 Valor total dos campos sem filhos: R$ {total_isolados:,.2f}")
                else:
                    self.log.debug("💰 Não há campos sem filhos.")

                 #
                # 🆕 Mapeia o grupo de cada item com base nos títulos-pai conhecidos
                grupo_por_item = {}

                def atribuir_grupo_recursivo(nome_valor, grupo_raiz):
                    nome_item, _ = nome_valor
                    grupo_por_item[normalize(nome_item)] = grupo_raiz
                    for filho in hierarquia_final.get(nome_valor, []):
                        atribuir_grupo_recursivo(filho, grupo_raiz)

                for titulo, filhos in hierarquia_final.items():
                    nome_grupo, _ = titulo
                    grupo_real = None
                    nome_grupo_norm = normalize(nome_grupo).replace(" ", "")
                    grupo_norm = normalize(grupo).replace(" ","")

                    # Primeiro: verifica os casos de longo prazo / não circulante
                    if any(p in nome_grupo_norm for p in self.nomes_nao_circulantes):
                        if "ativo" in grupo_norm:
                            grupo_real = "ativo não circulante"
                        elif "passivo" in grupo_norm:
                            grupo_real = "passivo não circulante"

                    # Só então verifica o "circulante" genérico
                    elif any(p in nome_grupo_norm for p in self.nomes_circulante):
                        if "ativo" in grupo_norm:
                            grupo_real = "ativo circulante"
                        elif "passivo" in grupo_norm:
                            grupo_real = "passivo circulante"

                    # Por fim, verifica patrimônio líquido
                    elif any(p in nome_grupo_norm for p in self.nomes_patrimonio):
                        grupo_real = "patrimônio líquido"

                    # Aplica se identificou corretamente
                    if grupo_real:
                        self.log.debug(f"🧭 Título '{nome_grupo}' classificado como '{grupo_real}'")
                        atribuir_grupo_recursivo(titulo, normalize(grupo_real))


                # ⚠️ AJUSTE AQUI — extrai nomes dos topos para comparação
                nomes_topo = set(nome for nome, _ in topo)

                # Agora sim: monta os componentes pendentes com base no nome, não na tupla inteira
                componentes_pendentes = [
                    (i, (nome, valor))
                    for i, (nome, valor) in enumerate(componentes_grupo)
                    if nome in nomes_topo
                ]

                # Refatorado para usar a hierarquia corretamente
                nomes_usados_mua = set()
                componentes_utilizados = []  # ← Para exibição no PDF

                # Define se é documento de ativo ou passivo com base no grupo inicial
                grupo_normalizado = normalize(grupo).replace(" ", "")
                if "ativo" in grupo_normalizado:
                    tipo_documento = "ativo"
                elif "passivo" in grupo_normalizado or "patrimonio" in grupo_normalizado:
                    tipo_documento = "passivo"
                else:
                    tipo_documento = "desconhecido"
                # Decide se usa o título pai ou os filhos com lógica de fallback correta
                nomes_processados = set()
                self.log.debug("🔄 Validando campos com os campos do MUA...")
                def processar_nome_recursivo(nome, valor = None):
                    self.log.debug(f"🔍 Processando nome: {nome}")
                    chave = (normalize(nome), round(valor or 0, 2))
                    if chave in nomes_processados:
                        self.log.debug(f"⏭️ Nome '{nome}' ({valor}) já validado anteriormente. Pulando para evitar duplicidade.")
                        return
                    grupo_reconhecido = grupo_por_item.get(normalize(nome))
                    if not grupo_reconhecido:
                        self.campos_sem_grupo.append((nome, valor))

                        if tipo_documento == "ativo":
                            grupo_reconhecido = "grupoativo"
                            self.log.debug(f"⚠️ Grupo não reconhecido para '{nome}', assumido como 'grupoativo'.")
                        elif tipo_documento == "passivo":
                            grupo_reconhecido = "grupopassivo"
                            self.log.debug(f"⚠️ Grupo não reconhecido para '{nome}', assumido como 'grupopassivo'.")
                        else:
                            grupo_reconhecido = "grupo nao identificado"
                            self.log.debug(f"⚠️ Grupo não reconhecido para '{nome}', usando grupo genérico.")



                    self.log.debug(f"🧭 Grupo reconhecido para '{nome}': {grupo_reconhecido}")

                    nomes_processados.add(chave)
                    self.log.debug(f"Hierarquia identificada: {hierarquia_final}")
                    valor_pai = next((v for n, v in componentes_grupo if normalize(n) == normalize(nome)), None)
                    filhos = hierarquia_final.get((nome, valor_pai), [])
                    self.log.debug(f" Filhos encontrados para '{nome}': {filhos}")

                    filhos_utilizaveis = []
                    for filho_nome, filho_valor in filhos:
                        filhos_utilizaveis.append((filho_nome, filho_valor))
                        self.log.debug(f"  - {filho_nome} ({filho_valor})")
                        break
                    self.log.debug(f" Filhos utilizáveis: {filhos_utilizaveis}")
                    valor_pai = next((v for n, v in componentes_grupo if normalize(n) == normalize(nome)), None)
                    if valor_pai is None:
                        self.log.debug(f"⚠️ Valor pai é None, ignorando...")
                        return

                    campo_pai, cod_pai = self.encontrar_campo_mua_balanco(
                        nome, grupo_reconhecido,
                        permitir_fallback=False,
                        valor_item=valor_pai  # 🆕 Passa o valor do pai para determinar lucro/prejuízo
                    )

                    if cod_pai:
                        # Pai possui campo → lança pai e ignora filhos
                        chave = (campo_pai, cod_pai)
                        totais_por_campo[chave] = totais_por_campo.get(chave, 0) + valor_pai
                        nomes_usados_mua.add(nome)
                        componentes_utilizados.append((nome, campo_pai, cod_pai, valor_pai))
                        self.log.debug(f"✅ Pai '{nome}' mapeado → {campo_pai} ({cod_pai})")
                    elif filhos:
                        self.log.debug(f"🔄 Pai '{nome}' sem campo direto, processando filhos...")
                        # Processa cada filho individualmente
                        for filho_nome, filho_valor in filhos:
                            self.log.debug(f"🚀 Processando filho: {filho_nome} ({filho_valor})" )
                            processar_nome_recursivo(filho_nome, filho_valor)
                    else:
                        # Nenhum campo encontrado → tenta lançar o pai com fallback
                        self.log.debug(f"⚠️ Pai '{nome}' sem campo direto, tentando fallback...")
                        campo_pai, cod_pai = self.encontrar_campo_mua_balanco(
                            nome, grupo_reconhecido,
                            permitir_fallback=True,
                            valor_item=valor_pai  # 🆕 Passa o valor do pai para determinar lucro/prejuízo
                        )
                        chave = (campo_pai, cod_pai)
                        totais_por_campo[chave] = totais_por_campo.get(chave, 0) + valor_pai
                        nomes_usados_mua.add(nome)
                        componentes_utilizados.append((nome, campo_pai, cod_pai, valor_pai))
                        self.log.debug(f"⚠️ Fallback: '{nome}' → {campo_pai} ({cod_pai})")
                    if cod_pai:
                        if not hasattr(self, "lancamentos_por_grupo"):
                            self.lancamentos_por_grupo = {"ativo": [], "passivo": [], "pl": []}

                        registro = {
                            "campo_documento": nome,      # Nome no balanço
                            "campo_sistema": campo_pai,   # Nome no MUA
                            "codigo": cod_pai,            # Código MUA
                            "valor": valor_pai
                        }

                        if cod_pai in self.campos_ativo_circulante.values() or cod_pai in self.campos_ativo_nao_circulante.values():
                            self.lancamentos_por_grupo["ativo"].append(registro)

                        elif cod_pai in self.campos_passivo_circulante.values() or cod_pai in self.campos_passivo_nao_circulante.values():
                            self.lancamentos_por_grupo["passivo"].append(registro)

                        elif cod_pai in self.campos_patrimonio_liquido.values():
                            self.lancamentos_por_grupo["pl"].append(registro)


                for _, (nome, valor) in componentes_pendentes:
                    self.log.debug(f"🚀 Enviando topo da hierarquia para validação no MUA: {nome} ({valor})")
                    processar_nome_recursivo(nome,valor)
                

                # Exibir apenas os nomes usados no MUA
               # ❗Excluir os pais de qualquer nome que foi usado como subtítulo
                nomes_a_exibir = set(nomes_usados_mua)

                for (pai_nome, pai_valor), filhos in hierarquia_final.items():
                    if any(filho_nome in nomes_usados_mua for filho_nome, _ in filhos):
                        nomes_a_exibir.discard(pai_nome)  # remove o pai se algum filho foi usado

                # Exibir apenas os campos realmente utilizados após validação hierárquica
                for nome, campo, codigo, valor in componentes_utilizados:
                    valor_formatado = self.format_br.formatar_valor(valor)
                    output_data.append([f"  - {nome}: {valor_formatado}"])

        erro_balanco, msgs_erro_balanco = False, []
        if (ativo_total_doc is not None and
            passivo_total_doc is not None and
            patrimonio_total_doc is not None):
            erro_balanco, msgs_erro_balanco = self.somar_valores(
                totais_por_campo,
                ativo_total_doc, passivo_total_doc, patrimonio_total_doc,
            )

        return output_data, totais_por_campo, erro_balanco, msgs_erro_balanco

    def ajustar_valor(self, chaves_prioridade, diferenca, totais_por_campo):
        direcao = 1 if diferenca > 0 else -1
        restante = round(abs(diferenca), 2)  # <- trava 2 casas

        for chave in chaves_prioridade:
            valor_atual = round(float(totais_por_campo.get(chave, 0)), 2)

            if direcao > 0:
                totais_por_campo[chave] = valor_atual + restante
                totais_por_campo[chave] = round(valor_atual + restante, 2)
                return True
            else:
                if valor_atual >= restante:
                    totais_por_campo[chave] = valor_atual - restante
                    totais_por_campo[chave] = round(valor_atual - restante, 2)
                    return True
                else:
                    totais_por_campo[chave] = 0
                    totais_por_campo[chave] = 0.00
                    restante = round(restante - valor_atual, 2)
        return False

    def _ajustar_por_subset_lancados(
        self,
        diferenca_abs: float,
        lancamentos: list,
        totais_por_campo: dict,
        allowed_codes: set,
        lado_label: str = "LADO",
        eps: float = 0.01,
        max_nodes: int = 300_000,
        target_total_abs: float | None = None,  # 🆕 modo seleção por alvo
    ) -> bool:
        """
        Modo 1 (padrão): quando a soma lançada está MAIOR, tenta REMOVER um subconjunto cuja soma == diferenca_abs.
        Modo 2 (target_total_abs): tenta SELECIONAR um subconjunto cuja soma (em módulo) == target_total_abs e manter só ele.
        Em ambos os modos, há logs detalhados do processo.
        """
        try:
            dif_alvo = round(float(diferenca_abs), 2)
        except Exception:
            dif_alvo = 0.0

        # ---------------------------
        # Preparação dos candidatos
        # ---------------------------
        candidatos = []
        for idx, it in enumerate(lancamentos or []):
            try:
                codigo = it.get("codigo")
                valor = float(it.get("valor", 0.0))
                campo_sistema = it.get("campo_sistema")
                campo_documento = it.get("campo_documento")
            except Exception:
                continue

            if codigo not in allowed_codes:
                continue

            # Para seleção por ALVO, trabalhamos em magnitude (abs_val)
            candidatos.append({
                "idx": idx,
                "chave": (campo_sistema, codigo),
                "valor": valor,                 # com sinal
                "abs_val": round(abs(valor), 2),# magnitude
                "campo_documento": campo_documento,
                "campo_sistema": campo_sistema,
                "codigo": codigo,
            })

        if not candidatos:
            self.log.debug(f"🟡 [{lado_label}] Sem candidatos válidos para ajustar.")
            return False

        # Ordena desc por magnitude para podar melhor
        candidatos.sort(key=lambda c: c["abs_val"], reverse=True)

        # ---------------------------
        # Utilitários de log
        # ---------------------------
        def _log_candidatos(prefixo="CANDIDATOS"):
            lst = ", ".join(
                f"{c['campo_sistema']}[{c['codigo']}]={c['valor']:.2f}"
                for c in candidatos
            )
            self.log.debug(f"🔎 [{lado_label}] {prefixo}: {lst}")

        def _aplicar_manter_subset(escolhidos):
            """Mantém somente 'escolhidos' do grupo; remove os demais do grupo."""
            self.log.debug(
                f"🧩 [{lado_label}] Subset escolhido (manter): " +
                " + ".join(f"{c['campo_sistema']}[{c['codigo']}]({c['valor']:.2f})" for c in escolhidos)
            )
            # 1) limpa totais do GRUPO (allowed_codes)
            for chave in list(totais_por_campo.keys()):
                _, codigo = chave
                if codigo in allowed_codes:
                    totais_por_campo.pop(chave, None)

            # 2) reconstroi com apenas o subset
            for c in escolhidos:
                v_atual = float(totais_por_campo.get(c["chave"], 0.0))
                totais_por_campo[c["chave"]] = round(v_atual + c["valor"], 2)

            # 3) atualiza lista de lançamentos do grupo
            manter_indices = set(c["idx"] for c in escolhidos)
            novos = [it for i, it in enumerate(lancamentos) if i in manter_indices]
            lancamentos.clear()
            lancamentos.extend(novos)

        def _aplicar_remover_subset(escolhidos):
            """Remove o subset do grupo (modo 'diferença')."""
            self.log.debug(
                f"🩹 [{lado_label}] Subset removido: " +
                " + ".join(f"{c['campo_sistema']}[{c['codigo']}]({c['valor']:.2f})" for c in escolhidos)
            )
            for c in escolhidos:
                v_atual = float(totais_por_campo.get(c["chave"], 0.0))
                totais_por_campo[c["chave"]] = round(v_atual - c["valor"], 2)  # remove o valor original (com sinal)

            remover_indices = set(c["idx"] for c in escolhidos)
            novos = [it for i, it in enumerate(lancamentos) if i not in remover_indices]
            lancamentos.clear()
            lancamentos.extend(novos)

        # ---------------------------
        # DFS genérico (por magnitude)
        # ---------------------------
        n = len(candidatos)
        prefix = [0.0]
        for c in candidatos:
            prefix.append(prefix[-1] + c["abs_val"])

        best_combo = None
        node_count = 0

        def dfs_por_alvo(i, soma, escolhidos_idx, alvo):
            nonlocal best_combo, node_count
            if best_combo is not None:
                return

            node_count += 1
            if node_count > max_nodes:
                return

            # solução encontrada
            if abs(soma - alvo) <= eps:
                best_combo = escolhidos_idx[:]
                return

            # passou do alvo → não faz sentido continuar
            if soma > alvo + eps:
                return

            # fim da lista
            if i >= n:
                return

            # poda por máximo possível
            max_rest = prefix[n] - prefix[i]
            if soma + max_rest < alvo - eps:
                return

            # ----- NOVA PODA: ignorar combinação impossível -----
            # incluir esse candidato deixaria a soma muito acima do alvo
            if soma + candidatos[i]["abs_val"] > alvo + 5:
                dfs_por_alvo(i + 1, soma, escolhidos_idx, alvo)
                return

            # pegar o candidato
            escolhidos_idx.append(i)
            dfs_por_alvo(i + 1, soma + candidatos[i]["abs_val"], escolhidos_idx, alvo)
            escolhidos_idx.pop()
            if best_combo is not None:
                return

            # pular o candidato
            dfs_por_alvo(i + 1, soma, escolhidos_idx, alvo)

        # ---------------------------
        # Modo 2: Selecionar subset que soma ao ALVO absoluto do grupo
        # ---------------------------
        if target_total_abs is not None and abs(target_total_abs) > eps:
            alvo = round(abs(float(target_total_abs)), 2)  # 👈 força alvo positivo
            self.log.debug(f"🔍 [{lado_label}] Tentando SELECIONAR subset que some ao alvo |alvo|={alvo:.2f} (eps={eps})")
            _log_candidatos("CANDIDATOS (seleção)")

            # se o alvo for maior que a soma máxima possível, nem tenta
            total_max = prefix[n]  # soma de todas magnitudes possíveis
            if alvo > total_max + eps:
                self.log.debug(f"❌ [{lado_label}] Alvo {alvo:.2f} > soma máxima possível {total_max:.2f}. Impossível montar subset pelo alvo.")
            else:
                dfs_por_alvo(0, 0.0, [], alvo)

            if best_combo is not None:
                escolhidos = [candidatos[k] for k in best_combo]
                soma_abs = sum(c["abs_val"] for c in escolhidos)
                self.log.debug(f"✅ [{lado_label}] Subset encontrado: soma≈{soma_abs:.2f} (alvo≈{alvo:.2f}). Mantendo apenas esse conjunto.")
                _aplicar_manter_subset(escolhidos)
                return True
            else:
                self.log.debug(f"❌ [{lado_label}] Nenhum subset soma ao alvo (|alvo|={alvo:.2f}).")
                # cai para o modo diferença se fizer sentido
        # ---------------------------
        # Modo 1: Remover subset que soma à diferença (excesso)
        # ---------------------------
        if dif_alvo <= eps:
            self.log.debug(f"🟡 [{lado_label}] Diferença ≤ eps; nada a remover por diferença.")
            return False

        self.log.debug(f"🔍 [{lado_label}] Tentando REMOVER subset que some à diferença |dif|={dif_alvo:.2f} (eps={eps})")
        _log_candidatos("CANDIDATOS (remoção)")
        best_combo = None
        node_count = 0
        dfs_por_alvo(0, 0.0, [], dif_alvo)

        if best_combo is None:
            self.log.debug(f"❌ [{lado_label}] Nenhum subset soma à diferença (|dif|={dif_alvo:.2f}).")
            return False

        escolhidos = [candidatos[k] for k in best_combo]
        soma_abs = sum(c["abs_val"] for c in escolhidos)
        self.log.debug(f"✅ [{lado_label}] Subset p/ remoção encontrado: soma≈{soma_abs:.2f} (dif≈{dif_alvo:.2f}). Removendo…")
        _aplicar_remover_subset(escolhidos)
        return True

    def somar_valores(self, totais_por_campo,
        ativo_total_doc,
        passivo_total_doc,
        patrimonio_total_doc,

        ):
        soma_ativo = sum(
            valor for (campo, codigo), valor in totais_por_campo.items()
            if codigo in list(self.campos_ativo_circulante.values()) + list(self.campos_ativo_nao_circulante.values())
            or any(p in normalize(campo).replace(" ", "") for p in self.nomes_ativo_circulante + self.nomes_ativo_nao_circulante)
        )

        soma_passivo = sum(
            valor for (campo, codigo), valor in totais_por_campo.items()
            if codigo in list(self.campos_passivo_circulante.values()) + list(self.campos_passivo_nao_circulante.values())
            or any(p in normalize(campo).replace(" ", "") for p in self.nomes_passivo_circulante + self.nomes_passivo_nao_circulante)
        )

        soma_patrimonio = sum(
            valor for (campo, codigo), valor in totais_por_campo.items()
            if codigo in self.campos_patrimonio_liquido.values()
            or any(p in normalize(campo).replace(" ", "") for p in self.nomes_patrimonio)
        )
        self.log.debug(
            "🧮 CONTEXTO INICIAL | "
            f"|ATIVO decl.|={ativo_total_doc:.2f} vs |soma ATIVO|={soma_ativo:.2f} | "
            f"|PASSIVO decl.|={passivo_total_doc:.2f} vs |soma PASSIVO|={soma_passivo:.2f} | "
            f"|PL decl.|/inf.={patrimonio_total_doc:.2f} vs |soma PL|={soma_patrimonio:.2f}"
        )
        allowed_codes_ativo = set(
            list(self.campos_ativo_circulante.values()) +
            list(self.campos_ativo_nao_circulante.values())
        )
        allowed_codes_passivo = set(
            list(self.campos_passivo_circulante.values()) +
            list(self.campos_passivo_nao_circulante.values())
        )
        ajustou_subset_passivo = False
        ajustou_subset_ativo = False
        
        self.log.debug(f"🔍 Soma do Ativo: {soma_ativo}, Passivo: {soma_passivo}, Patrimônio Líquido: {soma_patrimonio}")
        erro_balanco = False
        msgs_erro_balanco = []

        if patrimonio_total_doc == 0:
            if soma_patrimonio == 0:
                erro_balanco = True
                msgs_erro_balanco.append(
                    "✘ ERRO: Valor total do patrimônio zerado.\n"
                )
                return erro_balanco, msgs_erro_balanco 
            else:
                patrimonio_total_doc = soma_patrimonio

        # Diferença tolerável: 5% do ativo
        tolerancia = abs(ativo_total_doc) * 0.05

        # --- VALIDAÇÃO DO ATIVO ---
        
        dif_ativo = abs(ativo_total_doc) - abs(soma_ativo)
        # Se a soma do ATIVO está MAIOR que o declarado (dif_ativo < 0),
        # tenta remover exatamente o(s) isolado(s) que causam o excesso.
        if dif_ativo < 0:
            if abs(dif_ativo) <= tolerancia:
                self.log.info(f"⚠️ Diferença no ATIVO ({dif_ativo:.2f}) ajustada automaticamente.")
                chaves_ativo = [
                    ("Outros ativos realizáveis a longo prazo", 33),
                    ("Outros créditos", 17),
                ]
                self.ajustar_valor(chaves_ativo, dif_ativo, totais_por_campo)
            else:
                self.log.debug(
                    f"🧪 [ATIVO] Diferença (|decl|-|soma|)={dif_ativo:.2f} (módulo). "
                    f"Tentando selecionar subset que some a |Ativo declar.|={abs(ativo_total_doc):.2f}…"
                )
                ajustou_subset_ativo = self._ajustar_por_subset_lancados(
                    diferenca_abs=abs(dif_ativo),
                    lancamentos=self.lancamentos_por_grupo.get("ativo", []),
                    totais_por_campo=totais_por_campo,
                    allowed_codes=allowed_codes_ativo,
                    lado_label="ATIVO",
                    target_total_abs=abs(ativo_total_doc),  # 🆕 seleciona subset que soma ao alvo
                )

                # LOG dos lançados no ATIVO (após tentativa)
                self.log.debug(
                    "📋 [ATIVO] CAMPOS LANÇADOS NO SISTEMA: " +
                    ", ".join(f"{c['campo_sistema']}[{c['codigo']}]={c['valor']:.2f}" for c in self.lancamentos_por_grupo.get('ativo', []))
                )

                if ajustou_subset_ativo:
                    self.log.debug(f"🎯 [ATIVO] Subset aplicado. Soma ATIVO pós-ajuste = {abs(soma_ativo):.2f}")
                else:
                    self.log.debug(f"🟥 [ATIVO] Nenhum subset encontrado que bata com o alvo. Seguiremos com demais regras/erros.")

            soma_ativo = sum(
                v for (campo, codigo), v in totais_por_campo.items()
                if codigo in allowed_codes_ativo
                or any(p in normalize(campo).replace(" ", "") for p in self.nomes_ativo_circulante + self.nomes_ativo_nao_circulante)
            )
            dif_ativo = round(ativo_total_doc - soma_ativo, 2)
            
            # zerar moedinhas do ATIVO (≤ 0,01) pós-subset
            if abs(dif_ativo) <= 0.01 and dif_ativo != 0:
                self.ajustar_valor(
                    [("Outros ativos realizáveis a longo prazo", 33),
                    ("Outros créditos", 17)],
                    dif_ativo,
                    totais_por_campo
                )
                soma_ativo = sum(
                    v for (campo, codigo), v in totais_por_campo.items()
                    if codigo in allowed_codes_ativo
                    or any(p in normalize(campo).replace(" ", "") for p in self.nomes_ativo_circulante + self.nomes_ativo_nao_circulante)
                )
                dif_ativo = round(ativo_total_doc - soma_ativo, 2)

            # ❗️SÓ ERRO SE era caso > tolerância E subset falhou E ainda ficou diferença > tolerância
            if (abs(abs(ativo_total_doc) - abs(soma_ativo)) > tolerancia) and (abs(dif_ativo) > tolerancia) and (not ajustou_subset_ativo):
                self.log.error("✘ ERRO: Diferença entre o valor declarado e a soma dos campos do ATIVO.\n")
                self.log.error(f"Valor declarado: {self.format_br.formatar_valor(ativo_total_doc)} | Soma dos campos: {self.format_br.formatar_valor(soma_ativo)}\n")
                erro_balanco = True
                msgs_erro_balanco.append(
                    "✘ ERRO: Diferença entre o valor declarado e a soma dos campos do ATIVO.\n"
                    f"Valor declarado: {self.format_br.formatar_valor(ativo_total_doc)} | Soma dos campos: {self.format_br.formatar_valor(soma_ativo)}\n"
                )
        elif abs(dif_ativo) > 0:
            if abs(dif_ativo) <= tolerancia:
                self.log.info(f"⚠️ Diferença no ATIVO ({dif_ativo:.2f}) ajustada automaticamente.")
                chaves_ativo = [
                    ("Outros ativos realizáveis a longo prazo", 33),
                    ("Outros créditos", 17),
                ]
                self.ajustar_valor(chaves_ativo, dif_ativo, totais_por_campo)
                # 🔁 recomputa
                soma_ativo = sum(
                    v for (campo, codigo), v in totais_por_campo.items()
                    if codigo in list(self.campos_ativo_circulante.values()) + list(self.campos_ativo_nao_circulante.values())
                    or any(p in normalize(campo).replace(" ", "") for p in self.nomes_ativo_circulante + self.nomes_ativo_nao_circulante)
                )
                dif_ativo = round(ativo_total_doc - soma_ativo, 2)
            else:
                self.log.error("✘ ERRO: Diferença entre o valor declarado e a soma dos campos do ATIVO.\n")
                self.log.error(f"Valor declarado: {self.format_br.formatar_valor(ativo_total_doc)} | Soma dos campos: {self.format_br.formatar_valor(soma_ativo)}\n")
                erro_balanco = True
                msgs_erro_balanco.append(
                    "✘ ERRO: Diferença entre o valor declarado e a soma dos campos do ATIVO.\n"
                    f"Valor declarado: {self.format_br.formatar_valor(ativo_total_doc)} | Soma dos campos: {self.format_br.formatar_valor(soma_ativo)}\n"
                )

        # --- VALIDAÇÃO DO PASSIVO ---
        if abs(abs(passivo_total_doc) - abs(ativo_total_doc)) < 0.01:
            # Caso 1: Ativo = Passivo → calcula passivo exigível
            passivo_exigivel_esperado = passivo_total_doc - patrimonio_total_doc
            valor_esperado_passivo = passivo_exigivel_esperado
            dif_passivo = passivo_exigivel_esperado - abs(soma_passivo)

        else:
            # Caso 2: Passivo = Ativo - Patrimônio Líquido
            valor_esperado_passivo = abs(passivo_total_doc)
            dif_passivo = abs(passivo_total_doc) - abs(soma_passivo)
        self.log.debug(
            f"🧪 [PASSIVO] Diferença (|PASSIVO decl.| - |soma|)={abs(dif_passivo):.2f}. "
            f"Tentando selecionar subset que some a |PASSIVO|={valor_esperado_passivo:.2f}…"
        )

        soma_passivo_patrimonio = abs(soma_passivo + soma_patrimonio) 
        dif_passivo_ativo = abs(soma_passivo_patrimonio - soma_ativo)
        if soma_ativo > 0:
            if dif_passivo_ativo == 0 and abs(abs(soma_ativo) - abs(ativo_total_doc)) == 0:
                self.log.info("Ativo está igual ao passivo + patrimônio e bate com o declarado.")
                return False, []  # sem erro
            elif dif_passivo_ativo <= 0.01 and abs(abs(soma_ativo) - abs(ativo_total_doc)) <= 0.01:
                # (1) encosta o ATIVO no declarado (se faltar/sobrar 0,01)
                dif_ativo_res = round(ativo_total_doc - soma_ativo, 2)
                if abs(dif_ativo_res) <= 0.01 and dif_ativo_res != 0:
                    self.ajustar_valor(
                        [("Outros ativos realizáveis a longo prazo", 33),
                        ("Outros créditos", 17)],
                        dif_ativo_res,
                        totais_por_campo
                    )
                    soma_ativo = sum(
                        v for (campo, codigo), v in totais_por_campo.items()
                        if codigo in allowed_codes_ativo
                        or any(p in normalize(campo).replace(" ", "") for p in self.nomes_ativo_circulante + self.nomes_ativo_nao_circulante)
                    )

                # (2) agora encosta PASSIVO+PL no ATIVO (assinando a diferença!)
                dif_lados_res = round(soma_ativo - (soma_passivo + soma_patrimonio), 2)
                if abs(dif_lados_res) <= 0.01 and dif_lados_res != 0:
                    self.ajustar_valor(
                        [("Outros passivos de longo prazo", 71),
                        ("Outros passivos circulantes", 63),
                        ("Lucros Acumulados", 85) if dif_lados_res > 0 else ("Prejuízos Acumulados", 86)],
                        dif_lados_res,  # + aumenta PASSIVO/PL; - reduz PASSIVO/PL
                        totais_por_campo
                    )

                self.log.info("Ativo está igual ao passivo + patrimônio e bate com o declarado (ajustado a centavos).")
                return False, []  # sem erro
        # Se a soma do PASSIVO está MAIOR que o esperado (dif_passivo < 0),
        # tenta remover isolados do PASSIVO.
        if dif_passivo < 0:
            if abs(dif_passivo) <= tolerancia:
                self.log.info(f"⚠️ Diferença no PASSIVO ({dif_passivo:.2f}) ajustada automaticamente.")
                chaves_passivo = [
                    ("Outros passivos de longo prazo", 71),
                    ("Outros passivos circulantes", 63),
                    ("Lucros Acumulados", 85) if dif_passivo > 0 else ("Prejuízos Acumulados", 86)
                ]
                self.ajustar_valor(chaves_passivo, dif_passivo, totais_por_campo)
            else:
                ajustou_subset_passivo = self._ajustar_por_subset_lancados(
                    diferenca_abs=abs(dif_passivo),
                    lancamentos=self.lancamentos_por_grupo.get("passivo", []),
                    totais_por_campo=totais_por_campo,
                    allowed_codes=allowed_codes_passivo,
                    lado_label="PASSIVO",
                    target_total_abs=valor_esperado_passivo,  # 🆕 seleciona subset que soma ao alvo
                )

                # LOG dos lançados no PASSIVO (após tentativa)
                self.log.debug(
                    "📋 [PASSIVO] CAMPOS LANÇADOS NO SISTEMA: " +
                    ", ".join(f"{c['campo_sistema']}[{c['codigo']}]={c['valor']:.2f}" for c in self.lancamentos_por_grupo.get('passivo', []))
                )
                if ajustou_subset_passivo:
                    self.log.debug(f"🎯 [PASSIVO] Subset aplicado. Soma PASSIVO pós-ajuste = {abs(soma_passivo):.2f}")
                else:
                    self.log.debug(f"🟥 [PASSIVO] Nenhum subset encontrado que bata com o alvo. Seguiremos com demais regras/erros.")

            # 🔁 recomputa sempre
            soma_passivo = sum(
                v for (campo, codigo), v in totais_por_campo.items()
                if codigo in allowed_codes_passivo
                or any(p in normalize(campo).replace(" ", "") for p in self.nomes_passivo_circulante + self.nomes_passivo_nao_circulante)
            )
            if abs(abs(passivo_total_doc) - abs(ativo_total_doc)) < 0.01:
                dif_passivo = round((abs(passivo_total_doc) - abs(patrimonio_total_doc)) - abs(soma_passivo), 2)
            else:
                dif_passivo = round(abs(passivo_total_doc) - abs(soma_passivo), 2)

            # zerar moedinhas do PASSIVO/PL (≤ 0,01) pós-subset
            if abs(dif_passivo) <= 0.01 and dif_passivo != 0:
                self.ajustar_valor(
                    [("Outros passivos de longo prazo", 71),
                    ("Outros passivos circulantes", 63),
                    ("Lucros Acumulados", 85) if dif_passivo > 0 else ("Prejuízos Acumulados", 86)],
                    dif_passivo,
                    totais_por_campo
                )
                soma_passivo = sum(
                    v for (campo, codigo), v in totais_por_campo.items()
                    if codigo in allowed_codes_passivo
                    or any(p in normalize(campo).replace(" ", "") for p in self.nomes_passivo_circulante + self.nomes_passivo_nao_circulante)
                )
                if abs(abs(passivo_total_doc) - abs(ativo_total_doc)) < 0.01:
                    dif_passivo = round((abs(passivo_total_doc) - abs(patrimonio_total_doc)) - abs(soma_passivo), 2)
                else:
                    dif_passivo = round(abs(passivo_total_doc) - abs(soma_passivo), 2)

            # ❗️SÓ ERRO SE era caso > tolerância E subset falhou E ainda ficou diferença > tolerância
            if (abs(dif_passivo) > tolerancia) and (not ajustou_subset_passivo):
                if abs(abs(passivo_total_doc) - abs(ativo_total_doc)) < 0.01:
                    # caso “passivo exigível”
                    msgs_erro_balanco.append(
                        "✘ ERRO: Diferença entre o valor esperado e a soma dos campos do PASSIVO EXIGÍVEL.\n"
                        f"Valor esperado: {self.format_br.formatar_valor(passivo_total_doc - patrimonio_total_doc)} | "
                        f"Soma dos campos: {self.format_br.formatar_valor(soma_passivo)}\n"
                    )
                else:
                    msgs_erro_balanco.append(
                        "✘ ERRO: Diferença entre o valor declarado e a soma dos campos do PASSIVO.\n"
                        f"Valor declarado: {self.format_br.formatar_valor(passivo_total_doc)} | "
                        f"Soma dos campos: {self.format_br.formatar_valor(soma_passivo)}\n"
                    )
                erro_balanco = True
        elif abs(dif_passivo) > 0:
            if abs(dif_passivo) <= tolerancia:
                self.log.info(f"⚠️ Diferença no PASSIVO ({dif_passivo:.2f}) ajustada automaticamente.")
                chaves_passivo = [
                    ("Outros passivos de longo prazo", 71),
                    ("Outros passivos circulantes", 63),
                    ("Lucros Acumulados", 85) if dif_passivo > 0 else ("Prejuízos Acumulados", 86)
                ]
                self.ajustar_valor(chaves_passivo, dif_passivo, totais_por_campo)
            else:
                if abs(abs(passivo_total_doc) - abs(ativo_total_doc)) < 0.01:
                    self.log.error("✘ ERRO: Diferença entre o valor esperado e a soma dos campos do PASSIVO EXIGÍVEL.")
                    self.log.error(f"Valor esperado: {self.format_br.formatar_valor(passivo_exigivel_esperado)} | Soma dos campos: {self.format_br.formatar_valor(soma_passivo)}")
                    msgs_erro_balanco.append(
                        "✘ ERRO: Diferença entre o valor esperado e a soma dos campos do PASSIVO EXIGÍVEL.\n"
                        f"Valor esperado: {self.format_br.formatar_valor(passivo_exigivel_esperado)} | Soma dos campos: {self.format_br.formatar_valor(soma_passivo)}\n"
                    )
                else:
                    self.log.error("✘ ERRO: Diferença entre o valor declarado e a soma dos campos do PASSIVO.")
                    self.log.error(f"Valor declarado: {self.format_br.formatar_valor(passivo_total_doc)} | Soma dos campos: {self.format_br.formatar_valor(soma_passivo)}")
                    msgs_erro_balanco.append(
                        "✘ ERRO: Diferença entre o valor declarado e a soma dos campos do PASSIVO.\n"
                        f"Valor declarado: {self.format_br.formatar_valor(passivo_total_doc)} | Soma dos campos: {self.format_br.formatar_valor(soma_passivo)}\n"
                    )
                erro_balanco = True

        if abs(abs(ativo_total_doc) - abs(passivo_total_doc)) > 0.01:
            if abs(abs(ativo_total_doc) - abs(passivo_total_doc + patrimonio_total_doc)) > tolerancia:
                self.log.error("✘ ERRO: Ativo e Passivo não fecham com o Patrimônio Líquido.")
                erro_balanco = True
                msgs_erro_balanco = []
                msgs_erro_balanco.append(
                    "✘ ERRO: VALOR DO ATIVO E PASSIVO NÃO SÃO IGUAIS OU NÃO FECHAM COM O PATRIMÔNIO LÍQUIDO.\n"
                    f"Ativo Total: {self.format_br.formatar_valor(ativo_total_doc)}, "
                    f"Passivo Total: {self.format_br.formatar_valor(passivo_total_doc)}, "
                    f"Patrimônio Líquido: {self.format_br.formatar_valor(patrimonio_total_doc)}"
                )
         #
        return erro_balanco, msgs_erro_balanco
    
    def extrair_campos_e_valores(self, texto: str, max_por_campo: int = 2, palavra_divisora: str = "PASSIVO"):
        
        """
        Retorna:
        {
        "ano_1": {"Componentes do Ativo": {...}, "Componentes do Passivo e Patrimônio Líquido": {...}},
        "ano_2": {"Componentes do Ativo": {...}, "Componentes do Passivo e Patrimônio Líquido": {...}}
        }
        """
        # ---- REGEX ATUALIZADAS ----
        VALOR_BR_RE = re.compile(
            r"""^
                \(?\s*                      # parêntese inicial opcional
                -?\s*                       # sinal negativo antes (opcional)
                \d{1,3}(?:\.\d{3})*,\d{2}   # número BR
                (?:\s*(?:[DC]|CR|DB))?      # sufixo opcional D/C/CR/DB
                \s*-?\s*                    # sinal negativo depois (opcional)
                \)?                         # parêntese final opcional
            $""",
            re.IGNORECASE | re.VERBOSE
        )

        SO_NUMERO_SEM_VIRGULA_RE = re.compile(r'^[\d\.]+$')
        linhas = [l.strip() for l in texto.splitlines() if l.strip()]

        grupos = {
            "Componentes do Ativo": defaultdict(list),
            "Componentes do Passivo e Patrimônio Líquido": defaultdict(list),
        }

        grupo_atual = "Componentes do Ativo"
        campo_atual = None
        divisor_upper = palavra_divisora.upper()

        for linha in linhas:
            # ignora ruído (número sem vírgula)
            if SO_NUMERO_SEM_VIRGULA_RE.fullmatch(linha) and ',' not in linha:
                continue

            # é valor?
            if VALOR_BR_RE.fullmatch(linha):
                if campo_atual is not None:
                    bucket = grupos[grupo_atual][campo_atual]
                    if len(bucket) < max_por_campo:
                        bucket.append(linha)
                continue

            # é CAMPO (título/descrição)
            campo = " ".join(linha.split())  # normaliza espaços
            campo = re.sub(r"\(\s*-\s*\)", "(-)", campo)  # "( -)" -> "(-)"

            # se bateu o divisor, muda grupo daqui pra frente
            if campo.upper().startswith(divisor_upper):
                grupo_atual = "Componentes do Passivo e Patrimônio Líquido"

            campo_atual = campo

        # Monta por ano
        saida = {
            "ano_1": {
                "Componentes do Ativo": {},
                "Componentes do Passivo e Patrimônio Líquido": {}
            },
            "ano_2": {
                "Componentes do Ativo": {},
                "Componentes do Passivo e Patrimônio Líquido": {}
            },
        }

        for nome_grupo, dicionario in grupos.items():
            for campo, valores in dicionario.items():
                if len(valores) >= 1:
                    saida["ano_1"][nome_grupo][campo] = valores[0]
                if len(valores) >= 2:
                    saida["ano_2"][nome_grupo][campo] = valores[1]
                # 3º+ valores são ignorados por regra

        return saida

    def substituir_componentes_por_lista_nova(self, data_base: dict, lista_nova: dict, tolerancia: Decimal = Decimal("0.05")) -> dict:
        """
        Substitui componentes no data_base usando a lista_nova (que pode ter só ano_1 OU só ano_2).
        Só aplica substituição para anos que casarem pelos totais (Ativo; fallback Passivo).
        """

        # 👇 to_dec mantida AQUI dentro
        def to_dec(br):
            if not br:
                return Decimal("0")
            s = str(br).strip()

            # parênteses como negativo: "(388.662,19)" -> "-388.662,19"
            if s.startswith("(") and s.endswith(")"):
                s = "-" + s[1:-1].strip()

            # remove sufixos DB/CR/D/C com espaço antes
            for suf in ("DB", "D", "CR", "C"):
                suf_sp = " " + suf
                if s.upper().endswith(suf_sp):
                    s = s[:-len(suf_sp)]

            # "5.000,00-" -> "-5.000,00"
            if s.endswith("-"):
                s = "-" + s[:-1].strip()

            m = re.search(r"-?\d{1,3}(?:\.\d{3})*,\d{2}", s)
            if not m:
                return Decimal("0")
            return Decimal(m.group(0).replace(".", "").replace(",", "."))

        def dict_to_list(d):
            return [{"Nome": k, "Valor": v} for k, v in d.items()]

        # deep copy
        data = json.loads(json.dumps(data_base))
        balancos = data.get("Balanços") or data.get("Balancos") or {}
        if not isinstance(balancos, dict) or not balancos:
            self.log.warning("✘ data_base sem chave 'Balanços'.")
            return data

        # Monte a lista de candidatos disponíveis (pode ter 1 ou 2)
        candidatos = []

        def pegar_total(dic, chaves):
            for k in chaves:
                v = dic.get(k)
                if v:
                    return v
            return None

        for label in ("ano_1", "ano_2"):
            bloco = lista_nova.get(label) or {}
            comp_ativo = (bloco.get("Componentes do Ativo") or {})
            comp_pl    = (bloco.get("Componentes do Passivo e Patrimônio Líquido") or {})
            a_total = to_dec(pegar_total(comp_ativo, ["ATIVO", "ATIVO TOTAL", "TOTAL DO ATIVO", "TOTAL ATIVO"]))
            p_total = to_dec(pegar_total(comp_pl, ["PASSIVO", "PASSIVO TOTAL", "TOTAL DO PASSIVO", "TOTAL PASSIVO"]))
            if comp_ativo or comp_pl:
                candidatos.append({
                    "label": label,
                    "ativo_total": a_total,
                    "passivo_total": p_total,
                    "comp_ativo_list": dict_to_list(comp_ativo) if comp_ativo else [],
                    "comp_pl_list": dict_to_list(comp_pl) if comp_pl else []
                })

        if not candidatos:
            self.log.debug("⚠ Lista nova sem candidatos válidos (ano_1/ano_2 vazios). Nada a substituir.")
            return data

        # Para cada ano do data_base, escolhe o melhor candidato e substitui (se houver match)
        for ano, info in balancos.items():
            ativo_total_doc = to_dec(info.get("Ativo Total:", info.get("Ativo Total")))
            pass_total_doc  = to_dec(info.get("Passivo Total:", info.get("Passivo Total")))

            # 1) tenta casar pelo Ativo
            melhor = None
            melhor_diff = None
            for c in candidatos:
                diff = abs(ativo_total_doc - c["ativo_total"])
                if melhor is None or diff < melhor_diff:
                    melhor = c
                    melhor_diff = diff

            # Se ativo não bate dentro da tolerância, tenta pelo Passivo
            if melhor is None or melhor_diff is None or melhor_diff > tolerancia:
                melhor = None
                melhor_diff = None
                for c in candidatos:
                    diff = abs(pass_total_doc - c["passivo_total"])
                    if melhor is None or diff < melhor_diff:
                        melhor = c
                        melhor_diff = diff

            # Só substitui se achou algum candidato com componentes não vazios
            if melhor and (melhor["comp_ativo_list"] or melhor["comp_pl_list"]):
                if melhor["comp_ativo_list"]:
                    info["Componentes do Ativo:"] = melhor["comp_ativo_list"]
                if melhor["comp_pl_list"]:
                    info["Componentes do Passivo e Patrimônio Líquido:"] = melhor["comp_pl_list"]
                self.log.debug(f"🔄 Ano {ano} -> substituído por {melhor['label']} (diff≈{melhor_diff})")
            else:
                self.log.debug(f"ℹ Ano {ano}: nenhum candidato adequado para substituir (mantido).")

        return data
