from typing import Tuple, Dict, Any

from app.validators.base import ValidadorBase
from app.utils.helpers import normalize
from app.validators.registro import registrar_validador  
from difflib import SequenceMatcher
from app.validators.helpers.pj import identificar_subtitulos_por_hierarquia, interpretar_valor_bruto

@registrar_validador("dre", "demonstração de resultado", "demonstração do resultado do execercício")
class ValidadorDRE(ValidadorBase):
    def validar(self) -> bool:
        #breakpoint()
        self.mapeamento_dre = {
            "custo": ("Custo Produtos Vendidos", 6),
            "cmv": ("Custo Produtos Vendidos", 6),
            "cpv": ("Custo Produtos Vendidos", 6),
            "csv": ("Custo Produtos Vendidos", 6),
            "Deduções": ("Abatimentos e Devoluções", 2),
            "Devoluções": ("Abatimentos e Devoluções", 2),
            "Abatimentos": ("Abatimentos e Devoluções", 2),
            "ROB": ("RECEITA OPERACIONAL BRUTA", 1),
            "Receita Bruta": ("RECEITA OPERACIONAL BRUTA", 1),
            "Vendas": ("Despesas com Vendas", 9),
            "Administrativas": ("Despesas Administrativas", 10),
            "Provisões": ("Provisões Tributação e Impostos pagos", 25),
        }

        self.campos_sistema_dre = {
            "RECEITA OPERACIONAL BRUTA": 1,
            "Abatimentos e Devoluções": 2,
            "Impostos Faturados": 3,
            "Custo Produtos Vendidos": 6,
            "Despesas com Vendas": 9,
            "Despesas Administrativas": 10,
            "Receitas Financeiras": 12,
            "Despesas Financeiras": 13,
            "Desp.c/amortização de ágio em investimento": 14,
            "Desp.c/depreciação e amortização": 15,
            "Outras receitas operacionais": 16,
            "Outras despesas operacionais": 17,
            "Resultado de equivalência patrimonial": 18,
            "Receitas não operacionais": 21,
            "Despesas não operacionais": 22,
            "Saldo da Correção Monetária": 23,
            "Provisões Tributação e Impostos pagos": 25,
            "Participações/contribuições estatutárias": 26,
            "Reversão de juros s/capital próprio": 27
        }

        self.log.info("Iniciando Validação do DRE...")
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de DRE encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_dre_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )
    
    def validar_dre_individual(self):
        # 🔎 Detecta se veio múltiplos anos (novo formato da IA)
        if "DREs" in self.doc:
            dados_por_ano = self.doc["DREs"]
        else:
            dados_por_ano = {"Único": self.doc}  # compatibilidade com IA antiga

        primeiro_ano, primeiro_bloco = next(iter(dados_por_ano.items()))
        self.nome_documento = (self.extrair_nome_documento(primeiro_bloco) or '').upper()
        self.cnpj = primeiro_bloco.get("CNPJ:", "")
        if self.cnpj:
            try:
                soma_digitos_cnpj = sum(int(d) for d in self.format_br.digits(self.cnpj))
            except:
                soma_digitos_cnpj = 0
            if soma_digitos_cnpj < 5:
                self.cnpj = "CNPJ NAO IDENTIFICADO" 
        else:
            self.cnpj = 'CNPJ NAO IDENTIFICADO'
        self.data_referencia = primeiro_bloco.get("Data de Referência:", "")

        output_data = [["Documento lido:", self.file]]
        output_data.append(["Nome:", self.nome_documento.upper()])
        output_data.append(["CNPJ:", self.cnpj])
        output_data.append(["Data de Referência:", self.data_referencia])

        dados_mua_geral = {
            "CNPJ": self.cnpj,
            "Nome_Empresa": self.nome_documento.upper(),
            "Anos": {}
        }

        self.data_base = self.doc
        houve_erro_em_algum_ano = False

        for ano, dados_ano in dados_por_ano.items():
            output_data_ano = []
            output_data_ano.append([])
            output_data_ano.append([f"======== ANO {ano} ========", ""])
            try:
                #componentes = self.extrair_valor(self.doc,  False, "Componentes da DRE", "Componentes da DRE:", "Componentes do DRE", "Componentes do DRE:")
                componentes = self.extrair_valor(dados_ano, False, "Totais por Título", "Totais por Título:", "Totais por Titulo", "Totais por Titulo:", "totais por titulo", "totais por titulo:")

                lista_dre = []
                totais_por_campo = {}

                for item in componentes:
                    nome = self.extrair_valor(item,  False, "Nome", "Nome:", "nome", "nome:") 
                    valor = self.extrair_valor(item, True, "Valor", "Valor:", "valor", "valor:")

                    if nome and valor is not None:
                        try:
                            v = float(valor)
                            # Heurística: IA leu "19.585,04" como 19.58504  → recuperar "19585.04"
                            v_fix = self._fix_magnitude_if_misparsed(v)
                            if v_fix != 0:
                                lista_dre.append((nome.strip(), v_fix))
                        except:
                            continue


                if not lista_dre:

                    self.log.debug("⚠️ Nenhum item válido encontrado na DRE.")
                    #output_data.extend(output_data_ano)
                    continue

                rob_valor_raw = self.extrair_valor(dados_ano, True, "Renda Operacional Bruta:", "Renda Operacional Bruta")

                rob_valor = 0.0
                try:
                    rob_valor = (
                        float(rob_valor_raw) 
                        if isinstance(rob_valor_raw, (int, float))
                        else interpretar_valor_bruto(str(rob_valor_raw), "dre")
                    )
                except Exception:
                    pass
                # Construir hierarquia
                hierarquia = identificar_subtitulos_por_hierarquia(lista_dre)
                # Garante que campos isolados também apareçam
                campos_em_hierarquia = set()
                for pai, filhos in hierarquia.items():
                    campos_em_hierarquia.add(pai)
                    campos_em_hierarquia.update(filhos)

                for nome, valor in lista_dre:
                    if (nome, valor) not in campos_em_hierarquia:
                        self.log.debug(f"📥 Campo isolado detectado e incluído como topo: {nome} ({valor})")
                        hierarquia[(nome, valor)] = []
                # Exibir no terminal
                self.log.info("📊 HIERARQUIA DRE:")
                def print_dre_hierarquia(campo, nivel=0):
                    indent = "   " * nivel
                    self.log.info(f"{indent}- {campo[0]} ({self.format_br.formatar_valor(campo[1])})")
                    for filho in hierarquia.get(campo, []):
                        print_dre_hierarquia(filho, nivel + 1)

                topos = [campo for campo in hierarquia if all(campo not in filhos for filhos in hierarquia.values())]
                for campo in lista_dre:
                    if campo in topos:
                        print_dre_hierarquia(campo)

                # 🔍 Identificar valores de referência
                lucro_liquido_raw = self.extrair_valor(dados_ano, True, "Lucro Líquido do Exercício:", "Lucro Líquido do Exercício")
                lucro_liquido_valor = 0.0
                try:
                    lucro_liquido_valor = interpretar_valor_bruto(str(lucro_liquido_raw), "dre")
                except:
                    pass

                # 🚫 Remover campos com valor igual ao ROB ou LL
                topos_filtrados = []
                for topo in topos:
                    nome_topo, valor_topo = topo
                    if round(valor_topo, 2) in (round(rob_valor, 2), round(lucro_liquido_valor, 2)):
                        self.log.debug(f"🧹 Removendo topo duplicado: {nome_topo} ({valor_topo})")
                        continue  # ignora este topo e seus filhos
                    topos_filtrados.append(topo)

                topos = topos_filtrados

                # Exibir no PDF
                output_data_ano.append(["ESTRUTURA DA DRE (HIERARQUIA):"])
                output_data_ano.append(["ROB:", self.format_br.formatar_valor(rob_valor)])

                # 🔎 Receita Líquida (nomes comuns)
                receita_liquida_raw = (
                    self.extrair_valor(dados_ano, True, "Receita Líquida:", "Receita Líquida")
                    or self.extrair_valor(dados_ano, True, "Receita Operacional Líquida:", "Receita Operacional Líquida")
                    or self.extrair_valor(dados_ano, True, "ROL:", "ROL")
                    or self.extrair_valor(dados_ano, True, "Lucro Líquido do Exercício", "Lucro Líquido do Exercício:")
                )
                receita_liquida_valor = None
                try:
                    receita_liquida_valor = (
                        float(receita_liquida_raw)
                        if isinstance(receita_liquida_raw, (int, float))
                        else (interpretar_valor_bruto(str(receita_liquida_raw), "dre") if receita_liquida_raw is not None else None)
                    )
                except Exception:
                    receita_liquida_valor = None

                def append_dre_pdf(campo, nivel=0):
                    indent = "  " * nivel
                    output_data_ano.append([f"{indent}- {campo[0]}: {self.format_br.formatar_valor(campo[1])}"])
                    for filho in hierarquia.get(campo, []):
                        append_dre_pdf(filho, nivel + 1)

                for topo in topos:
                    append_dre_pdf(topo)
                
                output_data_ano.append(["Resultado Líquido:", self.format_br.formatar_valor(receita_liquida_valor)])
                
                # ✅ Verificação ROB → RL (1% de tolerância da ROB)
                # ✅ 1ª validação com os valores da IA (sem mexer em nada)
                verif = self.verificar_valores_dre(topos, rob_valor, receita_liquida_valor, tol_pct=0.01)

                # ❌ Se não bateu, TENTA flip de 1 campo por vez e revalida
                if not verif.get('ok', False):
                    encontrou, topos_corrigidos, campo_invertido, verif_flip = self._tentar_flip_um_campo_pos_erro(
                        topos, rob_valor, receita_liquida_valor, tol_pct=0.01
                    )
                    if encontrou:
                        # aplica os topos corrigidos e a validação vencedora
                        topos = topos_corrigidos
                        verif = verif_flip
                        if campo_invertido:
                            #self.log.debug(f"🔁 Correção automática: invertido sinal de '{campo_invertido[0]}' para fechar a RL.")
                            #output_data_ano.append(["🔁 Correção automática (sinal invertido para fechar RL):", campo_invertido[0]])
                            # (opcional) exibir RL antes/depois
                            rl_apos = self._rl_from_topos(topos, rob_valor)
                            #output_data_ano.append(["RL pela soma (após correção):", self.format_br.formatar_valor(rl_apos)])

                # segue fluxo normal usando o 'verif' resultante
                pais_para_delta = verif['pais_selecionados']


                # Se não bater, registre como no Balanço (“deu” x “deveria”)
                if receita_liquida_valor is not None and verif['rl_calculada'] is not None and not verif['exato']:
                    output_data_ano.append([])
                    if verif['ok']:
                        self.log.info("✓ Aceito por tolerância (1% ROB)")
                        #output_data_ano.append(["✓ Aceito por tolerância (1% ROB)"])
                        #output_data_ano.append(["Receita Líquida informada:", self.format_br.formatar_valor(verif['rl_informada'])])
                        #output_data_ano.append(["Receita Líquida pela soma dos campos (antes do ajuste):", self.format_br.formatar_valor(verif['rl_calculada'])])
                        #output_data_ano.append(["Ajuste incluído:", self.format_br.formatar_valor(verif['ajuste'])])
                    else:
                        output_data_ano.append(["✘ ERRO NA VALIDAÇÃO DA DRE"])
                        houve_erro_em_algum_ano = True
                        #output_data_ano.append(["Receita Líquida informada:", self.format_br.formatar_valor(verif['rl_informada'])])
                        #output_data_ano.append(["Receita Líquida pela soma dos campos:", self.format_br.formatar_valor(verif['rl_calculada'])])
                        output_data_ano.append(["Diferença encontrada nos campos:", self.format_br.formatar_valor(verif['desvio'])])



                # Adiciona o ROB como um campo isolado para validação
                if rob_valor:
                    self.log.debug(f"📌 Incluindo ROB como componente individual: R$ {rob_valor}")
                    totais_por_campo[("RECEITA OPERACIONAL BRUTA", 1)] = rob_valor
                
                # 🔍 Validar campos com base na hierarquia
                if pais_para_delta:
                    for topo in topos:
                        if topo not in pais_para_delta:
                            continue  # ⚠️ NÃO lançar outros topos
                        nome_topo, valor_topo = topo
                        filhos = hierarquia.get(topo, [])
                        self.log.debug(f"🔍 Validando campo: {nome_topo} ({valor_topo})")
                        # Tenta lançar o campo pai sem fallback
                        campo, codigo = self.encontrar_campo_dre(
                            nome_topo, valor_topo,
                            campos_sistema_dre=self.campos_sistema_dre,
                            mapeamento_dre=self.mapeamento_dre,
                            permitir_fallback=False
                        )

                        if codigo:
                            # Pai tem código → ignora filhos
                            self.log.debug(f"📌 Campo pai encontrado: {campo} ({codigo})")
                            totais_por_campo[(campo, codigo)] = totais_por_campo.get((campo, codigo), 0) + valor_topo
                            continue
                        self.log.debug(f"⚠️ Campo pai sem código: {nome_topo} ({valor_topo})")        
                        if filhos:
                            # Pai não tem código, mas tem filhos → tenta lançar os filhos
                            self.log.debug(f"🔍 Pai sem código, verificando filhos...")
                            for nome_filho, valor_filho in filhos:
                                campo_filho, codigo_filho = self.encontrar_campo_dre(
                                    nome_filho, valor_filho,
                                    campos_sistema_dre=self.campos_sistema_dre,
                                    mapeamento_dre=self.mapeamento_dre,
                                    permitir_fallback=False
                                )

                                if codigo_filho:
                                    # Filho tem código → registra normalmente
                                    self.log.debug(f"📌 Campo filho encontrado: {campo_filho} ({codigo_filho})")
                                    totais_por_campo[(campo_filho, codigo_filho)] = totais_por_campo.get((campo_filho, codigo_filho), 0) + valor_filho
                                else:
                                    # Fallback no filho
                                    self.log.debug(f"⚠️ Campo filho sem código, tentando fallback...")
                                    campo_fallback, cod_fallback = self.encontrar_campo_dre(
                                        nome_filho, valor_filho,
                                        campos_sistema_dre=self.campos_sistema_dre,
                                        mapeamento_dre=self.mapeamento_dre,
                                        permitir_fallback=True
                                    )
                                    self.log.debug(f"📌 Campo fallback encontrado: {campo_fallback} ({cod_fallback})")
                                    totais_por_campo[(campo_fallback, cod_fallback)] = totais_por_campo.get((campo_fallback, cod_fallback), 0) + valor_filho
                        else:
                            # Nenhum campo nem filho → fallback no pai
                            self.log.debug(f"⚠️ Pai sem código e sem filhos, tentando fallback...")
                            campo_fallback, cod_fallback = self.encontrar_campo_dre(
                                nome_topo, valor_topo,
                                campos_sistema_dre=self.campos_sistema_dre,
                                mapeamento_dre=self.mapeamento_dre,
                                permitir_fallback=True
                            )
                            self.log.debug(f"📌 Campo fallback encontrado: {campo_fallback} ({cod_fallback})")
                            totais_por_campo[(campo_fallback, cod_fallback)] = totais_por_campo.get((campo_fallback, cod_fallback), 0) + valor_topo
                output_data_ano.append([])
                output_data_ano.append(["CAMPOS PARA LANÇAMENTO NO MUA:", ""])
                # 🔚 RECONCILIAÇÃO FINAL — garantir que os campos lançados batem a RL do documento
                if receita_liquida_valor is not None and totais_por_campo:
                    soma_contrib = 0.0

                    for (campo, codigo), v in totais_por_campo.items():
                        # Ignora ROB aqui (código 1), pois RL = ROB - soma_contrib
                        if int(codigo) == 1:
                            continue

                        v = float(v)
                        campo_norm = normalize(campo)

                        # Heurística simples de receita (não cria função nova):
                        # - tem "receita" no nome  OU  código em grupo de receitas
                        is_receita = (
                            ("receita" in campo_norm)
                            or int(codigo) in {12, 16, 18, 21, 23, 27}  # Receitas Financeiras, Outras Receitas Operacionais, REP, Receitas não operacionais, Saldo correção monetária, Reversão de juros SCP
                        )

                        # Despesa => contribuição +|v| ; Receita => contribuição -|v|
                        soma_contrib += (-abs(v) if is_receita else abs(v))

                    rl_campos = float(rob_valor) - soma_contrib
                    delta_final = float(receita_liquida_valor) - rl_campos  # >0 faltou RECEITA ; <0 faltou DESPESA

                    # Se ainda ficou diferença (centavos à prova)
                    if abs(delta_final) > 0.005:
                        if delta_final > 0:
                            campo_adj = "Outras receitas operacionais"
                            cod_adj = self.campos_sistema_dre[campo_adj]  # 16
                        else:
                            campo_adj = "Outras despesas operacionais"
                            cod_adj = self.campos_sistema_dre[campo_adj]  # 17

                        totais_por_campo[(campo_adj, cod_adj)] = totais_por_campo.get((campo_adj, cod_adj), 0.0) + delta_final

                        # (opcional) registrar no PDF
                        #output_data_ano.append(["🔧 Ajuste final refletido no MUA:", f"{campo_adj} {self.format_br.formatar_valor(delta_final)}"])
                for (campo, codigo), valor in sorted(totais_por_campo.items(), key=lambda x: x[0][1]):
                    valor_formatado = self.format_br.formatar_valor(abs(valor))  # <- aplica abs aqui
                    output_data_ano.append([f"{campo}:", valor_formatado])
                dados_mua_geral["Anos"][ano] = {
                    "ROB": rob_valor,
                    "RL": receita_liquida_valor,
                    "Lançamentos": { (campo, codigo): valor for (campo, codigo), valor in totais_por_campo.items() }
                }
                output_data.extend(output_data_ano)
            except Exception as e:
                houve_erro_em_algum_ano = True
                output_data_ano.append([f"⚠ Erro ao validar ano {ano}:", str(e)])
                output_data.extend(output_data_ano)
        
        # 5) Regras (planilha > fallback)
        regras: Dict[str, Any] = {}
        if getattr(self, "regras_mua", None):
            nomes = ["DRE", "dre", "demonstração de resultado", "demonstração do resultado"]
            regras = self.regras_mua.get_doc(nomes)

        linhas_regras = self.exibir_regras_doc(regras)
        output_data.extend(linhas_regras)
        row = self._nome_validation_row()
        if row:
            output_data.append(row)  
        self.sections.append((self.type_name, output_data))
        self.log.info("✅ Validação DRE concluída com sucesso.")
        return not houve_erro_em_algum_ano
    
    def _fix_magnitude_if_misparsed(self, v: float) -> float:
        """
        Conserta casos típicos: "19.585,04" → 19.58504 (IA) → 19585.04 (correto)
        Regras:
        - Se parte inteira < 1000 e parte decimal tiver 3+ dígitos (ex.: 58504),
        então interprete o ponto como separador de milhar perdido.
        Ex.: 19.58504  -> "19" + "58504" -> 19585.04
            43.985     -> "43" + "985" + "00" (assume centavos 00) -> 43985.00
        - Não altera números normais (ex.: 9.85, 485.44, 146655.04).
        """
        s = f"{v:.10f}".rstrip("0").rstrip(".")  # string estável
        if "." not in s:
            return v
        inteiro, frac = s.split(".", 1)

        # já parece normal: inteiro ≥ 1000 ou centavos de 1–2 dígitos
        if len(frac) <= 2 or (inteiro.isdigit() and int(inteiro) >= 1000):
            return v

        # Se inteiro é pequeno e frac tem 3+ dígitos, tratamos como milhar+centavos colados
        if inteiro.isdigit() and int(inteiro) < 1000 and len(frac) >= 3:
            # últimos 2 dígitos = centavos
            cents = frac[-2:]
            milhar = inteiro + frac[:-2]  # concatena resto como milhar
            if milhar.isdigit():
                try:
                    return float(f"{int(milhar)}.{cents}")
                except:
                    return v

        return v

    def encontrar_campo_dre(
        self,
        nome_item: str,
        valor_item: float,
        campos_sistema_dre: dict,
        mapeamento_dre: dict,
        permitir_fallback: bool = True
    ) -> Tuple[str, int]:

        nome_normalizado = normalize(nome_item).replace("(-)", "").strip()
        self.log.debug(f"🔍 Iniciando busca pelo campo DRE: {nome_normalizado} (valor: {valor_item})")
        # 🔍 Mapeamento direto (ex: "Resultado Financeiro" → "Receitas Financeiras")
        for chave, (campo_mapeado, codigo_mapeado) in mapeamento_dre.items():
            if normalize(chave) in nome_normalizado or nome_normalizado in normalize(chave):
                self.log.debug(f"🔍 Mapeamento direto encontrado: {chave} → {campo_mapeado}")
                return campo_mapeado, codigo_mapeado

        # 🔍 Busca por similaridade nos campos do sistema
        melhor_score = 0
        melhor_campo = None
        melhor_codigo = None
        CAMPOS_RESTRITOS_SEM_FALLBACK = {
            "outras receitas operacionais",
            "outras despesas operacionais",
        }
        for campo, codigo in campos_sistema_dre.items():
            campo_norm = normalize(campo)
            if nome_normalizado in campo_norm or campo_norm in nome_normalizado:
                self.log.debug(f"🔍 Campo exato encontrado: {campo_norm} (código {codigo})")
                if not permitir_fallback and campo_norm in CAMPOS_RESTRITOS_SEM_FALLBACK:
                    self.log.debug(f"⚠️ Campo '{campo}' bloqueado (restrito) com fallback desligado.")
                    continue
                elif "nao" in campo_norm and "nao" not in nome_normalizado:
                    self.log.debug(f"⚠️ Campo '{campo}' não pode ser usado pois 'não' está ausente no campo.")
                    continue
                return campo, codigo
            score = SequenceMatcher(None, nome_normalizado, campo_norm).ratio()
            if score > melhor_score:
                melhor_score = score
                melhor_campo = campo
                melhor_codigo = codigo

        if melhor_score >= 0.8:
            # ⛔ Igual ao balanço: bloqueio também na escolha por similaridade
            if not permitir_fallback and normalize(melhor_campo) in CAMPOS_RESTRITOS_SEM_FALLBACK:
                self.log.debug(f"⚠️ Campo '{melhor_campo}' bloqueado (restrito) com fallback desligado.")
                return None, 0
            elif "não" in melhor_campo and "nao" not in nome_normalizado:
                self.log.debug(f"⚠️ Campo '{campo}' não pode ser usado pois 'não' está ausente no campo.")
                return None, 0
            return melhor_campo, melhor_codigo

        # ⚠️ Fallback se permitido e o campo não tiver filhos
        elif permitir_fallback:
            if valor_item >= 0:
                return "Outras receitas operacionais", campos_sistema_dre["Outras receitas operacionais"]
            else:
                return "Outras despesas operacionais", campos_sistema_dre["Outras despesas operacionais"]

        return None, 0

    def _subset_sum_melhor(self, itens, alvo):
        """
        itens: [(topo_tuple, valor_abs)]
        alvo: float positivo (ROB - RL)
        Retorna (subset, soma_subset, gap) mesmo fora da tolerância.
        """
        itens = sorted(itens, key=lambda x: x[1], reverse=True)
        alvo_c = int(round(alvo * 100))
        n = len(itens)

        melhor_subset = []
        melhor_gap = float("inf")
        melhor_soma_c = 0

        vals_c = [int(round(v * 100)) for _, v in itens]

        def bt(i, soma_c, esc):
            nonlocal melhor_subset, melhor_gap, melhor_soma_c
            gap = abs(alvo_c - soma_c)
            if gap < melhor_gap:
                melhor_gap = gap
                melhor_subset = esc[:]
                melhor_soma_c = soma_c
                if gap == 0:
                    return True
            if i >= n:
                return False
            # inclui i
            esc.append(i)
            if bt(i + 1, soma_c + vals_c[i], esc):
                return True
            esc.pop()
            # não inclui i
            if bt(i + 1, soma_c, esc):
                return True
            return False

        bt(0, 0, [])
        subset = [itens[i] for i in melhor_subset]
        return subset, melhor_soma_c / 100.0, melhor_gap / 100.0

    def verificar_valores_dre(self, topos, rob_valor, receita_liquida_valor, tol_pct=0.01):
        """
        1) Tenta fechar EXATO com combinação de PAIS (subset-sum com contribuições assinadas).
        2) Se não fechar, testa TODOS OS PAIS; se ficar dentro da tolerância, aceita com AJUSTE.
        Retorna:
        {
            'ok': bool,                      # True se exato OU aceito por tolerância (com ajuste)
            'exato': bool,                   # True se subset fechou centavo a centavo
            'usar_todos': bool,              # True se caiu no fallback de "todos os pais"
            'pais_selecionados': set(...),   # conjunto de topos a lançar (subset ou todos)
            'rl_calculada': float,           # ROB - soma_contribuições_do_conjunto
            'rl_informada': float|None,
            'desvio': float,                 # |RL_calc - RL_inf|
            'ajuste': float,                 # quanto falta/sobra p/ RL bater (se for aceitar por tolerância)
            'delta_alvo': float              # ROB - RL_inf (>=0)
        }
        """
        if not rob_valor or receita_liquida_valor is None:
            return {
                'ok': False, 'exato': False, 'usar_todos': False,
                'pais_selecionados': set(), 'rl_calculada': None,
                'rl_informada': receita_liquida_valor, 'desvio': None,
                'ajuste': 0.0, 'delta_alvo': 0.0
            }

        # delta que precisamos explicar (despesa líquida)
        delta_alvo = float(rob_valor) - float(receita_liquida_valor)
        tol = max(abs(rob_valor) * tol_pct, 1.00)

        # contribuições ASSINADAS: despesa(-) -> +|v| ; receita(+) -> -|v|
        candidatos = []
        for topo in topos:
            _, v = topo
            v = float(v)
            contrib = abs(v) if v < 0 else -abs(v)
            candidatos.append((topo, contrib))

        # subset-sum (melhor combinação, pode ter contribuições negativas)
        subset, soma_contrib, gap = self._subset_sum_melhor(candidatos, delta_alvo)
        rl_calc_subset = float(rob_valor) - float(soma_contrib)
        exato = (round(gap * 100) == 0)  # gap em reais -> centavos

        if exato:
            return {
                'ok': True, 'exato': True, 'usar_todos': False,
                'pais_selecionados': set(t for (t, _) in subset),
                'rl_calculada': rl_calc_subset, 'rl_informada': float(receita_liquida_valor),
                'desvio': 0.0, 'ajuste': 0.0, 'delta_alvo': delta_alvo
            }

        # fallback: TODOS OS PAIS
        soma_contrib_todos = sum(c for _, c in candidatos)
        rl_calc_todos = float(rob_valor) - float(soma_contrib_todos)
        desvio_todos = abs(rl_calc_todos - float(receita_liquida_valor))

        if desvio_todos <= tol:
            # Aceita por tolerância, mas devolve AJUSTE necessário
            ajuste = float(receita_liquida_valor) - rl_calc_todos  # >0 precisa RECEITA (+); <0 precisa DESPESA (-)
            return {
                'ok': True, 'exato': False, 'usar_todos': True,
                'pais_selecionados': set(t for (t, _) in candidatos),
                'rl_calculada': rl_calc_todos, 'rl_informada': float(receita_liquida_valor),
                'desvio': desvio_todos, 'ajuste': ajuste, 'delta_alvo': delta_alvo
            }

        # não fechou nem com todos os pais
        desvio_subset = abs(rl_calc_subset - float(receita_liquida_valor))
        return {
            'ok': False, 'exato': False, 'usar_todos': False,
            'pais_selecionados': set(t for (t, _) in subset),  # melhor tentativa, mas NÃO OK
            'rl_calculada': rl_calc_subset, 'rl_informada': float(receita_liquida_valor),
            'desvio': desvio_subset, 'ajuste': 0.0, 'delta_alvo': delta_alvo
        }
    
    def _rl_from_topos(self, topos, rob_valor: float) -> float:
        """
        RL_calc = ROB - sum(contribuições assinadas)
        Contribuição assinada: despesa(-) => +|v| ; receita(+) => -|v|
        """
        soma_contrib = 0.0
        for _, v in topos:
            v = float(v)
            soma_contrib += abs(v) if v < 0 else -abs(v)
        return float(rob_valor) - soma_contrib

    def _tentar_flip_um_campo_pos_erro(
        self,
        topos: list[tuple[str, float]],
        rob_valor: float,
        rl_informada: float,
        tol_pct: float = 0.01
    ):
        """
        Chamado APÓS uma primeira validação falhar.
        Testa inverter o sinal de CADA campo (um por vez), recalcula/valida e retorna na primeira solução boa.

        Retorna: (encontrou, topos_corrigidos, campo_invertido_ou_None, verif_obj)
        - 'encontrou' = True se bateu EXATO (preferência) ou OK por tolerância
        - 'topos_corrigidos' = lista de topos a usar a partir daqui (ou os originais)
        - 'campo_invertido_ou_None' = (nome, valor_apos_flip)
        - 'verif_obj' = objeto de retorno de verificar_valores_dre com o conjunto vencedor
        """
        if rl_informada is None:
            return False, topos, None, None

        alvo = float(rl_informada)

        for i, (nome, v) in enumerate(topos):
            topos_flip = list(topos)
            topos_flip[i] = (nome, -float(v))  # inverte sinal do i-ésimo campo

            # revalida usando a MESMA função que você já usa
            verif_i = self.verificar_valores_dre(topos_flip, rob_valor, rl_informada, tol_pct=tol_pct)

            # Preferência: EXATO; se não, OK por tolerância
            if verif_i.get('exato', False) or verif_i.get('ok', False):
                return True, topos_flip, (nome, -float(v)), verif_i

        # nenhum flip resolveu
        return False, topos, None, None

