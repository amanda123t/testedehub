# app/validators/nota_fiscal_validator.py
from __future__ import annotations
from typing import List, Dict, Optional
import re, unicodedata
from difflib import SequenceMatcher
from collections import Counter, defaultdict
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from datetime import datetime, date

def _norm(s):
    if s is None: return ""
    s = str(s).upper().strip()
    s = unicodedata.normalize("NFKD", s).encode("ASCII","ignore").decode("ASCII")
    return re.sub(r"\s+"," ", s)

def _norm_empresa(s):
    s = _norm(s)
    s = re.sub(r"\b(LTDA|EIRELI|ME|S/?A|SA|LIMITADA|EPP|EI)\b", "", s)
    return s.strip()

def _sim(a,b,t=0.7): 
    return SequenceMatcher(None, a, b).ratio() >= t

def _money(v):
    if v is None: return None
    s = re.sub(r"[^\d,.-]", "", str(v)).replace(".", "").replace(",", ".")
    try: return float(s)
    except: return None

def _parse_date_any(s) -> Optional[date]:
    """
    Aceita formatos comuns: DD/MM/AAAA, DD-MM-AAAA, AAAA-MM-DD, AAAA/MM/DD,
    e ISO com hora (ex: 2025-03-01T00:00:00). Retorna date ou None.
    """
    if not s:
        return None
    txt = str(s).strip()

    # Formatos diretos com datetime.strptime
    fmts = [
        "%d/%m/%Y", "%d-%m-%Y",
        "%Y-%m-%d", "%Y/%m/%d",
        "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f",
        "%d/%m/%Y %H:%M:%S", "%d-%m-%Y %H:%M:%S",
    ]
    for f in fmts:
        try:
            return datetime.strptime(txt, f).date()
        except Exception:
            pass

    # Fallback regex DD[sep]MM[sep]YYYY
    m = re.search(r"\b(\d{2})[\/\-](\d{2})[\/\-](\d{4})\b", txt)
    if m:
        dd, mm, yyyy = map(int, m.groups())
        try:
            return date(yyyy, mm, dd)
        except Exception:
            return None

    # Fallback regex YYYY[sep]MM[sep]DD
    m = re.search(r"\b(\d{4})[\/\-](\d{2})[\/\-](\d{2})\b", txt)
    if m:
        yyyy, mm, dd = map(int, m.groups())
        try:
            return date(yyyy, mm, dd)
        except Exception:
            return None

    return None

def _quarter(month: int) -> int:
    if 1 <= month <= 3:   return 1
    if 4 <= month <= 6:   return 2
    if 7 <= month <= 9:   return 3
    if 10 <= month <= 12: return 4
    return 0

def _mes_ano_ref(datas: List[date]) -> str:
    """ Retorna 'MM/AAAA' da última data (máxima). """
    if not datas:
        return ""
    d = max(datas)
    return f"{d.month:02d}/{d.year}"

def _mes_ano_atual() -> str:
    hoje = date.today()
    return f"{hoje.month:02d}/{hoje.year}"

def _dedup_key(nota: Dict):
    # Preferência: Chave de Acesso; senão (Numero, Valor)
    chave = nota.get("Chave de Acesso:") or nota.get("ChaveAcesso:") or nota.get("Chave:", "")
    if chave:
        return ("CHAVE", _norm(chave))
    num = (nota.get("NumeroNota:") or nota.get("Numero:") or "").strip()
    v = _money(nota.get("ValorTotal:") or nota.get("Valor:"))
    return ("NUMVAL", num, f"{v:.2f}" if v is not None else None)

def _tipo_por_nome(nota: Dict, associado_norm: str) -> Optional[str]:
    em = _norm_empresa(nota.get("Emissor:") or nota.get("Emitente:") or "")
    de = _norm_empresa(nota.get("Destinatário:") or nota.get("Destinatario:") or "")
    if not associado_norm:
        return None
    if _sim(em, associado_norm):  # associado é emissor
        return "saida"
    if _sim(de, associado_norm):  # associado é destinatário
        return "entrada"
    return None

def _tipo_extrator(nota: Dict, associado_norm: str) -> Optional[str]:
    raw = str(nota.get("Entrada/Saida:") or nota.get("EntradaSaida:") or "").strip()
    if raw in ("0","1"):
        return "saida" if raw == "1" else "entrada"
    return _tipo_por_nome(nota, associado_norm)

def _relacionado(nota: Dict, associado_norm: str) -> bool:
    if not associado_norm:
        return True
    em = _norm_empresa(nota.get("Emissor:") or nota.get("Emitente:") or "")
    de = _norm_empresa(nota.get("Destinatário:") or nota.get("Destinatario:") or "")
    return _sim(em, associado_norm) or _sim(de, associado_norm)

def _infer_associado_por_notas(notas: List[Dict]) -> str:
    """
    Retorna a forma 'crua' mais comum do nome (Emissor/Destinatário),
    escolhendo por frequência total e, em empate, preferindo quem mais aparece como DESTINATÁRIO.
    """
    counts = Counter()                  # emissor + destinatário
    dest_counts = Counter()             # apenas destinatário (desempate)
    raw_by_norm = defaultdict(Counter)  # norm -> contagem por forma crua

    for n in notas:
        em = n.get("Emissor:") or n.get("Emitente:")
        de = n.get("Destinatário:") or n.get("Destinatario:")
        if em:
            norm = _norm_empresa(em)
            if norm:
                counts[norm] += 1
                raw_by_norm[norm][em] += 1
        if de:
            norm = _norm_empresa(de)
            if norm:
                counts[norm] += 1
                dest_counts[norm] += 1
                raw_by_norm[norm][de] += 1

    if not counts:
        return ""

    best_norm, best_count = None, -1
    for norm, c in counts.items():
        if c > best_count:
            best_norm, best_count = norm, c
        elif c == best_count:
            # preferência por quem mais aparece como DESTINATÁRIO
            if dest_counts[norm] > dest_counts.get(best_norm, 0):
                best_norm = norm

    # devolve a forma "crua" mais comum daquele normalizado
    best_raw, _ = raw_by_norm[best_norm].most_common(1)[0]
    return best_raw
# +++ FIM NOVO

@registrar_validador("nota fiscal", "nota_fiscal", "notafiscal", "notas fiscais", "notas_fiscais", "nfe", "nf-e")

class ValidadorNotaFiscal(ValidadorBase):
    """
    Use este validador apenas UMA vez, no final do processo,
    passando em `data` a LISTA com todas as notas já extraídas (de todas as páginas / arquivos).

    Atributos opcionais:
      - product_keywords: List[str]  # palavras-chave válidas de produtos (opcional)
    """

    def validar(self) -> bool:
        self.log.info("Iniciando validação das Notas Fiscais")
        # Normaliza entrada (dict -> list[dict])
        
        #lista com os dados de cada nota, onde cada nota possui {'dados': {}, 'context': xxx, 'arquivo': xxx}
        lista_notas = self.lista

        #lista apenas com os dados de cada nota como é usado na validação
        notas = [self.extrair_valor(n, False, "dados", "dados:") for n in lista_notas if isinstance(n, dict)]

        if not notas:
            self.sections = [("NOTAS FISCAIS", [["Resultados do Processamento:"], ["Nenhuma nota identificada."]])]
            return self.build_output(status_geral=False, mensagem="Nenhuma nota fiscal encontrada.")

        # --- NOVO: associado (usa process_info se vier; senão infere pelas NFs)
        associado = ""
        try:
            associado = (self.process_info or {}).get("name", "") or ""
        except Exception:
            associado = ""

        associado_origem = "informado externamente"
        if not associado:
            inf = _infer_associado_por_notas(notas)
            if inf:
                associado = inf
                associado_origem = "inferido das NFs"
                try:
                    # persiste no process_info para uso por outros validadores, se desejado
                    if isinstance(self.process_info, dict):
                        self.process_info["name"] = associado
                except Exception:
                    pass

        associado_norm = _norm_empresa(associado)
        self.produtos_validos_nota = self.comprovantes.produtos_validos_nota
        keys = [_norm(k) for k in self.produtos_validos_nota]

        # --- Soma "ampla" (exceto duplicadas)
        uniq_all, soma_sem_dup = set(), 0.0
        for n in notas:
            k = _dedup_key(n)
            if k in uniq_all:
                continue
            uniq_all.add(k)
            v = _money(n.get("ValorTotal:") or n.get("Valor:"))
            if v is not None:
                soma_sem_dup += v

        # --- Classificação: terceiros / candidatos
        terceiros, candidatos = [], []
        for n in notas:
            if _relacionado(n, associado_norm):
                candidatos.append(n)
            else:
                terceiros.append(n)

        # --- Filtro por produto (opcional)
        pos_prod, prod_inv = [], []
        for n in candidatos:
            raw = n.get("Produtos:") or n.get("Produto:")
            if isinstance(raw, list):
                raw = " ".join(map(str, raw))
            prod_norm = _norm(raw or "")
            if not keys or not prod_norm or any(k in prod_norm for k in keys):
                pos_prod.append(n)
            else:
                prod_inv.append(n)

        # --- Dedup final + soma e quebras por ENTRADA/SAÍDA (respeita o que veio na nota)
        seen, duplicadas, validas = set(), [], []
        soma_total = 0.0
        notas_entrada, notas_saida = [], []
        soma_entrada, soma_saida = 0.0, 0.0

        for n in pos_prod:
            k = _dedup_key(n)
            if k in seen:
                duplicadas.append(n)
                continue
            seen.add(k)

            v = _money(n.get("ValorTotal:") or n.get("Valor:"))
            if v is None:
                continue

            tipo = _tipo_extrator(n, associado_norm) or "desconhecido"
            validas.append(n)
            soma_total += v
            if tipo == "entrada":
                notas_entrada.append(n); soma_entrada += v
            elif tipo == "saida":
                notas_saida.append(n);   soma_saida += v
            else:
                pass

        def fmt(x): 
            return f"R$ {x:,.2f}".replace(",", "X").replace(".", ",").replace("X",".")

        linhas: List[List[str]] = []
        linhas.append(["Resultados do Processamento:", ""])
        # +++ NOVO: mostra qual associado foi considerado
        linhas.append(["Associado considerado:", associado or "(não definido)"])
        #linhas.append(["Origem do associado:", associado_origem])
        # +++ FIM NOVO
        linhas.append(["Total de notas válidas:", str(len(validas))])
        if fmt(soma_total) == fmt(soma_sem_dup):
            linhas.append(["Soma total das notas:", fmt(soma_total)])
        else:
            linhas.append(["Soma total das notas:", fmt(soma_total)])
            linhas.append(["Soma total das notas encontradas (Exceto duplicadas):", fmt(soma_sem_dup)])
        linhas.append(["-> TOTAL POR TIPO: (ENTRADA/SAIDA)", ""])
        linhas.append(["    - Total de notas de SAÍDA:", str(len(notas_saida))])
        linhas.append(["    - Soma notas de SAÍDA:", fmt(soma_saida)])
        linhas.append(["    - Total de notas de ENTRADA:", str(len(notas_entrada))])
        linhas.append(["    - Soma notas de ENTRADA:", fmt(soma_entrada)])

        if duplicadas:
            linhas.append(["✘ Notas ignoradas por duplicidade:", ""])
            for n in duplicadas:
                linhas.append([f"  - Nº {n.get('NumeroNota:') or n.get('Numero:')} | Valor: {n.get('ValorTotal:') or n.get('Valor:')}"])
        else:
            linhas.append(["✔ Nenhuma nota duplicada encontrada!"])

        if terceiros and associado_norm:
            linhas.append(["✘ Notas ignoradas por serem de terceiros:", ""])
            for n in terceiros:
                linhas.append([f"  - Nº {n.get('NumeroNota:') or n.get('Numero:')} | Emissor: {n.get('Emissor:')} | Valor: {n.get('ValorTotal:') or n.get('Valor:')}"])
        else:
            linhas.append(["✔ Nenhuma nota de terceiros encontrada!"])

        if prod_inv:
            linhas.append(["✘ Notas ignoradas por produto inválido:", ""])
            for n in prod_inv:
                linhas.append([f"  - Nº {n.get('NumeroNota:')} | Produto: {n.get('Produtos:')} | Valor: {n.get('ValorTotal:')}"])
        else:
            # se não passou keywords, melhor mensagem neutra
            msg = "Validação de produto não aplicada" if not keys else "✔ Todos os produtos foram validados com sucesso"
            linhas.append([msg])

        
                # === NOVO: Validação de Datas / Período (2024–2025) ===
        # trabalha apenas com as "validas" (já filtradas por relação/produto/duplicidade/valor)
        datas_validas: List[date] = []
        anos_counter = Counter()
        soma_por_ano_validas = defaultdict(float)  # (A) válidas
        soma_por_ano_exc_dup = defaultdict(float)  # (B) todas exceto dup (preenche no passo 2)
        notas_sem_data = []
        soma_q_2025 = defaultdict(float)            # (A) por trimestre (válidas) {1..4: soma}
        soma_q_2025_exc_dup = defaultdict(float)    # (B) por trimestre (todas exceto dup) {1..4: soma}
        datas_q_2025 = defaultdict(list)            # {1..4: [dates]} (para data de referência)
        cont_q_2025 = Counter()                     # quantidade de notas por trimestre (válidas)
        SOMA_TOTAL_2025 = 0.0                       # (A) total 2025 válidas

        def _almost_equal(a: float, b: float, tol: float = 0.005) -> bool:
            return abs((a or 0.0) - (b or 0.0)) <= tol

        def _append_somas(linhas, rotulo: str, v_valid: float, v_excdup: float):
            """
            Se as somas forem iguais (dentro do tol), exibe uma única linha:
              'rotulo (soma total das notas): R$ ...'
            Caso contrário, exibe as duas:
              'rotulo (válidas): R$ ...'
              'rotulo (todas exceto duplicadas): R$ ...'
            """
            if _almost_equal(v_valid, v_excdup):
                linhas.append([f"{rotulo} (soma total das notas):", fmt(v_valid)])
            else:
                linhas.append([f"{rotulo} (válidas):", fmt(v_valid)])
                linhas.append([f"{rotulo} (todas exceto duplicadas):", fmt(v_excdup)])

        # (A) percorrendo apenas válidas
        for n in validas:
            d_raw = n.get("DataEmissao:") or n.get("DataEmissao") or n.get("Data:") or n.get("DataEmissão:")
            d = _parse_date_any(d_raw)
            v = _money(n.get("ValorTotal:") or n.get("Valor:"))
            if d:
                datas_validas.append(d)
                anos_counter[d.year] += 1
                if v is not None:
                    soma_por_ano_validas[d.year] += v
                if d.year == 2025:
                    q = _quarter(d.month)
                    cont_q_2025[q] += 1
                    if v is not None:
                        soma_q_2025[q] += v
                        SOMA_TOTAL_2025 += v
                    datas_q_2025[q].append(d)
            else:
                notas_sem_data.append(n)

        # (B) percorrendo todas as notas (exceto duplicadas) por ano e trimestre
        seen_by_year = defaultdict(set)       # ano -> set(keys)
        seen_by_year_q = defaultdict(set)     # (ano,q) -> set(keys)
        for n in notas:
            d_raw_all = n.get("DataEmissao:") or n.get("DataEmissao") or n.get("Data:") or n.get("DataEmissão:")
            d_all = _parse_date_any(d_raw_all)
            v_all = _money(n.get("ValorTotal:") or n.get("Valor:"))
            if not d_all or v_all is None:
                continue
            k_all = _dedup_key(n)

            # por ano (exceto duplicadas do ano)
            if k_all not in seen_by_year[d_all.year]:
                seen_by_year[d_all.year].add(k_all)
                soma_por_ano_exc_dup[d_all.year] += v_all

            # por trimestre 2025 (exceto duplicadas naquele trimestre)
            if d_all.year == 2025:
                q = _quarter(d_all.month)
                key_q = (d_all.year, q)
                if k_all not in seen_by_year_q[key_q]:
                    seen_by_year_q[key_q].add(k_all)
                    soma_q_2025_exc_dup[q] += v_all

        anos_detectados = sorted(anos_counter.keys())
        anos_antigos = [a for a in anos_detectados if a < 2024]
        tem_2024 = 2024 in anos_detectados
        tem_2025 = 2025 in anos_detectados

        # Cabeçalho da seção
        linhas.append([])
        #linhas.append(["-> VALIDAÇÃO DE DATAS(PERIODO 2024-2025):", ""])
        if notas_sem_data:
            linhas.append([f"✘ Notas com data de emissão inválidas/ausentes:", f"{len(notas_sem_data)} nota(s)."])
        
        if not datas_validas:
            linhas.append(["✘ ERRO:", " Nenhuma data de emissão pôde ser lida nas notas válidas."])
        else:
            linhas.append(["Anos detectados nas notas válidas:", ", ".join(map(str, anos_detectados))])
            if anos_antigos:
                soma_antigos_validas = sum(soma_por_ano_validas.get(a, 0.0) for a in anos_antigos)
                linhas.append([f"✘ Notas anteriores a 2024:",
                               f"{len([1 for d in datas_validas if d.year in anos_antigos])} nota(s) | Soma (válidas): {fmt(soma_antigos_validas)}"])
            else:
                linhas.append(["✔ Nenhuma Nota anterior a 2024!", ""])

            # CENÁRIOS
            if tem_2024 and not tem_2025 and not anos_antigos:
                # Apenas 2024
                linhas.append(["✔ Foi enviado apenas notas de 2024.", ""])
                linhas.append(["Lançar o valor total das notas como Renda efetiva 2024.",""])
                linhas.append(["Lançamento MUA:", f"Renda efetiva > Outros > 2024 > Rendas Agropecuárias (Anual)"])
                _append_somas(linhas, "Soma 2024", soma_por_ano_validas.get(2024, 0.0), soma_por_ano_exc_dup.get(2024, 0.0))
                despesas_2024 = soma_por_ano_exc_dup.get(2024, 0.0) * 0.3
                linhas.append(["Despesas(Anual)", f"{fmt(despesas_2024)}"])
                if not _almost_equal(soma_por_ano_validas.get(2024, 0.0), soma_por_ano_exc_dup.get(2024, 0.0)):
                    linhas.append([
                            "Aviso:",
                            "Cálculo das despesas foi baseado em 'todas as notas exceto duplicadas', se houver notas a serem desconsideradas, revisar o cálculo!"
                        ])


            elif not tem_2024 and not tem_2025 and anos_antigos:
                # Somente anos < 2024
                linhas.append(["✘ Notas vencidas, anteriores ao ano de 2024.", ""])
                # (sem lançamento)

            elif tem_2024 and tem_2025:
                # 2024 e 2025 — 2025 é desconsiderado para lançamento
                soma_2024_validas = soma_por_ano_validas.get(2024, 0.0)
                soma_2025_validas = soma_por_ano_validas.get(2025, 0.0)
                linhas.append(["ATENÇÃO:", "Há notas de 2024 e 2025; alinhamento de 2025 NÃO se aplica quando existe 2024."])
                linhas.append(["Lançamento MUA:", "Renda efetiva 2024 (usar apenas as notas de 2024)."])
                _append_somas(linhas, "Soma 2024", soma_2024_validas, soma_por_ano_exc_dup.get(2024, 0.0))
                _append_somas(linhas, "Soma 2025", soma_2025_validas, soma_por_ano_exc_dup.get(2025, 0.0))

            elif tem_2025 and not tem_2024 and not anos_antigos:
                # Apenas 2025 → Analisar trimestres
                qs_presentes = sorted([q for q in (1,2,3,4) if cont_q_2025.get(q, 0) > 0])
                q_names = {1: "1º trimestre (jan–mar)", 2: "2º trimestre (abr–jun)", 3: "3º trimestre (jul–set)", 4: "4º trimestre (out–dez)"}
                linhas.append(["Cenário:", "Apenas notas de 2025."])
                linhas.append(["Trimestres com notas:", ", ".join(q_names[q] for q in qs_presentes) if qs_presentes else "(nenhum)"])

                # Listar somas por trimestre (válidas vs exceto dup), aplicando regra de divergência
                for q in qs_presentes:
                    _append_somas(linhas, f"Soma {q_names[q]}",
                                  soma_q_2025.get(q, 0.0),
                                  soma_q_2025_exc_dup.get(q, 0.0))

                # Classificar e definir data de referência
                # Classificar e definir data de referência
                classificacao = "ANUAL"
                data_ref = _mes_ano_atual()

                if len(qs_presentes) == 1:
                    # Trimestral
                    classificacao = "TRIMESTRAL"
                    data_ref = _mes_ano_ref(datas_q_2025.get(qs_presentes[0], [])) or _mes_ano_atual()

                elif len(qs_presentes) == 2:
                    # Semestral apenas se for 1º+2º (set {1,2}) ou 3º+4º (set {3,4})
                    s = set(qs_presentes)
                    if s == {1, 2} or s == {3, 4}:
                        classificacao = "SEMESTRAL"
                        dref = []
                        dref.extend(datas_q_2025.get(qs_presentes[0], []))
                        dref.extend(datas_q_2025.get(qs_presentes[1], []))
                        data_ref = _mes_ano_ref(dref) or _mes_ano_atual()
                    else:
                        # pares como {2,3} ou {1,3} NÃO são semestre → ANUAL
                        classificacao = "ANUAL"
                        data_ref = _mes_ano_atual()
                else:
                    # 3 ou 4 trimestres → ANUAL
                    classificacao = "ANUAL"
                    data_ref = _mes_ano_atual()

                # Soma base do período (válidas vs exc_dup) para despesas
                if classificacao == "TRIMESTRAL":
                    q = qs_presentes[0]
                    soma_valid_periodo = soma_q_2025.get(q, 0.0)
                    soma_excdup_periodo = soma_q_2025_exc_dup.get(q, 0.0)
                    meses = 3
                    periodicidade = "trimestral"
                elif classificacao == "SEMESTRAL":
                    q1, q2 = qs_presentes
                    soma_valid_periodo = (soma_q_2025.get(q1, 0.0) + soma_q_2025.get(q2, 0.0))
                    soma_excdup_periodo = (soma_q_2025_exc_dup.get(q1, 0.0) + soma_q_2025_exc_dup.get(q2, 0.0))
                    meses = 6
                    periodicidade = "semestral"
                else:  # ANUAL
                    soma_valid_periodo = SOMA_TOTAL_2025
                    soma_excdup_periodo = soma_por_ano_exc_dup.get(2025, 0.0)
                    meses = 12
                    periodicidade = "anual"

                # Valor base para despesas:
                # - Se forem iguais: usa o comum.
                # - Se divergirem: usa "todas exceto duplicadas" e avisa.
                valor_base = soma_excdup_periodo
                # Cálculo das despesas:
                # 30% do valor / 12 = despesa mensal; multiplica pelos meses do período.
                despesa = 0.30 * (valor_base)         # anual = 30% do valor total


                # Mensagens finais do período
                if classificacao == "TRIMESTRAL":
                    linhas.append(["Validação:", "Apenas 1 trimestre com notas → TRIMESTRAL."])
                    linhas.append(["Lançamento MUA:", f"Renda efetiva > Outros > {data_ref} > rendas agropecuárias (trimestre)"])
                elif classificacao == "SEMESTRAL":
                    linhas.append(["Validação:", "1º+2º trimestre ou 3º+4º trimestre → SEMESTRAL."])
                    linhas.append(["Lançamento MUA:", f"Renda efetiva > Outros > {data_ref} > rendas agropecuárias (semestre)"])
                else:
                    linhas.append(["Validação:", "Ultrapassa um semestre → ANUAL."])
                    linhas.append(["Lançamento MUA:", f"Renda efetiva > Outros > {data_ref} > rendas agropecuárias (anual)"])

                # Totais 2025
                _append_somas(linhas, "Soma total 2025", SOMA_TOTAL_2025, soma_por_ano_exc_dup.get(2025, 0.0))

                
                linhas.append([f"Despesas ({periodicidade}):", fmt(despesa)])
                # Transparência quando houve divergência
                if not _almost_equal(soma_valid_periodo, soma_excdup_periodo):
                    linhas.append([
                        "Aviso:",
                        "Cálculo das despesas foi baseado em 'todas as notas exceto duplicadas', se houver notas a serem desconsideradas, revisar o cálculo!"
                    ])

            else:
                # Mistos diversos (ex.: 2023 e 2025, sem 2024)
                soma_mistos_validas = sum(soma_por_ano_validas.get(a, 0.0) for a in anos_detectados)
                linhas.append(["Validação:", "Conjunto de anos não coberto explicitamente pelas regras."])
                for a in anos_detectados:
                    _append_somas(linhas, f"Soma {a}",
                                  soma_por_ano_validas.get(a, 0.0),
                                  soma_por_ano_exc_dup.get(a, 0.0))
                linhas.append(["Soma total (informativo, válidas):", fmt(soma_mistos_validas)])

        # --- Regras/pareceres da planilha (SEM fallback) ---
        regras = {}
        if getattr(self, "regras_mua", None):
            # variações comuns para localizar o tipo na coluna "tipo"
            nomes = ["nota fiscal", "nota_fiscal", "notafiscal", "nf", "nfe", "nf-e", "notas fiscais", "notas_fiscais"]
            regras = self.regras_mua.get_doc(nomes)

        if regras:
            linhas.append([])
            linhas.append(["Regras/Orientações:", ""])
            linhas_regras = self.exibir_regras_doc(regras)  # usa {numero_processo}, {periodo}, {valor} do base
            linhas.extend(linhas_regras)

        row = self._nome_validation_row()
        if row:
            linhas.append(row)

        self.sections = [("NOTAS FISCAIS", linhas)]
        resultados = []
        for nota in lista_notas:
            self.doc = self.extrair_valor(nota, False, "dados", "dados:")
            self.context = self.extrair_valor(nota, False, "context", "context:")
            self.file = self.extrair_valor(nota, False, "arquivo", "arquivo:")

            resultados.append({
                "arquivo": self.file,
                "status": True,                         # por hora tudo OK
                "mensagem": "Validação concluída com sucesso.",
                "dados_extraidos": self.doc,               # apenas os dados daquela nota
                "context": self.context,
            })

        self.log.info("Validação das Notas Fiscais concluída")
        return self.build_output(status_geral=True, mensagem="Realizado a soma de todas notas fiscais enviadas!", resultados_docs=resultados)