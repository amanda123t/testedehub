from copy import deepcopy
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import normalize
from app.utils.helpers import organize_data
import re
from app.utils.APIs.api_cep import buscar_endereco, buscar_cep  # garantir que está importado
from app.utils.APIs.api_fipe import consultar_fipe
from app.utils.APIs.api_placa import consultar_placa_anycar
import app.utils.APIs.api_4dev as site_4_dev

# --- APPEND INTELIGENTE DA DESCRIÇÃO ---
def quebrar_descricao(desc: str, largura: int):
    """
    Quebra a descrição mantendo palavras inteiras sempre que possível.
    Se a palavra for maior que a largura, quebra essa palavra mesmo.
    Retorna lista de linhas mantendo o texto limpo para o PDF.
    """
    palavras = desc.split()
    linhas_local = []
    atual = ""

    for palavra in palavras:
        # testa se caberia adicionar esta palavra
        novo = palavra if not atual else f"{atual} {palavra}"

        if len(novo) <= largura:
            atual = novo
        else:
            # empurra linha atual e inicia nova
            linhas_local.append(atual)
            atual = palavra

    if atual:
        linhas_local.append(atual)

    return linhas_local

def _parse_ano(v):
    try:
        return int(str(v).strip())
    except:
        return None

CACHE_IRPF: dict[tuple[str, str], dict] = {}
CACHE_IRPF_TEXTO: dict[tuple[str, str], dict] = {}

@registrar_validador(
    "irpf",
    "imposto de renda",
    "declaração de imposto de renda",
    "declaracao de imposto de renda",
    "declaração de ajuste anual",
    "declaracao de ajuste anual",
)
class ValidadorIRPF(ValidadorBase):
    _KEY_REND_PJ = "RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA JURÍDICA PELO TITULAR"
    _KEY_REND_PFEX = "RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA FÍSICA E DO EXTERIOR PELO TITULAR"
    _KEY_REND_ISENTOS = "RENDIMENTOS ISENTOS E NÃO TRIBUTÁVEIS"
    _KEY_RESUMO = "Resumo"

    def validar(self) -> bool:
        self.log.info("Iniciando validação de IRPF")

        # limpa listas
        self.declaracoes_ir, self.recibos_ir = [], []

        # === NOVO PADRÃO ===
        # lista com os dados de cada IR, cada item tem {'dados': {}, 'context': xxx, 'arquivo': xxx}
        lista_ir = self.extrair_valor(
            self.data,
            False,
            "IRs", "IRPF", "Impostos de rendas",
            "imposto de renda", "ir", "irpf",
            self.type_name
        )
        if isinstance(lista_ir, dict):
            lista_ir = [lista_ir]
        if not isinstance(lista_ir, list):
            lista_ir = []

        resultados = []

        # === percorre cada documento IR individualmente ===
        for doc in lista_ir:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")

            # segurança: se não veio dados válidos, ignora
            if not isinstance(self.doc, dict):
                self.log.warning(f"Documento inválido ou sem dados: {self.file}")
                continue

            tipo = (self.doc.get("__tipo_documento__") or "").lower()
            if tipo == "irpf":
                self.declaracoes_ir.append(doc)
            elif tipo == "recibo":
                self.recibos_ir.append(doc)
            else:
                self.declaracoes_ir.append(doc)
        
        lista_recibos = self.extrair_valor(self.data, False, "Recibo de IR", "Recibo de IR:", "Recibo de IRPF:", "Recibo de IRPF", "Recibo de ir:", "Recibo de ir")
        self.log.debug(f"Lista de recibos encontradas: {lista_recibos}")
        if lista_recibos:
            for doc in lista_recibos:
                self.recibos_ir.append(doc)
        self.log.debug(f"Lista de documentos de recibos: {self.recibos_ir}")

        # === continua lógica normal (mesmo que antes) ===
        if not self.declaracoes_ir:
            self.sections.append(("AVISO", [["Nenhuma declaração de IRPF encontrada para análise."]]))
            return self.build_output(
                status_geral=False,
                mensagem="Nenhuma declaração de IRPF encontrada para análise.",
                resultados_docs=resultados
            )

        # cria índice para match recibo ↔ declaração
        idx_recibo = {}
        for r in self.recibos_ir:
            doc = self.extrair_valor(r, False, "dados", "dados:")
            chave = (normalize(self._get_nome(doc)), self._get_ano(doc) or "")
            idx_recibo.setdefault(chave, doc)
        self.log.debug(f"idx_recibo: {idx_recibo}")

        # processa cada declaração individualmente
        for declaracao in self.declaracoes_ir:
            self.doc = self.extrair_valor(declaracao, False, "dados", "dados:")
            self.context = self.extrair_valor(declaracao, False, "context", "context:")
            self.context = " ".join(self.context) if isinstance(self.context, list) else self.context
            self.file = self.extrair_valor(declaracao, False, "arquivo", "arquivo:")
            self.dados_mua = {}  # limpa antes de cada documento
            status_doc = False

            try:
                status_doc = self._processar_declaracao()
            except Exception as e:
                self.log.error(f"Erro ao processar declaração {self.file}: {e}")
                self.sections.append(("ERRO IRPF", [["Falha ao processar uma declaração:", str(e)]]))
                status_doc = False

            nome_key = self._get_nome(self.doc)
            nome_key_norm = normalize(nome_key)
            ano_key = self._get_ano(self.doc) or ""
            recibo = idx_recibo.get((nome_key_norm, ano_key))

            # ============================================================
            # 🔥 SEÇÃO ÚNICA: RECIBO (Entrega + Tipo Original/Retificadora)
            # ============================================================

            linhas_recibo = []

            tipo_declaracao = getattr(self, "_tipo_declaracao_extraido", None)
            tipo_declaracao_regra = getattr(self, "_tipo_declaracao_regra", True)

            # 1) Recibo encontrado ou não
            if recibo:
                linhas_recibo.append([f"✔ Recibo de entrega encontrado para {nome_key} - Ano {ano_key}"])
            else:
                linhas_recibo.append([f"✘ Nenhum recibo de entrega encontrado para {nome_key} - Ano {ano_key}"])
                # não retornar ainda — porque mesmo sem recibo queremos mostrar a seção inteira

            # 2) Validar tipo da declaração (se houver recibo + regra ativada)
            if tipo_declaracao_regra and recibo:

                # Normalizar tipo da declaração
                tipo_decl_raw = str(tipo_declaracao or "").lower()
                if any(w in tipo_decl_raw for w in ["retific", "retificada", "retificado", "retificador"]):
                    tipo_decl_norm = "RETIFICADORA"
                elif "original" in tipo_decl_raw:
                    tipo_decl_norm = "ORIGINAL"
                else:
                    tipo_decl_norm = "NÃO IDENTIFICADO"

                # Normalizar tipo do recibo
                tipo_recibo_raw = str(
                    recibo.get("Tipo")
                    or recibo.get("Tipo:")
                    or recibo.get("Título")
                    or recibo.get("Título:")
                    or ""
                ).lower()
                if any(w in tipo_recibo_raw for w in ["retific", "retificada", "retificado", "retificador"]):
                    tipo_recibo_norm = "RETIFICADORA"
                elif "original" in tipo_recibo_raw:
                    tipo_recibo_norm = "ORIGINAL"
                else:
                    tipo_recibo_norm = "NÃO IDENTIFICADO"

                # Comparação
                if tipo_decl_norm == tipo_recibo_norm:
                    linhas_recibo.append([f"✔ Tipo do IRPF ({tipo_decl_norm}) bate com o Recibo ({tipo_recibo_norm})"])
                else:
                    linhas_recibo.append([
                        f"✘ Divergência entre tipo da Declaração ({tipo_decl_norm}) e do Recibo ({tipo_recibo_norm})"
                    ])

            # Final: adiciona tudo como uma única seção
            self.sections.append(("Recibo", linhas_recibo))


            
            # === 🔽 AGORA sim adiciona o resultado após validar e gerar self.dados_mua ===
            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context,
                "dados_mua": getattr(self, "dados_mua", {})
            })

        self.log.info("Validação de IRPF finalizada.")
        return self.build_output(
            status_geral=any(r["status"] for r in resultados),
            mensagem="Validação de IRPF e recibo concluída com sucesso.",
            resultados_docs=resultados
        )

    def _extrair_despesa_agro(self):
        """
        Extrai a despesa da atividade rural diretamente de:
        DEMONSTRATIVO DE ATIVIDADE RURAL → APURAÇÃO DO RESULTADO
        usando self.extrair_valor para buscar variações de nome.
        """
        bloco = self.extrair_valor(
            self.doc, False,
            "DEMONSTRATIVO DE ATIVIDADE RURAL",
            "Demonstrativo de Atividade Rural",
            "DEMONSTRATIVO DA ATIVIDADE RURAL"
        )

        if not isinstance(bloco, dict):
            return 0.0

        apuracao = self.extrair_valor(
            bloco, False,
            "APURAÇÃO DO RESULTADO",
            "Apuração do Resultado",
            "APURACAO DO RESULTADO"
        )

        if not isinstance(apuracao, dict):
            return 0.0

        # tenta todas as chaves possíveis de “despesa”
        despesa_raw = self.extrair_valor(
            apuracao, False,
            "Despesa de custeio e investimento total",
            "Despesa Total",
            "Despesas de Custeio e Investimento Total",
            "Despesas da Atividade Rural",
            "DESPESA TOTAL"
        )

        return self.format_br.converter_valor_para_float(despesa_raw) if despesa_raw else 0.0

    def fmt(self, v):
        return self.format_br.formatar_moeda_br(
            self.format_br.converter_valor_para_float(v or "0,00")
        ).replace("R$ ", "")

    def _processar_declaracao(self):
        # === CACHE IRPF ===
        chave_cache = (self.file or "SEM_ARQ", str(self._get_ano(self.doc)) or "ANO_NI")

        # mescla cache anterior (prioridade para dados corretos)
        cache_antigo = CACHE_IRPF.get(chave_cache, {})
        if cache_antigo:
            self.doc = {**self.doc, **cache_antigo}
            self.log.debug(f"🔄 Mesclando cache existente (prioridade para dados corretos) para {chave_cache}")

        if "Ocupacao" in self.doc:
            self.doc["Ocupação"] = self.doc.pop("Ocupacao")
        
        cache_texto = CACHE_IRPF_TEXTO.get(chave_cache, {})
        sigilo_fiscal_cacheado = cache_texto.get("sigilo_fiscal")
        erro_irpf = False
        _err_tags: set[str] = set()

        considerar_despesas_agro = str(getattr(self.comprovantes, 'considerar_despesas_agro', 'Não'))
        exibir_despesas_em_rs = str(getattr(self.comprovantes, 'exibir_despesas_em_rs', 'Não'))
        exibir_resumo = self.to_bool(getattr(self.comprovantes, 'exibir_resumo', False)) is True
        self.desconsiderar_rendas_item_04 = self.to_bool(getattr(self.comprovantes, "desconsiderar_rendas_item_04", "Não")) is True
        self.desconsiderar_rendimentos_dependentes = self.to_bool(getattr(self.comprovantes, "desconsiderar_rendimentos_dependentes", "Sim")) is not False
        self.desconsiderar_99_seguros = self.to_bool(getattr(self.comprovantes, "desconsiderar_99_seguros", "Não")) is True
        tipo_declaracao_regra = self.to_bool(getattr(self.comprovantes, "tipo_declaracao_regra", "Sim")) is not False
        self._tipo_declaracao_regra = tipo_declaracao_regra  # ← salva também

        
        nome_declarante = self._get_nome(self.doc)
        ano_calendario = self._get_ano(self.doc) or "Ano N/I"
        ano_calendario_int = int(ano_calendario) if ano_calendario and ano_calendario != "Ano N/I" else 0
        ano_calendario_limite = getattr(self.comprovantes, 'ano_calendario_limite', '')
        ano_calendario_limite_int = int(ano_calendario_limite) if ano_calendario_limite else 0
        tipo_declaracao = self.extrair_valor(self.doc, False, "tipo", "tipo:", "Tipo:", "Tipo")
        self._tipo_declaracao_extraido = tipo_declaracao  # ← salva para o validar() usar
        self.periodo_documento = ano_calendario
        titulo_secao = f"IRPF - {nome_declarante} - Ano Calendário: {ano_calendario}"

        campos_mua = {"Aposentadoria/Pensões": 0.0, "Salário Líquido": 0.0, "Gratificações e Comissões": 0.0, "Locações e Arrendamento": 0.0, "Pró-labore/Part. Societárias": 0.0, "Rendas Agropecuárias": 0.0, "Outros": 0.0}
        self.cnpjs_item_04 = set()
        self.cnpjs_cooperativas_desconsideradas = set()
        
        rend_isentos = self.doc.get(self._KEY_REND_ISENTOS)
        if rend_isentos and isinstance(rend_isentos, list):

            for item in rend_isentos:
                cod_item = self.extrair_valor(item, False, "Item:", "Item", "item", "item:") or ""
                item_04 = "04" in str(cod_item) or "4" in str(cod_item)
                subitens = item.get("Subitens") or []

                if subitens and item_04:
                    self.log.debug(f"Item 04 encontrado, salvando cnpjs..")

                    for sub in subitens:
                        fonte = (sub.get("Fonte Pagadora") or "").strip()
                        cnpj_raw = sub.get("CNPJ", "") or ""
                        cnpj = self.format_br.digits(self.extrair_valor(sub,False,"CNPJ", "cnpj", "CNPJ:", "cnpj:"))
                        fonte = normalize(self.extrair_valor(sub,False,'Fonte Pagadora', 'Fonte Pagadora:', 'fonte pagadora', 'fonte pagadora:'))
                        self.log.debug(f"Salvando cnpj {cnpj}...")
                        if cnpj:
                            self.cnpjs_item_04.add(cnpj)
                        else:
                            self.cnpjs_item_04.add(fonte)   

        #  cabeçalho e identificação do contribuinte
        linhas = [
            ["Documento lido:", self.file],
            ["IDENTIFICAÇÃO DO CONTRIBUINTE", ""],
        ]

        for chave, valor in self.doc.items():

            # remove cabeçalho inútil
            if chave.lower() == "cabeçalho":
                continue

            # remove campos internos da IA
            if chave.startswith("__"):
                continue

            # só exibe se NÃO for dict/list
            if isinstance(valor, (dict, list)):
                continue

            # exibir como linha organizada
            linhas.append([f"{chave}:", str(valor)])

        # rendimentos de pj 
        valor_total_rend_pj = 0
        valor_total_13_pj = 0
        rend_pj = self.doc.get(self._KEY_REND_PJ)

        if rend_pj and isinstance(rend_pj, list):

            # =====================================================
            #   1) COLETAR COMPRIMENTOS REAIS DAS COLUNAS
            # =====================================================
            nomes_fonte = []
            valores_rend = []
            valores_imposto = []
            valores_13 = []
            valores_irrf = []

            for item in rend_pj:
                fonte = (item.get("Fonte Pagadora") or "").strip()
                nomes_fonte.append(fonte)
                valor_item_pj_float, valor_item_pj_brl = self._parse_valor(item.get("Rend. Recebidos de Pes. Jurídica") or item.get("Valor") or "0,00" )
                valor_total_rend_pj += valor_item_pj_float
                valores_rend.append(valor_item_pj_brl.replace("R$ ", ""))
                valores_imposto.append(self.fmt(item.get("Imposto Retido na Fonte") or "0,00").replace("R$ ", ""))
                valores_13.append(self.fmt(item.get("13º Salário") or "0,00").replace("R$ ", ""))
                valores_irrf.append(self.fmt(item.get("IRPF sobre 13º Salário") or "0,00").replace("R$ ", ""))

            # =====================================================
            #   2) DEFINIR TAMANHOS BASEADOS NO MAIOR ITEM
            # =====================================================
            # Fonte Pagadora — mínimo 15, máximo 22
            COL_FONTE = min(max(max((len(x) for x in nomes_fonte), default=15), 15), 20)

            # CNPJ é fixo
            COL_CNPJ = 14

            def calc_col(vals, minimo, maximo):
                return min(max(max((len(v) for v in vals), default=minimo), minimo), maximo)

            # tamanho dos títulos
            MIN_REND = len("Renda")        # 10
            MIN_IMPOSTO = len("Imposto")        # 7
            MIN_13 = len("13º")         # 11
            MIN_IRRF = len("IRRF 13º")          # 8

            COL_REND = calc_col(valores_rend, minimo=MIN_REND, maximo=12)
            COL_IMPOSTO = calc_col(valores_imposto, minimo=MIN_IMPOSTO, maximo=9)
            COL_13 = calc_col(valores_13, minimo=MIN_13, maximo=14)
            COL_IRRF = calc_col(valores_irrf, minimo=MIN_IRRF, maximo=10)


            # =====================================================
            #   3) EXIBIÇÃO
            # =====================================================
            linhas.extend([[], ["RENDIMENTOS RECEBIDOS DE PESSOA JURÍDICA", ""]])

            header = (
                f"{'Fonte Pagadora':<{COL_FONTE}}  "
                f"{'CNPJ':<{COL_CNPJ}}  "
                f"{'Renda':>{COL_REND}}  "
                f"{'Imposto':>{COL_IMPOSTO}}  "
                f"{'13º':>{COL_13}}  "
                f"{'IRRF 13º':<{COL_IRRF}}"
            )
            linhas.append([f"   {header}", ""])

            # =====================================================
            #   4) LINHAS DETALHES
            # =====================================================
            for item in rend_pj:
                fonte = (item.get("Fonte Pagadora") or "").strip()
                if len(fonte) > COL_FONTE:
                    fonte = fonte[:COL_FONTE-3] + "..."

                cnpj = self.format_br.digits((item.get("CNPJ") or "").strip())

                rend_f = self.fmt(item.get("Rend. Recebidos de Pes. Jurídica") or item.get("Valor")or "0,00").replace("R$ ", "")

                imposto_f = self.fmt(item.get("Imposto Retido na Fonte") or "0,00").replace("R$ ", "")

                decimo_f = self.fmt(item.get("13º Salário") or "0,00").replace("R$ ", "")

                irrf_f = self.fmt(item.get("IRPF sobre 13º Salário") or "0,00").replace("R$ ", "")

                linha = (
                    f"{fonte:<{COL_FONTE}}  "
                    f"{cnpj:<{COL_CNPJ}}  "
                    f"{rend_f:>{COL_REND}}  "
                    f"{imposto_f:>{COL_IMPOSTO}}  "
                    f"{decimo_f:>{COL_13}}  "
                    f"{irrf_f:<{COL_IRRF}}"
                )

                linhas.append([f"   {linha}", ""])  



        # totais rend pf

        # ===============================================================
        # RENDIMENTOS RECEBIDOS DE PESSOA FÍSICA / EXTERIOR (TABULADO)
        # ===============================================================

        rend_pf_list = self.doc.get(self._KEY_REND_PFEX)
        valor_total_rend_pf = 0
        if isinstance(rend_pf_list, list) and rend_pf_list:

            linhas.extend([[], ["RENDIMENTOS RECEBIDOS DE PESSOA FÍSICA / EXTERIOR", ""]])

            # --- 1) COLETAR COLUNAS ---

            col_mes    = max(len(item.get("Mês", "")) for item in rend_pf_list)
            col_trab   = max(len(self.fmt(item.get("Trabalho N. assalariado"))) for item in rend_pf_list)
            col_alug   = max(len(self.fmt(item.get("Aluguel"))) for item in rend_pf_list)
            col_outros = max(len(self.fmt(item.get("Outros"))) for item in rend_pf_list)
            col_ext    = max(len(self.fmt(item.get("Exterior"))) for item in rend_pf_list)

            # Mínimos baseados nos títulos
            col_mes    = max(col_mes, len("Mês"))
            col_trab   = max(col_trab, len("Trabalho N. Assalariado"))
            col_alug   = max(col_alug, len("Aluguel"))
            col_outros = max(col_outros, len("Outros"))
            col_ext    = max(col_ext, len("Exterior"))

            # --- 2) HEADER ---
            header = (
                f"{'Mês':<{col_mes}}  "
                f"{'Trabalho N. Assalariado':>{col_trab}}  "
                f"{'Aluguel':>{col_alug}}  "
                f"{'Outros':>{col_outros}}  "
                f"{'Exterior':>{col_ext}}"
            )
            linhas.append([f"   {header}", ""])


            # --- 3) VARIÁVEIS DE CONTROLE ---
            soma_meses_trab = soma_meses_alug = soma_meses_out = soma_meses_ext = 0.0

            # totais finais por coluna (o que será usado no resumo / MUA)
            self.total_pf_trabalho = 0.0
            self.total_pf_aluguel  = 0.0
            self.total_pf_outros   = 0.0
            self.total_pf_exterior = 0.0

            # flags se a IA trouxe TOTAL explícito para cada coluna
            tem_total_trab_ia = tem_total_alug_ia = False
            tem_total_out_ia  = tem_total_ext_ia  = False

            encontrou_linha_total = False

            # --- 4) LINHAS ---
            for item in rend_pf_list:

                mes = (item.get("Mês") or "").strip().upper()
                v_trab = self.fmt(item.get("Trabalho não assalariado"))
                v_alug = self.fmt(item.get("Aluguel"))
                v_out  = self.fmt(item.get("Outros"))
                v_ext  = self.fmt(item.get("Exterior"))

                if mes != "TOTAL":
                    # Acumula somatório dos meses EXCETO a linha TOTAL
                    soma_meses_trab += self.format_br.converter_valor_para_float(item.get("Trabalho não assalariado") or "0,00")
                    soma_meses_alug += self.format_br.converter_valor_para_float(item.get("Aluguel") or "0,00")
                    soma_meses_out  += self.format_br.converter_valor_para_float(item.get("Outros") or "0,00")
                    soma_meses_ext  += self.format_br.converter_valor_para_float(item.get("Exterior") or "0,00")
                else:
                    # Linha TOTAL informada pela IA
                    encontrou_linha_total = True

                    raw_trab = item.get("Trabalho não assalariado")
                    raw_alug = item.get("Aluguel")
                    raw_out  = item.get("Outros")
                    raw_ext  = item.get("Exterior")

                    # Para cada coluna:
                    # - se IA trouxe algo (não None / não vazio) → usa esse valor e valida
                    # - se IA NÃO trouxe → usa soma dos meses e NÃO valida

                    if raw_trab is not None and str(raw_trab).strip() != "":
                        tem_total_trab_ia = True
                        self.total_pf_trabalho = self.format_br.converter_valor_para_float(raw_trab)
                    else:
                        tem_total_trab_ia = False
                        self.total_pf_trabalho = soma_meses_trab

                    if raw_alug is not None and str(raw_alug).strip() != "":
                        tem_total_alug_ia = True
                        self.total_pf_aluguel = self.format_br.converter_valor_para_float(raw_alug)
                    else:
                        tem_total_alug_ia = False
                        self.total_pf_aluguel = soma_meses_alug

                    if raw_out is not None and str(raw_out).strip() != "":
                        tem_total_out_ia = True
                        self.total_pf_outros = self.format_br.converter_valor_para_float(raw_out)
                    else:
                        tem_total_out_ia = False
                        self.total_pf_outros = soma_meses_out

                    if raw_ext is not None and str(raw_ext).strip() != "":
                        tem_total_ext_ia = True
                        self.total_pf_exterior = self.format_br.converter_valor_para_float(raw_ext)
                    else:
                        tem_total_ext_ia = False
                        self.total_pf_exterior = soma_meses_ext

                # imprime a linha (incluindo TOTAL, com o que veio da IA)
                linha = (
                    f"{mes:<{col_mes}}  "
                    f"{v_trab:>{col_trab}}  "
                    f"{v_alug:>{col_alug}}  "
                    f"{v_out:>{col_outros}}  "
                    f"{v_ext:>{col_ext}}"
                )
                linhas.append([f"   {linha}", ""])

            # Se NÃO existe linha TOTAL na tabela → usa apenas soma dos meses como total, sem validação
            if not encontrou_linha_total:
                self.total_pf_trabalho = soma_meses_trab
                self.total_pf_aluguel  = soma_meses_alug
                self.total_pf_outros   = soma_meses_out
                self.total_pf_exterior = soma_meses_ext

                tem_total_trab_ia = tem_total_alug_ia = False
                tem_total_out_ia  = tem_total_ext_ia  = False

            # SOMA TOTAL DE RENDIMENTOS PF (usando os totais finais de cada coluna)
            valor_total_rend_pf = (
                (self.total_pf_trabalho or 0.0) +
                (self.total_pf_aluguel  or 0.0) +
                (self.total_pf_outros   or 0.0) +
                (self.total_pf_exterior or 0.0)
            )

            # --- 5) VALIDAÇÃO DOS TOTAIS ---

            erros = []
            avisos = []

            validou_alguma = False     # ao menos uma coluna com total da IA
            todas_colunas_ok = True    # assume que está OK até encontrar erro

            def checar(nome, soma, total, tem_total_ia):
                nonlocal validou_alguma, todas_colunas_ok

                if not tem_total_ia:
                    avisos.append(
                        f"✘ Total do item '{nome}' não encontrado no documento. Verificar."
                    )
                    return None

                validou_alguma = True

                if abs((soma or 0.0) - (total or 0.0)) > 1:
                    todas_colunas_ok = False
                    return (
                        f"✘ Divergência em '{nome}': meses "
                        f"({self.format_br.formatar_moeda_br(soma)}) "
                        f"≠ total informado ({self.format_br.formatar_moeda_br(total)})."
                    )
                return None


            # Executa validações:
            for nome, soma, total, flag in [
                ("Trabalho não assalariado", soma_meses_trab, self.total_pf_trabalho, tem_total_trab_ia),
                ("Aluguel", soma_meses_alug, self.total_pf_aluguel, tem_total_alug_ia),
                ("Outros", soma_meses_out, self.total_pf_outros, tem_total_out_ia),
                ("Exterior", soma_meses_ext, self.total_pf_exterior, tem_total_ext_ia),
            ]:
                err = checar(nome, soma, total, flag)
                if err:
                    erros.append(err)

            # --- saída no PDF:

            if erros:
                erro_irpf = True
                _err_tags.add("RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA FÍSICA E DO EXTERIOR PELO TITULAR")
                linhas.extend([[e, ""]] for e in erros)

            elif validou_alguma and todas_colunas_ok:
                # ✔ Todos os itens com total da IA bateram
                linhas.append(["✔ Todos os totais informados batem com a soma dos meses.", ""])

            # avisos para colunas SEM total (não são erros)
            for av in avisos:
                linhas.append([av, ""])


        # principais isentos e n tributaveis
        total_rend_isentos_float = 0
        if rend_isentos and isinstance(rend_isentos, list):
            linhas.extend([[], ["RENDIMENTOS ISENTOS E NÃO TRIBUTÁVEIS:", ""]])
            isentos_tem_subitens = False
            isentos_todos_ok = True

            for item in rend_isentos:
                valor_item = self.format_br.converter_valor_para_float(item.get("Valor"))
                subitens = item.get("Subitens") or []
                total_rend_isentos_float += valor_item

                # 1) Exibe item
                linhas.append([f"Item {item.get('Item')} - {item.get('Descrição')}:", self.format_br.formatar_moeda_br(valor_item)])

                # 2) Subitens
                if subitens:
                    isentos_tem_subitens = True

                    # Cabeçalho padronizado
                    linhas.append([
                        f"   {'Beneficiário':<13}  {'Fonte Pagadora':<30}  {'CNPJ':<14}  {'Valor':<15}",
                        ""
                    ])
                    soma_sub = 0.0
                    for sub in subitens:
                        soma_sub += self.format_br.converter_valor_para_float(sub.get("Valor") or "0")
                        beneficiario = (sub.get("Beneficiário") or "Titular").strip()
                        fonte = (sub.get("Fonte Pagadora") or "").strip()
                        cnpj_raw = sub.get("CNPJ", "") or ""
                        valor_raw = sub.get("Valor", "0") 
                        linha = self._fmt_linha_subitem(
                            beneficiario,
                            fonte,
                            cnpj_raw,
                            valor_raw,
                            col_benef=13,
                            col_fonte=30,
                            col_cnpj=14,
                            col_valor=15,
                        )

                        linhas.append([f"   {linha}", ""])


                    # 3) Validação
                    if abs(soma_sub - valor_item) > 1:
                        erro_irpf = True
                        _err_tags.add("RENDIMENTOS ISENTOS E NÃO TRIBUTÁVEIS")
                        isentos_todos_ok = False

                        linhas.append([
                            f"✘ Divergência: soma dos subitens ({self.format_br.formatar_moeda_br(soma_sub)}) "
                            f"≠ valor informado ({self.format_br.formatar_moeda_br(valor_item)})",
                            ""
                        ])
            if isentos_tem_subitens and isentos_todos_ok:
                linhas.append(["✔ Soma dos subitens dos rendimentos isentos batem com os valores dos itens"])


        # principais rendimentos sujeitos à tributação exclusiva/definitiva
        rend_tributados = self.doc.get("RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA/DEFINITIVA")
        if rend_tributados and isinstance(rend_tributados, list):

            linhas.extend([[], ["RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA/DEFINITIVA", ""]])

            exclusivos_tem_subitens = False
            exclusivos_todos_ok = True

            for item in rend_tributados:
                valor_item = self.format_br.converter_valor_para_float(item.get("Valor"))
                subitens = item.get("Subitens") or []

                # 1) Item principal
                linhas.append([
                    f"Item {item.get('Item')} - {item.get('Descrição')}:", 
                    self.format_br.formatar_moeda_br(valor_item)
                ])

                # 2) Subitens
                if subitens:
                    exclusivos_tem_subitens = True

                    linhas.append([
                        f"   {'Beneficiário':<13}  {'Fonte Pagadora':<30}  {'CNPJ':<14}  {'Valor':<15}",
                        ""
                    ])

                    soma_sub = 0.0
                    for sub in subitens:
                        soma_sub += self.format_br.converter_valor_para_float(sub.get("Valor") or "0")
                        beneficiario = (sub.get("Beneficiário") or "Titular").strip()
                        fonte = (sub.get("Fonte Pagadora") or "").strip()
                        cnpj_raw = sub.get("CNPJ", "")
                        valor_raw = sub.get("Valor", "0")

                        linha = self._fmt_linha_subitem(
                            beneficiario,
                            fonte,
                            cnpj_raw,
                            valor_raw,
                            col_benef=13,
                            col_fonte=30,
                            col_cnpj=14,
                            col_valor=15,
                        )

                        linhas.append([f"   {linha}", ""])


                    # 3) Validação dos subitens
                    if abs(soma_sub - valor_item) > 1:
                        erro_irpf = True
                        exclusivos_todos_ok = False
                        _err_tags.add("RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA/DEFINITIVA")

                        linhas.append([
                            f"✘ Divergência: soma dos subitens ({self.format_br.formatar_moeda_br(soma_sub)}) "
                            f"≠ valor informado ({self.format_br.formatar_moeda_br(valor_item)})",
                            ""
                        ])

            # ✔️ Exibir confirmação se tudo bateu
            if exclusivos_tem_subitens and exclusivos_todos_ok:
                linhas.append(["✔ Soma dos subitens dos rendimentos exclusivos batem com os valores dos itens"])

        # ===============================================================
        #   DECLARAÇÃO DE BENS E DIREITOS (TABULADO)
        # ===============================================================

        bens = self.doc.get("DECLARAÇÃO DE BENS E DIREITOS")
        maiusculo_sem_acentos = self.to_bool(getattr(self.comprovantes, 'maiusculo_sem_acentos', True)) is not False

        if isinstance(bens, list) and bens:

            linhas.extend([[], ["DECLARAÇÃO DE BENS E DIREITOS", ""]])

            COL_WRAP = 63  # largura máxima antes da quebra automática

            def wrap_desc(texto, indent="        ", titulo="Descrição"):
                linhas_desc = quebrar_descricao(texto, COL_WRAP)
                if not linhas_desc:
                    return []
                saida = [f"{indent}{titulo}: {linhas_desc[0]}"]
                prefix = f"{indent}{titulo}: "
                spaces = " " * len(prefix)
                for ln in linhas_desc[1:]:
                    saida.append(f"{spaces}{ln}")
                return saida

            # =====================================================================
            # 🔥 LOOP 1 — COLETAR VARIÁVEIS COMPLETAS (IA + FALLBACKS)
            # =====================================================================

            dados_bens = []

            regex_cep = re.compile(r"\b(\d{5}-\d{3}|\d{2}\.\d{3}-\d{3}|\d{8})\b")
            regex_placa = re.compile(r"\b([A-Z]{3}-?\d{4}|[A-Z]{3}-?\d[A-Z]\d{2})\b", re.IGNORECASE)
            regex_renavam = re.compile(r"\b(\d{9}|\d{11})\b")
            regex_chassi = re.compile(r"\b([A-HJ-NPR-Z0-9]{17})\b")
            regex_cnpj = re.compile(r"\b(\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}|\d{14})\b")
            regex_percentual = re.compile(r"(\d{1,3}(?:[.,]\d{1,2})?)\s*%")
            regex_data = re.compile(r"\b(\d{2}/\d{2}/\d{4})\b")
            regex_area = re.compile(r"(\d{1,5}(?:[.,]\d{1,3})?)\s*(m²|m2|ha)\b", re.IGNORECASE)
            regex_mat = re.compile(r"\b(?:matr[ií]cula|mat)\s*[:\-]?\s*(\d{3,10})", re.IGNORECASE)
            regex_ano = re.compile(r"\b(19|20)\d{2}\b")
            for bem in bens:

                tipo = (bem.get("tipo") or "").strip().capitalize()
                desc_original = (bem.get("descricao") or "")
                desc_lower = desc_original.lower()

                # dicionário final de variáveis do bem
                vars = {}
                vars["DESCRICAO"] = desc_original

                # inclui variáveis que vieram da IA
                for chave, valor in bem.items():
                    if valor not in (None, "", []):
                        vars[chave.upper()] = valor
                
                # --------------------------------------------------
                # 🔥 FALLBACKS (IMÓVEL)
                # --------------------------------------------------
                if tipo.lower() == "imóvel":
                    # 1) Tenta pegar o endereço bruto da IA
                    endereco_raw = self.extrair_valor(bem, False, "Endereço", "Endereco", "endereço")

                    # 2) Normalize para dict
                    if isinstance(endereco_raw, dict):
                        endereco_dict = endereco_raw.copy()
                    elif isinstance(endereco_raw, str) and endereco_raw.strip():
                        endereco_dict = {"texto": endereco_raw.strip()}
                    else:
                        endereco_dict = {}

                    # 3) Criar texto base
                    texto_inicial = ""
                    for parte, valor in endereco_dict.items():
                        if valor not in ("", None, [], {}):
                            texto_inicial += f"{parte}: {valor}, "
                    vars["ENDERECO_COMPLETO"] = texto_inicial.rstrip(", ").strip() or None

                    # 4) Determinar texto para busca de CEP
                    texto_busca_cep = f"{texto_inicial} {desc_lower} {str(endereco_raw)}".lower()

                    # 5) Regex para extrair CEP
                    m = regex_cep.search(texto_busca_cep)
                    cep_final = m.group(1) if m else None

                    # 6) Se não achou CEP → tenta buscar_cep() com endereço textual
                    if not cep_final:
                        endereco_limpo = texto_inicial or desc_original
                        endereco_limpo = re.sub(r"\s{2,}", " ", endereco_limpo).strip()
                        try:
                            cep_api = buscar_cep(endereco_limpo)
                            if cep_api:
                                cep_final = cep_api
                        except:
                            pass

                    vars["CEP"] = cep_final

                    # 7) Se tem CEP mas endereço incompleto → buscar_endereco()
                    precisa_api = False
                    if cep_final:
                        log = endereco_dict.get("logradouro")
                        bai = endereco_dict.get("bairro")
                        if not log or not bai:
                            precisa_api = True

                    if precisa_api and cep_final:
                        try:
                            api_data = buscar_endereco(cep_final)
                        except:
                            api_data = None

                        if api_data:
                            # preencher valores faltantes
                            if "logradouro" not in endereco_dict or not endereco_dict.get("logradouro"):
                                endereco_dict["logradouro"] = api_data.get("logradouro")
                            if "bairro" not in endereco_dict or not endereco_dict.get("bairro"):
                                endereco_dict["bairro"] = api_data.get("bairro")
                            if "municipio" not in endereco_dict or not endereco_dict.get("municipio"):
                                endereco_dict["municipio"] = api_data.get("cidade")
                            if "uf" not in endereco_dict or not endereco_dict.get("uf"):
                                endereco_dict["uf"] = api_data.get("estado")
                            endereco_dict["cep"] = api_data.get("cep")

                    # 8) reconstruir texto final para PDF/MUA
                    texto_final = ""
                    for parte, valor in endereco_dict.items():
                        if valor:
                            texto_final += f"{parte}: {valor}, "
                    vars["ENDERECO_COMPLETO"] = texto_final.rstrip(", ").strip() or None

                    # propriedade (%)
                    propriedade = bem.get("Propriedade (%)")
                    if not propriedade:
                        m = regex_percentual.search(desc_lower)
                        if m:
                            propriedade = m.group(1).replace(",", ".")
                    vars["PROPRIEDADE"] = propriedade

                    # data aquisição
                    data_aq = self.extrair_valor(bem, False, "data_aquisicao", "data_aquisição", "data aquisição", "data_aquisicao:")
                    if not data_aq:
                        m = regex_data.search(desc_lower)
                        if m:
                            data_aq = m.group(1)
                    vars["DATA_AQUISICAO"] = data_aq

                    # área total
                    area = self.extrair_valor(bem, False, "Área Total", "Área Total:", "Area Total", "Area Total:")
                    if not area:
                        m = regex_area.search(desc_lower)
                        if m:
                            area = m.group(1).replace(",", ".")
                    vars["AREA_TOTAL"] = area

                    # --------------------------------------------------
                    # 🔍 Identificar se é URBANO (m²/m2) ou RURAL (ha)
                    # --------------------------------------------------
                    tipo_area = None
                    texto_busca_area = desc_lower + " " + str(bem)

                    # 1) PRIMEIRA REGRA — pela unidade da área
                    if re.search(r"\b(m2|m²)\b", texto_busca_area):
                        tipo_area = "URBANO"
                    elif re.search(r"\bha\b", texto_busca_area):
                        tipo_area = "RURAL"

                    # 2) SEGUNDA REGRA — fallback por palavras no texto
                    if not tipo_area:
                        # palavras URBANO
                        palavras_urbano = [
                            "lote", "quadra", "apartamento", "casa", "sobrado", "garagem",
                            "condomínio", "bloco", "edifício", "edificio", "residencial",
                            "prédio", "predio"
                        ]

                        # palavras RURAL
                        palavras_rural = [
                            "fazenda", "sítio", "sitio", "chácara", "chacara",
                            "rural", "gleba", "propriedade rural"
                        ]

                        for p in palavras_urbano:
                            if p in desc_lower:
                                tipo_area = "URBANO"
                                break

                        if not tipo_area:
                            for p in palavras_rural:
                                if p in desc_lower:
                                    tipo_area = "RURAL"
                                    break

                    # 3) Caso não encontre nenhum indicador
                    vars["TIPO_IMOVEL"] = tipo_area or "NÃO IDENTIFICADO"

                    # --------------------------------------------------
                    # 🐄 Dados específicos de imóvel RURAL
                    # --------------------------------------------------
                    if vars.get("TIPO_IMOVEL") == "RURAL":

                        # 1) Primeiro tenta pegar da IA
                        nome_fazenda = bem.get("nome_fazenda") or bem.get("nome_fazenda:") or bem.get("Nome da Fazenda") or bem.get("Nome da Fazenda:")

                        # 2) Se não veio → regex no texto
                        if not nome_fazenda:
                            m = re.search(r"\b(fazenda|sitio|sítio|chácara|chacara)\s+(.+?)(?=,|\.|$)", desc_lower, flags=re.IGNORECASE)
                            if m:
                                nome_fazenda = m.group(2).strip()

                        vars["NOME_FAZENDA"] = nome_fazenda

                    # --------------------------------------------------
                    # 🏙️ Dados específicos de imóvel URBANO
                    # --------------------------------------------------
                    if vars.get("TIPO_IMOVEL") == "URBANO":

                        complemento = None
                        if isinstance(endereco_dict, dict):
                            complemento = endereco_dict.get("complemento") or endereco_dict.get("Complemento")

                        texto_busca = (complemento or "") + " " + desc_original

                        # Regex robusta para LOTES e QUADRAS
                        regex_lote = re.compile(r"\b(?:lote|lt\.?)\s*(\d+)", re.IGNORECASE)
                        regex_quadra = re.compile(r"\b(?:quadra|qd\.?)\s*(\d+)", re.IGNORECASE)

                        lote = None
                        quadra = None

                        m1 = regex_lote.search(texto_busca)
                        if m1:
                            lote = m1.group(1)

                        m2 = regex_quadra.search(texto_busca)
                        if m2:
                            quadra = m2.group(1)

                        vars["LOTE"] = lote
                        vars["QUADRA"] = quadra

                    # MATRÍCULA (fallback com regex)
                    mat = self.extrair_valor(bem, False, "matricula", "matricula:", "Matrícula", "Matrícula:", "matrícula", "matrícula:")
                    if not mat:
                        m = regex_mat.search(desc_lower)
                        if m:
                            mat = m.group(1)
                    vars["MATRICULA"] = mat


                # --------------------------------------------------
                # 🔥 FALLBACKS (VEÍCULO)
                # --------------------------------------------------
                elif tipo.lower() == "veículo":

                    texto_up = desc_original.upper()

                    placa = bem.get("placa") or bem.get("Placa")
                    if not placa:
                        m = regex_placa.search(texto_up)
                        if m:
                            placa = m.group(1).upper()
                    vars["PLACA"] = placa

                    renavam = bem.get("renavam")
                    if not renavam:
                        m = regex_renavam.search(texto_up)
                        if m:
                            renavam = m.group(1)
                    vars["RENAVAM"] = renavam
                    # -------------------------------
                    # 🔎 VALIDAÇÃO DE RENAVAM
                    # -------------------------------
                    if renavam:
                        try:
                            resultado = site_4_dev.validar_renavam(str(renavam))
                            resultado_norm = normalize(str(resultado))

                            if any(x in resultado_norm for x in ["falso", "inval", "invalido"]):
                                vars["ERRO_RENAVAM"] = "NUMERO INVALIDO"

                        except Exception as e:
                            self.log.warning(f"Erro ao validar RENAVAM {renavam}: {e}")
                            vars["ERRO_RENAVAM"] = "FALHA NA VALIDACAO"

                    m = regex_chassi.search(texto_up)
                    vars["CHASSI"] = m.group(1).upper() if m else None

                    if not vars.get("MARCA"):
                        vars["MARCA"] = bem.get("marca")

                    if not vars.get("MODELO"):
                        vars["MODELO"] = bem.get("modelo")


                    # ============================
                    # 🔢 ANO (MODELO / FABRICAÇÃO)
                    # ============================

                    ano_modelo = bem.get("ano_modelo")
                    ano_fabricacao = bem.get("ano_fabricacao")

                    # fallback por regex SOMENTE se IA não trouxe nada
                    if not ano_modelo and not ano_fabricacao:
                        # findall retorna só o grupo (19|20), então usamos finditer:
                        anos = [int(m.group(0)) for m in regex_ano.finditer(desc_original)]

                        if len(anos) >= 2:
                            ano_fabricacao = min(anos)
                            ano_modelo = max(anos)
                        elif len(anos) == 1:
                            # apenas um ano → não inferir ambos
                            pass

                    vars["ANO_FABRICACAO"] = ano_fabricacao
                    vars["ANO_MODELO"] = ano_modelo

                    # --------------------------------------------------
                    # 🔍 CONSULTA POR PLACA (API ANYCAR)
                    # --------------------------------------------------
                    if placa:
                        try:
                            self.log.debug(f"consultando placa {placa} do veículo na internet...")
                            dados_placa = consultar_placa_anycar(placa)
                            self.log.debug(f"Dados encontrados: {dados_placa}")
                            if isinstance(dados_placa, dict):
                                vars["DADOS_PLACA"] = dados_placa    
                                vars["PLACA_API"] = dados_placa.get("placa")
                                if not vars.get("MARCA_ANY_CAR"):
                                    vars["MARCA_ANY_CAR"] = dados_placa.get("marca")
                                if not vars.get("MODELO_ANY_CAR"):
                                    vars["MODELO_ANY_CAR"] = dados_placa.get("modelo")
                                if not vars.get("RENAVAM_ANY_CAR"):
                                    vars["RENAVAM_ANY_CAR"] = dados_placa.get("renavam")
                                if not vars.get("CHASSI_ANY_CAR"):
                                    vars["CHASSI_ANY_CAR"] = dados_placa.get("chassi")
                                if not vars.get("COR_ANY_CAR"):
                                    vars["COR_ANY_CAR"] = dados_placa.get("cor")
                                vars["ANO_MODELO_ANY_CAR"] = _parse_ano(dados_placa.get("anoModelo") or dados_placa.get("ano_modelo"))
                                vars["ANO_FABRICACAO_ANY_CAR"] = _parse_ano(dados_placa.get("anoFabricacao") or dados_placa.get("ano_fabricacao"))
                                self.log.debug(f"Vars atualizada depois da consulta no anycar: {vars}")
                        except Exception as e:
                            self.log.warning(f"Erro ao consultar placa {placa}: {e}")
                            vars["DADOS_PLACA"] = {'erro': f"Erro ao consultar a placa na internet."}
                            vars["ERRO_ANY_CAR"] = f"Erro ao consultar a placa na internet."
                    else:
                        self.log.debug(f"Veículo sem placa, não foi possível consultar a placa na internet.")

                    # --------------------------------------------------
                    # 🔹 FIPE – CAPTURA (PADRÃO IRPF)
                    # --------------------------------------------------
                    try:
                        dados_fipe = self._consultar_fipe_veiculo_irpf(vars, bem)
                    except Exception as e:
                        self.log.warning(f"Erro ao consultar FIPE: {e}")
                        dados_fipe = None

                    vars["FIPE"] = dados_fipe
                # --------------------------------------------------
                # 🔥 FALLBACKS (PARTICIPAÇÃO)
                # --------------------------------------------------
                elif tipo.lower() == "participação":

                    # 1) Capturar CNPJ
                    cnpj = bem.get("cnpj_empresa") or bem.get("CNPJ")
                    if not cnpj:
                        m = regex_cnpj.search(desc_original)
                        if m:
                            cnpj = m.group(1)

                    cnpj_limpo = self.format_br.digits(cnpj or "")
                    vars["CNPJ_EMPRESA"] = cnpj_limpo or "NÃO ENCONTRADO"

                    if cnpj_limpo:
                        try:

                            # 3) validar participação do associado no QSA
                            nome_associado = self._get_nome(self.doc)
                            nome_decl_norm = normalize(nome_associado)
                            # 1) verifica se a API aponta que o declarante é sócio
                            is_socio_api, dados_r = self.apis.validar_associado_em_cnpj(cnpj_limpo, nome_associado)
                            qualificacao_final = None
                            if dados_r:
                                # salvar no vars
                                vars["NOME_EMPRESA"] = dados_r.get("nome")
                                vars["SITUACAO_EMPRESA"] = dados_r.get("situacao")
                                qsa = dados_r.get("qsa", []) if dados_r else []
                                # 2) procurar na lista QSA da Receita
                                for socio in qsa:
                                    nome_qsa = normalize(socio.get("nome", ""))
                                    if nome_qsa == nome_decl_norm:
                                        associado_socio = "SIM"
                                        qualificacao_final = socio.get("qual") or None
                                        break

                                if is_socio_api:
                                    associado_socio = "SIM"
                                    qualificacao_final = str(qualificacao_final).upper()
                                else:
                                    associado_socio = "NÃO"
                                    qualificacao_final = "NÃO ENCONTRADO"

                                vars["ASSOCIADO_SOCIO"] = associado_socio
                                if qualificacao_final:
                                    qualificacao_final = re.sub(r"^\s*\d{2}\s*-\s*", "", qualificacao_final, flags=re.IGNORECASE)
                                else:
                                    qualificacao_final = None

                                vars["QUALIFICACAO_SOCIO"] = qualificacao_final
                            else:
                                vars["ERRO_PARTICIPACAO"] = 'CNPJ INVÁLIDO'
                                vars["QUALIFICACAO_SOCIO"] = 'NÃO ENCONTRADO'

                        except Exception as e:
                            self.log.error(f"Erro ao consultar Receita para {cnpj_limpo}: {e}")
                    else:
                       vars["ERRO_PARTICIPACAO"] = 'CNPJ NÃO INFORMADO' 
                # --------------------------------------------------
                # 🔥 FALLBACKS (CONTA / INVESTIMENTO)
                # --------------------------------------------------
                elif tipo.lower() in ("conta", "investimento", "outros"):

                    cnpj = self.extrair_valor(
                        bem, False,
                        "cnpj_instituicao", "cnpj_instituicao:",
                        "cnpj instituicao", "cnpj instituicao:",
                        "CNPJ da Instituição", "CNPJ da Instituição:"
                    )

                    if not cnpj:
                        m = regex_cnpj.search(desc_original)
                        if m:
                            cnpj = m.group(1)

                    cnpj_limpo = self.format_br.digits(cnpj or "")
                    vars["CNPJ_INSTITUICAO"] = cnpj_limpo or None

                    if cnpj_limpo:
                        try:
                            dados_r = self.apis.buscar_dados_receita(cnpj_limpo)

                            vars["NOME_EMPRESA"] = dados_r.get("nome")
                            vars["SITUACAO_EMPRESA"] = dados_r.get("situacao")

                        except Exception as e:
                            self.log.error(f"Erro ao consultar Receita para {cnpj_limpo}: {e}")
                            vars["ERRO_INSTITUICAO"] = "Erro ao consultar CNPJ da instituição"

                    conta = (
                        bem.get("Número da Conta")
                        or bem.get("Número da Conta:")
                        or bem.get("numero_conta")
                    )
                    vars["CONTA"] = conta

                # salva tudo
                dados_bens.append({
                    "bem": bem,
                    "tipo": tipo,
                    "variaveis": vars,
                    "desc_original": desc_original,
                })

            # =====================================================================
            # 🔥 LOOP 2 — EXIBIR (descrição + MUA + valores + subtítulos)
            # =====================================================================
            self.log.debug(f"Loop inicial finalizado, dados capturados: {dados_bens}")
            for item in dados_bens:

                bem = item["bem"]
                tipo = item["tipo"]
                vars = item["variaveis"]
                desc_original = item["desc_original"]

                desc_exibir = normalize(desc_original).upper() if maiusculo_sem_acentos else desc_original
                valor_f = self.format_br.formatar_moeda_br(bem.get("valor") or 0).replace("R$ ", "")

                # título
                linhas.append([f"{tipo}:", ""])

                # descrição IR
                for ln in wrap_desc(desc_exibir, titulo="Descrição"):
                    linhas.append([ln, ""])

                # descrição MUA (somente imóveis + se houver template)
                if tipo.lower() == "imóvel":
                    if vars.get("TIPO_IMOVEL") == "URBANO":
                        template = getattr(self.comprovantes, "descricao_imovel_urbano", None)
                    else:
                        template = getattr(self.comprovantes, "descricao_imovel_rural", None)

                    if template:
                        desc_mua = self.comprovantes.fill_template(template, vars)
                        desc_mua = re.sub(r"{[^}]+}", "XXXXX", desc_mua)
                        desc_mua = normalize(desc_mua).upper() if maiusculo_sem_acentos else desc_mua

                        for ln in wrap_desc(desc_mua, titulo="Descrição(MUA)"):
                            linhas.append([ln, ""])


                # valor
                linhas.append([f"        valor: {valor_f}", ""])

                # --------------------------------------------------------------
                # SUBTÍTULOS (usa somente valores brutos da IA para exibição)
                # --------------------------------------------------------------

                def add_if(label, val):
                    if val not in (None, "", []):
                        linhas.append([f"        {label}: {val}", ""])
                        return val
                    self.log.debug(f"Item {label} não possui valor, ignorando...")
                    return None

                # (a lógica de exibição continua igual ao seu código original)
                # mas SEM fallbacks — porque eles já foram feitos no loop 1

                # IMÓVEL
                if tipo.lower() == "imóvel":
                    add_if("Tipo do Imóvel", vars.get("TIPO_IMOVEL"))
                    add_if("Nome da Fazenda/Sítio", vars.get("NOME_FAZENDA"))
                    if vars.get("LOTE") or vars.get("QUADRA"):
                        add_if("Lote e Quadra", f'LOTE: {vars.get("LOTE")} | QUADRA: {vars.get("QUADRA")}')
                    add_if("inscrição municipal (IPTU)", bem.get("inscricao_municipal"))

                    if vars.get("ENDERECO_COMPLETO"):
                        for ln in wrap_desc(vars.get("ENDERECO_COMPLETO"), titulo="Endereço"):
                            linhas.append([ln, ""])
                    add_if("área total", vars.get("AREA_TOTAL"))
                    add_if("data aquisição", vars.get("DATA_AQUISICAO"))
                    add_if("matrícula", vars.get("MATRICULA"))
                    add_if("registrado em cartório", bem.get("registrado_cartorio"))
                    add_if("Nome do cartório", bem.get("nome_cartorio"))
                    add_if("propriedade (%)", vars.get("PROPRIEDADE"))
                    add_if("cep", vars.get("CEP"))

                # VEÍCULO
                elif tipo.lower() == "veículo":
                    add_if("Marca", vars.get("MARCA"))
                    add_if("Modelo", vars.get("MODELO"))
                    add_if("renavam", vars.get("RENAVAM"))
                    add_if("placa", vars.get("PLACA"))
                    add_if("chassi", vars.get("CHASSI"))
                    add_if("Ano Modelo", vars.get("ANO_MODELO"))
                    add_if("Ano Fabricação", vars.get("ANO_FABRICACAO")) 
                    add_if("Cor", vars.get("COR"))
                    
                    # ================================
                    # 🔹 DADOS DO VEÍCULO (PLACA)
                    # ================================
                    if vars.get("DADOS_PLACA"):
                        linhas.append(["      Consulta por placa no site: https://anycar.com.br:", ""])

                        add_if("Marca   (anycar)", vars.get("MARCA_ANY_CAR"))
                        add_if("Modelo  (anycar)", vars.get("MODELO_ANY_CAR"))
                        add_if("Ano fab (anycar)", vars.get("ANO_FABRICACAO_ANY_CAR"))
                        add_if("Ano mod (anycar)", vars.get("ANO_MODELO_ANY_CAR"))
                        add_if("Cor     (anycar)", vars.get("COR_ANY_CAR"))
                        add_if("Renavam (anycar)", vars.get("RENAVAM_ANY_CAR"))
                        add_if("Chassi  (anycar)", vars.get("CHASSI_ANY_CAR"))
                        add_if("ERRO    (anycar)", vars.get("ERRO_ANY_CAR"))

                    # ================================
                    # 🔹 FIPE – VEÍCULO (IRPF)
                    # ================================
                    dados_fipe = vars.get("FIPE")
                    if dados_fipe:
                        linhas.append(["      FIPE (Consulta no site: https://veiculos.fipe.org.br/):", ""])

                        fipe = dados_fipe.get("fipe", {})
                        match = dados_fipe.get("match", {})

                        add_if("FIPE - Marca", match.get("marca_encontrada"))
                        add_if("FIPE - Modelo", match.get("modelo_encontrado"))
                        add_if("FIPE - Ano", match.get("ano_nome"))
                        add_if("FIPE - Mês Referência", fipe.get("MesReferencia"))
                        add_if("FIPE - Valor", fipe.get("Valor"))
                        add_if("FIPE - Código", fipe.get("CodigoFipe"))
                        add_if("FIPE - Combustível", fipe.get("Combustivel"))
                    else:
                        add_if("FIPE", "Erro ao consultar a FIPE do veículo")

                # PARTICIPAÇÃO
                elif tipo.lower() == "participação":
                    add_if("pertence a", bem.get("pertence_a"))
                    add_if("cnpj empresa", vars.get("CNPJ_EMPRESA"))
                    add_if("nome empresarial", vars.get("NOME_EMPRESA"))
                    add_if("situação", vars.get("SITUACAO_EMPRESA"))
                    add_if("sócio no QSA?", vars.get("ASSOCIADO_SOCIO"))
                    add_if("qualificação do sócio", vars.get("QUALIFICACAO_SOCIO"))
                    add_if("ERRO", vars.get("ERRO_PARTICIPACAO"))


                # CONTA / INVESTIMENTO
                elif tipo.lower() in ("conta", "investimento", "outros"):
                    add_if("pertence a", bem.get("pertence_a"))
                    add_if("banco", bem.get("banco"))
                    add_if("conta", vars.get("CONTA"))
                    add_if("cnpj instituição", vars.get("CNPJ_INSTITUICAO"))
                    add_if("nome empresarial", vars.get("NOME_EMPRESA"))
                    add_if("situação", vars.get("SITUACAO_EMPRESA"))
                    add_if("observações", bem.get("observacoes"))

                linhas.append(["", ""])



        # --- 🔽 EXIBIÇÃO DO DEMONSTRATIVO DE ATIVIDADE RURAL ---
        demonstrativo_agro = (
            self.doc.get("DEMONSTRATIVO DE ATIVIDADE RURAL")
            or self.doc.get("Demonstrativo de Atividade Rural")
            or {}
        )

        if isinstance(demonstrativo_agro, dict) and demonstrativo_agro:
            apuracao = (
                demonstrativo_agro.get("APURAÇÃO DO RESULTADO")
                or demonstrativo_agro.get("Apuração do Resultado")
                or demonstrativo_agro.get("APURACAO DO RESULTADO")
            )
            receitas_e_despesas = (
                self.extrair_valor(demonstrativo_agro, False, "RECEITAS E DESPESAS", "RECEITAS E DESPESAS:")
            )
            if (
                (receitas_e_despesas and isinstance(receitas_e_despesas, dict)) 
                or 
                (apuracao and isinstance(apuracao, dict))
            ):
                linhas.extend([[], ["DEMONSTRATIVO DE ATIVIDADE RURAL", ""]])

            if receitas_e_despesas and isinstance(receitas_e_despesas, dict):
                COL_MES = 10
                COL_VALOR = 16
                COL_DESPESA = 16
                header = (
                    f"{'   MES':^{COL_MES}}  "
                    f"{'RENDA':^{COL_VALOR}}  "
                    f"{'DESPESA':^{COL_DESPESA}}"
                )
                linhas.append([header])
                for mes_agro, valores in receitas_e_despesas.items():
                    renda_float = self.format_br.converter_valor_para_float(valores.get("Receita Bruta", "")) if valores.get("Receita Bruta", "") else 0
                    despesa_float = self.format_br.converter_valor_para_float(valores.get("Despesas de Custeio/Investimento", "")) if valores.get("Despesas de Custeio/Investimento", "") else 0
                    renda_br = self.format_br.formatar_moeda_br(renda_float) if isinstance(renda_float,float) and renda_float > 0 else 'R$ 0,00'
                    despesa_br = self.format_br.formatar_moeda_br(despesa_float) if isinstance(despesa_float,float) and despesa_float > 0 else 'R$ 0,00'

                    linha = (
                        f"   {str(mes_agro).upper():<{COL_MES}}"
                        f"{renda_br:<{COL_VALOR}}  "
                        f"{despesa_br:<{COL_DESPESA}}"
                    )
                    linhas.append([linha])

            # só exibe se tiver algo relevante
            if apuracao and isinstance(apuracao, dict):
                agro_data = {"APURAÇÃO DO RESULTADO:": apuracao}
                linhas.extend(organize_data(agro_data, self.type_name))
        
        resumo = (
                self.doc.get("Resumo")
                or self.doc.get("RESUMO")
                or {}
            )
        # só exibe se tiver algo relevante
        if resumo and isinstance(resumo, dict) and exibir_resumo:
            linhas.extend(organize_data({"Resumo:": resumo}, self.type_name))
        

        # --- 🔼 FIM DO BLOCO ---
        self._consolidar_rendimentos_por_regras(campos_mua)
        renda_agro, tributos_agro = self._injetar_agro_receita_bruta_no_mua(campos_mua)
      
        # captura despesa agro para exibir, sem alterar o MUA
        despesa_agro_valor = self._extrair_despesa_agro()

        if not any((v or 0) > 0 for v in campos_mua.values()):
            campos_mua["Outros"] = 0.01
            self.log.debug("MUA vazio; forçando 'Outros' = 0,01.")
            
        # campos lancamento mua 
        linhas.extend([[], ["CAMPOS PARA LANÇAMENTO NO MUA:", ""]])
        linhas.append(["Período:", self.periodo_documento])
        soma_total_renda_mua = 0.0
        for campo, valor in campos_mua.items():
            if valor > 0: 
                linhas.append([f"{campo}:", self.format_br.formatar_moeda_br(valor)])
                soma_total_renda_mua += valor

        soma_pj = valor_total_rend_pj or 0.0
        soma_pf = valor_total_rend_pf or 0.0
        soma_tributos_agro = tributos_agro or 0.0
        soma_renda_agro = renda_agro or 0.0
        soma_total_tributos = soma_pj + soma_pf + soma_tributos_agro
        soma_total_renda_ir = soma_pj + soma_pf + soma_renda_agro

        # regras
        regras = {}
        if getattr(self, "regras_mua", None):
            nomes_auto = [
                "irpf", "imposto de renda", "declaração de imposto de renda",
                "declaracao de imposto de renda", "declaração de ajuste anual",
                "declaracao de ajuste anual"
            ]
            regras = self.regras_mua.get_doc(nomes_auto) or {}

        #despesa informa nas regras se houver
        despesa_padrao = str(regras.get('Despesas', '')) if regras else ''
        self.log.debug(f"Valor da despesa padrão: {despesa_padrao}")
        despesa_padrao_int = 0.0
        if despesa_padrao and "%" in despesa_padrao:
            self.log.debug(f"Percentual('%') encontrado")
            despesa_padrao_int = self.format_br.converter_valor_para_float(despesa_padrao.replace('%', ''))
            self.log.debug(f"Despesa formatada: {despesa_padrao_int}")
            despesa_padrao_int = despesa_padrao_int * soma_total_renda_mua / 100
        elif despesa_padrao and "R$" in  despesa_padrao.upper(): # ja vem com o valor correto em R$ 
            despesa_padrao_int = self.format_br.converter_valor_para_float(despesa_padrao) # função ja converte valores monetários corretamente
            self.log.debug(f"Despesa formatada: {despesa_padrao_int}")
        elif despesa_padrao:
            try: 
                despesa_padrao_int = float(despesa_padrao)
            except:
                despesa_padrao_int = 0.0
        else:
            despesa_padrao_int = 0.0

        # ============================================
        #  NOVA LÓGICA PARA EXIBIÇÃO DA DESPESA NO MUA
        # ============================================

        despesa_a_exibir = None
        remover_despesa_regras = False
        mensagem_despesa = None

        modo = considerar_despesas_agro.strip().lower()  # sempre / maior / menor / nunca

        tem_despesa_ir = (despesa_agro_valor or 0) > 0
        tem_despesa_padrao = (despesa_padrao_int or 0) > 0

        # ============================
        # CASO A — HÁ DESPESA NO IRPF
        # ============================
        self.log.debug(f"Considerar despesa agro?:{modo}")

        if tem_despesa_ir:
            self.log.debug(f"Despesa agro encontrada no IR!")
            if modo == "sempre" or modo == "sim":
                despesa_a_exibir = despesa_agro_valor
                remover_despesa_regras = True

            elif "maior" in modo:
                if not tem_despesa_padrao:
                    mensagem_despesa = "Erro: sem despesa padrão para comparar com o valor da despesa agro."
                elif despesa_agro_valor > despesa_padrao_int:
                    despesa_a_exibir = despesa_agro_valor
                    remover_despesa_regras = True
                    mensagem_despesa = f"A despesa padrão de {despesa_padrao} é MENOR que a despesa declarada no documento."
                else:
                    mensagem_despesa = f"A despesa padrão de {despesa_padrao} é MAIOR que a despesa declarada no documento."

            elif "menor" in modo:
                if not tem_despesa_padrao:
                    mensagem_despesa = "Erro: sem despesa padrão para comparar com o valor da despesa agro."
                elif despesa_agro_valor < despesa_padrao_int:
                    despesa_a_exibir = despesa_agro_valor
                    remover_despesa_regras = True
                    mensagem_despesa = f"A despesa padrão de {despesa_padrao} é MAIOR que a despesa declarada no documento."
                else:
                    mensagem_despesa = f"A despesa padrão de {despesa_padrao} é MENOR que a despesa declarada no documento."

            elif normalize(modo) in ['nao', 'nunca']:
                pass  # não exibe nada

        # =====================================
        # CASO B — NÃO HÁ DESPESA NO IRPF
        # =====================================
        else:
            self.log.debug(f"Sem despesa agro no IR")

            if not tem_despesa_padrao:
                mensagem_despesa = (
                    "Erro Sem Despesas - despesa agro não localizada no documento "
                    "e nenhum percentual informado nas regras para IRPF."
                )
            else:
                if modo == "sempre":
                    mensagem_despesa = (
                        "Despesa da atividade rural não encontrada no documento. "
                        f"Considerando o valor da despesa padrão informado nas regras de {despesa_padrao}."
                    )

                elif modo == "maior":
                    pass

                elif modo == "menor":
                    mensagem_despesa = (
                        "Despesa agro declarada está zerada. "
                        f"Considerar a despesa padrão informada nas regras de {despesa_padrao}."
                    )

                elif normalize(modo) in ['nao', 'nunca']:
                    pass

        # =============================
        # EXIBIR O RESULTADO NO PDF
        # =============================
        modo_despesa = exibir_despesas_em_rs.lower()
        if despesa_a_exibir:
            despesa_a_exibir = despesa_a_exibir / 12 if "mensal" in modo_despesa else despesa_a_exibir
            periodicidade_despesa = "MENSAL" if "mensal" in modo_despesa else "ANUAL"
            linhas.append([f"Despesa(CUSTEIO- {periodicidade_despesa}):", self.format_br.formatar_moeda_br(despesa_a_exibir)])
        # CASO 2 — não tem despesa agro → verificar exibir_despesas_em_rs
        else:
            ja_reportou_falta = (mensagem_despesa and "sem despesa" in mensagem_despesa.lower())

            if "sim" in modo_despesa and not ja_reportou_falta:

                if despesa_padrao_int <= 0:
                    linhas.append(["✘ Sem despesa padrão informado nas regras."])

                else:
                    # ANUAL
                    if "anual" in modo_despesa:
                        linhas.append([f"Despesa ({despesa_padrao} - Anual):",self.format_br.formatar_moeda_br(despesa_padrao_int)])

                    # MENSAL
                    elif "mensal" in modo_despesa:

                        # Se despesa padrão veio como porcentagem → dividir por 12
                        if "%" in despesa_padrao:
                            valor_mensal = despesa_padrao_int / 12
                        else:
                            # Valor fixo → não dividir
                            valor_mensal = despesa_padrao_int

                        linhas.append([
                            f"Despesa ({despesa_padrao} - Mensal):",self.format_br.formatar_moeda_br(valor_mensal)])
        if mensagem_despesa:
            linhas.append(["Observação:", mensagem_despesa])

        # =============================
        # REMOVER 'Despesas' das regras
        # =============================
        if remover_despesa_regras and "Despesas" in regras:
            regras.pop("Despesas", None)
   
        # --- 🔽 NOVO BLOCO: SALVAR DADOS_MUA (igual ao Pró-Labore) ---
        self.dados_mua = {
            "periodo": ano_calendario,        # usa o ano-calendário como período
            "doc_origem": self.file,
            "tipo": "IRPF",
            "campos": campos_mua
        }
        # --- 🔼 FIM DO NOVO BLOCO ---
        linhas.extend(self.exibir_regras_doc(regras))
        # validação de nome
        row = self._nome_validation_row()
        if row:
            linhas.append(row) 
        self.sections.append((titulo_secao, linhas))

        # --- 🔽 NOVA VALIDAÇÃO: conferência de 13º salário ---
        try:
            rend_pj = self.doc.get(self._KEY_REND_PJ, [])
            rend_exclusiva = self.doc.get("RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA/DEFINITIVA", [])
            self.log.debug(f"Rendimentos sujeitos a tributação excluiva {rend_exclusiva}")
            # soma todos os 13º das fontes PJ
            soma_13_pj = sum(
                self.format_br.converter_valor_para_float(item.get("13º Salário") or item.get("13 Salario") or "0,00")
                for item in rend_pj if isinstance(item, dict)
            )

            # pega o valor do item 01 - 13º salário da seção exclusiva
            valor_item_13 = 0.0
            if rend_exclusiva:
                for item in rend_exclusiva:
                    if isinstance(item, dict) and "13" in (item.get("Descrição") or "").replace("º", "").replace("°", ""):
                        valor_item_13 = self.format_br.converter_valor_para_float(item.get("Valor"))
                        break

            # CASOS DE ERRO:
            # - se existir valor de 13º na seção exclusiva
            #   mas soma_13_pj == 0 (nenhum item PJ tem 13º)
            # - ou se ambos existirem mas divergirem mais que 1 real
            if valor_item_13 > 0 and abs(soma_13_pj - valor_item_13) > 1:
                self.sections.append(("ERRO 13°: ", [[f"✘ Verificar se os valores do 13° foram capturados corretamente, divergência detectada entre 13º dos rendimentos da PJ ({soma_13_pj}) e item 01 dos rendimentos tributados ({valor_item_13})."]]))
                erro_irpf = True
                _err_tags.update({"13º Salário", "Rendimentos Tributáveis"})
        except Exception as e:
            self.log.error(f"Erro ao validar o 13º salário: {e}")
        
        # --- 🔽 VALIDAÇÃO: conferência com o RESUMO ---
        try:

            # =====================
            # 🔸 Busca flexível do campo de rendimentos
            # =====================
            # Permite tanto o formato antigo quanto o novo modelo plano
            if resumo and any(normalize(k) in ("recebidos de pessoa juridica pelo titular", "recebidos de pessoa física/exterior pelo titular") for k in resumo.keys()):
                # Novo formato direto (nosso modelo IRPFSummary)
                rend_resumo = resumo
            else:
                # Formato antigo, aninhado
                chave_rend = next(
                    (k for k in resumo.keys() if normalize(k) in ("rendimentos tributaveis", "rendimentos tributáveis")),
                    None
                )
                rend_resumo = resumo.get(chave_rend) if chave_rend else None


            resumo_pj = resumo_pf = resumo_agro = resumo_total = 0.0

            # =====================
            # 🔸 Caso 1: DICIONÁRIO DETALHADO
            # =====================
            if isinstance(rend_resumo, dict):
                resumo_pj = self.format_br.converter_valor_para_float(
                    rend_resumo.get("Recebidos de Pessoa Jurídica pelo Titular")
                    or rend_resumo.get("Pessoa Jurídica - Titular")
                    or rend_resumo.get("Pessoa Jurídica")
                    or 0
                )
                resumo_pf = self.format_br.converter_valor_para_float(
                    rend_resumo.get("Recebidos de Pessoa Física/Exterior pelo Titular")
                    or rend_resumo.get("Pessoa Física/Exterior - Titular")
                    or rend_resumo.get("Pessoa Física")
                    or 0
                )
                # tenta capturar o resultado tributável da atividade rural
                resumo_agro = self.format_br.converter_valor_para_float(
                    rend_resumo.get("Resultado Tributável da Atividade Rural")
                    or rend_resumo.get("Resultado tributável da Atividade Rural")
                    or rend_resumo.get("Resultado Atividade Rural")
                    or rend_resumo.get("Atividade Rural")
                    or 0
                )

                # se não veio no resumo, tenta buscar dentro do bloco DEMONSTRATIVO
                if resumo_agro == 0:
                    bloco_rural = (
                        self.doc.get("DEMONSTRATIVO DE ATIVIDADE RURAL")
                        or self.doc.get("Demonstrativo de Atividade Rural")
                        or {}
                    )
                    apur = bloco_rural.get("APURAÇÃO DO RESULTADO") or {}
                    resumo_agro = self.format_br.converter_valor_para_float(
                        apur.get("Resultado Tributável")
                        or apur.get("RESULTADO TRIBUTÁVEL")
                        or apur.get("RESULTADO TRIBUTAVEL")
                        or 0
                    )

                resumo_total = self.format_br.converter_valor_para_float(
                    rend_resumo.get("Total de Rendimentos Tributáveis")
                    or (resumo_pj + resumo_pf + resumo_agro)
                )

            # =====================
            # 🔸 Caso 2: STRING (Total direto)
            # =====================
            elif isinstance(rend_resumo, str):
                resumo_total = self.format_br.converter_valor_para_float(rend_resumo)

            # =====================
            # 🔸 Caso 3: NÚMERO
            # =====================
            elif isinstance(rend_resumo, (int, float)):
                resumo_total = float(rend_resumo)

            # =====================
            # 🔸 COMPARAÇÃO DETALHADA
            # =====================

            diff_pj = abs(soma_pj - resumo_pj)
            diff_pf = abs(soma_pf - resumo_pf)
            diff_agro = abs(soma_tributos_agro - resumo_agro)
            diff_total = abs(soma_total_tributos - resumo_total)

            self.log.info(
                f"[DEBUG IRPF] Comparação de rendimentos: "
                f"PJ={soma_pj} vs {resumo_pj} | "
                f"PF={soma_pf} vs {resumo_pf} | "
                f"AGRO={soma_tributos_agro} vs {resumo_agro} | "
                f"TOTAL={soma_total_tributos} vs {resumo_total}"
            )

            divergencias = []
            # Só checa parciais se o resumo for detalhado
            if isinstance(rend_resumo, dict):
                if diff_pj > 1:
                    divergencias.append(f"PJ ({soma_pj} ≠ {resumo_pj})")
                    _err_tags.update({"RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA JURÍDICA PELO TITULAR", "Resumo"})
                if diff_pf > 1:
                    divergencias.append(f"PF ({soma_pf} ≠ {resumo_pf})")
                    _err_tags.update({"RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA FÍSICA E DO EXTERIOR PELO TITULAR", "Resumo"})
                if diff_agro > 1:
                    divergencias.append(f"Agro ({soma_tributos_agro} ≠ {resumo_agro})")
                    _err_tags.update({"DEMONSTRATIVO DE ATIVIDADE RURAL", "Resumo"})

            total_soma_resumo = resumo_pj + resumo_pf + resumo_agro
            diff_total_por_itens = abs(soma_total_tributos - total_soma_resumo)

            total_ok = False

            # 1) Primeiro tenta bater com o total da IA
            if diff_total <= 1:
                total_ok = True

            # 2) Se não bateu, tenta com a soma dos itens do resumo (PJ + PF + AGRO)
            elif diff_total_por_itens <= 1:
                total_ok = True

            # 3) Nenhuma das formas bateu → erro
            else:
                divergencias.append(
                    f"Total divergente: "
                    f"capturado={soma_total_tributos} | "
                    f"total no resumo={total_soma_resumo}"
                )
                erro_irpf = True


            if divergencias:
                self.log.warning("⚠ Divergências detectadas no resumo: " + "; ".join(divergencias))
                self.sections.append(("ERRO: ", [[f"✘ Verificar se os valores do IR foram capturados corretamente, divergência detectada entre os valores capturados e o resumo do IRPF."]]))
                erro_irpf = True
            else:
                linhas.append([f"✔ Valores capturados estão de acordo com o resumo!"])                

        except Exception as e:
            self.log.error(f"Erro ao validar totais do resumo: {e}")

        validar_sigilo_fiscal = self.to_bool(
            getattr(self.comprovantes, 'validar_sigilo_fiscal', True)
        ) is not False

        if validar_sigilo_fiscal:

            # 🔥 1) SE JÁ EXISTE CACHE POSITIVO → USA E NÃO VALIDA DE NOVO
            if sigilo_fiscal_cacheado is True:
                self.log.debug("✔ Sigilo fiscal já validado anteriormente (cache).")
                linhas.append([f"✔ Documento com selo 'PROTEGIDO POR SIGILO FISCAL' (cache)."])

            else:
                # 🔍 2) VALIDA PELO TEXTO ATUAL
                nomes_sigilo_fiscal = [
                    normalize(item)
                    for item in ['sigilo fiscal', 'protegido por sigilo', 'protegida por sigilo']
                ]

                for nome_sigilo in nomes_sigilo_fiscal:
                    if nome_sigilo in normalize(self.context):
                        self.log.debug("✔ Selo 'PROTEGIDO POR SIGILO FISCAL' encontrado!")
                        linhas.append([f"✔ Documento com selo 'PROTEGIDO POR SIGILO FISCAL'."])

                        # 💾 SALVA NO CACHE TEXTUAL
                        CACHE_IRPF_TEXTO.setdefault(chave_cache, {})["sigilo_fiscal"] = True
                        break
                else:
                    self.log.debug("✘ Selo 'PROTEGIDO POR SIGILO FISCAL' NÃO encontrado!")
                    linhas.append([f"✘ Selo 'PROTEGIDO POR SIGILO FISCAL' não encontrado, verifique."])
                    erro_irpf = True

        
        if ano_calendario_limite_int > 0:
            if ano_calendario_int >= ano_calendario_limite_int:
                linhas.append([f"✔ Ano calendário({ano_calendario_int}) está dentro do limite({ano_calendario_limite_int})."])
            else:
                linhas.append([f"✘ IRPF vencido, ano calendário({ano_calendario_int}) anterior ao limite({ano_calendario_limite_int})."])     

        # === CACHE IRPF ===
        if erro_irpf:
            doc_limpo = self.drop_keys_simples(self.doc, list(_err_tags))
            CACHE_IRPF[chave_cache] = doc_limpo
            self.log.debug(f"💾 Cache parcial ({chave_cache}) sem {sorted(_err_tags)} -> {list(doc_limpo.keys())}")
        else:
            CACHE_IRPF[chave_cache] = dict(self.doc)
            self.log.debug(f"✅ Cache completo atualizado para {chave_cache}")
            
        return (not erro_irpf)

    def _categorizar_rendimento_pj(self, rendimento_pj: dict, nome_declarante: str, regras_pj: list, valor_13: float = 0.0) -> str:
        """
        Decide o campo MUA com base na ordem das regras da planilha.
        Sempre usa o valor principal + 13º juntos, mas o tipo 13° influencia o destino.
        """
        nome_pagador = (rendimento_pj.get("Fonte Pagadora") or rendimento_pj.get("Fonte") or "").upper()
        cnpj_pagador = str(rendimento_pj.get("CNPJ", "") or "")

        palavras_previdencia = ["PREV.", "PREVIDENCIA", "INSS", "INSTITUTO NACIONAL DO SEGURO SOCIAL", "APOSENT", "SEGURIDADE SOCIAL"]
        palavras_cooperativas = ["COOPERATIVA", "CCPI", "COOP", "SICREDI", "SICOOB", "BANCO", "BRADESCO", "ITAU", "CEF", "CAIXA", "BB", "BANCO DO BRASIL", "CC CREDICOOP", "CC CREDICOPE", "C.C.L.A.A", "VALE DO CERRADO"]
        
        is_previdencia = any(normalize(p) in normalize(nome_pagador) for p in palavras_previdencia)
        is_cooperativa = any(normalize(p) in normalize(nome_pagador) for p in palavras_cooperativas)
        is_socio = False
        try:
            if nome_declarante and cnpj_pagador:
                is_socio, _ = self.apis.validar_associado_em_cnpj(cnpj_pagador, nome_declarante)
        except Exception:
            pass

        fallback_categoria = "Salário Líquido"  # padrão

        # 🔥 REGRA DO ITEM 04 — ignorar todos os rendimentos desse CNPJ
        cnpj_limpo = self.format_br.digits(cnpj_pagador)
        if (cnpj_limpo in self.cnpjs_item_04 or normalize(nome_pagador) in self.cnpjs_item_04 ) and self.desconsiderar_rendas_item_04:
            self.log.debug(f"[ITEM 04] Ignorando rendimento PJ pois CNPJ {cnpj_limpo} aparece em Item 04 (rescisão).")
            return None   # NÃO LANÇA NO MUA
        # ===========================================================
        # 🔥 NOVA REGRA — CONTROLE DE COOPERATIVAS
        # ===========================================================
        considerar_coop = normalize(getattr(self.comprovantes, "considerar_cooperativas", "Sim") or "Sim").strip()
        ocupacao_raw = self.extrair_valor(self.doc,False, "ocupação:", "ocupação", "Ocupação:", "Ocupação", "Ocupacao:", "Ocupacao", 'ocupacao', 'ocupacao:')
        ocup_raw = normalize(str(ocupacao_raw or ""))

        # Detectar se a ocupação é bancária / cooperativa
        palavras_bancario = ["banco", "banc", "financial", "finance", "coop", "cooperativa", "sicredi", "sicoob"]
        ocupacao_eh_bancario = any(p in ocup_raw for p in palavras_bancario)
        # -------------------------------
        # CASO 1 → "Não" → ignorar item
        # -------------------------------
        if considerar_coop.lower() == "nao":
            if is_cooperativa:
                self.log.debug(f"[COOP] Item '{nome_pagador}' ignorado (regra = NÃO).")
                if cnpj_limpo:
                    self.cnpjs_cooperativas_desconsideradas.add(cnpj_limpo)
                else:
                    self.cnpjs_cooperativas_desconsideradas.add(nome_pagador)
                return None   # ← retorna None: NÃO LANÇA NO MUA

        # ---------------------------------------------------------------
        # CASO 2 → "Apenas para bancário"
        # ---------------------------------------------------------------
        if "bancario" in considerar_coop.lower():
            if is_cooperativa:
                # só aceita se tiver 13° OU ocupação indicar bancário/cooperativa
                if not (valor_13 > 0 or ocupacao_eh_bancario):
                    self.log.debug(
                        f"[COOP] Item '{nome_pagador}' ignorado (Apenas para bancário: sem 13° e ocupação não bancária)"
                    )
                    if cnpj_limpo:
                        self.cnpjs_cooperativas_desconsideradas.add(cnpj_limpo)
                    else:
                        self.cnpjs_cooperativas_desconsideradas.add(nome_pagador)
                    return None
                else:
                    self.log.debug(
                        f"[COOP] Item '{nome_pagador}' considerado, possui 13° ou ocupação ligado ao banco."
                    )
            else:
                self.log.debug(
                        f"Item '{nome_pagador}' NÃO é cooperativa."
                    )
        # ---------------------------------------------------------------
        # CASO 3 → "Sim"
        # → não faz nada
        # ---------------------------------------------------------------


        for condicao, categoria_final in regras_pj:
            cond = normalize(condicao)

            # fallback configurável
            if "demais" in cond:
                fallback_categoria = categoria_final
                continue

            # 1️⃣ Previdência — prioridade máxima
            if "previdencia" in cond or "inss" in cond:
                if is_previdencia:
                    self.log.debug(f"→ Regra '{condicao}' (previdência) casou com {nome_pagador}")
                    return categoria_final

            # 2️⃣ Regra de 13° — respeita a posição na planilha
            if any(t in cond for t in ("13", "décimo terceiro", "decimo terceiro", "13º", "13o")):
                if valor_13 > 0:
                    self.log.debug(f"→ Regra '{condicao}' (13°) casou com {nome_pagador}")
                    return categoria_final

            # 3️⃣ Sócio
            if "socio" in cond or "sócio" in cond:
                if is_socio:
                    self.log.debug(f"→ Regra '{condicao}' (sócio) casou com {nome_pagador}")
                    return categoria_final

            # 4️⃣ Cooperativa
            # 4️⃣ Cooperativa
            if "cooperativa" in cond:
                if is_cooperativa:
                    if valor_13 > 0:
                        # Se cooperativa e tiver 13°, trata como salário líquido
                        self.log.debug(
                            f"→ Regra '{condicao}' (cooperativa) casou, mas tem 13° → enviando para 'Salário Líquido'"
                        )
                        return "Salário Líquido"
                    else:
                        self.log.debug(f"→ Regra '{condicao}' (cooperativa) casou com {nome_pagador}")
                        return categoria_final


        # 5️⃣ Fallback (demais)
        self.log.debug(f"→ Nenhuma regra casou para {nome_pagador}. Usando fallback '{fallback_categoria}'")
        return fallback_categoria

    def _consolidar_rendimentos_por_regras(self, campos_mua: dict):
        regras = getattr(self, "comprovantes", None)
        if not regras:
            self.log.error("⚠️ Planilha de regras de IRPF não encontrada.")
            return
        nome_declarante = self.extrair_valor(self.doc, False, "Nome", "Nome:")
        considerar_13 = normalize(getattr(self.comprovantes, 'considerar_13', 'Sim'))
        rendimentos_pj = self.doc.get(self._KEY_REND_PJ, [])
        if rendimentos_pj and isinstance(rendimentos_pj, list):
            regras_pj_planilha = getattr(self.comprovantes, 'regras_pj', [])

            for item in rendimentos_pj:
                # valores
                valor_principal = self.format_br.converter_valor_para_float(
                    item.get("Rend. Recebidos de Pes. Jurídica")
                    or item.get("Rendimentos Recebidos de Pessoa Jurídica")
                    or item.get("Valor")
                ) or 0.0

                valor_13 = self.format_br.converter_valor_para_float(
                    item.get("13º Salário") or item.get("13 Salário") or "0,00"
                ) or 0.0

                # se for para desconsiderar o 13°, ignora no cálculo do total
                if considerar_13 == "sim":
                    valor_total = valor_principal + valor_13
                elif "outros" in considerar_13:
                    valor_total = valor_principal
                    campos_mua["Outros"] += valor_13
                else:
                    valor_total = valor_principal

                if valor_total <= 0:
                    continue


                # categoria de destino conforme regras da planilha
                campo_mua = self._categorizar_rendimento_pj(item, nome_declarante, regras_pj_planilha, valor_13)

                campo_norm = normalize(campo_mua)
                for k in campos_mua.keys():
                    if normalize(k) == campo_norm:
                        campos_mua[k] += valor_total
                        self.log.debug(f"✔ Rendimento '{item.get('Fonte Pagadora')}' lançado em '{campo_mua}' ({valor_total})")
                        break
                else:
                    self.log.debug(f"⚠ Campo '{campo_mua}' não encontrado em campos_mua. Ignorado.")
        
        if self._KEY_REND_PFEX in self.doc and hasattr(self.comprovantes, 'rendimentos_pf'):
            regras_pf, mapeamento_regras_pf = getattr(self.comprovantes, 'rendimentos_pf', {}), {
                "Trabalho N. Assalariado": getattr(self, "total_pf_trabalho", 0.0),
                "Aluguel": getattr(self, "total_pf_aluguel", 0.0), 
                "Outros": getattr(self, "total_pf_outros", 0.0),
                "Exterior": getattr(self, "total_pf_exterior", 0.0)
            }
            for regra_key, valor in mapeamento_regras_pf.items():
                if valor > 0:
                    campo_mua = regras_pf.get(regra_key, "Outros")
                    campo_norm = normalize(campo_mua)
                    for k in campos_mua.keys():
                        if normalize(k) == campo_norm:
                            campos_mua[k] += valor
        
        rendimentos_isentos = self.doc.get(self._KEY_REND_ISENTOS, [])
        if rendimentos_isentos and isinstance(rendimentos_isentos, list) and hasattr(self.comprovantes, 'rendimentos_isentos'):
            regras_isentos = getattr(self.comprovantes, 'rendimentos_isentos', {})
            self.log.debug(f"Lista regras rend isentos: {regras_isentos}")
            for item in rendimentos_isentos:
                try:
                    self.log.debug(f"Iniciando validação do Item Isento: {item}")
                    item_id, valor = int(str(item.get("Item", "")).strip()), self.format_br.converter_valor_para_float(item.get("Valor"))
                    self.log.debug(f"Item ID -> {item_id}| Valor -> {valor}")

                    if valor:
                        campo_mua = regras_isentos.get(str(item_id))
                        self.log.debug(f"Camo MUA encontrado para o item: {campo_mua}")
                        # ---------- ajuste para item com subitens ----------
                        subitens = item.get("Subitens") or []

                        if subitens:
                            soma_validos = 0.0
                            soma_item_04 = 0.0

                            for sub in subitens:
                                valor_sub = self.format_br.converter_valor_para_float(sub.get("Valor") or 0)
                                fonte_sub = normalize(sub.get("Fonte Pagadora") or "")
                                cnpj_limpo = self.format_br.digits(sub.get("CNPJ") or "")
                                beneficiario = normalize(self.extrair_valor(sub, False, "Beneficiário", "Beneficiário:", "beneficiário", "beneficiário:", "beneficiario", "beneficiario:"))
                                descrição = normalize(self.extrair_valor(sub, False, "Descrição", "Descrição:", "descrição", "descrição:", "Descricao", "Descricao:", "descricao", "descricao:"))
                                eh_item_04 = (
                                    cnpj_limpo in self.cnpjs_item_04
                                    or fonte_sub in (normalize(x) for x in self.cnpjs_item_04)
                                )
                                eh_coop_desc = (
                                    cnpj_limpo in self.cnpjs_cooperativas_desconsideradas
                                    or fonte_sub in (normalize(x) for x in self.cnpjs_cooperativas_desconsideradas)
                                )

                                eh_dependente = (
                                    beneficiario == "dependente"
                                )
                                if not descrição and "|" in fonte_sub:
                                    fonte_sub = fonte_sub.split('|')[0].strip()
                                    descrição = fonte_sub.split('|')[1].strip()

                                eh_seguro = (
                                    "seguro" in descrição
                                )

                                if ((eh_item_04 and self.desconsiderar_rendas_item_04) or 
                                    (eh_dependente and self.desconsiderar_rendimentos_dependentes) or
                                    (eh_seguro and "99" in str(item_id) and self.desconsiderar_99_seguros) or
                                    eh_coop_desc
                                    ):
                                    # subitem pertence ao item 04 → será DESCONTADO
                                    soma_item_04 += valor_sub
                                    continue


                                # subitem válido, não é item 04
                                soma_validos += valor_sub

                            # NOVA REGRA:
                            # Sempre usar o total do item como base
                            valor_final = valor - soma_item_04

                            # Se o valor_final ficou negativo por erro, zera
                            if valor_final < 0:
                                valor_final = 0

                            valor = valor_final


                        # 🔥 fallback: se item não existir, usa "DEMAIS/OUTROS/RESTO/TUDO" se existir
                        if campo_mua is None:
                            self.log.debug(f"Campo NÃO encontrado, tentando buscar por campo geral")
                            fallback_keys = ["demais", "geral", "outros", "resto", "tudo"]

                            for key_original, destino in regras_isentos.items():
                                if normalize(str(key_original)) in fallback_keys:
                                    campo_mua = destino
                                    break
                        # Se encontrou campo (normal ou fallback), soma
                        if campo_mua:
                            self.log.debug(f"Campo encontrado")
                            campo_norm = normalize(campo_mua)
                            for k in campos_mua.keys():
                                if normalize(k) == campo_norm:
                                    campos_mua[k] += valor    

                except (ValueError, TypeError): continue
        
        # rendimentos sujeitos à tributação exclusiva/definitiva (usa regras de 'Rendimentos_Tributados')
        rendimentos_tributados = self.doc.get("RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA/DEFINITIVA", [])
        if rendimentos_tributados and isinstance(rendimentos_tributados, list) and hasattr(self.comprovantes, 'rendimentos_tributados'):
            regras_tributados = getattr(self.comprovantes, 'rendimentos_tributados', {})
            # converte chaves numéricas em int

            for item in rendimentos_tributados:
                try:
                    item_id = int(str(item.get("Item", "")).strip())
                    valor = self.format_br.converter_valor_para_float(item.get("Valor"))

                    if valor:
                        campo_mua = regras_tributados.get(item_id)

                        # ---------- ajuste para item com subitens ----------
                        subitens = item.get("Subitens") or []

                        if subitens:
                            soma_validos = 0.0
                            soma_item_04 = 0.0

                            for sub in subitens:
                                valor_sub = self.format_br.converter_valor_para_float(sub.get("Valor") or 0)
                                fonte_sub = normalize(sub.get("Fonte Pagadora") or "")
                                cnpj_limpo = self.format_br.digits(sub.get("CNPJ") or "")
                                beneficiario = normalize(self.extrair_valor(sub, False, "Beneficiário", "Beneficiário:", "beneficiário", "beneficiário:", "beneficiario", "beneficiario:"))
                                eh_item_04 = (
                                    cnpj_limpo in self.cnpjs_item_04
                                    or fonte_sub in (normalize(x) for x in self.cnpjs_item_04)
                                )
                                eh_coop_desc = (
                                    cnpj_limpo in self.cnpjs_cooperativas_desconsideradas
                                    or fonte_sub in (normalize(x) for x in self.cnpjs_cooperativas_desconsideradas)
                                )

                                eh_dependente = (
                                    beneficiario == "dependente"
                                )


                                if (eh_item_04 and self.desconsiderar_rendas_item_04) or eh_coop_desc or (eh_dependente and self.desconsiderar_rendimentos_dependentes):
                                    # subitem pertence ao item 04 → será DESCONTADO
                                    soma_item_04 += valor_sub
                                    continue


                                # subitem válido, não é item 04
                                soma_validos += valor_sub

                            # NOVA REGRA:
                            # Sempre usar o total do item como base
                            valor_final = valor - soma_item_04

                            # Se o valor_final ficou negativo por erro, zera
                            if valor_final < 0:
                                valor_final = 0

                            valor = valor_final


                        # 🔥 fallback: se item não existir, usa "DEMAIS/OUTROS/RESTO/TUDO" se existir
                        if campo_mua is None:
                            self.log.debug(f"Campo NÃO encontrado")
                            fallback_keys = ["demais", "geral", "outros", "resto", "tudo"]

                            for key_original, destino in regras_tributados.items():
                                if normalize(str(key_original)) in fallback_keys:
                                    campo_mua = destino
                                    break
                        # Se encontrou campo (normal ou fallback), soma
                        if campo_mua:
                            self.log.debug(f"Campo encontrado")
                            campo_norm = normalize(campo_mua)
                            for k in campos_mua.keys():
                                if normalize(k) == campo_norm:
                                    campos_mua[k] += valor    

                except (ValueError, TypeError):
                    continue

    def _consultar_fipe_veiculo_irpf(self, vars: dict, bem: dict):
        try:
            marca = vars.get("MARCA") or vars.get("MARCA_ANY_CAR")
            modelo = vars.get("MODELO") or vars.get("MODELO_ANY_CAR")
            ano = vars.get("ANO_MODELO") or vars.get("ANO_MODELO_ANY_CAR") or vars.get("ANO_FABRICACAO") or vars.get("ANO_FABRICACAO_ANY_CAR")

            if not (marca and modelo and ano):
                return None

            return consultar_fipe(marca, modelo, int(ano))

        except Exception as e:
            self.log.warning(f"Erro ao consultar FIPE (IRPF): {e}")
            return None


                
    def _fmt_linha_subitem(self, beneficiario, fonte, cnpj, valor,
                       col_benef=15, col_fonte=35, col_cnpj=14, col_valor=15):
        """
        Formata a linha padrão:
        Beneficiário | Fonte Pagadora | CNPJ | Valor
        """
        # limpa
        cnpj_limp = self.format_br.digits(cnpj or "")
        valor_limpo = (
            self.format_br.formatar_moeda_br(
                self.format_br.converter_valor_para_float(valor or "0")
            ).replace("R$ ", "")
        )

        # corta a fonte se for grande demais
        if len(fonte) > col_fonte:
            fonte = fonte[:col_fonte - 3] + "..."

        linha = (
            f"{beneficiario:<{col_benef}}  "
            f"{fonte:<{col_fonte}}  "
            f"{cnpj_limp:<{col_cnpj}}  "
            f"{valor_limpo:<{col_valor}}"
        )
        return linha
                     
    def _get_nome(self, d: dict) -> str:
        """Nome padronizado do declarante para matching e exibição."""
        bruto = (
            d.get("__nome_pessoa__")
            or d.get("Nome:")
            or d.get("Nome")
            or d.get("Nome do declarante")
            or "N/I"
        )
        return bruto.strip()
    
    def _get_ano(self, d: dict) -> str:
        ano = self.extrair_valor(
            d, False,
            "Ano-Calendário", "Ano-Calendário:", "__ano_calendario__",
            "Ano", "Ano-Calêndário", "Ano-Calêndário:", "Ano-Calendario"
        )
        if ano is None:
            return ""
        return str(ano).strip()

    def _injetar_agro_receita_bruta_no_mua(self, campos_mua: dict) -> tuple[float, float]:
        """
        Se existir 'DEMONSTRATIVO DE ATIVIDADE RURAL' com
        'APURAÇÃO DO RESULTADO' → 'Receita bruta total',
        soma esse valor em 'Rendas Agropecuárias' no MUA.
        """
        bloco = self.extrair_valor(self.doc,False, "DEMONSTRATIVO DE ATIVIDADE RURAL:", "DEMONSTRATIVO DE ATIVIDADE RURAL", 
            "Demonstrativo de Atividade Rural","Demonstrativo de Atividade Rural:", "DEMONSTRATIVO DA ATIVIDADE RURAL", "DEMONSTRATIVO DA ATIVIDADE RURAL:", 
            "DEMONSTRATIVO DE ATIVIDADE RURAL - BRASIL", "DEMONSTRATIVO DE ATIVIDADE RURAL - BRASIL:"
        )                         
        if not isinstance(bloco, dict):
            return 0.0, 0.0

        apur = (
            bloco.get("APURAÇÃO DO RESULTADO")
            or bloco.get("Apuração do Resultado")
            or bloco.get("APURACAO DO RESULTADO")
        )
        if not isinstance(apur, dict):
            return 0.0, 0.0

        valor_bruto = (
            apur.get("Receita bruta total")
            or apur.get("Receita Bruta Total")
            or apur.get("RECEITA BRUTA TOTAL")
        )
        valor_tributavel = self.extrair_valor(apur, True, "RESULTADO TRIBUTÁVEL", "RESULTADO TRIBUTAVEL", "RESULTADO TRIBUTÁVEL:")
        # v = receita bruta total
        # i = resultado tributável (imposto)
        v = self.format_br.converter_valor_para_float(valor_bruto) or 0.0
        i = self.format_br.converter_valor_para_float(valor_tributavel) or 0.0

        considerar_renda_agro = self.to_bool(getattr(self.comprovantes, "rendas_agro", "Sim")) is not False
        if v > 0 and considerar_renda_agro:
            campos_mua["Rendas Agropecuárias"] = campos_mua.get("Rendas Agropecuárias", 0.0) + v

        return v, i
