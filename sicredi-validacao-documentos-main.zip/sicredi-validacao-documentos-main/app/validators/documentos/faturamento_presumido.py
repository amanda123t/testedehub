import re
from datetime import datetime, date, timedelta
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data, normalize

@registrar_validador("faturamento presumido", "presumido", "presumedbilling")
class ValidadorFaturamentoPresumido(ValidadorBase):
    def validar(self) -> bool:
        self.log.info("Iniciando validação do Faturamento Presumido")
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de Renda Presumida encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_faturamento_presumido_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )
        
    def validar_faturamento_presumido_individual(self):
        # 1) Nome do documento + validação de nome
        self.nome_documento = self.extrair_nome_documento(self.doc)

        # ====== NOVO: helper para contar meses de operação ======
        def meses_de_operacao(data_abertura: date, hoje: date) -> int:
            """
            Conta meses fechados entre o 1º dia do mês de abertura e o 1º dia do mês corrente (exclusivo).
            - Mês de abertura conta.
            - Mês corrente NÃO conta.
            - Piso = 1 (evita divisão por zero).
            Ex.: hoje=27/08; abertura=30/05 -> conta 05,06,07 = 3 meses.
            """
            inicio = date(data_abertura.year, data_abertura.month, 1)
            fim_exclusivo = date(hoje.year, hoje.month, 1)
            if inicio >= fim_exclusivo:
                return 1
            return max(1, (fim_exclusivo.year - inicio.year) * 12 + (fim_exclusivo.month - inicio.month))

        # 3) Montagem base das linhas
        linhas = organize_data(self.doc, self.doc_type)
        linhas = [["Documento lido:", self.file]] + linhas

        # 4) Captura e normalização de campos principais
        # CNPJ (tenta várias chaves comuns)
        self.cnpj_empregador = (
            self.doc.get("CNPJ:") or
            self.doc.get("CNPJ") or
            self.doc.get("CNPJ da Empresa:") or "SEM CNPJ"
        ).strip()

        # Valor total do faturamento presumido anual
        valor_str = (
            self.doc.get("Valor Total:", "")
            or self.doc.get("Faturamento Presumido Anual:", "")
            or self.doc.get("Faturamento Presumido Anual", "")
            or ""
        )
        valor_float = self.format_br.converter_valor_para_float(valor_str) if valor_str else None
        self.valor_documento = self.format_br.formatar_moeda_br(valor_float) if valor_float is not None else ""

        data_emissao = self._extrair_data_emissao()
        if isinstance(data_emissao, datetime):
            data_emissao = data_emissao.date()
        # A) Limite em dias -> usa SOMENTE a data de emissão (sua regra)
        limite_dias = getattr(getattr(self, "comprovantes", None), "limite_dias_faturamento_presumido", None)
        try:
            limite_dias_int = int(limite_dias) if (limite_dias is not None and str(limite_dias).strip() != "") else None
        except Exception:
            limite_dias_int = None

        hoje = datetime.now().date()

        if limite_dias_int is not None and data_emissao:
            data_corte = hoje - timedelta(days=limite_dias_int)
            if data_emissao < data_corte:
                linhas.append([
                    #"Limite de dias do faturamento presumido:",
                    f"✘ Data de emissão {data_emissao.strftime('%d/%m/%Y')} é anterior ao limite de {limite_dias_int} dias (corte em {data_corte.strftime('%d/%m/%Y')})."
                ])
            else:
                linhas.append([
                    #"Limite de dias do faturamento presumido:",
                    f"✔ Data de emissão dentro do limite de {limite_dias_int} dias (emissão {data_emissao.strftime('%d/%m/%Y')}, corte {data_corte.strftime('%d/%m/%Y')})."
                ])
        elif limite_dias_int is not None and not data_emissao:
            linhas.append([
                #"Limite de dias do faturamento presumido:",
                "✘ Limite da data de emissão configurado, mas a data de emissão não foi identificada no documento."
            ])
        else:
            linhas.append([
                #"Limite de dias do faturamento presumido:",
                "✔ Não aplicado (sem limites para data de emissão configurado)."
            ])

        # 5) Consulta na Receita: situação + data de abertura (respeita flag da planilha)
        validar_situacao = getattr(getattr(self, "comprovantes", None), "validar_situacao_do_cnpj_fat_presumido", True)
        validar_situacao = self.to_bool(validar_situacao) is not False
        data_abertura_str = None
        meses_operacao = None
        if validar_situacao:
            if self.cnpj_empregador:
                dados_receita = self.apis.buscar_dados_receita(self.cnpj_empregador)
                if dados_receita:
                    situacao = (dados_receita.get('situacao') or "").upper()
                    if situacao == "ATIVA":
                        linhas.append(["✔ CNPJ está ATIVO na Receita Federal"])
                    else:
                        linhas.append([f"✘ CNPJ está {situacao or 'com situação não informada'} na Receita Federal"])

                    # Data de abertura
                    data_abertura_str = (dados_receita.get('abertura') or "").strip()  # esperado "dd/mm/aaaa"
                    if data_abertura_str:
                        try:
                            dt_abertura = self.format_br.formatar_data_br(data_abertura_str).date()
                            hoje = date.today()
                            meses_operacao = meses_de_operacao(dt_abertura, hoje)
                            linhas.append(["Data de abertura (Receita):", data_abertura_str])
                            linhas.append(["Meses de operação (fechados):", str(meses_operacao)])
                        except Exception:
                            linhas.append([f"✘ Formato inválido da data de abertura: {data_abertura_str}"])
                    else:
                        linhas.append(["✘ Data de abertura na receita não informada"])
                else:
                    linhas.append(["✘ Dados do CNPJ não encontrados na Receita. Verificar!"])
            else:
                linhas.append(["✘ CNPJ não informado no documento"])
        
        # 6) Cálculo do valor mensal
        valor_mensal = None  # <- garante variável mesmo se não houver valor_total

        # Regra: divisor = 12 se meses_operacao >= 12; senão divisor = meses_operacao (piso 1).
        dividir_por = getattr(getattr(self, "comprovantes", None), "dividir_por", '12') 
        if valor_float is not None:
            divisor = 12
            if isinstance(meses_operacao, int) and meses_operacao > 0 and meses_operacao < 12 and "abertura" in str(dividir_por):
                divisor = meses_operacao
            valor_mensal = valor_float / divisor
            linhas.append([f"Valor mensal (faturamento/{divisor}):", self.format_br.formatar_moeda_br(valor_mensal)])
        else:
            linhas.append(["✘ Valor total do faturamento não identificado no documento"])
        
                # ====== Validação contra limites da planilha (se existirem e > 0) ======
        def _to_float_pos(v):
            """Converte v em float. Se None, vazio, inválido ou <= 0, retorna None (não valida)."""
            if v is None:
                return None
            if isinstance(v, (int, float)):
                return float(v) if float(v) > 0 else None
            s = str(v).strip()
            if not s:
                return None
            try:
                num = self.format_br.converter_valor_para_float(s)
                return num if (num is not None and num > 0) else None
            except Exception:
                return None

        limite_mensal = None
        limite_anual = None
        if hasattr(self, "comprovantes") and self.comprovantes is not None:
            limite_mensal = _to_float_pos(getattr(self.comprovantes, "limite_mensal_fat_presumido", None))
            limite_anual  = _to_float_pos(getattr(self.comprovantes, "limite_anual_fat_presumido", None))

        # Valida apenas se houver pelo menos um limite > 0 e houver valor_total para comparar
        if valor_float is not None and (limite_mensal is not None or limite_anual is not None):
            #linhas.append(["", ""])  # separador visual

            # Limite mensal (se > 0)
            if limite_mensal is not None:
                if valor_mensal is not None:
                    if valor_mensal <= limite_mensal:
                        linhas.append([
                            "Limite mensal (planilha):",
                            f"✔ {self.format_br.formatar_moeda_br(valor_mensal)} <= {self.format_br.formatar_moeda_br(limite_mensal)}"
                        ])
                    else:
                        diff = valor_mensal - limite_mensal
                        linhas.append([
                            "Limite mensal (planilha):",
                            f"✘ {self.format_br.formatar_moeda_br(valor_mensal)} ultrapassa "
                            f"{self.format_br.formatar_moeda_br(limite_mensal)} em {self.format_br.formatar_moeda_br(diff)}"
                        ])
                else:
                    linhas.append([
                        "Limite mensal (planilha):",
                        "✘ Não foi possível calcular o valor mensal (valor total ausente)."
                    ])

            # Limite anual (se > 0)
            if limite_anual is not None:
                if valor_float <= limite_anual:
                    linhas.append([
                        "Limite anual (planilha):",
                        f"✔ {self.format_br.formatar_moeda_br(valor_float)} <= {self.format_br.formatar_moeda_br(limite_anual)}"
                    ])
                else:
                    diff = valor_float - limite_anual
                    linhas.append([
                        "Limite anual (planilha):",
                        f"✘ {self.format_br.formatar_moeda_br(valor_float)} ultrapassa "
                        f"{self.format_br.formatar_moeda_br(limite_anual)} em {self.format_br.formatar_moeda_br(diff)}"
                    ])
        else:
            linhas.append(["✔ Sem limites definidos para faturamento presumido"])


        # ------------ VALIDAÇÃO POR PORTE (limites_por_porte + adicional MEI) -------------
        validar_por_porte = getattr(getattr(self, "comprovantes", None), "validar_total_com_o_porte_fat_presumido", True)
        validar_por_porte = self.to_bool(validar_por_porte) is not False

        if validar_por_porte:
            porte_receita = self.apis.capturar_porte_receita(self.cnpj_empregador) if (self.cnpj_empregador and self.cnpj_empregador != "SEM CNPJ") else None
            limites_por_porte = getattr(getattr(self, "comprovantes", None), "limites_por_porte", None)
            limite_faturamento = None
            if isinstance(limites_por_porte, dict) and porte_receita:
                limite_faturamento = limites_por_porte.get(porte_receita)
                try:
                    limite_faturamento = float(limite_faturamento)
                except Exception:
                    limite_faturamento = None
            
            # ------------ LIMITE ADICIONAL DO MEI (se configurado) -------------
            limite_adicional_mei = None
            try:
                raw_adicional = getattr(getattr(self, "comprovantes", None), "limite_adicional_do_MEI", None)
                if raw_adicional not in (None, "", 0):
                    limite_adicional_mei = float(raw_adicional)
            except Exception:
                limite_adicional_mei = None

            if valor_float is not None:
                # Caso especial: MEI
                if porte_receita == "MEI" and isinstance(limite_adicional_mei, (int, float)) and limite_adicional_mei > 0:
                    adicional_brl = self.format_br.formatar_moeda_br(limite_adicional_mei)

                    if not isinstance(limite_faturamento, (int, float)) or limite_faturamento == 0:
                        # Sem limite padrão configurado -> valida só pelo adicional
                        if valor_float <= limite_adicional_mei:
                            linhas.append([f"✔ Dentro do limite adicional do MEI de {adicional_brl}."])
                        else:
                            linhas.append([ f"✘ ACIMA do limite adicional do MEI de {adicional_brl}."])
                    else:
                        # Com limite padrão:
                        limite_brl = self.format_br.formatar_moeda_br(limite_faturamento)
                        if valor_float <= limite_faturamento:
                            linhas.append([ f"✔ Dentro do limite de {limite_brl} para o porte MEI."])
                        elif valor_float <= limite_adicional_mei:
                            linhas.append([ f"✔ Dentro do limite adicional do MEI de {adicional_brl}."])
                        else:
                            linhas.append([ f"✘ ACIMA do limite adicional do MEI de {adicional_brl}."])

                else:
                    # Não é MEI (ou sem adicional válido) -> valida só pelo limite padrão
                    if not isinstance(limite_faturamento, (int, float)) or limite_faturamento == 0:
                        if porte_receita:
                            linhas.append([ f"✔ Não há limite configurado para o porte '{porte_receita}'."])
                        else:
                            linhas.append([ "✘ Porte não identificado na Receita; não foi possível validar contra limites."])
                    else:
                        limite_brl = self.format_br.formatar_moeda_br(limite_faturamento)
                        if valor_float <= limite_faturamento:
                            linhas.append([ f"✔ Dentro do limite de {limite_brl} para o porte {porte_receita}."])
                        else:
                            linhas.append([ f"✘ ACIMA do limite de {limite_brl} para o porte {porte_receita}."])

        regras = {}
        
        if getattr(self, "regras_mua", None):
            nomes = ["Faturamento presumido", "Presumido", "fat presumido", "faturamento(presumido)", "presumedbilling"]
            # get_doc aceita string ou lista. Se for tua versão antiga, pode trocar por nomes[0].
            regras = self.regras_mua.get_doc(nomes)

        linhas_regras = self.exibir_regras_doc(regras)
        linhas.extend(linhas_regras)


        # 6) Finalização
        linhas.append([])
        row = self._nome_validation_row()
        if row:
            linhas.append(row)

        self.sections.append(("FATURAMENTO PRESUMIDO", linhas))
        self.log.info("Validação do Faturamento Presumido concluída.")
        return True

    def _extrair_data_emissao(self) -> date | None:
        """Procura a data de emissão nas chaves (case/acentos flexível) e no contexto."""
        candidatos = {
            "data de emissao", "data emissão", "data da emissão", "emissão",
            "data do documento", "data", "data de emissão",
        }

        for k, v in (self.doc or {}).items():
            if v and re.sub(r"[:\s]+$", "", normalize(k or "")) in candidatos:
                dt = self.format_br.formatar_data_br(str(v))
                if dt:
                    return dt.date()  # <-- garante date

        ctx = (self.context or "")
        m = re.search(r"(\d{2}/\d{2}/\d{4})", ctx)
        if m:
            dt = self.format_br.formatar_data_br(m.group(1))
            return dt.date() if dt else None  # <-- garante date

        return None
