# app/validators/renda_presumida.py
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data, normalize

@registrar_validador("renda presumida", "income")
class ValidadorRendaPresumida(ValidadorBase):
    def validar(self) -> bool:
        self.log.info("Iniciando validação da renda presumida")
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de Renda Presumida encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_renda_presumida_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context,
                "dados_mua": getattr(self, "dados_mua", {})
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )

    def validar_renda_presumida_individual(self):
        self.nome_documento = self.extrair_nome_documento(self.doc)
        usuario_sicredi = '_' in self.nome_documento
        self.dados_mua = {
            "periodo": "",
            "doc_origem": "",
            "tipo": "Efetivo",
            "campos": {}
        }
        # 3) período (quatro opções com fallback para data atual se emissão não encontrada)
        periodo_cfg = getattr(getattr(self, "comprovantes", None), "periodo_renda_presumida", None)

        # montar saída
        linhas = organize_data(self.doc, self.doc_type)
        linhas = [["Documento lido:", self.file]] + linhas
        linhas.append([])
        
        # —–– Período (usa só Base) –––
        ano, mes = self.format_br.obter_ano_mes_atual()
        ref_atual = self.format_br.extrair_mes_ano(datetime(ano, mes, 1))                    # "MM/AAAA"
        ref_anterior = self.format_br.extrair_mes_ano(self.format_br.mes_anterior(datetime(ano, mes, 1)))

        self._aviso_emissao = None # para exibir aviso no PDF quando faltar emissão

        periodo_cfg = getattr(getattr(self, "comprovantes", None), "periodo_renda_presumida", None)
        if periodo_cfg:
            p = str(periodo_cfg).strip().lower()
            if "emiss" in p:
                emissao_dt = self._encontrar_data_emissao()  # ver abaixo: troca _parse_data_flex por formatar_data_br
                if not emissao_dt:
                    linhas.append(["✘ Data de emissão não encontrada no documento, emitir uma nova renda presumida no Bureau"])
                    self.periodo_documento = ref_anterior if "anterior" in p else ref_atual
                else:
                    self.periodo_documento = self.format_br.extrair_mes_ano(
                        self.format_br.mes_anterior(emissao_dt) if "anterior" in p else emissao_dt
                    )
            else:
                self.periodo_documento = ref_atual if ("atual" in p and "anterior" not in p) else ref_anterior
        else:
            self.periodo_documento = ref_anterior
            linhas.append(["✔ Sem regras de período definidas; considerado mês anterior ao atual"])

        # -----------------------------
        # APLICAÇÃO DA DATA DE CORTE
        # -----------------------------
        data_corte = getattr(self.comprovantes, "data_virada_mes_renda_presumida", None)

        if data_corte not in (None, "", 0, "0"):
            try:
                corte_dia = int(str(data_corte).strip())
            except:
                corte_dia = None

            if corte_dia and corte_dia > 0:
                hoje = datetime.today()

                # Se o dia de hoje é maior ou igual ao dia da data de corte → soma 1 mês
                if hoje.day >= corte_dia:
                    try:
                        mes, ano = map(int, self.periodo_documento.split("/"))
                        if mes == 12:
                            mes = 1
                            ano += 1
                        else:
                            mes += 1
                        self.periodo_documento = f"{mes:02d}/{ano}"
                    except Exception as e:
                        linhas.append(["✘ Erro ao verificar a data de corte, verificar o periodo a ser incluso no MUA."])

        # 4) valor original + percentual
        valor_original = self.format_br.converter_valor_para_float(self.doc.get("Valor:") or self.doc.get("Valor") or "0") or 0.0
        perc_cfg = getattr(getattr(self, "comprovantes", None), "percentual_valor", None)
        perc_dec, perc_label = self.comprovantes.parse_percent_to_decimal_and_label(perc_cfg)  # (0.7, "70%")
        valor_final = valor_original * perc_dec

        # flag considerar_limite
        considerar_limite = False
        cfg = getattr(self, "comprovantes", None)
        if cfg is not None:
            considerar_limite = bool(self.to_bool(getattr(cfg, "considerar_limite", None)))

        # 5) validação de limite (retorno estruturado)
        limite_info = self._validar_limites(valor_final, considerar_limite=considerar_limite)  # dict ou None

        # valor que será exibido/lançado
        valor_exibir = valor_final
        if limite_info and isinstance(limite_info, dict) and limite_info.get("override_valor") is not None:
            valor_exibir = float(limite_info["override_valor"])

        # expõe para {valor} no parecer e para linhas
        self.valor_documento = self.format_br.formatar_moeda_br(valor_exibir)
        
        if not usuario_sicredi:
            if self.nome_documento:
                row = self._nome_validation_row()
                if row:
                    linhas.append(row)
            else:
                linhas.append([f"✘ Erro ao capturar o nome no documento, verificar!"])
        else:
            linhas.append([f"✘ Erro ao capturar o nome no documento - foi pego o usuário Sicredi({self.nome_documento}), verificar!"])

        # mensagens finais de limite
        if limite_info and limite_info.get("row"):
            linhas.append([limite_info["row"]])
        if limite_info and limite_info.get("extra_row"):
            linhas.append([limite_info["extra_row"]])
        if limite_info.get("fallback_validacao"):
            linhas.append([limite_info["row"]])
            linhas.append([limite_info["fallback_validacao"]["row"]])
        linhas.append(["Campos no MUA:", ""])
        linhas.append(["Período:", self.periodo_documento])
        linhas.append([f"Valor ({perc_label}):", self.valor_documento])

        # 7) regras (planilha > fallback)
        regras: Dict[str, Any] = {}
        if getattr(self, "regras_mua", None):
            nomes = ["renda presumida", "income", "presumida", "renda estimada"]
            regras = self.regras_mua.get_doc(nomes)
        self.log.debug(f'Regras encontradas para renda presumida: {regras}')

        doc_origem_regra = (regras.get("Documento Origem") or "Outros").strip()
        campo_regra = (regras.get("Campo") or "Outros").strip()

        self.dados_mua = {
            "periodo": self.periodo_documento,
            "doc_origem": doc_origem_regra,
            "tipo": "Efetivo",
            "campos": {
                campo_regra: self.format_br.converter_valor_para_float(self.valor_documento) or 0.0
            },
            "ocupacao": {}
        }
        self.log.debug(f"Dados MUA gerados para renda presumida: {self.dados_mua}")

        linhas_regras = self.exibir_regras_doc(regras)  # usa BASE do ValidadorBase
        linhas.extend(linhas_regras)

        self.sections.append(("RENDA PRESUMIDA", linhas))
        self.log.info("Validação da renda presumida FINALIZADA.")
        return True
    
    # ---------- decisão de limite único x carteiras ----------
    def _validar_limites(self, valor_final: float, considerar_limite: bool = False) -> Optional[dict]:
        cfg = getattr(self, "comprovantes", None)
        if not cfg:
            return {
                "row": ("✔ Sem limites definidos para Renda presumida"),
                "override_valor": None,
                "extra_row": None,
            }

        # --------------------------------------------------------
        # 1) Montar limites_dict primeiro
        # --------------------------------------------------------
        limites_dict: Dict[str, float] = {}
        raw = getattr(cfg, "limites_por_carteira", None)

        if isinstance(raw, dict):
            limites_dict = {
                str(k): self.format_br.converter_valor_para_float(v)
                for k, v in raw.items() if v is not None
            }
        elif isinstance(raw, list):
            for item in raw:
                try:
                    k = str(item["carteiras/porte/risco"])
                    v = self.format_br.converter_valor_para_float(item["limites"])
                    limites_dict[k] = v
                except Exception:
                    continue

        limite_unico_override = getattr(cfg, "limite_renda_presumida", None)
        limite_unico_override = (
            self.format_br.converter_valor_para_float(limite_unico_override)
            if limite_unico_override not in (None, "")
            else None
        )

        # --------------------------------------------------------
        # 2) Detectar se contém algum risco
        # --------------------------------------------------------
        RISCOS_COMUNS = [
            "BAIXISSIMO", "BAIXO", "MÉDIO 1", "MÉDIO 2",
            "ALTO", "ALTISSIMO", "DEFAUT"
        ]
        RISCOS_COMUNS = [normalize(item) for item in RISCOS_COMUNS]

        contem_risco = any(
            any(risco in normalize(k) for risco in RISCOS_COMUNS)
            for k in limites_dict.keys()
        )

        # --------------------------------------------------------
        # 3) CASO SEJA RISCO
        # --------------------------------------------------------
        if contem_risco:
            risco_doc = (
                self.doc.get("Faixa de risco:") or
                self.doc.get("Faixa de risco") or
                ""
            )
            risco_doc_normalizado = normalize(risco_doc)

            # --- Caso B — IA não encontrou risco ---
            if risco_doc_normalizado == "":
                return {
                    "row": ("⚠ Faixa de risco não encontrada no documento — validado usando todos os limites."),
                    "override_valor": None,
                    "extra_row": None,
                    "fallback_validacao": self._validar_limites_por_carteira(
                        valor_final, limites_dict, considerar_limite
                    )
                }

            # --- Caso A — risco encontrado ---
            # -----------------------------
            # 1) Correspondência EXATA
            # -----------------------------
            for chave, limite_valor in limites_dict.items():
                chave_norm = normalize(chave)
                if chave_norm == risco_doc_normalizado:
                    return self._validar_limite_unico(
                        valor_final,
                        limite_valor,
                        considerar_limite
                    )

            # -----------------------------
            # 2) Correspondência PARCIAL (documento ⟶ planilha)
            # -----------------------------
            matches = []
            for chave, limite_valor in limites_dict.items():
                chave_norm = normalize(chave)
                if chave_norm in risco_doc_normalizado:
                    matches.append((chave_norm, limite_valor))

            # -----------------------------
            # 3) Correspondência PARCIAL (planilha ⟶ documento)
            # -----------------------------
            for chave, limite_valor in limites_dict.items():
                chave_norm = normalize(chave)
                if risco_doc_normalizado in chave_norm:
                    matches.append((chave_norm, limite_valor))

            # Se encontrou correspondências parciais, usa a melhor (maior string)
            if matches:
                matches = list(dict.fromkeys(matches))
                # ordena pelo tamanho e pega o melhor match
                melhor_chave, melhor_limite = sorted(matches, key=lambda x: len(x[0]), reverse=True)[0]
                return self._validar_limite_unico(
                    valor_final,
                    melhor_limite,
                    considerar_limite
                )

            # -----------------------------
            # 4) Nada bateu
            # -----------------------------
            return {
                "row": (f"✘ Risco '{risco_doc}' existe no documento mas NÃO existe na planilha."),
                "override_valor": None,
                "extra_row": None,
            }

        # --------------------------------------------------------
        # 4) NÃO É RISCO → LÓGICA NORMAL
        # --------------------------------------------------------
        n_lim = len(limites_dict)

        if n_lim == 1:
            ((_, lim_lista),) = limites_dict.items()
            limite_efetivo = lim_lista

            if limite_unico_override is not None and abs(limite_unico_override - lim_lista) > 1e-9:
                limite_efetivo = limite_unico_override

            return self._validar_limite_unico(valor_final, limite_efetivo, considerar_limite)

        elif n_lim > 1:
            return self._validar_limites_por_carteira(valor_final, limites_dict, considerar_limite)

        else:
            if limite_unico_override is not None:
                return self._validar_limite_unico(valor_final, limite_unico_override, considerar_limite)

            return {
                "row": ("✔ Sem limites definidos para Renda presumida"),
                "override_valor": None,
                "extra_row": None,
            }

    def _validar_limite_unico(self, valor: float, limite: float, considerar_limite: bool = False) -> dict:
        txt_lim = self.format_br.formatar_moeda_br(limite)
        txt_val = self.format_br.formatar_moeda_br(valor)

        if valor <= limite:
            return {"row": (  f"✔ Valor de {txt_val} está dentro do limite de {txt_lim}"),
                    "override_valor": None, "extra_row": None}

        # excedeu
        if considerar_limite:
            msg = f"✔ Valor de {txt_val} ultrapassou o limite de {txt_lim} mas foi considerado o valor do limite para inclusão no MUA."
            return {"row": (  msg),
                    "override_valor": limite,  # usa o limite como valor a lançar/exibir
                    "extra_row": None}
        else:
            return {"row": (  f"✘ Valor de {txt_val} excedeu o limite de {txt_lim}"),
                    "override_valor": None, "extra_row": None}

    # ----- limites por carteira (múltiplos) -----
    def _validar_limites_por_carteira(
        self,
        valor: float,
        limites_dict: Optional[Dict[str, float]] = None,
        considerar_limite: bool = False
    ) -> Optional[dict]:
        if not limites_dict:
            return None

        carteiras_dentro: List[str] = []
        carteiras_acima: List[str] = []
        for cart, lim in limites_dict.items():
            if valor <= lim:
                carteiras_dentro.append(cart)
            else:
                carteiras_acima.append(cart)

        if carteiras_dentro and not carteiras_acima:
            return {"row": (  f"✔ DENTRO DO LIMITE PARA TODAS AS CARTEIRAS {', '.join(carteiras_dentro)}"),
                    "override_valor": None, "extra_row": None}

        if carteiras_acima and not carteiras_dentro:
            base_msg = f"✘ ACIMA DO LIMITE PARA TODAS AS CARTEIRAS {', '.join(carteiras_acima)}"
            extra = ("Orientação:", "Utilizar o valor do limite da carteira para inclusão no MUA.") if considerar_limite else None
            return {"row": (  base_msg), "override_valor": None, "extra_row": extra}

        # misto
        partes = []
        if carteiras_dentro:
            partes.append(f"✔ DENTRO ({', '.join(carteiras_dentro)})")
        if carteiras_acima:
            partes.append(f"✘ ACIMA ({', '.join(carteiras_acima)})")
        msg = " | ".join(partes)
        extra = ("Orientação:", "Utilizar o valor do limite da carteira para inclusão no MUA.") if (considerar_limite and carteiras_acima) else None
        return {"row": ( msg), "override_valor": None, "extra_row": extra}
    
    def _encontrar_data_emissao(self) -> Optional[datetime]:
        """
        Renda Presumida: NÃO usa fallback de contexto.
        Aceita apenas chaves conhecidas no JSON e filtra datas implausíveis.
        Trata None como ausência.
        """
        chaves = [
            "Data de Emissão:", "Data de Emissão", "Data de emissão",
            "Emissão:", "Emissão",
            "Data de Extração:", "Data de Extração", "Data de extracao",
            "Data da Consulta:", "Data da Consulta", "Data Consulta",
            "Data:", "Data",
        ]
        for k in chaves:
            if k in self.doc:
                v = self.doc.get(k)
                if v in (None, "", "None", "null"):
                    continue
                dt = self.format_br.formatar_data_br(str(v))   # <— Base!
                hoje = datetime.today()
                # ajuste o limiar se quiser (ex.: 2005). Coloquei 2010 por segurança.
                if dt and 2010 <= dt.year <= hoje.year and dt <= hoje:
                    return dt
        return None
