from typing import Dict, Any
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data, normalize
from datetime import datetime, date, timedelta
from calendar import monthrange
from app.validators.helpers.pj import primeiro_e_ultimo_mes_do_periodo_str
import re

@registrar_validador("simples nacional", "simples", "dasn", "simei")
class ValidadorSimplesNacional(ValidadorBase):
    def validar(self) -> bool:
        self.log.info("Iniciando validação do Simples Nacional")
        # 1) nome do documento (se vier no JSON)
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de Simples nacional encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.context = " ".join(self.context) if isinstance(self.context, list) else self.context
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            self.metodo_extracao = self.extrair_valor(doc, False, "metodo_extracao", "metodo extracao:", "metodo_extracao:", "metodo extracao")
            try:
                status_doc = self.validar_simples_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )
    
    def validar_simples_individual(self):
        # Nome do documento + validação
        self.nome_documento = self.extrair_nome_documento(self.doc) or \
            self.extrair_valor(self.doc, False, "Nome:", "Nome") or ""

        # Montagem das linhas-base
        linhas = organize_data(self.doc, self.doc_type)
        linhas = [["Documento lido:", self.file]] + linhas

        # ---------------- VALIDAÇÃO DO NOME ----------------

        # 1) Validação do nome, se tiver nome do processo nos dados do RPA.
        validacao_nome = self._nome_validation_row()
        if validacao_nome:
            linhas.append(validacao_nome)


        #------------ VALIDAÇÕES RECEITA FEDERAL -------------:
        self.cnpj_empregador = self.extrair_valor(self.doc, False, 'CNPJ:', 'CNPJ', 'cnpj:', 'cnpj', 'CNPJ Matriz', 'CNPJ Matriz:') or "SEM CNPJ"
        cnpj = self.format_br.digits(self.cnpj_empregador) if self.cnpj_empregador and self.cnpj_empregador != "SEM CNPJ" else "SEM CNPJ"

        if cnpj and cnpj != "SEM CNPJ":
            dados_receita = self.apis.buscar_dados_receita(cnpj)
            if dados_receita:
                situacao = (dados_receita.get('situacao') or "").upper()
                if situacao == "ATIVA":
                    linhas.append(["✔ CNPJ está ativo na receita!"])
                elif situacao:
                    linhas.append([f"✘ CNPJ está {situacao} na receita!"])
                else:
                    linhas.append(["✘ Situação do CNPJ não encontrado na receita!"])
                
            else:
                linhas.append(["✘ Dados do CNPJ não encontrado na receita, verificar!"])
        else:
            dados_receita = None
            linhas.append(["✘ CNPJ não encontrado no documento"])


        # ---------------- VALIDAÇÃO DOS MESES (PERIODO) ----------------
        periodo = self.extrair_valor(
            self.doc, False, "Período:", "Período", "Periodo:", "Período Abrangido:", "Periodo Abrangido:"
        )
        self.periodo_documento = periodo if periodo else ""

        # garanta que existam, para evitar UnboundLocalError mais tarde
        primeiro_mes_periodo = None
        ultimo_mes_periodo = None

        if self.periodo_documento:
            # ex.: "01/09/2024 - 31/08/2025" (ou "01/09/2024 a 31/08/2025")
            primeiro_mes_periodo, ultimo_mes_periodo = primeiro_e_ultimo_mes_do_periodo_str(self.periodo_documento)

            if primeiro_mes_periodo and ultimo_mes_periodo:
                # ATENÇÃO: calcular_meses_entre(a1,m1,a2,m2) = (a1,m1) - (a2,m2)
                # então para contar meses inclusivos entre INÍCIO→FIM, passe FIM primeiro:
                meses_qtd = self.format_br.calcular_meses_entre(
                    ultimo_mes_periodo.year, ultimo_mes_periodo.month,
                    primeiro_mes_periodo.year, primeiro_mes_periodo.month
                ) + 1

                # Exibe contagem
                #linhas.append([f"✔ Período informado cobre {meses_qtd} mês(es)."])

                # --- Regra de suficiência de cobertura ---
                # Tenta obter idade da empresa no último mês do período
                meses_empresa = None
                try:
                    # se você já calculou data_abertura acima, reuse; senão pode calcular aqui depois de buscar receita
                    # meses da empresa (inclusivo) até o último mês do período
                    if dados_receita:
                        abertura_str = dados_receita.get("abertura") or dados_receita.get("data de abertura")
                        if abertura_str:
                            dt_abertura = self.format_br.formatar_data_br(abertura_str)
                            if dt_abertura:
                                d_abertura = date(dt_abertura.year, dt_abertura.month, 1)
                                d_fim = date(ultimo_mes_periodo.year, ultimo_mes_periodo.month, 1)
                                if d_fim >= d_abertura:
                                    meses_empresa = self.format_br.calcular_meses_entre(
                                        d_fim.year, d_fim.month, d_abertura.year, d_abertura.month
                                    ) + 1
                except Exception:
                    meses_empresa = None  # se der erro, só não aplica a regra dependente da abertura

                # Caso 1: empresa com < 12 meses → documento deve ter exatamente essa quantidade
                if isinstance(meses_empresa, int) and meses_empresa < 12:
                    if meses_qtd < meses_empresa:
                        linhas.append([f"✘ Documento possui {meses_qtd} mês(es), mas a empresa tem {meses_empresa} mês(es)."])
                    else:
                        # Se o período extrapola a idade, a validação de abertura já acusa (período antes da abertura)
                        linhas.append([f"✔ Quantidade de meses compatível com a idade da empresa ({meses_empresa} mês(es))."])

                # Caso 2: empresa com ≥ 12 meses (ou sem dado de abertura) → exige mínimo 12
                else:
                    if meses_qtd < 12:
                        linhas.append([f"✘ Documento possui {meses_qtd} mês(es); para empresas com + de 12 meses, exige ao menos 12."])
                    else:
                        linhas.append(["✔ Faturamento possui 12 meses."])
        # ---------------- VALIDAÇÃO DATA DE ABERTURA DA EMPRESA ----------------
        if dados_receita:
            data_abertura_str = dados_receita.get("abertura") or dados_receita.get("data de abertura")
            data_abertura = None
            if data_abertura_str:
                data_abertura = self.format_br.formatar_data_br(data_abertura_str)
                if data_abertura:
                    data_abertura = data_abertura.date()

            if data_abertura and primeiro_mes_periodo:
                if primeiro_mes_periodo < date(data_abertura.year, data_abertura.month, 1):
                    linhas.append([
                        #"Validação Data de Abertura:",
                        f"✘ Período informado inicia em {self.format_br.extrair_mes_ano(primeiro_mes_periodo)}, "
                        f"mas a empresa só foi aberta em {data_abertura.strftime('%d/%m/%Y')}."
                    ])
                else:
                    linhas.append([
                        #"Validação Data de Abertura:",
                        f"✔ Período inicia após a abertura ({data_abertura.strftime('%d/%m/%Y')})."
                    ])
            elif not data_abertura:
                linhas.append([
                   # "Validação Data de Abertura:",
                    "✘ Data de abertura da empresa não encontrada na Receita."
                ])
        

        # ---------------- VALIDAÇÃO DA DATA DE EMISSÃO ----------------


        # --- Data de virada do mês (corte) ---
        corte_raw = getattr(getattr(self, "comprovantes", None), "data_corte_fat", None)
        try:
            corte_dia = int(corte_raw) if corte_raw not in (None, "", 0) else None
        except Exception:
            corte_dia = None

        hoje = datetime.now().date()

        data_corte_dt = None
        data_corte_str = ""
        if corte_dia:
            # garante que não estoura o último dia do mês
            last_day = monthrange(hoje.year, hoje.month)[1]
            corte_eff = min(max(1, corte_dia), last_day)
            data_corte_dt = date(hoje.year, hoje.month, corte_eff)
            data_corte_str = data_corte_dt.strftime('%d/%m/%Y')
        
        data_emissao = self._extrair_data_emissao()
        if isinstance(data_emissao, datetime):
            data_emissao = data_emissao.date()
        # A) Limite em dias -> usa SOMENTE a data de emissão (sua regra)
        limite_dias = getattr(getattr(self, "comprovantes", None), "limite_dias_faturamento", None)
        try:
            limite_dias_int = int(limite_dias) if (limite_dias is not None and str(limite_dias).strip() != "") else None
        except Exception:
            limite_dias_int = None

        if limite_dias_int is not None and data_emissao:
            data_corte = hoje - timedelta(days=limite_dias_int)
            if data_emissao < data_corte:
                linhas.append([
                    #"Limite de dias do faturamento:",
                    f"✘ Data de emissão {data_emissao.strftime('%d/%m/%Y')} excede o limite de {limite_dias_int} dias (corte em {data_corte.strftime('%d/%m/%Y')})."
                ])
            else:
                linhas.append([
                    #"Limite de dias do faturamento:",
                    f"✔ Dentro do limite de {limite_dias_int} dias (emissão {data_emissao.strftime('%d/%m/%Y')}, corte {data_corte.strftime('%d/%m/%Y')})."
                ])
        elif limite_dias_int is not None and not data_emissao:
            linhas.append([
                #"Limite de dias do faturamento:",
                "✘ Limite para a data de emissao configurado, mas a data não foi identificada no documento."
            ])
        else:
            linhas.append([
                #"Limite de dias do faturamento:",
                "✔ Sem limite configurado para a data de emissão."
            ])

        # ---------------- VALIDAÇÃO FATURAMENTO NO MES DA EMISSÃO ----------------


        # B) Proibição de valores no mês da emissão -> comparar último mês (derivado) vs mês/ano da emissão
        permitido_mes_emissao_raw = getattr(getattr(self, "comprovantes", None), "permitido_fat_no_mes_da_emissao", None)
        permitido_mes_emissao = None if permitido_mes_emissao_raw in [None, ""] else self.to_bool(permitido_mes_emissao_raw)

        if permitido_mes_emissao is False:
            if not data_emissao:
                linhas.append([
                    #"Faturamento no mês da emissão:",
                    "✘ Não foi possível verificar se possui faturamento para o mês da emissão, pois a data de emissão não foi identificada no documento."
                ])
            elif not ultimo_mes_periodo:
                linhas.append([
                    #"Faturamento no mês da emissão:",
                    "✘ Não foi possível verificar se possui faturamento para o mês da emissão, pois os meses do faturamento não foram encontrados no documento."
                ])
            else:
                par_emissao = (data_emissao.year, data_emissao.month)
                par_ultimo  = (ultimo_mes_periodo.year, ultimo_mes_periodo.month)
                if par_emissao == par_ultimo:
                    # mês da emissão: permitido APÓS a data de corte OU quando a emissão for posterior ao corte
                    liberado_por_corte = False
                    if data_corte_dt:
                        # 1) se a EMISSÃO for posterior ao corte, pode
                        if data_emissao >= data_corte_dt:
                            liberado_por_corte = True
                        # 2) ou se hoje já passou do corte (coops que liberam pelo "momento atual")
                        elif hoje >= data_corte_dt:
                            liberado_por_corte = True

                    if liberado_por_corte:
                        linhas.append([
                            #"Faturamento no mês da emissão:",
                            f"✔ Faturamento no mes da emissão permitido pois estamos no final do mês (data de corte {data_corte_str})."
                        ])
                    else:
                        msg_corte = f" (Data de corte {data_corte_str})" if data_corte_dt else ""
                        linhas.append([
                            #"Faturamento no mês da emissão:",
                            f"✘ Não é permitido declarar faturamento no próprio mês da emissão{msg_corte}."
                        ])

                elif par_ultimo < par_emissao:
                    linhas.append([
                        #"Faturamento no mês da emissão:",
                        f"✔ Documento emitido em {self.format_br.extrair_mes_ano(date(data_emissao.year, data_emissao.month, 1))} e não há valores declarados para esse mês; período vai até {self.format_br.extrair_mes_ano(ultimo_mes_periodo)}."
                    ])
                else:  # par_ultimo > par_emissao
                    linhas.append([
                        #"Faturamento no mês da emissão:",
                        f"✘ Período informado ({self.format_br.extrair_mes_ano(ultimo_mes_periodo)}) ultrapassa o mês da emissão ({self.format_br.extrair_mes_ano(date(data_emissao.year, data_emissao.month, 1))})."
                    ])
        else:
            linhas.append([
                #"Faturamento no mês da emissão:", 
                "✔ Sem regras definidas para valores no mês da emissão."])



       # ---------------- VALIDAÇÃO DA DATA DO ULTIMO MES FATURADO ----------------
        limite_ult_mes_raw = getattr(getattr(self, "comprovantes", None), "limite_meses_ult_mes_faturado", None)

        # normaliza para int ou None
        try:
            limite_ult_mes = int(limite_ult_mes_raw) if (limite_ult_mes_raw not in (None, "", False)) else None
        except Exception:
            limite_ult_mes = None

        if not limite_ult_mes or limite_ult_mes == 0:
            linhas.append([
                #"Último mês faturado:", 
                "✔ Sem limites definidos para o ultimo mes faturado"])
        else:
            text_mes = "meses" if (isinstance(limite_ult_mes, int) and limite_ult_mes > 1) else "mês"
            # precisa ter identificado o último mês do período
            if not ultimo_mes_periodo:
                linhas.append([
                    #"Último mês faturado:", 
                    f"✘ Não foi possível identificar o último mês do período, verificar se esta dentro de {limite_ult_mes} {text_mes}."])
            else:
                ano_atual, mes_atual = self.format_br.obter_ano_mes_atual()
                diff = self.format_br.calcular_meses_entre(ano_atual, mes_atual, ultimo_mes_periodo.year, ultimo_mes_periodo.month)

                # regra: aceitar se 1 <= diff <= limite_ult_mes
                if diff < 0:
                    # futuro: continua inválido
                    linhas.append([
                        #"Último mês faturado:",
                        f"✘ Último mês informado ({self.format_br.extrair_mes_ano(ultimo_mes_periodo)}) é futuro."
                    ])
                elif diff == 0:
                    # mês atual: permitido APÓS a data de corte
                    if data_corte_dt and hoje >= data_corte_dt:
                        linhas.append([
                            #"Último mês faturado:",
                            f"✔ Faturamento no mês atual aceito (estamos após a data de corte: {data_corte_str})."
                        ])
                    else:
                        if data_corte_dt:
                            linhas.append([
                                #"Último mês faturado:",
                                f"✘ Faturamento para o mês atual, verificar!"
                            ])
                elif diff <= limite_ult_mes:
                    linhas.append([
                        #"Último mês faturado:",
                        f"✔ Dentro do limite de {limite_ult_mes} {text_mes} para o ultimo mes faturado: {self.format_br.extrair_mes_ano(ultimo_mes_periodo)}."
                    ])
                else:
                    # fora do limite (ex.: hoje = setembro, último = junho → diff=3 >2)
                    linhas.append([
                        #"Último mês faturado:",
                        f"✘ Fora do limite de {limite_ult_mes} {text_mes} para o ultimo mes faturado: último mês {self.format_br.extrair_mes_ano(ultimo_mes_periodo)}."
                    ])

        # ------------ TOTAL DO FATURAMENTO -------------

        # Valor pode não existir — se vier, formatamos; se não, deixamos vazio (placeholder permanece no texto)
        valor_str = self.extrair_valor(self.doc, False, "Receita Bruta Total", "Receita Bruta Total:", "Faturamento total:", "Valor Total:", "Valor:")
        valor_float = self.format_br.converter_valor_para_float(valor_str) if valor_str else None
        self.valor_documento = self.format_br.formatar_moeda_br(valor_float) if valor_float is not None else ""

        # ------------ VALIDAÇÃO TOTAL DO FATURAMENTO CONFORME O PORTE NA RECEITA -------------

        porte_receita = self.apis.capturar_porte_receita(cnpj) if (cnpj and cnpj != "SEM CNPJ") else None
        limites_por_porte = getattr(getattr(self, "comprovantes", None), "limites_por_porte", None)
        limite_faturamento = None
        if isinstance(limites_por_porte, dict) and porte_receita:
            limite_faturamento = limites_por_porte.get(porte_receita)
            try:
                limite_faturamento = float(limite_faturamento)
            except Exception:
                limite_faturamento = None
        
        # Limite adicional do MEI (se configurado)
        limite_adicional_mei = None
        try:
            raw_adicional = getattr(getattr(self, "comprovantes", None), "limite_adicional_do_MEI", None)
            if raw_adicional not in (None, "", 0):
                limite_adicional_mei = float(raw_adicional)
        except Exception:
            limite_adicional_mei = None

        if valor_float is None:
            linhas.append(["✘ Não foi possível determinar o faturamento total."])
        else:
            # Caso especial: MEI
            if porte_receita == "MEI" and isinstance(limite_adicional_mei, (int, float)) and limite_adicional_mei > 0:
                adicional_brl = self.format_br.formatar_moeda_br(limite_adicional_mei)

                if not isinstance(limite_faturamento, (int, float)) or limite_faturamento == 0:
                    # Sem limite padrão configurado -> valida só pelo adicional
                    if valor_float <= limite_adicional_mei:
                        linhas.append([ f"✔ Faturamento total dentro do limite adicional do MEI de {adicional_brl}."])
                    else:
                        linhas.append([  f"✘ Faturamento total ACIMA do limite adicional do MEI de {adicional_brl}."])
                else:
                    # Com limite padrão:
                    limite_brl = self.format_br.formatar_moeda_br(limite_faturamento)
                    if valor_float <= limite_faturamento:
                        linhas.append([  f"✔ Faturamento total dentro do limite de {limite_brl} para o porte MEI."])
                    elif valor_float <= limite_adicional_mei:
                        linhas.append([  f"✔ Faturamento total dentro do limite adicional do MEI de {adicional_brl}."])
                    else:
                        linhas.append([  f"✘ Faturamento total ACIMA do limite adicional do MEI de {adicional_brl}."])

            else:
                # Não é MEI (ou sem adicional válido) -> valida só pelo limite padrão
                if not isinstance(limite_faturamento, (int, float)) or limite_faturamento == 0:
                    if porte_receita:
                        linhas.append([f"✔ Não há limite para o faturamento total configurado para o porte '{porte_receita}'."])
                    else:
                        linhas.append(["✘ Porte não identificado na Receita; não foi possível validar contra limites."])
                else:
                    limite_brl = self.format_br.formatar_moeda_br(limite_faturamento)
                    if valor_float <= limite_faturamento:
                        linhas.append([  f"✔ Faturamento total Dentro do limite de {limite_brl} para o porte {porte_receita}."])
                    else:
                        linhas.append([  f"✘ Faturamento total ACIMA do limite de {limite_brl} para o porte {porte_receita}."])

        if isinstance(valor_float, (int, float)):
            linhas.append(["Campos no MUA:"])
            linhas.append(["Periodo:", ultimo_mes_periodo.year])
            valor_float = valor_float if valor_float > 0 else 0.01
            linhas.append(["Faturamento total:", self.format_br.formatar_moeda_br(valor_float)])

        # 5) Regras (planilha > fallback)
        regras: Dict[str, Any] = {}
        if getattr(self, "regras_mua", None):
            nomes = ["simples nacional", "simples", "simei", "declaraçao anual do simples nacional", "declaraçao anual do simples"]
            regras = self.regras_mua.get_doc(nomes)

        # ---------------- Regras / Parecer ----------------
        linhas_regras = self.exibir_regras_doc(regras)
        linhas.extend(linhas_regras)

        # 6) Finalização
        linhas.append([])

        self.sections.append(("SIMPLES NACIONAL", linhas))
        self.log.info("Validação do Simples Nacional FINALIZADA.")
        return True

    def _extrair_data_emissao(self) -> date | None:
        chaves = [
            "Data de Emissão", "Data da Emissão", "Emissão", "Data do Documento", "Data", "Data e Horário", "Data e Horário:", "Data e Horario"
        ]
        valor = self.extrair_valor(self.doc, False, *chaves)
        if valor:
            dt = self.format_br.formatar_data_br(str(valor))
            if dt and (2010 <= dt.year <= datetime.today().year) and dt.date() <= datetime.today().date():
                return dt.date()
        # fallback no contexto
        m = re.search(r"(\d{2}/\d{2}/\d{4})", self.context or "")
        if m:
            dt = self.format_br.formatar_data_br(m.group(1))
            if dt and (2010 <= dt.year <= datetime.today().year) and dt.date() <= datetime.today().date():
                return dt.date()
        return None