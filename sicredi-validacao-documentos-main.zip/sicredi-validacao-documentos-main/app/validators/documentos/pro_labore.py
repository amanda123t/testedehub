from typing import Dict
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data, normalize, normalize_no_space   # <- já usa normalize aqui
from app.utils.folha_fiscal import FolhaFiscal          # <- cálculo de INSS/IR
import re  
from datetime import datetime
# feriados nacionais a considerar (apenas os 3 últimos de 2025, conforme pedido)
FERIADOS_NACIONAIS_2025: Dict[str, str] = {
    "15/11/2025": "Proclamação da República",
    "20/11/2025": "Dia Nacional de Zumbi e Consciência Negra",
    "25/12/2025": "Natal",
}


@registrar_validador("pro-labore", "prolabore", "pró-labore", "pró labore")
class ValidadorProLabore(ValidadorBase):
    def validar(self):
        self.log.info("Iniciando validação do Pró-Labore")

        lista_prolabores = self.lista
        resultados = []

        if isinstance(lista_prolabores, dict):
            lista_prolabores = [lista_prolabores]
        if not isinstance(lista_prolabores, list):
            lista_prolabores = []
        self.log.debug(f"Lista de pro labores recebidas: {lista_prolabores}")
        for doc in lista_prolabores:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")

            try:
                status_doc = self._validar_pro_labore_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context,
                "dados_mua": self.dados_mua
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )

    
    def _validar_pro_labore_individual(self):
        status = True
        self.nome_documento = self.extrair_nome_documento(self.doc) or \
        self.extrair_valor(self.doc, False, "Nome:", "Nome") or ""
        # 2) Conferência por palavras-chave no contexto (como no original)
        #ctx_norm = (normalize(self.context or "").upper())
        #gatilhos = ["PRO-LABORE", "PROLABORE", "ADMINISTRADOR", "SOCIA", "SOCIO", "DIRETOR", "PRO LABORE"]
        #if not any(g in ctx_norm for g in gatilhos):
        #    self.log.info("⚠ Classificado como Pró-Labore, mas palavra-chave não encontrada.")
        #    return None
        # 3) Montar saída base
        linhas = organize_data(self.doc, self.doc_type)
        linhas = [["Documento lido:", self.file]] + linhas
        linhas.append([])
        #empregador:
        self.nome_empregador = self.extrair_valor(self.doc, False, 'Instituição:', 'Instituição', 'Instituicao:', 'Instituicao')
        self.cnpj_empregador = self.extrair_valor(self.doc, False, 'CNPJ:', 'CNPJ', 'cnpj:', 'cnpj:') or "SEM CNPJ"
            
        # 3.2) período
        periodo_str = self.extrair_valor(self.doc, False,
            "Período:", "Periodo:", 
            "Competência:", "Competencia:",
            "Mês de Referência:", "Mes de Referencia:")
        self.contador = self.extrair_valor(self.doc, False, "Contador:", "Contador", "contador:", "contador") or {}
        
        # === NOVO BLOCO: valor (Pró-Labore vs Salário Base) ===
        # Tenta buscar separadamente
        pro_labore_str = self.extrair_valor(
            self.doc, False,
            "Pró-Labore:", "Pro-Labore:", "Pro Labore:", "Pró Labore:",
            "Pró-labore:", "Prólabore:", "Prolabore:"
        )
        salario_base_str = self.extrair_valor(
            self.doc, False,
            "Salário Base:", "Salario Base:"
        )

        # Converte strings para float (se existirem)
        pro_labore_val = self.format_br.converter_valor_para_float(pro_labore_str) if pro_labore_str else None
        salario_base_val = self.format_br.converter_valor_para_float(salario_base_str) if salario_base_str else None

        # Regra de decisão:
        # - Se só um existir, usa o que existir
        # - Se ambos existirem, usa o maior
        # - Se nenhum existir, fallback para "Valor/Rendimento"
        valor_float = None
        if pro_labore_val is not None and salario_base_val is not None:
            valor_float = max(pro_labore_val, salario_base_val)
        elif pro_labore_val is not None:
            valor_float = pro_labore_val
        elif salario_base_val is not None:
            valor_float = salario_base_val
        else:
            # Fallback (mantém compatibilidade com seu fluxo atual)
            valor_str_fallback = self.extrair_valor(
                self.doc, False,
                "Valor:", "Rendimento:", "Rendimentos:"
            )
            valor_float = self.format_br.converter_valor_para_float(valor_str_fallback) if valor_str_fallback else None
        # === FIM DO NOVO BLOCO ===

        # 4) Placeholders possíveis
        dt_periodo = self.format_br.formatar_data_br(periodo_str) if periodo_str else None
        self.periodo_documento = self.format_br.extrair_mes_ano(dt_periodo) if dt_periodo else ""
        self.valor_documento = self.format_br.formatar_moeda_br(valor_float) if valor_float is not None else ""
        self.cargo = self.extrair_valor(self.doc, False, 'Cargo:', 'Cargo', 'cargo:', 'cargo')
        self.cbo = self.extrair_valor(self.doc, False, 'cbo:', 'cbo', 'CBO:', 'CBO') or ""
        if not self.cargo and not self.cbo:
            self.cargo = "Diretor Geral de Empresa e organizações"
            self.cbo = '121010'
        elif not self.cbo:
            self.cbo = "SEM CBO"
        elif not self.cargo:
            self.cargo = "SEM CARGO"
        

        if not isinstance(valor_float, (int, float)) or (isinstance(valor_float, (int, float)) and valor_float <= 0): 
            status = False
            linhas.append([f"✘ Erro ao capturar o valor do Pró-Labore, verificar!"])

        descontos_map = self.extrair_valor(self.doc, False, "Descontos:", "Descontos", "descontos:", "descontos")
        valor_total_descontos = 0
        desconto_inss = {}
        desconto_irpf = {}

        if descontos_map:
            gatilhos_inss = [normalize_no_space(item) for item in [
                "inss", "i.n.s.s", "inss empregador", "i.n.s.s empregador"
            ]]
            gatilhos_irpf = [normalize_no_space(item) for item in [
                "irpf", "irrf", "i.r.p.f", "i.r.r.f", "imposto de renda",
                "i.renda", "irrf empregador", "irpf empregador",
                "imposto de renda empregador"
            ]]

            for desconto in descontos_map:
                nome_desconto = self.extrair_valor(desconto, False, "Nome", "Nome:", "nome", "nome:") or ""
                nome_norm = normalize_no_space(nome_desconto)

                # verifica se algum gatilho está contido no nome ou vice-versa
                for gatilho in gatilhos_inss:
                    if gatilho in nome_norm or nome_norm in gatilho:
                        desconto_inss = desconto
                        break
                for gatilho in gatilhos_irpf:
                    if gatilho in nome_norm or nome_norm in gatilho:
                        desconto_irpf = desconto
                        break

                valor_desconto = self.extrair_valor(desconto, True, "Valor:", "Valor", "valor:", "valor") or 0
                valor_total_descontos += abs(self.format_br.converter_valor_para_float(valor_desconto))
        else:
            linhas.append([f"✘ Nenhum desconto foi encontrado no Pró-Labore."])
            status = False

        if valor_total_descontos == 0:
            status = False

        desconto_irpf_ok = False
        desconto_inss_ok = False
        desconto_irpf_invalido = False
        faixas = [0.075, 0.15, 0.225, 0.275]
        valores = [pro_labore_val, salario_base_val]
        valor_candidatos = []
        for valor in valores:
            for faixa in faixas:
                try:
                    valor_faixa = valor * faixa
                    valor_candidatos.append(valor_faixa)
                except Exception:
                    pass
        if desconto_inss or desconto_irpf:
            if desconto_inss:
                valor_desconto_inss = self.extrair_valor(desconto_inss, True, "Valor:", "Valor", "valor:", "valor") or 0
                valor_desconto_inss = self.format_br.converter_valor_para_float(valor_desconto_inss)
            if desconto_irpf and not desconto_irpf_invalido:
                valor_desconto_irpf = self.extrair_valor(desconto_irpf, True, "Valor:", "Valor", "valor:", "valor") or 0
                valor_desconto_irpf = self.format_br.converter_valor_para_float(valor_desconto_irpf)
            if desconto_irpf and valor_desconto_irpf > 0:                
                for valor_can in valor_candidatos:
                    dif = abs(valor_can - valor_desconto_irpf)
                    if dif <= 1:
                        linhas.append([f"✘ Desconto do IRPF inválido, cálculo não abateu o valor do INSS, verificar!"])
                        desconto_irpf_invalido = True
                        break
            for valor in valores:
                if isinstance(valor, (int,float)) and valor >0:
                    r = FolhaFiscal.calcular_inss_e_irrf(valor, 0, 0, "socio")
                    valor_inss, valor_irpf_simplificado, valor_irpf_tradicional = r['INSS'], r['IRRF_simplificado'], r['IRRF_tradicional']
                    if isinstance(valor_inss, (float,int)) and (valor_inss == valor_desconto_inss or valor_inss> valor_desconto_inss or abs(valor_inss - valor_desconto_inss) <= (0.3 * valor_inss)):
                        desconto_inss_ok = True
                        linhas.append([f"✔ Valor do desconto do INSS compatível!"])
                        break
                    if not desconto_irpf_invalido:
                        if isinstance(valor_irpf_simplificado, (float,int)) and (valor_irpf_simplificado == valor_desconto_irpf or valor_irpf_simplificado> valor_desconto_irpf or abs(valor_irpf_simplificado - valor_desconto_irpf) <= (0.3 * valor_irpf_simplificado)):
                            desconto_irpf_ok = True
                            linhas.append([f"✔ Valor do desconto do IRRF compatível!"])
                            break
                        if isinstance(valor_irpf_tradicional, (float,int)) and (valor_irpf_tradicional == valor_desconto_irpf or valor_irpf_tradicional> valor_desconto_irpf or abs(valor_irpf_tradicional - valor_desconto_irpf) <= (0.3 * valor_irpf_tradicional)):
                            desconto_irpf_ok = True
                            linhas.append([f"✔ Valor do desconto do IRRF compatível!"])
                            break
            if desconto_inss_ok or desconto_irpf_ok:
                # pelo menos um bateu -> ok, não precisa gerar erro genérico
                pass
            else:
                status = False
                if not desconto_irpf_ok and not desconto_inss_ok:
                    linhas.append([f"✘ Descontos de IRPF e INSS inválidos para o valor do pró-labore, verificar!"])
                elif not desconto_irpf_ok and not desconto_irpf_invalido:
                    linhas.append([f"✘ Desconto do IRPF incompatível com o valor do Pró-Labore, verificar!"])
                elif not desconto_inss_ok:
                    linhas.append([f"✘ Desconto do INSS incompatível com o valor do Pró-Labore, verificar!"])

        elif not desconto_inss and not desconto_irpf:
            status = False
            linhas.append([f"✘ Nenhum desconto(IRRF e INSS) encontrado no documento, verificar!"])
        elif not desconto_irpf and isinstance(valor_float, (int,float)) and valor_float >= 3000:
            linhas.append([f"✘ Desconto do IRPF não encontrado, verificar!"])
            status = False

        # ✔ Validação do salário líquido (testa com o outro valor se não bater)
        tolerancia = 1.0  # até R$ 1,00 de diferença é ok

        salario_liquido = self.extrair_valor(
            self.doc, False,
            "Salário Líquido:", "Salário Líquido", "Salario Liquido:", "Salario Liquido",
            "salario liquido:", "salario liquido", "salário líquido:", "salário líquido"
        )
        salario_liquido_val = self.format_br.converter_valor_para_float(salario_liquido) if salario_liquido else None

        # Definição simples dos dois valores brutos
        nome_prim, valor_prim = None, None
        nome_alt, valor_alt = None, None

        if pro_labore_val is not None and salario_base_val is not None:
            if pro_labore_val >= salario_base_val:
                nome_prim, valor_prim = "Pró-Labore", pro_labore_val
                nome_alt, valor_alt = "Salário Base", salario_base_val
            else:
                nome_prim, valor_prim = "Salário Base", salario_base_val
                nome_alt, valor_alt = "Pró-Labore", pro_labore_val
        elif pro_labore_val is not None:
            nome_prim, valor_prim = "Pró-Labore", pro_labore_val
        elif salario_base_val is not None:
            nome_prim, valor_prim = "Salário Base", salario_base_val

        # Se líquido não veio no documento
        if salario_liquido_val is None:
            if isinstance(valor_prim, (int, float)) and isinstance(valor_total_descontos, (int, float)):
                esperados = []
                if valor_prim is not None:
                    esperados.append(f"{nome_prim}: {self.format_br.formatar_moeda_br(valor_prim - valor_total_descontos)}")
                if valor_alt is not None:
                    esperados.append(f"{nome_alt}: {self.format_br.formatar_moeda_br(valor_alt - valor_total_descontos)}")
                # fallback opcional: se nenhum dos dois veio, mas valor_float existe
                if not esperados and isinstance(valor_float, (int, float)):
                    esperados.append(f"Valor/Rendimento: {self.format_br.formatar_moeda_br(valor_float - valor_total_descontos)}")
                msg_esp = " | ".join(esperados) if esperados else "indisponível"
                linhas.append([f"✘ Valor líquido não encontrado no documento. Líquido(s) esperado(s) → {msg_esp}."])
            else:
                houve_erro = True
                status = False
                linhas.append([f"✘ Valor líquido não encontrado no documento, verificar!"])
        else:
            # Temos líquido, validar
            if not isinstance(valor_total_descontos, (int, float)) or valor_total_descontos < 0:
                houve_erro = True
                linhas.append([f"✘ Total de descontos inválido ({valor_total_descontos})."])
                status = False
            elif not isinstance(valor_prim, (int, float)) or valor_prim <= 0:
                # opcional: se primário ausente/<=0, tenta cair pro fallback antes de marcar erro
                if isinstance(valor_float, (int, float)) and valor_float > 0:
                    nome_prim, valor_prim = "Valor/Rendimento", valor_float
                #else:
                #    linhas.append([f"✘ Valor bruto inválido ({valor_prim})."])
            if isinstance(valor_prim, (int, float)) and valor_prim > 0:
                liquido_prim = valor_prim - valor_total_descontos
                diferenca_prim = abs(liquido_prim - salario_liquido_val)

                if diferenca_prim <= tolerancia:
                    linhas.append([f"✔ Valor líquido correto com base em {nome_prim} "
                                f"(Total: {self.format_br.formatar_moeda_br(valor_prim)} | "
                                f"Descontos: {self.format_br.formatar_moeda_br(valor_total_descontos)} | "
                                f"Líquido esperado: {self.format_br.formatar_moeda_br(liquido_prim)})."])
                elif valor_alt is not None:
                    liquido_alt = valor_alt - valor_total_descontos
                    diferenca_alt = abs(liquido_alt - salario_liquido_val)
                    if diferenca_alt <= tolerancia:
                        linhas.append([f"✔ Valor líquido confere com base em {nome_alt} "
                                    f"(Total: {self.format_br.formatar_moeda_br(valor_alt)} | "
                                    f"Descontos: {self.format_br.formatar_moeda_br(valor_total_descontos)} | "
                                    f"Líquido esperado: {self.format_br.formatar_moeda_br(liquido_alt)}). "
                                    f"Observação: não bateu com {nome_prim} (diferença de {self.format_br.formatar_moeda_br(diferenca_prim)})."])
                    else:
                        status = False
                        linhas.append([f"✘ Valor líquido divergente "
                                    f"(Esperado {nome_prim}: {self.format_br.formatar_moeda_br(liquido_prim)} | "
                                    f"{nome_alt}: {self.format_br.formatar_moeda_br(liquido_alt)} | "
                                    f"Informado: {self.format_br.formatar_moeda_br(salario_liquido_val)}). Verificar!"])
                else:
                    status = False
                    linhas.append([f"✘ Valor líquido divergente com base em {nome_prim} "
                                f"(Esperado: {self.format_br.formatar_moeda_br(liquido_prim)} | "
                                f"Informado: {self.format_br.formatar_moeda_br(salario_liquido_val)}). Verificar!"])
        # --- ADD: carregar flags da planilha com defaults ---
        f_validar_situacao = self.to_bool(getattr(self.comprovantes, "validar_situacao_do_cnpj_prolabore", None)) is not False
        f_validar_qsa      = self.to_bool(getattr(self.comprovantes, "validar_socio_qsa_prolabore", None)) is not False
        f_validar_valor_porte      = self.to_bool(getattr(self.comprovantes, "validar_total_com_o_porte_prolabore")) is not False
        f_validar_crc      = self.to_bool(getattr(self.comprovantes, "validar_crc_contador_prolabore", None)) is not False
        aceitar_mes_atual  = self.to_bool(getattr(self.comprovantes, "aceitar_sempre_mes_atual_prolabore", None)) is True
        limite_darf = getattr(self.comprovantes, "limite_darf", None)
        if limite_darf:
            limite_darf = self.format_br.converter_valor_para_float(limite_darf)
        limite_meses = getattr(self.comprovantes, "limite_meses_prolabore", None)
        dia_corte    = getattr(self.comprovantes, "data_virada_mes_prolabore", None)

        # --- validação de competência conforme regras ---
        msg_comp = self._validar_competencia_prolabore(
            dt_periodo,
            limite_meses=limite_meses,
            aceitar_sempre_mes_atual=aceitar_mes_atual,
            dia_corte=dia_corte
        )
        if msg_comp:
            linhas.append([msg_comp])


        # Validação da situação do CNPJ na receita.
        # Validação CNPJ (Receita)
        if self.validar_cnpj(self.cnpj_empregador):
            # ----------- VALIDAÇÃO VALOR COM O PORTE NA RECEITA 
            if f_validar_valor_porte:
                porte_receita = self.apis.capturar_porte_receita(self.cnpj_empregador)
                # Regra nova: só aceitar pró-labore para MEI se configurado na planilha
                if porte_receita:
                    recibo_pro_labore_para_mei = self.to_bool(
                        getattr(self.comprovantes, "recibo_pro_labore_para_mei", False)
                    )

                    if recibo_pro_labore_para_mei:
                        # porte_receita pode vir como "MEI", "MEI CAMINHONEIRO", etc.
                        porte_norm = str(porte_receita).upper().strip()

                        if "MEI" not in porte_norm:
                            linhas.append([
                                f"✘ Recibo de Pró-Labore somente permitido para MEI, "
                                f"mas o porte da empresa é '{porte_norm}'. Verificar!"
                            ])
                            status = False
                        else:
                            linhas.append([
                                f"✔ Pró-Labore aceito — porte MEI detectado ({porte_norm})."
                            ])

                    limites_por_porte = getattr(getattr(self, "comprovantes", None), "limites_por_porte", None)
                    limite_faturamento = None

                    if isinstance(limites_por_porte, dict) and porte_receita:
                        limite_faturamento = limites_por_porte.get(porte_receita)

                        # fallback: se não existir limite específico para MEI CAMINHONEIRO, usa MEI
                        if limite_faturamento is None and porte_receita == "MEI CAMINHONEIRO":
                            limite_faturamento = limites_por_porte.get("MEI")

                        try:
                            limite_faturamento = float(limite_faturamento)
                        except Exception:
                            limite_faturamento = None
                    
                    # Verifica se o valor mensal está acima do limite mensal do faturamento do empregador. (se o empregador não pode FATURAR acima de X no mês, impossível um pró labore(lucro) ser maior que isso, indício de fraude)
                    if limite_faturamento and valor_float > 0:
                        limite_faturamento_mensal = limite_faturamento / 12
                        linhas.append([f"Porte(receita): {str(porte_receita).upper()} | Limite de faturamento mensal: {self.format_br.formatar_moeda_br(limite_faturamento_mensal)}"])

                        if valor_float > limite_faturamento_mensal:
                            linhas.append([f"✘ Valor do Pró-Labore está acima do limite mensal de faturamento({self.format_br.formatar_moeda_br(limite_faturamento_mensal)}) para o porte {porte_receita}, verificar!"])
                        #Se não estiver acima do limite, mas estiver muito próximo (80% do limite) informa. (exceto para mei que tende a ter pro-labore sempre igual/proximo ao limite)
                        elif valor_float > (limite_faturamento_mensal * 0.8) and not "MEI" in str(porte_receita).upper():
                            linhas.append([f"✘ Valor do Pró-Labore está muito próximo do limite mensal de faturamento({self.format_br.formatar_moeda_br(limite_faturamento_mensal)}) para o porte {porte_receita}, verificar!"])
                        else:
                            linhas.append([f"✔ Valor do Pró-Labore está compatível com o porte {str(porte_receita).upper()} da empresa empregadora!."])
                else:
                    linhas.append([f"✘ Porte da empresa não localizado na receita."])  
            if f_validar_situacao:
                linhas.append(self.apis.validar_situacao_cnpj(self.cnpj_empregador))
            if f_validar_qsa:
                try:
                    ok_qsa, dados_r = self.apis.validar_associado_em_cnpj(self.cnpj_empregador, self.nome_documento)
                except Exception:
                    ok_qsa, dados_r = False, None

                if ok_qsa:
                    linhas.append([ f"✔ Sócio '{self.nome_documento}' encontrado no QSA da empresa!"])
                else:
                    linhas.append([ f"✘ Sócio '{self.nome_documento}' NÃO encontrado no QSA da empresa!"])


        else:
            linhas.append([ "✘ CNPJ inválido ou não encontrado no documento"])
            status = False

        if f_validar_crc:
            msg_crc = self._validar_contador_crc()
            if msg_crc:
                linhas.append([msg_crc])

        if isinstance(valor_float, (int, float)) and valor_float > 0 and isinstance(limite_darf, (int, float)) and limite_darf > 0:
            if valor_float > limite_darf:
                linhas.append([f"✘ Necessário vir a darf, valor acima do limite de {self.format_br.formatar_moeda_br(limite_darf)}."])
            else:
                linhas.append([f"✔ Não é necessário vir a darf, valor menor que o limite de {self.format_br.formatar_moeda_br(limite_darf)}."])
        elif isinstance(limite_darf, (int, float)) and limite_darf > 0:
            linhas.append([f"✘ Limite para darf configurado mas valor total não encontrado, se o total for maior que {self.format_br.formatar_moeda_br(limite_darf)} será necessário o envio da DARF!."])
        elif isinstance(valor_float, (int, float)) and valor_float > 0:
            linhas.append([f"✔ Sem limites definidos para o envio da DARF!"])
            

        linhas.append(["Campos no MUA:", ""])

        # Exibe também nas linhas (ok se vazio, segue seu padrão)
        if self.periodo_documento:
            linhas.append(["Período:", self.periodo_documento])
        if self.valor_documento:
            linhas.append(["Valor:", self.valor_documento])

        # regras (planilha > fallback)
        regras = {}
        if getattr(self, "regras_mua", None):
            nomes_pro_labore = ["Recibo de Pró-Labore","recibo prolabore","recibo pro-labore","recibo de pro labore", "recibo de prolabore", "recibo pró labore"]
            regras = self.regras_mua.get_doc(nomes_pro_labore) # busca no Excel
            if not regras: # fallback: tenta pegar as regras de pro labore se não tiver especificas para recibo.
                nomes_pro_labore = ["pro-labore","prolabore","pro labore","pró labore", "pró-labore", "prólabore"]
                regras = self.regras_mua.get_doc(nomes_pro_labore) # busca no Excel
        self.log.debug(f'Regras encontradas para pro labore: {regras}')
       
        doc_origem_regra = (regras.get("Documento Origem") or "Comprovante de Renda").strip()
        campo_regra = (regras.get("Campo") or "Pró-labore/Part. Societárias").strip()
        tipo_ocupacao_regra = (regras.get("Ocupação") or "Outros").strip()
        cargo_regra = (regras.get("Cargo") or self.cargo).strip()
        cargo_regra = cargo_regra.split('|')[1].strip() if "|" in cargo_regra else cargo_regra
        dados_ocupacao = {
            "tipo": tipo_ocupacao_regra,
            "cargo": cargo_regra,
            "nome_empregador": self.nome_empregador,
            "cnpj_empregador": self.cnpj_empregador,
        }
        self.dados_mua = {
            "periodo": self.periodo_documento,
            "doc_origem": doc_origem_regra,
            "tipo": "Efetivo",
            "campos": {
                campo_regra: self.format_br.converter_valor_para_float(self.valor_documento) or 0.0
            },
            "ocupacao": dados_ocupacao
        }
        # 3.6) regras do MUA (preferindo a planilha; fallback se ausente)
        linhas_regras = self.exibir_regras_doc(regras)
        linhas.extend(linhas_regras)

        # 6) Resultado da validação de nome
        row = self._nome_validation_row()
        if row:
            linhas.append(row)

        # 7) Adiciona seção
        self.sections.append(("PRÓ-LABORE", linhas))
        self.log.info("Validação do pro-labore FINALIZADA.")
        return status

    def _validar_competencia_prolabore(
        self,
        dt_periodo: datetime | None,
        *,
        limite_meses: int | None,
        aceitar_sempre_mes_atual: bool,
        dia_corte: int | None
    ) -> str:
        if not dt_periodo:
            return "✘ Competência não informada ou inválida"

        hoje = datetime.today()
        ano_atual, mes_atual = hoje.year, hoje.month
        ano_doc, mes_doc = dt_periodo.year, dt_periodo.month

        if (ano_doc, mes_doc) > (ano_atual, mes_atual):
            return f"✘ Competência futura ({mes_doc:02d}/{ano_doc})"

        diff_meses = (ano_atual - ano_doc) * 12 + (mes_atual - mes_doc)

        if limite_meses is not None:
            try:
                if diff_meses > int(limite_meses):
                    return f"✘ Competência fora do limite ({diff_meses} meses > {int(limite_meses)} meses)"
            except Exception:
                pass  # se vier quebrado, ignora o limite

        if diff_meses == 0:  # mês atual
            if aceitar_sempre_mes_atual:
                return "✔ Competência do mês atual aceita (regra: aceitar sempre)"
            if isinstance(dia_corte, int) and 1 <= dia_corte <= 31:
                if hoje.day >= dia_corte:
                    return f"✔ Competência do mês atual aceita (após dia de corte: {dia_corte})"
                else:
                    return f"✘ Competência do mês atual ainda não aceita (corte no dia {dia_corte})"
            return "✘ Competência do mês atual não aceita (sem 'aceitar sempre' e sem data de corte)"

        return f"✔ Competência aceita ({mes_doc:02d}/{ano_doc})"

    def _pick_melhor_registro_crc(self, lista: list[dict]) -> dict:
        """
        Entre vários registros do CFC, escolhe o 'melhor':
        1) Prioriza SituacaoCadastral em {ATIVO, ATIVA, REGULAR}
        2) Em empate, prioriza Descricao_Tipo_Registro == 'ORIGINARIO'
        3) Persistindo empate, retorna o primeiro da lista
        """
        if not lista:
            return {}
        alvo_status = {"ATIVO", "ATIVA", "REGULAR"}

        # 1) Filtra ATIVO/ATIVA/REGULAR
        ativos = [x for x in lista if str(x.get("SituacaoCadastral", "")).upper() in alvo_status]
        candidatos = ativos if ativos else lista

        # 2) Preferir ORIGINARIO
        orig = [x for x in candidatos if str(x.get("Descricao_Tipo_Registro", "")).upper() == "ORIGINARIO"]
        if orig:
            return orig[0]
        return candidatos[0]

    def _extrair_lista_crc(self, resp_crc: dict) -> list[dict]:
        """
        Aceita respostas nos dois formatos:
        A) {'data': [...], 'totalCount': N}
        B) {'ok': True, 'dados': {'data': [...], 'totalCount': N}, ...}
        Retorna sempre a lista de registros (ou []).
        """
        if not isinstance(resp_crc, dict):
            return []

        # Formato B (envolto em 'dados')
        dados = resp_crc.get("dados")
        if isinstance(dados, dict) and isinstance(dados.get("data"), list):
            return dados["data"]

        # Formato A (flat)
        if isinstance(resp_crc.get("data"), list):
            return resp_crc["data"]

        return []

    def _validar_contador_crc(self) -> str | None:
        """
        Valida o contador no CFC (CRC) e adiciona o resultado em 'linhas'.
        Usa cache via self.apis.buscar_dados_crc(). Só roda se a IA realmente trouxe contador.
        """
        try:
            # Só valida se a IA trouxe algo que pareça contador
            if not isinstance(self.contador, dict):
                return None
            if not (self.contador.get("Nome") and self.contador.get("CPF") or
                    self.contador.get("nome") and self.contador.get("cpf")):
                return None

            resp_crc = self.apis.buscar_dados_crc(self.contador)  # usa seu cache + API
            lista = self._extrair_lista_crc(resp_crc or {})

            if not lista:
                return "✘ Não foi possível validar o CRC do contador no CFC"

            registro_escolhido = self._pick_melhor_registro_crc(lista)
            situ = str(registro_escolhido.get("SituacaoCadastral", "")).upper()
            registro = registro_escolhido.get("Registro") or registro_escolhido.get("Chave") or "-"
            categoria = registro_escolhido.get("Descricao_Categoria") or "-"
            conselho = registro_escolhido.get("EstadoConselho") or "-"

            if situ in {"ATIVO", "ATIVA", "REGULAR"}:
                return f"✔ CRC do contador OK ({situ}). Registro {registro} — {categoria} — {conselho}"
            else:
                return f"✘ CRC do contador não aceito ({situ}). Registro {registro} — {categoria} — {conselho}"

        except Exception as e:
            self.log.error(f"Erro na validação do CRC do contador: {e}")
            return "✘ Erro ao validar o CRC do contador no CFC"