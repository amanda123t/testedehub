# app/validators/crlv.py
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data, normalize
from app.utils.APIs.api_fipe import consultar_fipe
from app.utils.APIs.api_placa import consultar_placa_anycar
import app.utils.APIs.api_4dev as site_4_dev

@registrar_validador(
    "crlv",
    "crlve",
    "certificado de registro e licenciamento de veículo",
    "documento veicular",
)
class ValidadorCRLV(ValidadorBase):
    """
    Validador inicial para CRLV:
      - Exibe os campos do JSON usando organize_data (igual ao genérico)
      - Tenta buscar regras com buscar_regras_doc("crlv") e exibe se encontrar
      - Ainda não aplica validações: apenas mostra informações
    """

    def validar(self) -> bool:
        self.log.info("Iniciando validação do CRLV")
        # 1) Cabeçalho da seção
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de CRLV encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_crlv_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )


    def validar_crlv_individual(self):
        self.nome_documento = self.extrair_nome_documento(self.doc)
        houve_erro = False
        linhas = organize_data(self.doc, self.doc_type)
        linhas = [["Documento lido:", self.file]] + linhas
        linhas.append([])
        # ================================
        # 🔍 CONSULTA POR PLACA (ANYCAR)
        # ================================
        placa = self.extrair_valor(self.doc, False, "Placa:", "Placa", "placa")
        #renavam = self.extrair_valor(self.doc, False, "Renavam:", "Renavam", "Renavam")
        #if renavam:
        #    resultado = site_4_dev.validar_renavam(renavam)
        #    resultado_norm = normalize(str(resultado))
        #    if any(x in resultado_norm for x in ["falso", "inval", "invalido"]):
        #        linhas.append(["✘ Renavam informado é inválido, verifique!"])
        #        houve_erro = True

        vars = {}  # vars local do CRLV

        if placa:
            try:
                self.log.debug(f"consultando placa {placa} (CRLV)...")
                dados_placa = consultar_placa_anycar(placa)

                if isinstance(dados_placa, dict) and not dados_placa.get("erro"):
                    vars["DADOS_PLACA"] = dados_placa
                    vars["PLACA_API"] = dados_placa.get("placa")
                    vars["MARCA_ANY_CAR"] = dados_placa.get("marca")
                    vars["MODELO_ANY_CAR"] = dados_placa.get("modelo")
                    vars["RENAVAM_ANY_CAR"] = dados_placa.get("renavam")
                    vars["CHASSI_ANY_CAR"] = dados_placa.get("chassi")
                    vars["COR_ANY_CAR"] = dados_placa.get("cor")
                    vars["ANO_MODELO_ANY_CAR"] = dados_placa.get("anoModelo") or dados_placa.get("ano_modelo")
                    vars["ANO_FABRICACAO_ANY_CAR"] = dados_placa.get("anoFabricacao") or dados_placa.get("ano_fabricacao")

            except Exception as e:
                self.log.warning(f"Erro ao consultar placa {placa}: {e}")
                vars["ERRO_ANY_CAR"] = "Erro ao consultar a placa na internet."
        else:
            self.log.debug("CRLV sem placa — consulta AnyCar ignorada.")

        # ================================
        # 📄 EXIBIÇÃO DADOS DA PLACA
        # ================================
        if vars.get("DADOS_PLACA") or vars.get("ERRO_ANY_CAR"):
            linhas.append(["Consulta por placa no site: https://anycar.com.br:", ""])

            def add_if(label, value):
                if value not in (None, "", [], {}):
                    linhas.append([label, value])

            add_if("Placa (anycar)", vars.get("PLACA_API"))
            add_if("Marca (anycar)", vars.get("MARCA_ANY_CAR"))
            add_if("Modelo (anycar)", vars.get("MODELO_ANY_CAR"))
            add_if("Ano fabricação (anycar)", vars.get("ANO_FABRICACAO_ANY_CAR"))
            add_if("Ano modelo (anycar)", vars.get("ANO_MODELO_ANY_CAR"))
            add_if("Cor (anycar)", vars.get("COR_ANY_CAR"))
            add_if("Renavam (anycar)", vars.get("RENAVAM_ANY_CAR"))
            add_if("Chassi (anycar)", vars.get("CHASSI_ANY_CAR"))
            add_if("Erro (anycar)", vars.get("ERRO_ANY_CAR"))

            linhas.append([])


        # ================================
        # 🔹 CONSULTA FIPE
        # ================================
        dados_fipe = self._consultar_fipe_crlv()

        if dados_fipe:
            linhas.append(["FIPE (Consulta no site: https://veiculos.fipe.org.br/):", ""])

            entrada = dados_fipe.get("entrada", {})
            match = dados_fipe.get("match", {})
            fipe = dados_fipe.get("fipe", {})

            linhas.extend([
                ["Marca informada:", entrada.get("marca")],
                ["Modelo informado:", entrada.get("modelo")],
                ["Ano informado:", entrada.get("ano")],
                [],
                ["Marca encontrada:", match.get("marca_encontrada")],
                ["Score marca:", match.get("score_marca")],
                ["Modelo encontrado:", match.get("modelo_encontrado")],
                ["Score modelo:", match.get("score_modelo")],
                ["Ano FIPE:", match.get("ano_nome")],
                [],
                ["Valor FIPE:", fipe.get("Valor")],
                ["Código FIPE:", fipe.get("CodigoFipe")],
                ["Combustível:", fipe.get("Combustivel")],
                ["Mês referência:", fipe.get("MesReferencia")],
            ])
            linhas.append([])

        else:
            linhas.append(["FIPE:", "Não foi possível consultar automaticamente"])
            linhas.append([])

        # 2) Exibição dos dados do documento (igual ao genérico, via organize_data)
        #    O organize_data já trata dict/list/None e normaliza chaves/valores.
        regras = {}
        if getattr(self, "regras_mua", None):
            nomes_auto = ["crlv","crlve","crlv-e","certificado de registro e licenciamento de veículo", "documento veicular"]
            regras = self.regras_mua.get_doc(nomes_auto) # busca no Excel

        linhas_regras = self.exibir_regras_doc(regras)
        #linhas.append(["Campos no MUA:", ""])
        linhas.extend(linhas_regras)
        row = self._nome_validation_row()
        if row:
            linhas.append(row)
        # 5) Envia a seção para o PDF
        self.sections.append(("CRLV", linhas))
        self.log.info("Validação do CRLV FINALIZADA.")
        return not houve_erro
    
    def _consultar_fipe_crlv(self):
        try:
            info = self.doc.get("Informações:") or {}
            marca = info.get("Marca")
            modelo = info.get("Modelo")
            versao = info.get("Versão")

            if versao:
                modelo = f"{modelo} {versao}"

            ano_raw = self.doc.get("Ano de Fabricação:")
            if not (marca and modelo and ano_raw):
                return None

            # "2017/2025" → 2017
            ano = int(str(ano_raw).split("/")[0])

            return consultar_fipe(marca, modelo, ano)

        except Exception as e:
            self.log.warning(f"Erro ao consultar FIPE: {e}")
            return None
