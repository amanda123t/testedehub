from __future__ import annotations
from typing import List, Dict, Any
import re
import unicodedata
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from datetime import datetime, date
from collections import defaultdict, Counter
from dateutil.relativedelta import relativedelta
from app.utils.format_br import converter_valor_para_float, formatar_moeda_br
from app.utils.helpers import normalize 

@registrar_validador("extrato", "bank_statement", "extrato_bancario", "extratos", "extratos_bancarios")
class ValidadorBankStatement(ValidadorBase):
    """
    Validador de Extratos Bancários.
    Regras:

    1. Ignora operações financeiras (Poupança/Empréstimo/Estorno).
    2. Considera apenas os últimos 12 meses FECHADOS (ignora mês corrente incompleto).
    """

    def limpar_data_ocr(self, data_raw: Any) -> str | None:
        """Limpa e normaliza datas do OCR."""
        if not data_raw: return None
        texto = normalize(str(data_raw)).upper()
        texto_limpo = re.sub(r"[^\w\/\.\s]", " ", texto).replace("//", "/")

        patterns = [
            r"(\d{2})[\/\.](\d{2})[\/\.](\d{4})",
            r"(\d{2})\s+([A-Z]{3})\w*\s+(\d{4})",
            r"(\d{2})[\/\.](\d{2})[\/\.](\d{2})\b"
        ]
        
        meses = {
            "JAN": "01", "FEV": "02", "FEB": "02", "MAR": "03", "ABR": "04", "APR": "04",
            "MAI": "05", "MAY": "05", "JUN": "06", "JUL": "07", "AGO": "08", "AUG": "08",
            "SET": "09", "SEP": "09", "OUT": "10", "OCT": "10", "NOV": "11", "DEZ": "12", "DEC": "12"
        }

        for p in patterns:
            match = re.search(p, texto_limpo)
            if match:
                parts = match.groups()
                dia, mes, ano = parts
                if len(mes) >= 3 and mes[:3] in meses: mes = meses[mes[:3]]
                if len(ano) == 2: ano = f"20{ano}"
                try:
                    # retorna objeto date direto
                    return datetime(int(ano), int(mes), int(dia)).date()
                except: continue
        return None

    def validar(self) -> bool:
        self.log.info("Iniciando validação de extratos (Regra: 12 Meses Fechados)")

    
        lista_docs = self.lista
        extratos = [self.extrair_valor(n, False, "dados", "dados:") for n in lista_docs if isinstance(n, dict)]

        if not extratos:
            self.sections = [("EXTRATOS BANCÁRIOS", [["Nenhum extrato identificado."]])]
            return self.build_output(False, mensagem="Nenhum extrato encontrado.")

      # regras
        blacklist_regex = [
            r"\bSALDO\b", r"\bESTORNO\b", r"\bDEVOLUCAO\b", r"\bJUROS\b", r"\bTAR\b", r"\bSAQUE\b", r"\bCAMBIO\b",
            r"\bRESG\b", r"\bRESGATE\b", r"\bAPLIC\b", r"\bAPLICACAO\b",
            r"\bPOUPANCA\b", r"\bPOUP\b", r"\bTEV\s+POUP\b",
            r"\bEMPRESTIMO\b", r"\bFINANC\b", r"\bMUTUO\b", r"\bCONSIG\b", 
            r"\bCAPITAL\s+GIRO\b", r"\bCREDITO\s+PESSOAL\b", r"\bCDC\b", 
            r"\bGIRO\b", r"\bSOB\s+MEDIDA\b", r"\bANTECIPACAO\b"
        ]
        
        categorias_regex = {
            "PIX": r"\bPIX\b|\bCRED\s+PAG\s+INST\b",
            "TRANSFERÊNCIA": r"\bTED\b|\bDOC\b|\bTRANSF\b|\bSTR\b|\bTITULA\b",
            "DEPÓSITO": r"\bDEP\b|\bDEPOSITO\b|\bLOTERICO\b",
            "SALÁRIO": r"\bSALARIO\b|\bPROVENTOS\b|\bPAGAMENTO\b",
        }


        renda_por_mes = defaultdict(float)
        fontes_pagadoras = Counter() 
        categorias_valores = defaultdict(float)
    
        todas_transacoes_validas = [] 
        total_ignorado_blacklist = 0.0

        for doc in extratos:
            periodo_doc = doc.get("Periodo", "") or doc.get("Mês", "")
            data_ref_doc = self.limpar_data_ocr(periodo_doc)

            lista_trans = doc.get("Transações", [])
            if not isinstance(lista_trans, list): continue

            for t in lista_trans:
                desc_orig = str(t.get("Descrição", "") or t.get("Histórico/Complemento", ""))
                desc_norm = normalize(desc_orig).upper()
                fav_orig = str(t.get("Favorecido", ""))
                
                valor = converter_valor_para_float(t.get("Valor", "0"))
                ##
                # valida a blacklist
                if valor is None or valor <= 0: continue
                if any(re.search(p, desc_norm) for p in blacklist_regex): 
                    total_ignorado_blacklist += valor
                    continue

               
                dt_obj = self.limpar_data_ocr(t.get("Data", ""))
                if not dt_obj and data_ref_doc: dt_obj = data_ref_doc

                
               
                t_processada = {
                    "data": dt_obj,
                    "valor": valor,
                    "desc": desc_orig,
                    "desc_norm": desc_norm,
                    "favorecido": fav_orig
                }
                todas_transacoes_validas.append(t_processada)

        
        hoje = date.today()
    
        primeiro_dia_mes_atual = date(hoje.year, hoje.month, 1)
        
    
        transacoes_filtradas = []
        valor_ignorado_mes_aberto = 0.0
        
        for t in todas_transacoes_validas:
            dt = t["data"]
            if dt:
                if dt >= primeiro_dia_mes_atual:
                    valor_ignorado_mes_aberto += t["valor"]
                    continue
            else:
                
                pass
                
            transacoes_filtradas.append(t)

    
        for t in transacoes_filtradas:
            valor = t["valor"]
            dt = t["data"]
            desc_norm = t["desc_norm"]
            favorecido = t["favorecido"]
            
            # ctegorização
            cat = "OUTROS CRÉDITOS"
            for c_nome, c_pat in categorias_regex.items():
                if re.search(c_pat, desc_norm):
                    cat = c_nome
                    break
            categorias_valores[cat] += valor

            # mes e fonte
            if dt:
                chave_mes = f"{dt.month:02d}/{dt.year}"
                renda_por_mes[chave_mes] += valor
            else:
                renda_por_mes["DATA_DESCONHECIDA"] += valor

            fonte_display = favorecido if favorecido else t["desc"]
            fonte_display = re.sub(r"(?i)PIX\s*(RECEBIDO|ENVIADO)?|CRED\s*TED|DOC", "", fonte_display).strip()
            fonte_display = fonte_display.replace("***", "").strip()
            if fonte_display: fontes_pagadoras[fonte_display] += valor

        if not renda_por_mes:
            self.sections = [("EXTRATOS BANCÁRIOS", [["Nenhuma renda válida encontrada nos meses fechados."]])]
            return self.build_output(False, mensagem="Sem renda válida (Meses abertos ignorados).")

        # ultimos 12 meses

        meses_validos = [k for k in renda_por_mes.keys() if k != "DATA_DESCONHECIDA"]
        
        def sort_key(k):
            try: return (int(k.split('/')[1]), int(k.split('/')[0]))
            except: return (0,0)

        # ordena do mais recente para o mais antigo (Dez, Nov, Out...)
        meses_ordenados_dec = sorted(meses_validos, key=sort_key, reverse=True)
        
        
        top_12_meses = meses_ordenados_dec[:12]
        
        
        soma_12_meses = sum(renda_por_mes[m] for m in top_12_meses)
        
        
        divisor = len(top_12_meses)
        if divisor == 0: divisor = 1
        
  
       
        soma_final_calculo = soma_12_meses + renda_por_mes["DATA_DESCONHECIDA"]
        media_mensal = soma_final_calculo / divisor


        linhas = [] 
        linhas.append(["RESUMO DA ANÁLISE", ""])
        linhas.append(["Status:", f"Considerando últimos {divisor} meses fechados"])
        linhas.append(["Renda Bruta (Top 12 Meses):", formatar_moeda_br(soma_final_calculo)])
        linhas.append(["Média Mensal Calculada:", formatar_moeda_br(media_mensal)])
        
        if valor_ignorado_mes_aberto > 0:
             linhas.append(["⚠ Mês Atual Ignorado:", f"{formatar_moeda_br(valor_ignorado_mes_aberto)} (Mês em aberto desconsiderado)"])

        linhas.append([""])
        linhas.append(["EVOLUÇÃO MENSAL (Últimos 12 Fechados)", ""])
        # cronológico 
        for mes in sorted(top_12_meses, key=sort_key):
            linhas.append([f"  • {mes}:", formatar_moeda_br(renda_por_mes[mes])])
        
        if renda_por_mes["DATA_DESCONHECIDA"] > 0:
             linhas.append([f"  • SEM DATA LEGÍVEL:", formatar_moeda_br(renda_por_mes["DATA_DESCONHECIDA"])])

        # meses descartados 
        meses_descartados = len(meses_validos) - len(top_12_meses)
        if meses_descartados > 0:
            linhas.append([""])
            linhas.append([f"⚠ Histórico Antigo:", f"{meses_descartados} meses anteriores a {top_12_meses[-1]} foram ignorados no cálculo."])

        linhas.append([""])
        linhas.append(["PRINCIPAIS FONTES", ""])
        for nome, val in fontes_pagadoras.most_common(5):
            linhas.append([f"  • {nome[:30]}...:", formatar_moeda_br(val)])

        self.sections = [("ANÁLISE FINANCEIRA - EXTRATOS", linhas)]

        resultados = []
        for n in lista_docs:
            resultados.append({
                "arquivo": n.get("arquivo"), "status": True, 
                "mensagem": "Processado (Regra 12 meses fechados).", "dados_extraidos": n.get("dados")
            })

        return self.build_output(status_geral=True, resultados_docs=resultados)