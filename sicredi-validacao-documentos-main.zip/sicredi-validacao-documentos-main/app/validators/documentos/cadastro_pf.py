from typing import Dict, Any, List, Optional, Tuple
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data, normalize, similar

@registrar_validador(
    "cadastro pf",
    "registration_pf",
    "cadastro pessoa fisica",
    "cadastro pessoa física",
)
class ValidadorCadastroPF(ValidadorBase):
    def validar(self) -> bool:
        self.log.info("Iniciando validação do Cadastro PF")
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de cadastro PF encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_cadastropf_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )

    def validar_cadastropf_individual(self):
        # 1) Nome do documento (se existir no JSON) + validação de nome
        self.nome_documento = self.extrair_nome_documento(self.doc)

        # 2) Se inspeção estiver desabilitada, não processa
        if not getattr(self, "inspecao", True):
            self.log.info("🔕 Validação de Cadastro PF ignorada (self.inspecao é False).")
            return True

        self.log.debug(f"🧪 dados_cadastro recebido: {type(self.doc)}")

        # 4) Inspeções (renda/campo/periodicidade e ocupação via holerite)
        renda_msg, campo_msg, periodo_msg, ocupacao_linhas = self._inspecao_cadastro_pf()

        linhas = organize_data(self.doc, self.doc_type)
        linhas = [["Documento lido:", self.file]] + linhas
        linhas.append(["Validação da Renda:", renda_msg])
        linhas.append(["Validação do Campo:", campo_msg])
        linhas.append(["Validação da Periodicidade:", periodo_msg])
        # Ocupação (já vem pronta da inspeção unificada)
        linhas.extend(ocupacao_linhas)

        linhas.append([])
        row = self._nome_validation_row()
        if row:
            linhas.append(row)

        self.sections.append(("CADASTRO PF", linhas))
        self.log.info("Validação do Cadastro PF FINALIZADA!")
        return True
    # -------------------- INSPEÇÕES --------------------

    def _inspecao_cadastro_pf(self) -> Tuple[str, str, str, List[List[str]]]:
        """
        Unifica as inspeções:
        - Renda/Campo/Periodicidade: valida usando `dados_mua.campos`, `periodicidade`, `doc_origem`.
        - Ocupação: valida usando `dados_mua.ocupacao` (cargo, empregador por nome ou CNPJ).
        Regras importantes:
        * Se NÃO houver nenhum documento com dados de ocupação -> retorna "✔ Sem ocupação para validar".
        * Se houver ocupações, valida e reporta ✔/✘ por campo e um resumo.
        Retorno:
        (msg_renda, msg_campo, msg_periodicidade, linhas_ocupacao)
        """
        self.log.debug(f"🔍 Iniciando inspeção do cadastro PF para {self.nome_documento}.")

        # --- Localiza a pessoa correspondente no dicionário recebido ---
        base = getattr(self, "dados_por_pessoa", {}) or {}
        alvo = normalize(self.nome_documento or "")
        chave_ok = None
        for k in base.keys():
            if similar(normalize(k), alvo) >= 0.8:
                chave_ok = k
                break
        if not chave_ok:
            self.log.warning(f"❌ Pessoa '{self.nome_documento}' não encontrada em dados_por_pessoa.")
            return ("✘ Nenhum comprovante encontrado para esta pessoa", "", "", [["Validação de Ocupação:", "✔ Sem ocupação para validar nos comprovantes."]])

        dados_pessoa = base.get(chave_ok, {})
        jsons = dados_pessoa.get("jsons", [])

        # --- Extrai COMPROVANTES (renda) e OCUPAÇÕES direto de dados_mua ---
        comprovantes: List[Dict[str, Any]] = []
        ocupacoes: List[Dict[str, Any]] = []

        for bloco in jsons:
            tipo_doc = bloco.get("tipo_documento") or ""
            documentos = bloco.get("documentos") or []
            for doc_item in documentos:
                dados_mua = doc_item.get("dados_mua") or {}

                # Renda (campos)
                campos = dados_mua.get("campos") or {}
                for campo_nome, valor in (campos.items() if isinstance(campos, dict) else []):
                    comprovantes.append({
                        "tipo": tipo_doc,
                        "campo": normalize(campo_nome),
                        "valor": self.format_br.converter_valor_para_float(valor),
                        "periodicidade": normalize(dados_mua.get("periodicidade", "Mensal")),
                        "doc_origem": normalize(dados_mua.get("doc_origem", "")),
                        "periodo": dados_mua.get("periodo", ""),
                    })

                # Ocupação
                oc = dados_mua.get("ocupacao") or {}
                if isinstance(oc, dict) and oc:
                    ocupacoes.append({
                        "tipo": tipo_doc,
                        "cargo": normalize(oc.get("cargo", "")),
                        "nome_empregador": normalize(oc.get("nome_empregador", "")),
                        "cnpj_empregador": normalize(oc.get("cnpj_empregador", "")),
                        "admissao": oc.get("admissao", ""),
                        # "cbo": normalize(oc.get("cbo", ""))  # se futuramente você passar CBO nos dados_mua
                    })

        self.log.debug(f"📦 Comprovantes coletados: {len(comprovantes)} | Ocupações coletadas: {len(ocupacoes)}")

        # --- Extrai dados do CADASTRO PF ---
        valor_cadastro = self.format_br.converter_valor_para_float(self.doc.get("Valor:", "0"))
        campo_cadastro = normalize(self.doc.get("Campo:", "") or "")
        periodicidade_cadastro = normalize(self.doc.get("Periodicidade:", "") or "")
        origem_cadastro = normalize(self.doc.get("Documento Origem:", "") or "")

        # Ocupação no cadastro
        cargo_cad = normalize(self.doc.get("Ocupação:", "") or self.doc.get("Ocupacao:", ""))
        cbo_cad = normalize(self.doc.get("CBO:", ""))
        empregador_cad = normalize(self.doc.get("Empregador:", ""))
        cnpj_emp_cad = normalize(self.doc.get("CNPJ do Empregador:", "") or "")

        self.log.debug(
            f"🎯 Cadastro -> Valor: {valor_cadastro} | Campo: {campo_cadastro} | "
            f"Periodicidade: {periodicidade_cadastro} | Origem: {origem_cadastro} | "
            f"Ocupação: cargo='{cargo_cad}', cbo='{cbo_cad}', emp='{empregador_cad}', cnpj='{cnpj_emp_cad}'"
        )

        # =======================
        # 1) Renda/Campo/Periodicidade
        # =======================
        validacao_renda = "✘ Nenhum comprovante correspondente encontrado"
        validacao_campo = "✘ Campo diferente de todos os comprovantes"
        validacao_periodicidade = "✘ Periodicidade diferente de todos os comprovantes"

        tipos_campo_ok, tipos_periodo_ok = [], []
        valor_bateu = False

        if comprovantes and (valor_cadastro is not None):
            for comp in comprovantes:
                tipo = comp.get("tipo", "")
                valor = comp.get("valor")
                campo_doc = comp.get("campo")
                periodicidade_doc = comp.get("periodicidade")

                # valor
                if (valor is not None) and abs((valor_cadastro or 0) - valor) <= 1:
                    validacao_renda = f"✔ Valor da renda corresponde ao comprovante '{tipo}'"
                    valor_bateu = True

                # campo
                if campo_cadastro == campo_doc or (
                    campo_cadastro == "salario bruto" and campo_doc == "salario liquido"
                ):
                    tipos_campo_ok.append(tipo)

                # periodicidade
                if periodicidade_cadastro == periodicidade_doc:
                    tipos_periodo_ok.append(tipo)

                if valor_bateu and (campo_cadastro == campo_doc) and (periodicidade_cadastro == periodicidade_doc):
                    validacao_campo = f"✔ Campo está correto para o comprovante '{tipo}'"
                    validacao_periodicidade = f"✔ Periodicidade está correta ({periodicidade_doc})"
                    break

            if not valor_bateu:
                validacao_renda = "✘ Valor da renda está diferente de todos os comprovantes encontrados."
            if tipos_campo_ok:
                validacao_campo = f"✔ Campo está correto para o(s) comprovante(s): {', '.join(sorted(set(tipos_campo_ok)))}"
            if tipos_periodo_ok:
                validacao_periodicidade = f"✔ Periodicidade está correta para o(s) comprovante(s): {', '.join(sorted(set(tipos_periodo_ok)))}"
        else:
            # Sem comprovantes *ou* sem valor no cadastro → não dá para validar, mantém mensagens padrão de forma branda
            if not comprovantes:
                validacao_renda = "⚠ Sem comprovantes com valor/campo/periodicidade para validar."
                validacao_campo = "⚠ Sem comprovantes para validar Campo."
                validacao_periodicidade = "⚠ Sem comprovantes para validar Periodicidade."

        # =======================
        # 2) Ocupação
        # =======================
        ocupacao_linhas: List[List[str]] = []

        # Regra solicitada: se NÃO houver nenhum documento com ocupação → considerar OK silencioso
        if not ocupacoes:
            ocupacao_linhas.append(["Validação de Ocupação:", "✔ Sem ocupação para validar nos comprovantes."])
            return validacao_renda, validacao_campo, validacao_periodicidade, ocupacao_linhas

        cargo_ok = False
        empregador_ok = False
        cbo_ok = False

        for oc in ocupacoes:
            tipo_doc = oc.get("tipo", "")
            # Cargo
            if cargo_cad and oc.get("cargo"):
                sim = similar(oc["cargo"], cargo_cad)
                ocupacao_linhas.append([
                    "Validação do Cargo:",
                    f"{'✔' if sim > 0.8 else '✘'} Cadastro: '{cargo_cad}' / {tipo_doc}: '{oc['cargo']}'"
                ])
                if sim > 0.8:
                    cargo_ok = True

            # CBO (apenas se futuramente vier no dados_mua)
            cbo_doc = oc.get("cbo", "")
            if cbo_cad and cbo_doc:
                ok = cbo_doc.replace("-", "") == cbo_cad.replace("-", "")
                ocupacao_linhas.append([
                    "Validação do CBO:",
                    "✔ CBO confere" if ok else f"✘ CBO diferente: cadastro '{cbo_cad}' / {tipo_doc} '{cbo_doc}'"
                ])
                if ok:
                    cbo_ok = True

            # Empregador (nome OU CNPJ)
            nome_doc = oc.get("nome_empregador", "")
            cnpj_doc = oc.get("cnpj_empregador", "")
            cnpj_emp_cad_digits = self.format_br.digits(cnpj_emp_cad)
            cnpj_doc_digits = self.format_br.digits(cnpj_doc)
            if empregador_cad or cnpj_emp_cad_digits:
                match_emp = False
                if empregador_cad and nome_doc:
                    if similar(nome_doc, empregador_cad) > 0.8:
                        match_emp = True
                if not match_emp and cnpj_emp_cad_digits and cnpj_doc_digits:
                    match_emp = (cnpj_emp_cad_digits == cnpj_doc_digits)

                ocupacao_linhas.append([
                    "Validação do Empregador:",
                    f"{'✔' if match_emp else '✘'} Cadastro: '{empregador_cad or cnpj_emp_cad}' / {tipo_doc}: '{nome_doc or cnpj_doc}'"
                ])
                if match_emp:
                    empregador_ok = True

        # Resumo
        resumo = []
        if cargo_ok: resumo.append("✔ Cargo compatível")
        if cbo_ok: resumo.append("✔ CBO compatível")
        if empregador_ok: resumo.append("✔ Empregador compatível")
        if resumo:
            ocupacao_linhas.append(["Resumo da Ocupação:", ", ".join(resumo)])
        else:
            ocupacao_linhas.append(["Resumo da Ocupação:", "✘ Nenhuma correspondência encontrada"])

        return validacao_renda, validacao_campo, validacao_periodicidade, ocupacao_linhas