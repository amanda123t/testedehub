import re
from datetime import datetime, date, timedelta
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data, normalize
from typing import Optional, Tuple, Dict, Any
from calendar import monthrange
from app.utils.APIs.api_crc import CRC
from app.validators.helpers.pj import primeiro_e_ultimo_mes_do_periodo_str
CACHE_FATURAMENTO: dict[tuple[str, str], dict] = {}

@registrar_validador("faturamento", "invoice")
class ValidadorFaturamento(ValidadorBase):
    def validar(self) -> bool:
        # 1) Nome do documento + validação de nome
        self.log.info("Iniciando validação do Faturamento")
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de Renda Presumida encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.context = " ".join(self.context) if isinstance(self.context, list) else self.context
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_faturamento_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )
    
    def _valor_total_str(self, raw) -> Optional[float]:
        """
        Extrai o valor total do faturamento a partir de:
        - string: "R$ 350.000,00" ou "à vista: R$ 100.000,00; à prazo: R$ 200.000,00"
        - dict: {"à vista": "R$ 120.000,00", "à prazo": "R$ 80.000,00"}
        - list/tuple: valores misturados
        Retorna None se não encontrar nenhum número.
        """

        # Caso 1 — None
        if raw is None:
            return None

        # Caso 2 — já é número
        if isinstance(raw, (int, float)):
            return float(raw)

        # Caso 3 — string
        if isinstance(raw, str):
            matches = re.findall(r'(\d{1,3}(?:\.\d{3})*,\d{2})', raw)
            if not matches:
                return None

            total = 0.0
            for m in matches:
                v = self.format_br.converter_valor_para_float(m)
                if v is not None:
                    total += v
            return total if total > 0 else None

        # Caso 4 — dict “à vista / à prazo”
        if isinstance(raw, dict):
            total = 0.0
            achou = False
            for v in raw.values():
                subtotal = self._valor_total_str(v)
                if subtotal is not None:
                    total += subtotal
                    achou = True
            return total if achou else None

        # Caso 5 — lista ou tupla
        if isinstance(raw, (list, tuple)):
            total = 0.0
            achou = False
            for item in raw:
                subtotal = self._valor_total_str(item)
                if subtotal is not None:
                    total += subtotal
                    achou = True
            return total if achou else None

        # Caso desconhecido
        return None

    
    def validar_faturamento_individual(self):
        
        self.nome_documento = self.extrair_nome_documento(self.doc)
        
        # dentro da função validar_faturamento_individual
        chave_cache = (self.file, self.nome_documento or "SEM_NOME")

        # mescla cache anterior, priorizando os dados corretos já salvos no cache
        cache_antigo = CACHE_FATURAMENTO.get(chave_cache, {})
        if cache_antigo:
            self.doc = {**self.doc, **cache_antigo}
            self.log.debug(f"🔄 Mesclando cache existente com novos dados para {chave_cache}")    

        erro_faturamento = False
        _err_tags: set[str] = set()  # <- aqui vamos marcar os “culpados” pelos erros
        title = self.extrair_valor(self.doc, False, 'Título:', 'Título', 'titulo:', 'titulo') or ""
        cnpj = self.extrair_valor(self.doc, False, 'CNPJ:', 'CNPJ', 'cnpj:', 'cnpj')
        cnpj = self.format_br.digits(cnpj) or "SEM CNPJ"

        # Busca o Período
        periodo = (
            self.doc.get("Período:", "")
            or self.doc.get("Periodo:", "")
            or self.doc.get("Período Abrangido:", "")
            or self.doc.get("Periodo Abrangido:", "")
        )
        self.periodo_documento = str(periodo).strip() if periodo else ""

        total_str = self.extrair_valor(
            self.doc, False,
            'Faturamento total:', 'Faturamento Total:',
            'Valor Total:', 'Valor:', 'Total:'
        ) or None

        socios_raw = self.extrair_valor(self.doc, False, "Sócios:", "Sócios", "socios:", "socios") or []
        contador_raw = self.extrair_valor(self.doc, False, "Contador:", "Contador", "contador:", "contador") or {}

        socios_ok, contadores_ok, socios_nao_confirmados, contadores_nao_confirmados = self.apis.validar_socios_e_contadores(socios_raw, contador_raw, cnpj)
        self.contadores_ok = contadores_ok
        self.contadores_nao_confirmados = contadores_nao_confirmados

        self.doc["Sócios:"] = socios_ok
        self.doc["Contador:"] = (
            contadores_ok[0]
            if contadores_ok
            else (contadores_nao_confirmados[0] if isinstance(contadores_nao_confirmados, list) and contadores_nao_confirmados else {})
        )
        contador = self.extrair_valor(self.doc, False, "Contador:", "Contador", "contador:", "contador") or {}
        self.contador = str(self.extrair_valor(contador, False, "Nome:", "Nome", "nome:", "nome") or "")
        self.crc_contador = self.extrair_valor(contador, False, "CRC:", "CRC", "crc:", "crc") or ""
        
        linhas = []
        # se não veio 'Período:' da IA, tenta derivar do dicionário 'Meses:'
        meses_raw = self.doc.get("Meses:") or self.doc.get("Meses")  # pode ser dict OU list
        meses = {}
        # EXIBIR meses quando vierem como lista (para não depender do organize_data)
        # --- Sempre usar o total consolidado por mês (à vista + à prazo somados) ---
        meses_presentes, totais_por_mes = self._mapear_meses_e_totais(self.doc.get("Meses:") or self.doc.get("Meses"))
        self.log.debug(f"Meses presentes: {meses_presentes}")
        quantidade_meses = len(meses_presentes)
        self.log.debug(f"Totais por mês: {totais_por_mes}")
        valor_total_ia = None
        # soma o valor de cada mês
        soma_meses_para_total = sum(totais_por_mes.values())
        encontrou_algum_mes = len(totais_por_mes) > 0
        # Substitui no dicionário original o campo "Meses:" por um dict legível para o organize_data
        if totais_por_mes:
            meses_formatados = {
                self.format_br.extrair_mes_ano(date(ano, mes, 1)): self.format_br.formatar_moeda_br(total)
                for (ano, mes), total in sorted(totais_por_mes.items())
            }
            self.doc["Meses:"] = meses_formatados
        # --------------------------------------------------------------
        # AJUSTE DO FATURAMENTO TOTAL PARA O PDF (consolidar se vier a vista / a prazo)
        # --------------------------------------------------------------
        tolerancia_permitida = getattr(self.comprovantes, "tolerancia_permitida_fat", 0)
        raw_total = self.doc.get("Faturamento total:") or self.doc.get("Faturamento total") or total_str

        # Caso 1: dict {"à vista": "...", "à prazo": "..."}
        if isinstance(raw_total, dict):
            parcial = 0.0
            for v in raw_total.values():
                f = self._valor_total_str(str(v))
                parcial += f or 0.0
            valor_total_ia = parcial

        # Caso 2: string "à vista: R$ ...; à prazo: R$ ..."
        elif isinstance(raw_total, str):
            valor_total_ia = self._valor_total_str(raw_total)

        # Caso 3: não tem nada útil
        else:
            valor_total_ia = None

        # Seleciona melhor valor: IA → soma dos meses
        valor_total_final = valor_total_ia or (soma_meses_para_total if encontrou_algum_mes else None)
        total_para_media = None
        if valor_total_ia is not None and soma_meses_para_total > 0:
            if abs(soma_meses_para_total - valor_total_ia) <= tolerancia_permitida:
                total_para_media = soma_meses_para_total
            else:
                total_para_media = valor_total_ia
        elif valor_total_ia is not None:
            total_para_media = valor_total_ia
        elif soma_meses_para_total > 0:
            total_para_media = soma_meses_para_total

        media_mensal = (
            total_para_media / quantidade_meses
            if total_para_media and quantidade_meses > 0
            else None
        )
        
        # Formata e grava no self.doc ANTES do organize_data
        if valor_total_final is not None:
            self.doc["Faturamento total:"] = self.format_br.formatar_moeda_br(valor_total_final)
        else:
            self.doc["Faturamento total:"] = ""
        
        if media_mensal is not None and media_mensal > 0:
            self.doc["Média Mensal:"] = self.format_br.formatar_moeda_br(media_mensal)

        # --------- REORDENA PARA COLOCAR MÉDIA LOGO APÓS O FATURAMENTO TOTAL ---------
        if "Faturamento total:" in self.doc and "Média Mensal:" in self.doc:
            novo = {}
            for chave, valor in self.doc.items():
                novo[chave] = valor
                if chave == "Faturamento total:":
                    # insere imediatamente após
                    novo["Média Mensal:"] = self.doc["Média Mensal:"]
            self.doc = novo
        # -------------------------------------------------------------------------------

        # Montagem das linhas
        linhas = organize_data(self.doc, self.doc_type)
        linhas = [["Documento lido:", self.file]] + linhas


        # ---------------- VALIDAÇÃO DO NOME ----------------

        # 1) Validação do nome, se tiver nome do processo nos dados do RPA.
        validacao_nome = self._nome_validation_row()
        if validacao_nome:
            linhas.append(validacao_nome)

        # ---------------- VALIDAÇÃO DO TITULO ----------------
        validar_titulo = getattr(getattr(self, "comprovantes", None), "validar_titulo_fat", True)
        validar_titulo = self.to_bool(validar_titulo) is not False
        palavra_encontrada = False
        if validar_titulo:
            if title:
                palavras_nao_aceitas = ["PREVISÃO", "PREVISTO", "RELAÇÃO DE DESPESAS", "RELAÇÃO DE COMPRAS", "ESTIMATIVA", "ESTIMADO"]
                for palavra in palavras_nao_aceitas:
                    if normalize(palavra) in normalize(title):
                        linhas.append([f"✘ Título contém a palavra '{palavra}', verificar!"])
                        palavra_encontrada = True
                        break
                    if normalize(palavra) in normalize(self.context):
                        linhas.append([f"✘ Texto contém a palavra '{palavra}', verificar!"])
                        palavra_encontrada = True
                        break
                if palavra_encontrada:
                    linhas.append([f"✔ Título '{title}' parece adequado, sem palavras como 'PREVISÃO', 'CUSTOS', 'ESTIMATIVA', etc."])
        
        #------------ VALIDAÇÕES RECEITA FEDERAL -------------:
        validar_situacao_receita = getattr(getattr(self, "comprovantes", None), "validar_situacao_do_cnpj_fat", True)
        validar_situacao_receita = self.to_bool(validar_situacao_receita) is not False
        if validar_situacao_receita:
            if self.validar_cnpj(cnpj):
                linhas.append(self.apis.validar_situacao_cnpj(cnpj))
            else:
                _err_tags.add("cnpj") 
                dados_receita = None
                erro_faturamento = True
                linhas.append(["✘ CNPJ inválido ou não encontrado no documento"])

        # ---------------- VALIDAÇÃO DOS MESES (PERIODO) ----------------

        primeiro_mes_periodo = None
        ultimo_mes_periodo = None

        # Derivar do campo Meses
        if isinstance(meses_raw, dict):
            primeiro_mes_periodo, ultimo_mes_periodo = self.obter_primeiro_e_ultimo_mes_por_meses_dict(meses_raw)
            if primeiro_mes_periodo and ultimo_mes_periodo:
                self.periodo_documento = f"{self.format_br.extrair_mes_ano(primeiro_mes_periodo)} a {self.format_br.extrair_mes_ano(ultimo_mes_periodo)}"
        elif isinstance(meses_raw, list):
            # parse cada item da lista 'mm/aaaa' (ou 'Mês aaaa')
            datas = []
            for mes in meses_raw:
                label = str(mes).split(":", 1)[0]
                data_mes = self.format_br.formatar_data_br(label)
                if data_mes:
                    datas.append(date(data_mes.year, data_mes.month, 1))
            if datas:
                datas.sort()
                ultimo_mes_periodo = datas[-1]
                # preencher período para exibir bonitinho
                if not self.periodo_documento:
                    self.periodo_documento = f"{self.format_br.extrair_mes_ano(datas[0])} a {self.format_br.extrair_mes_ano(datas[-1])}"

        # Fallback enxuto: só entra se as tentativas iniciais não deram certo
        if not self.periodo_documento and meses_presentes:
            ano_inicial, mes_inicial = min(meses_presentes)  # menor (ano, mes)
            ano_final, mes_final = max(meses_presentes)  # maior (ano, mes)

            primeiro_mes_do_periodo = date(ano_inicial, mes_inicial, 1)
            ultimo_mes_do_periodo   = date(ano_final, mes_final, 1)

            self.periodo_documento = (
                f"{self.format_br.extrair_mes_ano(primeiro_mes_do_periodo)} "
                f"a {self.format_br.extrair_mes_ano(ultimo_mes_do_periodo)}"
            )

        elif not ultimo_mes_periodo and meses_presentes:
            # garante a variável 'ultimo_mes_periodo' mesmo que o período já exista
            ano_final, mes_final = max(meses_presentes)
            ultimo_mes_periodo = date(ano_final, mes_final, 1)
        
        # ---------------- VALIDAÇÃO DATA DE ABERTURA DA EMPRESA ----------------
        validar_valores_antes_da_abertura_fat = getattr(getattr(self, "comprovantes", None), "validar_valores_antes_da_abertura_fat", True)
        validar_valores_antes_da_abertura_fat = self.to_bool(validar_valores_antes_da_abertura_fat) is not False
        data_abertura_empresa = None
        if validar_valores_antes_da_abertura_fat:
            dados_receita = self.apis.buscar_dados_receita(cnpj) if self.validar_cnpj(cnpj) else None
            if dados_receita:
                #Pega a data de abertura
                abertura_str = dados_receita.get("abertura") or dados_receita.get("data de abertura")
                dt_abertura = self.format_br.formatar_data_br(abertura_str) if abertura_str else None
                data_abertura_empresa = dt_abertura.date() if dt_abertura else None

                if data_abertura_empresa:
                    # Normaliza para "primeiro dia do mês de abertura"
                    primeiro_dia_abertura = self.primeiro_dia_do_mes(
                        data_abertura_empresa.year, data_abertura_empresa.month
                    )

                    # Meses informados que são anteriores ao mês da abertura
                    meses_antes_da_abertura = [
                        (ano, mes)
                        for (ano, mes) in meses_presentes
                        if self.primeiro_dia_do_mes(ano, mes) < primeiro_dia_abertura
                    ]

                    # Existe faturamento (> 0) em algum mês anterior?
                    tem_faturamento_antes = any(
                        (totais_por_mes.get((ano, mes), 0.0) or 0.0) > 0.0
                        for (ano, mes) in meses_antes_da_abertura
                    )

                    if tem_faturamento_antes:
                        meses_str = ", ".join(
                            self.format_br.extrair_mes_ano(self.primeiro_dia_do_mes(ano, mes))
                            for (ano, mes) in meses_antes_da_abertura
                            if (totais_por_mes.get((ano, mes), 0.0) or 0.0) > 0.0
                        )
                        linhas.append([
                            f"✘ Faturamento anterior à data de abertura "
                            f"({data_abertura_empresa.strftime('%d/%m/%Y')}): {meses_str}."
                        ])
                    else:
                        linhas.append([
                            f"✔ Não há faturamento anterior à data de abertura "
                            f"({data_abertura_empresa.strftime('%d/%m/%Y')})."
                        ])
                else:
                    linhas.append(["✘ Data de abertura não encontrada na Receita."])

        # --- Validação da cobertura de meses (janela contínua) ---
        validar_se_possui_12_meses_fat = getattr(getattr(self, "comprovantes", None), "validar_se_possui_12_meses_fat", True)
        validar_se_possui_12_meses_fat = self.to_bool(validar_se_possui_12_meses_fat) is not False
        meses_desde_abertura = None
        if validar_se_possui_12_meses_fat:
            if ultimo_mes_periodo:
                # Quantos meses de vida a empresa tinha no último mês do período?
                if data_abertura_empresa:
                    primeiro_dia_abertura = self.primeiro_dia_do_mes(
                        data_abertura_empresa.year, data_abertura_empresa.month
                    )
                    fim_periodo_mes = self.primeiro_dia_do_mes(
                        ultimo_mes_periodo.year, ultimo_mes_periodo.month
                    )
                    # diferença em meses, inclusiva (ex.: mai–set = 5)
                    meses_desde_abertura = (
                        (fim_periodo_mes.year - primeiro_dia_abertura.year) * 12
                        + (fim_periodo_mes.month - primeiro_dia_abertura.month) + 1
                    )

                # Tamanho da janela esperada (12 padrão; exceção para empresa jovem)
                if meses_desde_abertura is not None and meses_desde_abertura < 12:
                    tamanho_janela = meses_desde_abertura
                    inicio_requerido = self.primeiro_dia_do_mes(
                        data_abertura_empresa.year, data_abertura_empresa.month
                    )
                else:
                    tamanho_janela = 12
                    # Calcula o início retrocedendo 11 meses a partir do último mês do período (zero-based)
                    total_mes_ultimo = ultimo_mes_periodo.year * 12 + (ultimo_mes_periodo.month - 1)
                    total_mes_inicio = total_mes_ultimo - (tamanho_janela - 1)
                    ano_ini = total_mes_inicio // 12
                    mes_ini = (total_mes_inicio % 12) + 1
                    inicio_requerido = self.primeiro_dia_do_mes(ano_ini, mes_ini)

                # Gera a lista contígua de (ano, mes) esperados na janela
                meses_esperados_contiguos: list[tuple[int, int]] = []
                ano_corr, mes_corr = inicio_requerido.year, inicio_requerido.month
                for _ in range(tamanho_janela):
                    meses_esperados_contiguos.append((ano_corr, mes_corr))
                    mes_corr += 1
                    if mes_corr == 13:
                        mes_corr = 1
                        ano_corr += 1

                # Verifica meses faltantes
                meses_faltantes = [
                    (aa, mm) for (aa, mm) in meses_esperados_contiguos
                    if (aa, mm) not in meses_presentes
                ]

                if meses_faltantes:
                    faltantes_str = ", ".join(
                        self.format_br.extrair_mes_ano(self.primeiro_dia_do_mes(aa, mm))
                        for (aa, mm) in meses_faltantes
                    )
                    linhas.append([
                        f"✘ Faltam meses no período esperado "
                        f"({self.format_br.extrair_mes_ano(inicio_requerido)} a {self.format_br.extrair_mes_ano(ultimo_mes_periodo)}): "
                        f"{faltantes_str}."
                    ])
                    _err_tags.update({"meses:", "periodo"})
                    erro_faturamento = True
                else:
                    linhas.append([
                        f"✔ Período contínuo de {self.format_br.extrair_mes_ano(inicio_requerido)} "
                        f"a {self.format_br.extrair_mes_ano(ultimo_mes_periodo)} ({tamanho_janela} meses)."
                    ])
            else:
                linhas.append([
                    "✘ Não foi possível identificar o último mês do período para validar a quantidade de meses informados; "
                    "verifique se há 12 meses."
                ])
                _err_tags.update({"meses:", "periodo"})
                erro_faturamento = True

        
        # ---------------- VALIDAÇÃO DA DATA DE EMISSÃO ----------------

        # --- Data de corte do faturamento ---
        corte_raw = getattr(getattr(self, "comprovantes", None), "data_corte_fat", None)
        try:
            corte_dia = int(corte_raw) if corte_raw not in (None, "", 0) else None
        except Exception:
            corte_dia = None

        hoje = datetime.now().date()

        data_corte_dt = None
        data_corte_str = ""
        if corte_dia:
            # garante que não estoura o último dia do mês
            last_day = monthrange(hoje.year, hoje.month)[1]
            corte_eff = min(max(1, corte_dia), last_day)
            data_corte_dt = date(hoje.year, hoje.month, corte_eff)
            data_corte_str = data_corte_dt.strftime('%d/%m/%Y')
        
        data_emissao = self._extrair_data_emissao()
        if isinstance(data_emissao, datetime):
            data_emissao = data_emissao.date()
        # A) Limite em dias -> usa SOMENTE a data de emissão (sua regra)
        limite_dias = getattr(getattr(self, "comprovantes", None), "limite_dias_faturamento", None)
        try:
            limite_dias_int = int(limite_dias) if (limite_dias is not None and str(limite_dias).strip() != "") else None
        except Exception:
            limite_dias_int = None

        if limite_dias_int is not None and limite_dias_int > 0 and data_emissao:
            data_corte = hoje - timedelta(days=limite_dias_int)
            if data_emissao < data_corte:
                linhas.append([
                    #"Limite de dias do faturamento:",
                    f"✘ Data de emissão {data_emissao.strftime('%d/%m/%Y')} excede o limite de {limite_dias_int} dias (corte em {data_corte.strftime('%d/%m/%Y')})."
                ])
                erro_faturamento = True
                _err_tags.add("Data de emissão:")
            else:
                linhas.append([
                    #"Limite de dias do faturamento:",
                    f"✔ Dentro do limite de {limite_dias_int} dias (emissão {data_emissao.strftime('%d/%m/%Y')}, corte {data_corte.strftime('%d/%m/%Y')})."
                ])
        elif limite_dias_int is not None and limite_dias_int > 0 and not data_emissao:
            linhas.append([
                #"Limite de dias do faturamento:",
                "✘ Limite para a data de emissao configurado, mas a data não foi identificada no documento."
            ])
            erro_faturamento = True
            _err_tags.add("Data de emissão:")
        
        # ---------------- VALIDAÇÃO FATURAMENTO NO MES DA EMISSÃO ----------------

        # B) Proibição de valores no mês da emissão -> comparar último mês (derivado) vs mês/ano da emissão
        permitido_mes_emissao_raw = getattr(getattr(self, "comprovantes", None), "permitido_fat_no_mes_da_emissao", False)
        permitido_mes_emissao = None if permitido_mes_emissao_raw in [None, ""] else self.to_bool(permitido_mes_emissao_raw)

        if permitido_mes_emissao is False:
            if not data_emissao:
                linhas.append([
                    #"Faturamento no mês da emissão:",
                    "✘ Não foi possível verificar se possui faturamento para o mês da emissão, pois a data de emissão não foi identificada no documento."
                ])
                erro_faturamento = True
                _err_tags.add("Data de emissão:")
            elif not ultimo_mes_periodo:
                linhas.append([
                    #"Faturamento no mês da emissão:",
                    "✘ Não foi possível verificar se possui faturamento para o mês da emissão, pois os meses do faturamento não foi encontrado no documento."
                ])
                erro_faturamento = True
                _err_tags.add("meses:")
            else:
                par_emissao = (data_emissao.year, data_emissao.month)
                par_ultimo  = (ultimo_mes_periodo.year, ultimo_mes_periodo.month)
                if par_emissao == par_ultimo:
                    total_emissao = totais_por_mes.get(par_emissao, 0.0)
                    if total_emissao <= 0:
                        linhas.append([ "✔ Sem valores no mês da emissão."])
                    else:
                        # mantém a sua lógica de corte/liberação
                        liberado_por_corte = False
                        if data_corte_dt:
                            if data_emissao >= data_corte_dt or hoje >= data_corte_dt:
                                liberado_por_corte = True
                        if liberado_por_corte:
                            linhas.append([ f"✔ Faturamento no mes da emissão permitido pois estamos no final do mês (data de corte {data_corte_str})."])
                        else:
                            msg_corte = f" (Data de corte {data_corte_str})" if data_corte_dt else ""
                            linhas.append([ f"✘ Não é permitido declarar faturamento no próprio mês da emissão{msg_corte}."])
                            _err_tags.update({"meses:", "periodo", "Data de emissão:"})

                elif par_ultimo < par_emissao:
                    linhas.append([
                        #"Faturamento no mês da emissão:",
                        f"✔ Documento emitido em {self.format_br.extrair_mes_ano(date(data_emissao.year, data_emissao.month, 1))} e não há valores declarados para esse mês; período vai até {self.format_br.extrair_mes_ano(ultimo_mes_periodo)}."
                    ])
                else:  # par_ultimo > par_emissao
                    linhas.append([
                        #"Faturamento no mês da emissão:",
                        f"✘ Período informado ({self.format_br.extrair_mes_ano(ultimo_mes_periodo)}) ultrapassa o mês da emissão ({self.format_br.extrair_mes_ano(date(data_emissao.year, data_emissao.month, 1))})."
                    ])
                    erro_faturamento = True
                    _err_tags.update({"meses:", "periodo", "Data de emissão:"})

        # ---------------- VALIDAÇÃO DA DATA DO ULTIMO MES FATURADO ----------------
        limite_ult_mes_raw = getattr(getattr(self, "comprovantes", None), "limite_meses_ult_mes_faturado", None)

        # normaliza para int ou None
        try:
            limite_ult_mes = int(limite_ult_mes_raw) if (limite_ult_mes_raw not in (None, "", False)) else None
        except Exception:
            limite_ult_mes = None

        if not limite_ult_mes or limite_ult_mes == 0:
            linhas.append([
                #"Último mês faturado:", 
                "✔ Sem limites definidos para o ultimo mes faturado"])
        else:
            text_mes = "meses" if (isinstance(limite_ult_mes, int) and limite_ult_mes > 1) else "mês"
            # precisa ter identificado o último mês do período
            if not ultimo_mes_periodo:
                linhas.append([
                    #"Último mês faturado:", 
                    f"✘ Não foi possível identificar o último mês do período, verificar se esta dentro de {limite_ult_mes} {text_mes}."])
                _err_tags.update({"meses", "periodo"})
                erro_faturamento = True
            else:
                ano_atual, mes_atual = self.format_br.obter_ano_mes_atual()
                diff = self.format_br.calcular_meses_entre(ano_atual, mes_atual, ultimo_mes_periodo.year, ultimo_mes_periodo.month)

                # regra: aceitar se 1 <= diff <= limite_ult_mes
                if diff < 0:
                    # futuro: continua inválido
                    linhas.append([
                        #"Último mês faturado:",
                        f"✘ Último mês informado ({self.format_br.extrair_mes_ano(ultimo_mes_periodo)}) é futuro."
                    ])
                    erro_faturamento = True
                    _err_tags.update({"meses:", "periodo"})
                elif diff == 0:
                    # mês atual: permitido APÓS a data de corte
                    if data_corte_dt and hoje >= data_corte_dt:
                        linhas.append([
                            #"Último mês faturado:",
                            f"✔ Faturamento no mês atual aceito (estamos após a data de corte: {data_corte_str})."
                        ])
                    else:
                        if data_corte_dt:
                            linhas.append([
                                #"Último mês faturado:",
                                f"✘ Faturamento para o mês atual, verificar!"
                            ])
                            erro_faturamento = True
                            _err_tags.update({"meses:", "periodo"})
                elif diff <= limite_ult_mes:
                    linhas.append([
                        #"Último mês faturado:",
                        f"✔ Dentro do limite de {limite_ult_mes} {text_mes} para o ultimo mes faturado: {self.format_br.extrair_mes_ano(ultimo_mes_periodo)}."
                    ])
                else:
                    # fora do limite (ex.: hoje = setembro, último = junho → diff=3 >2)
                    linhas.append([
                        #"Último mês faturado:",
                        f"✘ Fora do limite de {limite_ult_mes} {text_mes} para o ultimo mes faturado: último mês {self.format_br.extrair_mes_ano(ultimo_mes_periodo)}."
                    ])
                    erro_faturamento = True
                    _err_tags.update({"meses:", "periodo"})

       # ------------ VALIDAÇÃO TOTAL DO FATURAMENTO -------------
        
        valor_total_declarado = self._valor_total_str(total_str)
        valor_total_calculado = soma_meses_para_total if encontrou_algum_mes else None
        valor = valor_total_calculado if valor_total_calculado else valor_total_declarado
        self.valor_documento = self.format_br.formatar_moeda_br(valor) if valor else None

        #------ VALIDA SE O VALOR TOTAL DO FATURAMENTO INFORMADO BATE COM O VALOR TOTAL DA SOMA DOS MESES ------------
        validar_total_com_os_meses_fat = getattr(getattr(self, "comprovantes", None), "validar_total_com_os_meses_fat", True)
        validar_total_com_os_meses_fat = self.to_bool(validar_total_com_os_meses_fat) is not False
        if validar_total_com_os_meses_fat:
    
            # Só valida se realmente existia um total informado no documento
            if total_str:
                if valor_total_declarado is not None and valor_total_calculado is not None:
                    diferenca = abs(valor_total_declarado - valor_total_calculado)

                    if not tolerancia_permitida:
                        tolerancia_permitida = 1

                    if diferenca <= tolerancia_permitida:
                        linhas.append([
                            f"✔ Valor total informado ({self.format_br.formatar_moeda_br(valor_total_declarado)}) "
                            f"bate com a soma dos meses ({self.format_br.formatar_moeda_br(valor_total_calculado)})."
                        ])
                    else:
                        linhas.append([
                            f"✘ Valor total informado ({self.format_br.formatar_moeda_br(valor_total_declarado)}) "
                            f"é divergente da soma dos meses ({self.format_br.formatar_moeda_br(valor_total_calculado)}), "
                            f"diferença de {self.format_br.formatar_moeda_br(diferenca)}."
                        ])
                        erro_faturamento = True
                        _err_tags.update({"meses:", "Faturamento total:"})
                else:
                    linhas.append(["✘ Não foi possível calcular ou extrair o faturamento total corretamente, usando a soma dos meses."])
                    erro_faturamento = True
                    _err_tags.update({"meses:", "Faturamento total:"})
       # ------------ VALIDAÇÃO TOTAL DO FATURAMENTO CONFORME O PORTE NA RECEITA -------------
        
        validar_total_com_o_porte_fat = getattr(getattr(self, "comprovantes", None), "validar_total_com_o_porte_fat", True)
        validar_total_com_o_porte_fat = self.to_bool(validar_total_com_o_porte_fat) is not False
        porte_receita = self.apis.capturar_porte_receita(cnpj) if self.validar_cnpj(cnpj) else None
        limites_por_porte = getattr(getattr(self, "comprovantes", None), "limites_por_porte", None)
        limite_faturamento = None

        if isinstance(limites_por_porte, dict) and porte_receita:
            limite_faturamento = limites_por_porte.get(porte_receita)

            # fallback: se não existir limite específico para MEI CAMINHONEIRO, usa MEI
            if limite_faturamento is None and porte_receita == "MEI CAMINHONEIRO":
                limite_faturamento = limites_por_porte.get("MEI")

            try:
                limite_faturamento = float(limite_faturamento)
            except Exception:
                limite_faturamento = None
                
        # Limite adicional do MEI (se configurado)
        limite_adicional_mei = None
        try:
            raw_adicional = getattr(getattr(self, "comprovantes", None), "limite_adicional_MEI", None)
            if raw_adicional not in (None, "", 0):
                limite_adicional_mei = float(raw_adicional)
        except Exception:
            limite_adicional_mei = None
        if validar_total_com_o_porte_fat:
            if valor is None:
                linhas.append(["✘ Não foi possível determinar o faturamento total."])
                erro_faturamento = True
                _err_tags.update({"meses:", "Faturamento total:"})
            else:
                #valor_mensal_faturamento = valor / quantidade_meses
                # Caso especial: MEI
                if porte_receita == "MEI" and isinstance(limite_adicional_mei, (int, float)) and limite_adicional_mei > 0:
                    adicional_brl = self.format_br.formatar_moeda_br(limite_adicional_mei)

                    if not isinstance(limite_faturamento, (int, float)) or limite_faturamento == 0:
                        # Sem limite padrão configurado -> valida só pelo adicional
                        if valor <= limite_adicional_mei:
                            linhas.append([ f"✔ Faturamento total dentro do limite adicional do MEI de {adicional_brl}."])
                        else:
                            linhas.append([  f"✘ Faturamento total ACIMA do limite adicional do MEI de {adicional_brl}."])
                    else:
                        # Com limite padrão:
                        limite_brl = self.format_br.formatar_moeda_br(limite_faturamento)
                        if valor <= limite_faturamento:
                            linhas.append([  f"✔ Faturamento total dentro do limite de {limite_brl} para o porte MEI."])
                        elif valor <= limite_adicional_mei:
                            linhas.append([  f"✔ Faturamento total dentro do limite adicional do MEI de {adicional_brl}."])
                        else:
                            linhas.append([  f"✘ Faturamento total ACIMA do limite adicional do MEI de {adicional_brl}."])
                else:
                    # Não é MEI (ou sem adicional válido) -> valida só pelo limite padrão
                    if not isinstance(limite_faturamento, (int, float)) or limite_faturamento == 0:
                        if porte_receita:
                            linhas.append([f"✔ Não há limite para o faturamento total configurado para o porte '{porte_receita}'."])
                        else:
                            linhas.append(["✘ Porte não identificado na Receita; não foi possível validar contra limites."])
                    else:
                        limite_brl = self.format_br.formatar_moeda_br(limite_faturamento)
                        if valor <= limite_faturamento:
                            linhas.append([  f"✔ Faturamento total Dentro do limite de {limite_brl} para o porte {porte_receita}."])
                        else:
                            linhas.append([  f"✘ Faturamento total ACIMA do limite de {limite_brl} para o porte {porte_receita}."])

        # ------------ VALIDAÇÃO ASSINATURAS DO DOCUMENTO (pós-validar_socios_e_contadores) -------------
        validar_assinaturas = getattr(getattr(self, "comprovantes", None), "validar_assinaturas_fat", True)
        validar_assinaturas = self.to_bool(validar_assinaturas) is not False
        if validar_assinaturas:
            # listas já corrigidas pela função validar_socios_e_contadores(...)
            socios_ok = self.doc.get("Sócios:") or self.doc.get("Socios:") or []
            contadores_ok = self.contadores_ok if hasattr(self, "contadores_ok") else []

            tem_representante = bool(socios_ok)
            tem_contador = bool(contadores_ok)

            if tem_representante and tem_contador:
                # mensagem principal
                nome_rep = ((socios_ok[0].get("Nome") or socios_ok[0].get("Nome:") or "").strip())
                nome_cont = ((contadores_ok[0].get("Nome") or contadores_ok[0].get("Nome:") or "").strip())
                linhas.append([f"✔ Documento assinado pelo representante {nome_rep.split(' ')[0]} e pelo contador {nome_cont.split(' ')[0]}."])

                # detalhes de QSA: para cada sócio
                for s in socios_ok:
                    ns = (s.get("Nome") or s.get("Nome:") or "").strip()
                    linhas.append([f"✔ Sócio '{ns}' consta no QSA da empresa."])

                # detalhes de CRC: para cada contador
                for c in contadores_ok:
                    nc = (c.get("Nome") or c.get("Nome:") or "").strip()
                    # já verificado na resolução; aqui apenas informamos
                    linhas.append([f"✔ Contador '{nc}' com CRC ativo no CFC."])

            elif (not tem_representante) and (not tem_contador):
                erro_faturamento = True
                _err_tags.update({"Sócios:", "Contador:"})
                if self.validar_cnpj(cnpj) is False:
                    if socios_nao_confirmados and contadores_nao_confirmados:
                        linhas.append(["✘ CNPJ inválido ou não encontrado, não foi possível validar o representante no QSA da empresa e o contador que assinou o documento não foi localizado no CFC."])
                    elif socios_nao_confirmados and (not contadores_nao_confirmados):
                        linhas.append(["✘ CNPJ inválido ou não encontrado, não foi possível validar o representante no QSA da empresa e não foi encontrado a identificação do contador no documento."])
                    elif (not socios_nao_confirmados) and contadores_nao_confirmados:
                        linhas.append(["✘ Contador que assinou não consta no CFC e não foi localizada a identificação do representante no documento."])
                    else:
                        linhas.append(["✘ Não foi possível identificar o representante nem o contador no documento."])
                else:
                    if socios_nao_confirmados and contadores_nao_confirmados:
                        linhas.append(["✘ Documento assinado pelo representante e contador porém o representante não consta no QSA e o contador não consta no CFC."])
                    elif socios_nao_confirmados and (not contadores_nao_confirmados):
                        linhas.append(["✘ Representante que assinou não consta no QSA, nem no CFC e não foi localizada a identificação do contador no documento."])
                    elif (not socios_nao_confirmados) and contadores_nao_confirmados:
                        linhas.append(["✘ Contador que assinou não consta no CFC, nem no QSA e não foi localizada a identificação do representante no documento."])
                    else:
                        linhas.append(["✘ Não foi possível identificar o representante nem o contador no documento."])


            elif tem_contador and (not tem_representante):
                # contador correto (CFC)
                cont = contadores_ok[0]
                nome_cont = (cont.get("Nome") or cont.get("Nome:") or "").strip()
                linhas.append([f"✔ Contador '{nome_cont}' com CRC ativo no CFC."])

                if not self.validar_cnpj(cnpj):
                    linhas.append(["✘ CNPJ inválido ou não encontrado, não foi possível validar o QSA da empresa."])
                else:
                    # precisa ser também sócio para aceitar assinatura única
                    ok_qsa, _dados_r = self.apis.validar_associado_em_cnpj(cnpj, (nome_cont or "").strip())
                    if ok_qsa:
                        linhas.append([f"✔ Contador '{nome_cont}' também consta no QSA da empresa."])
                        linhas.append([f"✔ Assinatura única aceita (contador também é representante, consta no QSA)."])
                    else:
                        if socios_nao_confirmados:
                            erro_faturamento = True
                            _err_tags.update({"Sócios:", "Contador:"})
                            linhas.append([f"✘ Representante que assinou não consta no QSA da empresa."])
                        else:
                            erro_faturamento = True
                            _err_tags.update({"Sócios:", "Contador:"})
                            linhas.append([f"✘ Não foi localizada a identificação do representante (contador também não consta no QSA)."])

            else:  # tem_representante e não tem_contador
                # representantes corretos (QSA)
                for s in socios_ok:
                    ns = (s.get("Nome") or s.get("Nome:") or "").strip()
                    linhas.append([f"✔ Representante '{ns}' consta no QSA da empresa."])

                # checa se algum representante possui CRC ativo (usa 's', não 'contador')
                representante_com_crc_ativo = None
                for s in socios_ok:
                    nome = (s.get("Nome") or s.get("Nome:") or "").strip()
                    cpf  = self.format_br.digits(s.get("CPF") or s.get("CPF:") or "")
                    try:
                        resp = self.apis.buscar_dados_crc({"Nome": nome, "CPF": cpf})
                    except Exception:
                        resp = None
                    dados = (resp or {}).get("dados") if isinstance(resp, dict) else None
                    regs = (dados or {}).get("data") if isinstance(dados, dict) else None
                    if isinstance(regs, list):
                        for r in regs:
                            sit = str(r.get("SituacaoCadastral") or "").strip().upper()
                            if sit in {"ATIVO", "ATIVA", "REGULAR"}:
                                representante_com_crc_ativo = nome
                                break
                    if representante_com_crc_ativo:
                        break

                if representante_com_crc_ativo:
                    linhas.append([f"✔ Representante '{representante_com_crc_ativo}' possui CRC ativo no CFC."])
                    linhas.append(["✔ Assinatura única aceita (representante com CRC ativo)."])
                else:
                    # exceção: MEI dentro do limite
                    if porte_receita and valor and porte_receita == "MEI" and isinstance(limite_faturamento, (int, float)):
                        nome_rep_full = ((socios_ok[0].get("Nome") or socios_ok[0].get("Nome:") or "").strip()) if socios_ok else ""
                        nome_rep_curto = (nome_rep_full.split(' ')[0] if nome_rep_full else "da empresa")
                        if valor <= limite_faturamento:
                            linhas.append([f"✔ Documento assinado pelo representante {nome_rep_curto}"])
                            linhas.append(["✔ Não foi localizada a assinatura do contador mas a empresa é MEI!"])
                        else:
                            linhas.append([f"✔ Documento assinado pelo representante {nome_rep_curto}"])
                            linhas.append([f"✘ Não foi localizada a assinatura do contador e o faturamento total ({self.format_br.formatar_moeda_br(valor)}) ultrapassa o limite do MEI ({self.format_br.formatar_moeda_br(limite_faturamento)})."])
                            erro_faturamento = True
                            _err_tags.update({"Sócios:", "Contador:"})
                    else:
                        if contadores_nao_confirmados:
                            # havia contador informado mas NÃO ativo no CFC
                            linhas.append(["✘ Contador informado foi identificado, mas não possui CRC ativo no CFC."])
                            erro_faturamento = True
                            _err_tags.update({"Sócios:", "Contador:"})
                        else:
                            # nenhum contador identificado no documento
                            linhas.append(["✘ Não foi localizada a assinatura/identificação do contador."])
                            erro_faturamento = True
                            _err_tags.update({"Sócios:", "Contador:"})

                        # deixa explícito que nenhum representante tem CRC ativo p/ assinatura única
                        linhas.append(["✘ Nenhum representante possui CRC ativo no CFC para assinar como contador."])
                        erro_faturamento = True
                        _err_tags.update({"Sócios:", "Contador:"})

        # ---------------- Regras / Parecer ----------------
        regras = {}
        if getattr(self, "regras_mua", None):
            nomes = ["faturamento", "relacao de faturamento", "relação de faturamento", "declaração de faturamento", "invoice"]
            regras = self.regras_mua.get_doc(nomes)

        linhas.extend(self.exibir_regras_doc(regras))
        linhas.append([])

        if erro_faturamento:
            # Salvar no cache APENAS os campos válidos (remove os marcados)
            doc_limpo = self.drop_keys_simples(self.doc, list(_err_tags))
            CACHE_FATURAMENTO[chave_cache] = doc_limpo
            self.log.debug(f"💾 Cache parcial ({chave_cache}) sem {sorted(_err_tags)} -> {list(doc_limpo.keys())}")
        else:
            # Tudo certo: cache completo (pode inclusive limpar tags antigas)
            CACHE_FATURAMENTO[chave_cache] = dict(self.doc)
            self.log.debug(f"✅ Cache completo atualizado para {chave_cache}")

        self.sections.append(("FATURAMENTO", linhas))
        self.log.info("Validação de Faturamento concluída.")
        return not erro_faturamento

    def primeiro_dia_do_mes(self, ano: int, mes: int) -> date:
        return date(ano, mes, 1)
    
    def obter_primeiro_e_ultimo_mes_por_meses_dict(self, meses_dict: Dict[Any, Any] | None) -> Tuple[Optional[date], Optional[date]]:
        """
        Retorna (primeiro_mês, último_mês) considerando APENAS o rótulo do mês.
        Ex.: "03/2025", "março 2025", "Mar/2025" etc. Valores não influenciam aqui.
        """
        if not isinstance(meses_dict, dict):
            return (None, None)

        candidatos: list[date] = []
        for rotulo in meses_dict.keys():
            dt = self.format_br.formatar_data_br(rotulo)
            if dt:
                candidatos.append(date(dt.year, dt.month, 1))

        if not candidatos:
            return (None, None)
        return (min(candidatos), max(candidatos))

    def _extrair_data_emissao(self) -> date | None:
        """Procura a data de emissão nas chaves (case/acentos flexível) e no contexto."""
        candidatos = {
            "data de emissao", "data emissão", "data da emissão", "emissão",
            "data do documento", "data", "data de emissão",
        }

        for k, v in (self.doc or {}).items():
            if v and re.sub(r"[:\s]+$", "", normalize(k or "")) in candidatos:
                dt = self.format_br.formatar_data_br(str(v))
                if dt:
                    return dt.date()  # <-- garante date

        ctx = (self.context or "")
        m = re.search(r"(\d{2}/\d{2}/\d{4})", ctx)
        if m:
            dt = self.format_br.formatar_data_br(m.group(1))
            return dt.date() if dt else None  # <-- garante date

        return None

    def _valor_mes_total(self, raw) -> float | None:
        """
        Soma valores do mês (ex.: 'à vista' + 'à prazo').
        Aceita:
        - float/int
        - str: com 1+ valores (ex.: "à vista: R$ X; à prazo: R$ Y")
        - dict: soma de subcampos monetários
        - list/tuple: soma recursiva
        Retorna None se não achar nenhum número; 0.0 se achar e somar zero.
        """
        if raw is None:
            return None

        if isinstance(raw, (int, float)):
            return float(raw)

        if isinstance(raw, str):
            vdir = self.format_br.converter_valor_para_float(raw)
            if vdir is not None:
                return vdir
            matches = re.findall(r'(?:R\$\s*)?(\d{1,3}(?:\.\d{3})*,\d{2})', raw)
            total = 0.0; achou = False
            for m in matches:
                vm = self.format_br.converter_valor_para_float(m)
                if vm is not None:
                    total += vm; achou = True
            return total if achou else None

        if isinstance(raw, dict):
            total = 0.0; achou = False
            for k, v in raw.items():
                k_norm = re.sub(r'[\s\.\-_:]+', '', str(k)).lower()
                if k_norm in ('mes','mês','month','rotulo','rótulo','label','descricao','descrição','periodo','período','total','totais','resultado'):
                    continue
                vm = self._valor_mes_total(v)
                if vm is not None:
                    total += vm; achou = True
            return total if achou else None

        if isinstance(raw, (list, tuple)):
            total = 0.0; achou = False
            for v in raw:
                vm = self._valor_mes_total(v)
                if vm is not None:
                    total += vm; achou = True
            return total if achou else None

        return None
    
    def _mapear_meses_e_totais(self, meses_raw):
        """
        Retorna (meses_presentes, totais_por_mes)
        - meses_presentes: set[(ano, mes)]
        - totais_por_mes: dict[(ano, mes)] = float (>=0)
        """
        meses_presentes: set[tuple[int,int]] = set()
        totais: dict[tuple[int,int], float] = {}

        if isinstance(meses_raw, dict):
            for rotulo, valor in meses_raw.items():
                dt = self.format_br.formatar_data_br(rotulo)
                if not dt:
                    continue
                key = (dt.year, dt.month)
                meses_presentes.add(key)
                v = self._valor_mes_total(valor)
                if v is not None:
                    totais[key] = v

        elif isinstance(meses_raw, list):
            for item in meses_raw:
                if isinstance(item, (list, tuple)) and len(item) >= 2:
                    rotulo, valor = item[0], item[1]
                    dt = self.format_br.formatar_data_br(str(rotulo))
                    if dt:
                        key = (dt.year, dt.month)
                        meses_presentes.add(key)
                        v = self._valor_mes_total(valor)
                        if v is not None:
                            totais[key] = v
                elif isinstance(item, dict):
                    rotulo = item.get("Mês:") or item.get("Mes:") or item.get("Mês") or item.get("Mes") or item.get("month") or item.get("Month") or ""
                    dt = self.format_br.formatar_data_br(str(rotulo))
                    if dt:
                        key = (dt.year, dt.month)
                        meses_presentes.add(key)
                        v = self._valor_mes_total(item)
                        if v is not None:
                            totais[key] = v
                else:
                    s = str(item)
                    label = s.split(":", 1)[0]  # pega só "Março 2022"
                    dt = self.format_br.formatar_data_br(label)
                    if dt:
                        key = (dt.year, dt.month)
                        meses_presentes.add(key)
                        v = self._valor_mes_total(s)  # soma "à vista" + "à prazo"
                        if v is not None:
                            totais[key] = v

        return meses_presentes, totais
