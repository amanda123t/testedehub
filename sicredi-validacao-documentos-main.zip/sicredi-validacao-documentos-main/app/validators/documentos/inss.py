from typing import List
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data

@registrar_validador("inss")
class ValidadorINSS(ValidadorBase):
    def validar(self) -> bool:
        self.log.info("Iniciando validação do INSS")
        # 1) nome do documento (se vier no JSON)
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de INSS encontrado.")
        resultados = []
        for doc in lista_docs:
            self.log.debug(f"Documento -> {doc}")
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            self.log.debug(f"Dados recebidos -> {doc}")
            recibos = self.extrair_valor(self.doc, False, "Recibo", "Recibos", "Recibo:", "Recibos:") or []
            if not recibos:
                recibos = [self.doc]
            self.log.debug(f"Recibos inss -> {recibos}")

            for recibo in recibos:
                self.doc = recibo
                self.log.debug(f"Doc atual -> {self.doc}")
                try:
                    status_doc = self.validar_inss_individual()
                except Exception as e:
                    self.log.error(f"Erro ao validar '{self.file}': {e}")
                    status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context,
                "dados_mua": getattr(self, "dados_mua", {})
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )

    def validar_inss_individual(self):
        self.dados_mua = {
            "periodo": "",
            "doc_origem": "",
            "tipo": "Efetivo",
            "campos": {}
        }
        self.nome_documento = (self.doc.get("Nome:") or self.doc.get("Nome") or "").strip()
        linhas: List[List[str]] = organize_data(self.doc, self.type_name)
        linhas = [["Documento lido:", self.file]] + linhas
        linhas.append([])
        linhas.append(["Campos no MUA:", ""])

        # --- período e valor ---
        periodo_raw = self.extrair_valor(
            self.doc, False, "Competência:", "Competencia:", "Período:", "Periodo:"
        )        
        dt_periodo = self.format_br.formatar_data_br(str(periodo_raw)) if periodo_raw else None
        self.periodo_documento = self.format_br.extrair_mes_ano(dt_periodo) if dt_periodo else ""

        valor_inss = self.extrair_valor(self.doc, True, "Valor:", "Valor", "valor:", "valor")
        self.log.debug(f"Valor do inss -> {valor_inss}")
        valor_inss_float = self.format_br.converter_valor_para_float(valor_inss)
        self.log.debug(f"Valor INSS float -> {valor_inss_float}")

        self.valor_documento = (
            self.format_br.formatar_moeda_br(valor_inss_float)
            if valor_inss_float is not None
            else ""
        )
        self.log.debug(f"Valor do inss BRL-> {valor_inss}")

        self.nome_empregador = self.extrair_valor(self.doc, "Fonte Pagadora:", "Fonte Pagadora", "fonte pagadora:", "fonte pagadora")
        # adiciona nas linhas exibidas
        linhas.append(["Período:", self.periodo_documento])
        linhas.append(["Valor:", self.valor_documento])

        # --- regras (planilha > fallback) ---
        regras = {}
        if getattr(self, "regras_mua", None):
            nomes_auto = ["inss", "extrato inss", "aposentadoria"]
            regras = self.regras_mua.get_doc(nomes_auto) # busca no Excel


        # --- 🔽 SALVAR DADOS MUA conforme regras ---
        doc_origem_regra = (regras.get("Documento Origem") or "Outros").strip()
        campo_regra = (regras.get("Campo") or "Aposentadoria/Pensões").strip()
        tipo_ocupacao_regra = (regras.get("Ocupação") or "Outros").strip()
        cargo_regra = (regras.get("Cargo") or "Aposentados e Beneficiários do INSS").strip()
        cargo_regra = cargo_regra.split('|')[1].strip() if "|" in cargo_regra else cargo_regra
        dados_ocupacao = {
            "tipo": tipo_ocupacao_regra,
            "cargo": campo_regra,
            "admissao": '',
            "nome_empregador": self.nome_empregador,
            "cnpj_empregador": ''
        }
        self.dados_mua = {
            "periodo": self.periodo_documento,
            "doc_origem": doc_origem_regra,
            "tipo": "Efetivo",
            "campos": {
                campo_regra: self.format_br.converter_valor_para_float(self.valor_documento) or 0.0
            },
            "ocupacao": dados_ocupacao
        }
        self.log.debug(f"Dados MUA gerados para INSS: {self.dados_mua}")


        # aplica as regras
        linhas.extend(self.exibir_regras_doc(regras))

        # resultado da validação de nome
        row = self._nome_validation_row()
        if row:
            linhas.append(row)

        self.sections.append(("INSS", linhas))
        self.log.info("Validação do INSS FINALIZADA.")
        return True