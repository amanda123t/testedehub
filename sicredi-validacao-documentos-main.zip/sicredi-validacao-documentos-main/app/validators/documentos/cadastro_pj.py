from typing import Any, List
import re
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import normalize, similar

@registrar_validador(
    "cadastro pj",
    "registration_pj",
    "cadastro pessoa juridica",
    "cadastro pessoa jurídica",
)
class ValidadorCadastroPJ(ValidadorBase):
    # ---------------------- utilidades locais ----------------------

    def _same_text(self, a: str | None, b: str | None) -> bool:
        return normalize(a or "") == normalize(b or "")

    def _normalizar_logradouro(self, s: str | None) -> str:
        """Remove prefixos tipo 'Rua', 'Av.', etc. e normaliza."""
        txt = normalize(s or "")
        # remove o primeiro token se for um tipo de via
        tipos = {"rua","avenida","av","travessa","estrada","rodovia","alameda","praca","praça","largo","vicinal","servidao","servidão"}
        partes = txt.split()
        if partes and partes[0] in tipos:
            partes = partes[1:]
        return " ".join(partes)

    def _comparar_cnae(self, cnae_cadastro: str | None, cnae_receita: str | None) -> bool:
        # cadastro pode vir "J6010100 - ATIVIDADES ..." ou só "6010100"
        cad = re.sub(r"\D", "", (cnae_cadastro or ""))
        rec = re.sub(r"\D", "", (cnae_receita or ""))
        return cad != "" and rec != "" and cad == rec
    
    def _clean_ampersand(self, s: str | None) -> str:
        """Remove '&' para comparar com o cadastro (o sistema não aceita '&')."""
        return re.sub(r"&+", "", (s or "")).strip()

    def _eq_or_sim(self, a: str | None, b: str | None, thr: float = 0.85) -> bool:
        a_n = normalize(a or "")
        b_n = normalize(b or "")
        if a_n == b_n:  # permite vazio == vazio
            return True
        try:
            return similar(a_n, b_n) >= thr
        except Exception:
            return False

    def _similarity(self, a: str | None, b: str | None) -> float:
        """Apenas retorna a similaridade (0..1) usando o helpers.similar."""
        return similar(normalize(a or ""), normalize(b or "")) or 0.0

    # ---------------------- principal ----------------------

    def validar(self) -> bool:
        self.log.info("Iniciando validação do Cadastro PJ")
        
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de cadastro PJ encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_cadastropj_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )

    def validar_cadastropj_individual(self):
        # 1) Nome do documento + validação de nome
        self.nome_documento = (self.doc.get("Nome:") or self.doc.get("Nome") or "").strip()

        # 2) Inspeção habilitada?
        if not getattr(self, "inspecao", True):
            self.log.info("🔕 Validação de Cadastro PJ ignorada (self.inspecao é False).")
            return True

        # 4) Captura dos dados do CADASTRO (do JSON)
        razao = (self.doc.get("Nome/Razão social:", "")
                 or self.doc.get("Razão Social:", "")
                 or self.doc.get("Razao Social:", "")
                 or self.doc.get("Nome:", "")
                 or "").strip()

        cnpj = (self.doc.get("CNPJ:", "")
                or self.doc.get("CNPJ", "")
                or "").strip()

        nome_fantasia = (self.doc.get("Nome fantasia:", "")
                         or self.doc.get("Nome Fantasia:", "")
                         or "").strip()

        cnae = (self.doc.get("CNAE:", "") or self.doc.get("CNAE", "") or "").strip()

        matriz = (self.doc.get("Matriz:", "") or "").strip()  # "Sim"/"Não" esperado

        natureza_juridica = (self.doc.get("Natureza Jurídica:", "")
                             or self.doc.get("Natureza Juridica:", "")
                             or "").strip()

        capital_social_str = (self.doc.get("Capital Social:", "")
                              or self.doc.get("Capital social:", "")
                              or "").strip()
        capital_social = self.format_br.converter_valor_para_float(capital_social_str)

        # Endereço (aceita formato aninhado "Endereço: { ... }" e chaves planas)
        end_tipo, end_logradouro, end_numero, end_bairro, end_uf = self._extrair_endereco_cadastro()

        # String bonitinha sem vírgulas/traços soltos
        endereco_cad = " ".join(x for x in [end_tipo, end_logradouro] if x).strip()
        if end_numero:
            endereco_cad += f", {end_numero}"
        sufixo = " - ".join(x for x in [end_bairro, end_uf] if x)
        if sufixo:
            endereco_cad += f" - {sufixo}"


        # 5) Busca dados da RECEITA
        dados_r = self.apis.buscar_dados_receita(cnpj)

        linhas: List[List[str]] = [["Documento lido:", self.file]]
        linhas.append([])

        if not dados_r:
            linhas.append(["Consulta Receita:", "✘ Erro ao consultar CNPJ na base da Receita ou retorno vazio"])
            # Ainda assim exibimos o cadastro e encerramos
            linhas.extend([
                ["Razão Social (cadastro):", razao],
                ["CNPJ (cadastro):", cnpj],
                ["Nome Fantasia (cadastro):", nome_fantasia],
                ["CNAE (cadastro):", cnae],
                ["Matriz (cadastro):", matriz],
                ["Natureza Jurídica (cadastro):", natureza_juridica],
                ["Capital Social (cadastro):", self.format_br.formatar_moeda_br(capital_social)],
                ["Endereço (cadastro):", f"{end_tipo} {end_logradouro}, {end_numero} - {end_bairro}/{end_uf}"],
            ])
            linhas.append([])
            row = self._nome_validation_row()
            if row:
                linhas.append(row)
            self.sections.append(("CADASTRO PJ", linhas))
            self.log.info("Validação do Cadastro PJ FINALIZADA.")
            return True

        # 6) Comparações: Cadastro × Receita
        comparacoes: List[List[str]] = []
        divergencias: List[str] = []

        def registrar_comparacao(rotulo: str, confere: bool, valor_cadastro: Any, valor_receita: Any, detalhe: str | None = None) -> None:
            """
            Registra o resultado de uma comparação entre o valor do Cadastro e o da Receita.

            - Se confere=True: adiciona linha "✔ Confere".
            - Se confere=False: adiciona linha "✘ Divergente" com detalhe (opcional) e
            os dois valores; também anota o rótulo em `divergencias`.
            """
            if confere:
                comparacoes.append([rotulo + ":", "✔ Confere"])
            else:
                msg = "✘ Divergente"
                if detalhe:
                    msg += f" — {detalhe}"
                msg += f" | Cadastro: {valor_cadastro} | Receita: {valor_receita}"
                comparacoes.append([rotulo + ":", msg])
                divergencias.append(rotulo)

        # Razão social
        # Razão social (remove '&' do lado da Receita)
        # Razão social
        razao_receita_raw = dados_r.get("nome")
        razao_receita_cmp = self._clean_ampersand(razao_receita_raw)
        razao_ok = self._eq_or_sim(razao, razao_receita_cmp, thr=0.85)
        detalhe = None if razao_ok else f"similaridade={self._similarity(razao, razao_receita_cmp):.2f} < 0.85"
        registrar_comparacao("Razão Social", razao_ok, razao, razao_receita_raw, detalhe=detalhe)


        registrar_comparacao(
            "Razão Social",
            razao_ok,
            razao, razao_receita_raw,
            detalhe=detalhe
        )

        # Nome Fantasia (remove '&' do lado da Receita)
        fantasia_receita_raw = dados_r.get("fantasia") or ""
        fantasia_receita_cmp = self._clean_ampersand(fantasia_receita_raw)

        fantasia_ok = self._eq_or_sim(nome_fantasia, fantasia_receita_cmp, thr=0.85)
        detalhe = None if fantasia_ok else f"similaridade={self._similarity(nome_fantasia, fantasia_receita_cmp):.2f} < 0.85"

        registrar_comparacao(
            "Nome Fantasia",
            fantasia_ok,
            nome_fantasia, fantasia_receita_raw,
            detalhe=detalhe
        )

        # CNPJ (somente dígitos)
        registrar_comparacao(
            "CNPJ",
            self.format_br.digits(cnpj) == self.format_br.digits(dados_r.get("cnpj", "")),
            cnpj, dados_r.get("cnpj")
        )

        # CNAE
        cnae_receita = ""
        ap = dados_r.get("atividade_principal") or []
        if ap and isinstance(ap, list) and ap[0].get("code"):
            cnae_receita = ap[0]["code"]
        registrar_comparacao(
            "CNAE (Código)",
            self._comparar_cnae(cnae, cnae_receita),
            cnae, cnae_receita
        )

        # Matriz
        cad_matriz = "sim" if normalize(matriz) == "sim" else "nao"
        rec_matriz = "sim" if normalize(dados_r.get("tipo", "")) == "matriz" else "nao"
        registrar_comparacao(
            "Matriz",
            cad_matriz == rec_matriz,
            matriz, dados_r.get("tipo")
        )

        # Natureza jurídica
        natureza_r_desc = (dados_r.get("natureza_juridica", "") or "")
        natureza_r_desc = natureza_r_desc.split(" - ", 1)[-1] if natureza_r_desc else ""
        registrar_comparacao(
            "Natureza Jurídica",
            self._same_text(natureza_juridica, natureza_r_desc),
            natureza_juridica, natureza_r_desc
        )

        # Capital social
        cap_receita = self.format_br.converter_valor_para_float(dados_r.get("capital_social"))
        cap_ok = (capital_social is not None and cap_receita is not None and abs(capital_social - cap_receita) <= 1.0)
        registrar_comparacao(
            "Capital Social",
            cap_ok,
            self.format_br.formatar_moeda_br(capital_social),
            self.format_br.formatar_moeda_br(cap_receita)
        )

        # Endereço - Número / UF / Bairro
        registrar_comparacao(
            "Endereço - Número",
            self._same_text(end_numero, str(dados_r.get("numero", ""))),
            end_numero, dados_r.get("numero")
        )
        registrar_comparacao(
            "Endereço - UF",
            self._same_text(end_uf, dados_r.get("uf")),
            end_uf, dados_r.get("uf")
        )
        registrar_comparacao(
            "Endereço - Bairro",
            self._same_text(end_bairro, dados_r.get("bairro")),
            end_bairro, dados_r.get("bairro")
        )

        # Endereço - Logradouro (similaridade)
        log_cad = self._normalizar_logradouro(end_logradouro)
        log_rec = self._normalizar_logradouro(dados_r.get("logradouro"))
        sim_ok = similar(log_cad, log_rec) >= 0.85
        registrar_comparacao(
            "Endereço - Logradouro",
            sim_ok,
            end_logradouro, dados_r.get("logradouro"),
            detalhe=None if sim_ok else "Logradouro divergente"
        )


        # --- Sócios (QSA) com similaridade ---
        qsa = dados_r.get("qsa") or []
        socios_receita_raw = [q.get("nome","") for q in qsa if q.get("nome")]
        socios_receita = [normalize(n) for n in socios_receita_raw]

        socios_cadastro_raw = self._extrair_socios_cadastro() or []
        socios_cadastro = [normalize(s) for s in socios_cadastro_raw]

        if socios_cadastro and socios_receita:
            set_cad, set_rec = set(socios_cadastro), set(socios_receita)
            # 1) exatos
            em_comum_exatos = set_cad & set_rec

            # 2) fuzzy (evita reutilizar o mesmo sócio de Receita em múltiplos matches)
            restantes_cad = [s for s in socios_cadastro if s not in em_comum_exatos]
            restantes_rec = [s for s in socios_receita if s not in em_comum_exatos]

            usados_rec = set()
            pares_fuzzy = []
            for sc in restantes_cad:
                melhor = None
                melhor_sim = 0.0
                for sr in restantes_rec:
                    if sr in usados_rec:
                        continue
                    sim = self._similarity(sc, sr)
                    if sim > melhor_sim:
                        melhor_sim = sim
                        melhor = sr
                if melhor and melhor_sim >= 0.85:
                    usados_rec.add(melhor)
                    pares_fuzzy.append((sc, melhor, melhor_sim))

            faltando = [s for s in restantes_cad if not any(p[0] == s for p in pares_fuzzy)]
            extras   = [s for s in restantes_rec if s not in usados_rec]

            if not faltando and not extras:
                if pares_fuzzy:
                    msg = "✔ Lista de sócios compatível (por similaridade)"
                else:
                    msg = "✔ Lista de sócios confere com a Receita"
                comparacoes.append(["Sócios:", msg])
            else:
                partes_msg = []
                if em_comum_exatos:
                    partes_msg.append(f"Exatos: {', '.join(sorted({s.title() for s in em_comum_exatos}))}")
                if pares_fuzzy:
                    parts = [f"{a.title()} ~ {b.title()} ({sim:.2f})" for a,b,sim in pares_fuzzy]
                    partes_msg.append("Fuzzy: " + ", ".join(parts))
                if faltando:
                    partes_msg.append("No cadastro e não na Receita: " + ", ".join(sorted({s.title() for s in faltando})))
                if extras:
                    partes_msg.append("Na Receita e não no cadastro: " + ", ".join(sorted({s.title() for s in extras})))

                comparacoes.append(["Sócios:", "✘ Divergente — " + " | ".join(partes_msg)])
                divergencias.append("Sócios")
        else:
            # quando um dos lados não tem sócios → usa função base
            ok, _ = self.apis.validar_associado_em_cnpj(cnpj, self.nome_documento)
            if ok:
                comparacoes.append(["Sócios / Empresarial:", f"✔ Encontrado no QSA"])
            else:
                comparacoes.append(["Sócios / Empresarial:", "✘ Não encontrado no QSA nem no Nome Empresarial"])
                divergencias.append("Sócios")



        # 7) Montagem final das linhas p/ PDF
        linhas.extend([
            ["Razão Social (cadastro):", razao],
            ["CNPJ (cadastro):", cnpj],
            ["Nome Fantasia (cadastro):", nome_fantasia],
            ["CNAE (cadastro):", cnae],
            ["Matriz (cadastro):", matriz],
            ["Natureza Jurídica (cadastro):", natureza_juridica],
            ["Capital Social (cadastro):", self.format_br.formatar_moeda_br(capital_social)],
            ["Endereço (cadastro):", endereco_cad],
            [],
            ["Comparação Cadastro × Receita:", ""],
        ])
        linhas.extend(comparacoes)

        if divergencias:
            linhas.append([])
            linhas.append(["Resumo:", f"✘ {len(divergencias)} divergência(s): {', '.join(divergencias)}"])
        else:
            linhas.append([])
            linhas.append(["Resumo:", "✔ Todos os dados conferem com a Receita"])

        linhas.append([])
        row = self._nome_validation_row()
        if row:
            linhas.append(row)

        self.sections.append(("CADASTRO PJ", linhas))
        self.log.info("Validação do Cadastro PJ FINALIZADA!")
        return True
    
    def _extrair_endereco_cadastro(self) -> tuple[str, str, str, str, str]:
        """
        Tenta extrair o endereço do JSON do cadastro, lidando com:
        - estrutura aninhada em 'Endereço:' (dict)
        - ou chaves planas (Endereço.Logradouro:, Logradouro:, etc.)
        Retorna: (tipo, logradouro, numero, bairro, uf)
        """
        def pick(d: dict, *keys: str) -> str:
            for k in keys:
                v = d.get(k)
                if v is not None and str(v).strip():
                    return str(v).strip()
            return ""

        end = (
            self.doc.get("Endereço:")
            or self.doc.get("Endereço")
            or self.doc.get("Endereco:")
            or self.doc.get("Endereco")
        )
        if isinstance(end, dict):
            end_tipo       = pick(end, "Tipo:", "Tipo")
            end_logradouro = pick(end, "Logradouro:", "Logradouro")
            end_numero     = pick(end, "Número:", "Numero:", "Número", "Numero")
            end_bairro     = pick(end, "Bairro:", "Bairro")
            end_uf         = pick(end, "UF:", "Uf:", "UF")
            return end_tipo, end_logradouro, end_numero, end_bairro, end_uf

        # fallback (chaves planas)
        d = self.doc
        end_tipo       = pick(d, "Endereço.Tipo:", "Endereço - Tipo:", "Tipo:", "Tipo")
        end_logradouro = pick(d, "Endereço.Logradouro:", "Endereço - Logradouro:", "Logradouro:", "Logradouro")
        end_numero     = pick(d, "Endereço.Número:", "Endereço - Número:", "Número:", "Numero:", "Número", "Numero")
        end_bairro     = pick(d, "Endereço.Bairro:", "Endereço - Bairro:", "Bairro:", "Bairro")
        end_uf         = pick(d, "Endereço.UF:", "Endereço - UF:", "UF:", "Uf", "UF")
        return end_tipo, end_logradouro, end_numero, end_bairro, end_uf

    def _extrair_socios_cadastro(self) -> list[str]:
        """
        Aceita Tanto 'Sócios:'/'Socios:' quanto 'Cotistas:' (lista de dicts ou string).
        Retorna nomes normalizados.
        """
        raw = (
            self.doc.get("Sócios:")
            or self.doc.get("Socios:")
            or self.doc.get("Cotistas:")
            or self.doc.get("QSA:")
            or ""
        )

        nomes: list[str] = []
        if isinstance(raw, list):
            for it in raw:
                if isinstance(it, dict):
                    nm = (
                        it.get("Nome Sócio:")
                        or it.get("Nome Socio:")
                        or it.get("Nome:")
                        or it.get("Nome")
                        or ""
                    )
                    nm = nm.strip()
                    if nm:
                        nomes.append(normalize(nm))
        elif isinstance(raw, str):
            for parte in re.split(r"[;\n,]+", raw):
                parte = parte.strip()
                if parte:
                    nomes.append(normalize(parte))
        return nomes
