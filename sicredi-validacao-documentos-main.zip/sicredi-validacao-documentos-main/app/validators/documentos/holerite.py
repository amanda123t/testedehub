import re
from datetime import datetime 
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data, normalize, normalize_no_space,similar
from app.utils.format_br import formatar_cnpj
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime, date
from calendar import monthrange
from app.utils.folha_fiscal import FolhaFiscal          # <- cálculo de INSS/IR

# feriados nacionais a considerar (apapenas DD/MES, ano é irrelevante, ex: 01/01 = 1º de janeiro de qualquer ano)
FERIADOS_NACIONAIS_2025 = (
    "01/01",
    "21/04",
    "01/05",
    "07/09",
    "12/10",
    "02/11",
    "15/11",
    "25/12",
)

estados = [
    {"nome": "Governo do Estado do Acre", "uf": "AC", "cnpj": "63.606.479/0001-24"},
    {"nome": "Governo do Estado de Alagoas", "uf": "AL", "cnpj": "12.200.176/0001-76"},
    {"nome": "Governo do Estado do Amazonas", "uf": "AM", "cnpj": "04.312.369/0001-90"},
    {"nome": "Governo do Estado do Amapá", "uf": "AP", "cnpj": "00.394.577/0001-25"},
    {"nome": "Governo do Estado da Bahia", "uf": "BA", "cnpj": "13.937.032/0001-60"},
    {"nome": "Governo do Estado do Ceará", "uf": "CE", "cnpj": "07.954.480/0001-79"},
    {"nome": "Governo do Distrito Federal", "uf": "DF", "cnpj": "00.394.601/0001-26"},
    {"nome": "Governo do Estado do Espírito Santo", "uf": "ES", "cnpj": "27.080.530/0001-43"},
    {"nome": "Governo do Estado de Goiás", "uf": "GO", "cnpj": "01.409.580/0001-38"},
    {"nome": "Governo do Estado do Maranhão", "uf": "MA", "cnpj": "06.354.468/0001-60"},
    {"nome": "Governo do Estado de Minas Gerais", "uf": "MG", "cnpj": "18.715.615/0001-60"},
    {"nome": "Governo do Estado do Mato Grosso do Sul", "uf": "MS", "cnpj": "15.412.257/0001-28"},
    {"nome": "Governo do Estado do Mato Grosso", "uf": "MT", "cnpj": "03.507.415/0001-44"},
    {"nome": "Governo do Estado do Pará", "uf": "PA", "cnpj": "05.054.861/0001-76"},
    {"nome": "Governo do Estado da Paraíba", "uf": "PB", "cnpj": "08.761.124/0001-00"},
    {"nome": "Governo do Estado de Pernambuco", "uf": "PE", "cnpj": "10.571.982/0001-25"},
    {"nome": "Governo do Estado do Piauí", "uf": "PI", "cnpj": "06.553.481/0001-49"},
    {"nome": "Governo do Estado do Paraná", "uf": "PR", "cnpj": "76.416.940/0001-28"},
    {"nome": "Governo do Estado do Rio de Janeiro", "uf": "RJ", "cnpj": "42.498.600/0001-71"},
    {"nome": "Governo do Estado do Rio Grande do Norte", "uf": "RN", "cnpj": "08.241.739/0001-05"},
    {"nome": "Governo do Estado de Rondônia", "uf": "RO", "cnpj": "00.394.585/0001-71"},
    {"nome": "Governo do Estado de Roraima", "uf": "RR", "cnpj": "84.012.012/0001-26"},
    {"nome": "Governo do Estado do Rio Grande do Sul", "uf": "RS", "cnpj": "87.934.675/0001-96"},
    {"nome": "Governo do Estado de Santa Catarina", "uf": "SC", "cnpj": "82.951.229/0001-76"},
    {"nome": "Governo do Estado de Sergipe", "uf": "SE", "cnpj": "13.128.798/0001-01"},
    {"nome": "Governo do Estado de São Paulo", "uf": "SP", "cnpj": "46.379.400/0001-50"},
    {"nome": "Governo do Estado do Tocantins", "uf": "TO", "cnpj": "01.786.029/0001-03"},
]


@registrar_validador("holerite", "comprovante de renda", "paycheck")

class ValidadorHolerite(ValidadorBase):
    def validar(self) -> bool:
        self.log.info("Iniciando validação dos Holerites")
        self.log.debug(f"Dados recebidos para validação dos holerites {self.data}")
        self._exibir_no_pdf = True

        # variáveis de configuração vindas da planilha de regras---
        cfg = getattr(self, "comprovantes", None)

        # salva como atributos para usar em outros pontos
        self.exibir_descontos = self.to_bool(
            getattr(cfg, "exibir_descontos", False)
        )
        self.exibir_apenas_ultimo = self.to_bool(
            getattr(cfg, "exibir_apenas_ultimo", True)
        )
        self.feriados = getattr(cfg, "feriados", None)  # pode vir None das regras

        self.aceitar_sempre_mes_atual = self.to_bool(
            getattr(cfg, "aceitar_sempre_mes_atual", False)
        )
        
        self.aviso_sobre_mes_atual = getattr(cfg, "aviso_sobre_mes_atual", None)
    
        self.considerar_itens_por_lei = self.to_bool(
            getattr(cfg, "considerar_itens_por_lei", True)
        )
        self.deve_vir_3_para_media = self.to_bool(getattr(cfg, "deve_vir_3_para_media", True)) is not False
        self.log.debug("verificando feriados...")
        # fixos (DD/MM) -> para qualquer ano
        feriados_fixos_dm: set[tuple[int, int]] = set()
        for dm in FERIADOS_NACIONAIS_2025:
            dm = re.sub(r"[^\d/]", "", dm or "")
            m = re.match(r"^(\d{1,2})/(\d{1,2})$", dm)
            if m:
                d, mo = m.groups()
                feriados_fixos_dm.add((int(d), int(mo)))

        # absolutos (DD/MM/AAAA) vindos da planilha -> mantém o nome feriados_set
        feriados_set: set[date] = set()
        for f in (getattr(self, "feriados", []) or []):
            if isinstance(f, datetime):
                feriados_set.add(f.date())
            elif isinstance(f, date):
                feriados_set.add(f)
            elif isinstance(f, str):
                dt = self.format_br.formatar_data_br(f)  # entende DD/MM/AAAA
                if dt:
                    feriados_set.add(dt.date())

        # --- Novo formato da lista (cada item tem dados/context/arquivo)
        lista_docs = self.lista
        self.log.debug(f"Lista recebida: {lista_docs}")
        # Extrai o conteúdo base (dados, context, arquivo)
        holerites = []
        for d in lista_docs:
            dados = d.get("dados") or {}
            context = d.get("context")
            arquivo = d.get("arquivo")

            # Se dentro de 'dados' houver uma chave "Holerites" (lista interna),
            # cria um item separado para cada holerite encontrado
            if isinstance(dados, dict) and "Holerites" in dados:
                for h in (dados.get("Holerites") or []):
                    if isinstance(h, dict):
                        holerites.append({
                            "dados": h,
                            "context": context,
                            "arquivo": arquivo
                        })
            else:
                holerites.append({
                    "dados": dados,
                    "context": context,
                    "arquivo": arquivo
                })
        lista_docs = holerites
        holerites = [d.get("dados") or {} for d in lista_docs]

        self.log.debug(f"Holerites ajustados: {holerites}")
        if holerites and isinstance(holerites, list):
            self.nome_documento = (holerites[0].get("Nome:") or holerites[0].get("Nome") or "").strip()
        else:
            self.nome_documento = ""

        if not holerites:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de Holerite encontrado.")
        

        self.log.debug("Configurando listas...")

        # Configurações / listas
        self.NAO_ENTRA, self.ENTRA_COM_3, self.ENTRA_COM_1, sem_itens_cfg = self._config_listas()

        self.log.debug(f"Listas configuradas: ENTRA_EM_1: {self.ENTRA_COM_1} | ENTRA_EM_3: {self.ENTRA_COM_3} | NAO ENTRA: {self.NAO_ENTRA} | considerar por lei? {self.considerar_itens_por_lei}")
        # Limite de meses para o holerite mais recente aceito
        limite = getattr(cfg, "limite_meses_holerite", None)  # pode vir None das regras

        #Captura o ano e mês atual
        ano_atual, mes_atual = self.format_br.obter_ano_mes_atual()

        # --- Data de virada do mês (corte) ---
        hoje = datetime.now().date()
        corte_raw = getattr(cfg, "data_virada_mes_holerite", None)
        try:
            corte_dia = int(corte_raw) if corte_raw not in (None, "", 0) else None
        except Exception:
            corte_dia = None

        data_corte_dt = None
        data_corte_str = ""
        if corte_dia:
            last_day = monthrange(hoje.year, hoje.month)[1]
            corte_eff = min(max(1, corte_dia), last_day)
            data_corte_dt = date(hoje.year, hoje.month, corte_eff)
            data_corte_str = data_corte_dt.strftime('%d/%m/%Y')

        # Agrupa por CNPJ
        grupos = self.agrupar_por_cnpj(holerites)
        resultados = []
        # ⚖️ Escolhe regras específicas para parecer e ocupação
        nomes_auto_holerite = ["holerite", "contracheque", "contra-cheque", "paycheck"]
        nomes_auto_prolabore = ["pro-labore","prolabore","pro labore","pró labore", "pró-labore", "prólabore"]

        # Processa por CNPJ → um bloco por CNPJ (para caso o associado tenha dois empregos/2 cnpjs diferentes da mesma pessoa)
        for cnpj_norm, lista in grupos.items():
            self.log.debug(f"Iniciando validação dos holerites do cnpj {cnpj_norm}...")
            status = True
            # 1) Ordena os holerites por competência (ano, mês), do mais recente para o mais antigo.
            holerites_ordenados = sorted(
                lista,
                key=lambda hol: (hol["_comp_tuple"][0], hol["_comp_tuple"][1]),  # (ano, mês)
                reverse=True  # mais recente primeiro
            )

            # 2) Indexa por competência: (ano, mês) -> holerite correspondente.
            #    Observação: como a lista está do mais recente para o mais antigo, se houver
            #    duplicatas no mesmo mês, ficamos com o *primeiro* encontrado (o mais recente).
            # 2) Indexa por competência: (ano, mês) -> lista de holerites do mês
            index_por_competencia: Dict[Tuple[int, int], List[Dict[str, Any]]] = {}
            for holerite in holerites_ordenados:
                ano, mes = holerite.get("_comp_tuple", (0, 0))
                if not ano or not mes:
                    continue
                index_por_competencia.setdefault((ano, mes), []).append(holerite)

            # 3) Escolhe o holerite principal (de maior salário total) para exibir
            # --- NOVO BLOCO: exibe todos os holerites, mas sem duplicar o principal do mês ---
            holerites_para_exibir = []
            for (ano, mes), hols in sorted(index_por_competencia.items(), key=lambda kv: kv[0], reverse=True):
                # define o principal (maior salário total)
                principal = max(
                    hols,
                    key=lambda h: self.format_br.converter_valor_para_float(
                        h.get("Salário Total:") or h.get("Salario Total") or 0
                    )
                )

                # adiciona o principal primeiro (mais recente)
                holerites_para_exibir.append(principal)

                # adiciona os outros do mesmo mês (ex.: comissão, complemento etc.)
                for h in hols:
                    if h is not principal:
                        holerites_para_exibir.append(h)



            # 3) um único loop para exibir/validar todos (ou só o primeiro)
            for i, pc_exibir in enumerate(holerites_para_exibir):
                self.dados_mua = {
                    "periodo": "",
                    "doc_origem": "",
                    "tipo": "Efetivo",
                    "campos": {}
                }
                campos_mua = {"Aposentadoria/Pensões": 0.0, "Salário Líquido": 0.0, "Gratificações e Comissões": 0.0, "Locações e Arrendamento": 0.0, "Pró-labore/Part. Societárias": 0.0, "Rendas Agropecuárias": 0.0, "Outros": 0.0}

                original = next(
                    (item for item in lista_docs if item.get("dados") == pc_exibir), {}
                )
                self.doc = self.extrair_valor(original, False, "dados", "dados:")
                self.context = self.extrair_valor(original, False, "context", "context:")
                self.file = self.extrair_valor(original, False, "arquivo", "arquivo:")

                # =======================================================
                # 🔍 DETECÇÃO DE PRÓ-LABORE (CONTRACHEQUE)
                # =======================================================

                # tenta pegar CNPJ e nome para verificar QSA
                cnpj_para_checar = self.format_br.digits(
                    pc_exibir.get("CNPJ:") or pc_exibir.get("CNPJ") or ""
                )
                nome_associado = (self.nome_documento or "").strip()
                eh_socio_qsa = False

                if cnpj_para_checar and nome_associado:
                    try:
                        eh_socio_qsa, dados_r = self.apis.validar_associado_em_cnpj(
                            cnpj_para_checar, nome_associado
                        )
                    except Exception:
                        eh_socio_qsa = False

                # busca se há item "Pró-Labore" nos Itens de Salário
                itens_salario = self.extrair_valor(
                    pc_exibir, False,
                    "Itens de Salário:", "Itens de Salario:", "Itens de salário", "Itens de Salario"
                ) or []
                tem_item_prolabore = False
                if itens_salario:
                    tem_item_prolabore = any(
                        "PROLABORE" in normalize_no_space(item.get("Nome", "") or "").replace("-","").upper()
                        for item in itens_salario
                    )
                
                salario_base = self.extrair_valor(
                    pc_exibir, False,
                    "Salário Base:", "Salário Base", "Salario Base", "Salario base"
                )

                if salario_base:
                    salario_base_float = self.format_br.converter_valor_para_float(str(salario_base)) or 0.0
                else:
                    salario_base_float = 0
                eh_prolabore = False
                # define se é pró-labore
                eh_prolabore = eh_socio_qsa or tem_item_prolabore
                # bloco base (decide se irá exibir os descontos ou não conforme marcado nas regras)
                if self.exibir_descontos:
                    base = {k: v for k, v in pc_exibir.items() if not str(k).startswith("_")}
                else:
                    base = {k: v for k, v in pc_exibir.items()
                            if k not in ("Descontos:", "Descontos") and not str(k).startswith("_")}

                linhas = [["Documento lido:", self.file]]
                linhas.append(["Documentos enviados:", len(holerites_ordenados)])
                linhas += organize_data(base, self.type_name)
                valor_float = 0.0
                if eh_prolabore:
                    f_validar_qsa      = self.to_bool(getattr(self.comprovantes, "validar_socio_qsa_prolabore", None)) is not False
                    if f_validar_qsa:
                        if eh_socio_qsa:
                            linhas.append(["✔ Associado encontrado no QSA da empresa."])
                        elif tem_item_prolabore:
                            linhas.append(["✘ O associado não consta no QSA, porém consta item de Pró-Labore no documento."])
                        else:
                            linhas.append(["✘ Documento identificado como Pró-Labore, mas sem confirmação no QSA."])

                    # Captura valor do pró-labore (ou salário base como fallback)
                    for item in itens_salario:
                        nome_item = normalize_no_space(str(item.get("Nome", ""))).upper()
                        if "PROLABORE" in nome_item or "PRO LABORE" in nome_item:
                            valor_float = self.format_br.converter_valor_para_float(
                                str(item.get("Valor:", "0")).strip()
                            ) or 0.0
                            break

                    if not valor_float:
                        valor_float = salario_base_float
                    limite_darf = getattr(self.comprovantes, "limite_darf", 0)
                    limite_darf = self.format_br.converter_valor_para_float(limite_darf) if limite_darf else 0
                    if isinstance(valor_float, (int, float)) and valor_float > 0 and isinstance(limite_darf, (int, float)) and limite_darf > 0:
                        if valor_float > limite_darf:
                            linhas.append([f"✘ Necessário vir a darf, valor acima do limite de {self.format_br.formatar_moeda_br(limite_darf)}."])
                        else:
                            linhas.append([f"✔ Não é necessário vir a darf, valor menor que o limite de {self.format_br.formatar_moeda_br(limite_darf)}."])
                    elif isinstance(limite_darf, (int, float)) and limite_darf > 0:
                        linhas.append([f"✘ Limite para darf configurado mas valor total não encontrado, se o total for maior que {self.format_br.formatar_moeda_br(limite_darf)} será necessário o envio da DARF!."])
                    elif isinstance(valor_float, (int, float)) and valor_float > 0:
                        linhas.append([f"✔ Sem limites definidos para o envio da DARF!"])
                    # força o valor do documento e zera média
                    self.media_holerite = "R$ 0,00"
                    nome_tipo = 'Pró-Labore'
                    # ajusta campos MUA
                    campos_mua["Pró-labore/Part. Societárias"] = valor_float
                    campos_mua["Salário Líquido"] = 0.0
                    campos_mua["Gratificações e Comissões"] = 0.0
                else:
                    # soma todos os holerites da mesma competência
                    meses_iguais = index_por_competencia.get(pc_exibir["_comp_tuple"], [])
                    if len(meses_iguais) > 1:
                        soma_mes = sum(self.calcular_salario_liquido_mes(h) for h in meses_iguais)
                        valor_float = soma_mes
                    else:
                        valor_float = self.calcular_salario_liquido_mes(pc_exibir)
                    self.log.debug(f"Salário líquido: {valor_float}")
                    nome_tipo = 'Holerite'
                # =======================================================
                # 🔚 (segue fluxo normal do holerite abaixo)
                # =======================================================
                # É o holerite âncora (mais recente)? Só ele exibe/calcúla média.
                is_mais_recente = (i == 0)
                self.valor_documento = self.format_br.formatar_moeda_br(valor_float)
                # VALIDAÇÃO DOS DESCONTOS:
                descontos_map = self.extrair_valor(pc_exibir, False, "Descontos:", "Descontos", "descontos:", "descontos")
                valor_total_descontos = 0
                desconto_inss = {}
                desconto_irpf = {}

                if descontos_map:
                    gatilhos_inss = [normalize_no_space(item) for item in [
                        "inss", "i.n.s.s", "inss empregador", "i.n.s.s empregador"
                    ]]
                    gatilhos_irpf = [normalize_no_space(item) for item in [
                        "irpf", "irrf", "i.r.p.f", "i.r.r.f", "imposto de renda",
                        "i.renda", "irrf empregador", "irpf empregador",
                        "imposto de renda empregador"
                    ]]

                    for desconto in descontos_map:
                        nome_desconto = self.extrair_valor(desconto, False, "Nome", "Nome:", "nome", "nome:") or ""
                        nome_norm = normalize_no_space(nome_desconto)

                        # verifica se algum gatilho está contido no nome ou vice-versa
                        for gatilho in gatilhos_inss:
                            if gatilho in nome_norm or nome_norm in gatilho:
                                desconto_inss = desconto
                                break
                        for gatilho in gatilhos_irpf:
                            if gatilho in nome_norm or nome_norm in gatilho:
                                desconto_irpf = desconto
                                break

                        valor_desconto = self.extrair_valor(desconto, True, "Valor:", "Valor", "valor:", "valor") or 0
                        valor_total_descontos += abs(self.format_br.converter_valor_para_float(valor_desconto))
                else:
                    linhas.append([f"✘ Nenhum desconto foi encontrado no {nome_tipo}."])
                    self.log.debug(f"status false, Sem descontos no contraqueche")
                    status = False

                if valor_total_descontos == 0:
                    status = False
                    self.log.debug(f"status false, Sem descontos no contraqueche")

                salario_total = self.extrair_valor(pc_exibir, True, "Salário Total:", "Salário Total", "Salario Total:", "Salario Total")
                salario_total_float = self.format_br.converter_valor_para_float(salario_total)
                desconto_irpf_ok = False
                desconto_inss_ok = False
                valor_desconto_irpf = 0
                valor_desconto_inss = 0
                desconto_irpf_invalido = False
                faixas = [0.075, 0.15, 0.225, 0.275]
                valores = [valor_float, salario_total_float, salario_base_float]
                valor_candidatos = []
                for valor in valores:
                    for faixa in faixas:
                        try:
                            valor_faixa = valor * faixa
                            valor_candidatos.append(valor_faixa)
                        except Exception:
                            pass
                tipo_associado = "socio" if eh_prolabore else "empregado"
                if desconto_inss or desconto_irpf:
                    if desconto_inss:
                        valor_desconto_inss = self.extrair_valor(desconto_inss, True, "Valor:", "Valor", "valor:", "valor") or 0
                        valor_desconto_inss = self.format_br.converter_valor_para_float(valor_desconto_inss)
                    if desconto_irpf:
                        valor_desconto_irpf = self.extrair_valor(desconto_irpf, True, "Valor:", "Valor", "valor:", "valor") or 0
                        valor_desconto_irpf = self.format_br.converter_valor_para_float(valor_desconto_irpf)
                    if desconto_irpf and valor_desconto_irpf > 0:                
                        for valor_can in valor_candidatos:
                            dif = abs(valor_can - valor_desconto_irpf)
                            if dif <= 1:
                                linhas.append([f"✘ Desconto do IRPF inválido, cálculo não abateu o valor do INSS, verificar!"])
                                desconto_irpf_invalido = True
                                break
                    for valor in valores:
                        if isinstance(valor, (int,float)) and valor >0:
                            r = FolhaFiscal.calcular_inss_e_irrf(valor, 0, 0, tipo_associado)
                            valor_inss, valor_irpf_simplificado, valor_irpf_tradicional = r['INSS'], r['IRRF_simplificado'], r['IRRF_tradicional']
                            if isinstance(valor_inss, (float,int)) and (valor_inss == valor_desconto_inss or valor_inss> valor_desconto_inss or abs(valor_inss - valor_desconto_inss) <= (0.3 * valor_inss)):
                                desconto_inss_ok = True
                                linhas.append([f"✔ Valor do desconto do INSS compatível!"])
                                break
                            if not desconto_irpf_invalido:
                                if isinstance(valor_irpf_simplificado, (float,int)) and (valor_irpf_simplificado == valor_desconto_irpf or valor_irpf_simplificado> valor_desconto_irpf or abs(valor_irpf_simplificado - valor_desconto_irpf) <= (0.3 * valor_irpf_simplificado)):
                                    desconto_irpf_ok = True
                                    linhas.append([f"✔ Valor do desconto do IRRF compatível!"])
                                    break
                                if isinstance(valor_irpf_tradicional, (float,int)) and (valor_irpf_tradicional == valor_desconto_irpf or valor_irpf_tradicional> valor_desconto_irpf or abs(valor_irpf_tradicional - valor_desconto_irpf) <= (0.3 * valor_irpf_tradicional)):
                                    desconto_irpf_ok = True
                                    linhas.append([f"✔ Valor do desconto do IRRF compatível!"])
                                    break
                    if desconto_inss_ok or desconto_irpf_ok:
                        # pelo menos um bateu -> ok, não precisa gerar erro genérico
                        pass
                    else:
                        self.log.debug(f"status false, descontos não bateram")

                        status = False
                        if not desconto_irpf_ok and not desconto_inss_ok:
                            linhas.append([f"✘ Descontos de IRPF e INSS inválidos para o valor do {nome_tipo}, verificar!"])
                        elif not desconto_irpf_ok and not desconto_irpf_invalido:
                            linhas.append([f"✘ Desconto do IRPF incompatível com o valor do {nome_tipo}, verificar!"])
                        elif not desconto_inss_ok:
                            linhas.append([f"✘ Desconto do INSS incompatível com o valor do {nome_tipo}, verificar!"])

                elif not desconto_inss and not desconto_irpf:
                    self.log.debug(f"status false, descontos IRPF e INSS não encontrados")
                    status = False
                    linhas.append([f"✘ Nenhum desconto(IRRF e INSS) encontrado no {nome_tipo}, verificar!"])
                # Competência (ano, mês) do holerite atual; (0,0) quando ausente.
                ano_competencia, mes_competencia = pc_exibir.get("_comp_tuple", (0, 0))
                tem_competencia = bool(ano_competencia and mes_competencia)

                # Rótulo amigável para exibir a competência (MM/AAAA) ou mensagem padrão.
                self.periodo_documento = (
                    f"{mes_competencia:02d}/{ano_competencia}"
                    if tem_competencia else "(competência não identificada)"
                )

                # Exibe a validação do Nome caso tenha o nome no processo(apenas para rpas que conseguem capturar os dados do processo)
                row = self._nome_validation_row()
                if row:
                    linhas.append(row)
                self.log.debug("Configurando variaveis(empregador, cargo, cbo, etc)...")
                # Empregador/CNPJ/Cargo/CBO tirados do próprio pc_exibir
                self.nome_empregador = self.extrair_valor(pc_exibir, False, 'Instituição:', 'Instituição', 'Instituicao:', 'Instituicao') or ''
                self.cnpj_empregador = self.extrair_valor(pc_exibir, False, 'CNPJ:', 'CNPJ', 'cnpj:', 'cnpj')
                self.cnpj_empregador = self.format_br.digits(self.cnpj_empregador) or "SEM CNPJ"
                self.cargo = self.extrair_valor(pc_exibir, False, 'Cargo:', 'Cargo', 'cargo:', 'cargo') or ""
                self.cbo = self.extrair_valor(pc_exibir, False, 'cbo:', 'cbo', 'CBO:', 'CBO') or ""
                governo_do_estado = {}
                if (not self.cnpj_empregador or self.cnpj_empregador == "SEM CNPJ") and self.nome_empregador:
                    for estado in estados:
                        nome_est = estado["nome"]
                        cnpj_est = estado["cnpj"]
                        if similar(normalize(nome_est), normalize(self.nome_empregador)) > 0.9:
                            governo_do_estado = estado
                            self.cnpj_empregador = self.format_br.digits(cnpj_est)
                            linhas.append([f"✔ Não foi identificado o CNPJ no documento, usando o CNPJ do '{nome_est.upper()}' como referência: {formatar_cnpj(cnpj_est)}"])
                            break
                        
                if eh_prolabore:
                    if not self.cargo and not self.cbo:
                        self.cargo = "Diretor Geral de Empresa e organizações"
                        self.cbo = '121010'
                    elif not self.cbo:
                        self.cbo = "SEM CBO"
                    elif not self.cargo:
                        self.cargo = "SEM CARGO"

                self.log.debug("Validando CNPJ na receita...")

                # Validação CNPJ (Receita)
                if self.cnpj_empregador and self.cnpj_empregador != "SEM CNPJ":
                    # ----------- VALIDAÇÃO VALOR COM O PORTE NA RECEITA 
                    porte_receita = self.apis.capturar_porte_receita(self.cnpj_empregador)
                    if porte_receita:
                        limites_por_porte = getattr(getattr(self, "comprovantes", None), "limites_por_porte", None)
                        limite_faturamento = None

                        if isinstance(limites_por_porte, dict) and porte_receita:
                            limite_faturamento = limites_por_porte.get(porte_receita)

                            # fallback: se não existir limite específico para MEI CAMINHONEIRO, usa MEI
                            if limite_faturamento is None and porte_receita == "MEI CAMINHONEIRO":
                                limite_faturamento = limites_por_porte.get("MEI")

                            try:
                                limite_faturamento = float(limite_faturamento)
                            except Exception:
                                limite_faturamento = None
                        
                        # Verifica se o valor mensal está acima do limite mensal do faturamento do empregador. (se o empregador não pode FATURAR acima de X no mês, impossível um pró labore(lucro) ser maior que isso, indício de fraude)
                        if limite_faturamento and valor_float > 0:
                            limite_faturamento_mensal = limite_faturamento / 12
                            if valor_float > limite_faturamento_mensal:
                                linhas.append([f"✘ Valor do {nome_tipo} está acima do limite mensal de faturamento({self.format_br.formatar_moeda_br(limite_faturamento_mensal)}) para o porte {porte_receita}, verificar!"])
                            #Se não estiver acima do limite, mas estiver muito próximo (80% do limite) informa. (exceto para mei que tende a ter pro-labore sempre igual/proximo ao limite)
                            elif valor_float > (limite_faturamento_mensal * 0.8) and not "MEI" in str(porte_receita).upper():
                                linhas.append([f"✘ Valor do {nome_tipo} está muito próximo do limite mensal de faturamento({self.format_br.formatar_moeda_br(limite_faturamento_mensal)}) para o porte {porte_receita}, verificar!"])
                            else:
                                linhas.append([f"✔ Valor do {nome_tipo} está compatível com o porte {str(porte_receita).upper()} do CNPJ."])
                    linhas.append(self.apis.validar_situacao_cnpj(self.cnpj_empregador))
                else:
                    linhas.append([ "✘ CNPJ não encontrado no documento"])
                    status = False
                    self.log.debug(f"status false, cnpj não encontrado no documento")

                

                

                self.log.debug("Validando data de admissão...")

                # Validação admissão
                data_admissao_obrigatoria = self.to_bool(getattr(self.comprovantes, "obrigatorio_data_admissao", False)) is True
                data_admissao = pc_exibir.get("Desde Quando na Função:") or pc_exibir.get("Desde quando na função:") or ""
                data_admissao_formatada = self.format_br.formatar_data_br(data_admissao)
                if not data_admissao:
                    if data_admissao_obrigatoria:
                        linhas.append(["✘ Data de admissão não encontrada no documento, verificar!"])
                    else:
                        linhas.append(["Data de admissão não informada no documento"])
                    status = False
                    self.log.debug(f"status false, data não informada")

                elif not data_admissao_formatada:
                    linhas.append(["✘ Data de admissão inválida (inexistente ou formato incorreto)"])
                    status = False
                    self.log.debug(f"status false, data invalida")

                else:
                    DOMINGO = 6
                    eh_domingo = (data_admissao_formatada.weekday() == DOMINGO)
                    dia = data_admissao_formatada.date()
                    dm_tuple = (dia.day, dia.month)
                    eh_feriado = (dm_tuple in feriados_fixos_dm) or (dia in feriados_set)
                    if eh_domingo:
                        linhas.append([ "✘ Data de admissão cai em um DOMINGO"])
                    if eh_feriado:
                        linhas.append([ f"✘ Data de admissão cai em um FERIADO NACIONAL!"])
                    if not eh_domingo and not eh_feriado:
                        linhas.append([ "✔ Data de admissão OK (não é domingo/feriado)"])

                # Validação competência/limite
                self.log.debug("Validando Competência...")

                if ano_competencia == 0 or mes_competencia == 0:
                    status = False
                    self.log.debug(f"Status false, competencia nao identificada")

                    linhas.append([  "✘ Competência não identificada"])
                else:
                    diff = self.format_br.calcular_meses_entre(ano_atual, mes_atual, ano_competencia, mes_competencia)

                    if diff < 0:
                        # mês futuro (sempre inválido)
                        status = False
                        self.log.debug(f"Status false, competencia futura")
                        linhas.append([  f"✘ Competência futura ({self.periodo_documento})"])
                    elif diff == 0: 
                        if self.aceitar_sempre_mes_atual:
                            linhas.append([  f"✔ Mês atual aceito."])
                            if self.aviso_sobre_mes_atual:
                                linhas.append(["Aviso Sobre mês Atual:", self.aviso_sobre_mes_atual])
                        else:
                            if data_corte_dt:
                                # mês atual com data de corte configurada
                                if hoje >= data_corte_dt:
                                    # após a data de corte → permitido (mantendo regra de limite igual)
                                    linhas.append([  f"✔ Mês atual aceito (após data de corte {data_corte_str})."])
                                else:
                                    # antes da data de corte → tratar como 'futuro'
                                    linhas.append([  f"✘ Documento do mês atual ANTES da data de corte ({data_corte_str})"])
                            else:
                                #Holerite do mes atual mas sem data de corte definido na planilha de regras
                                linhas.append([  f"✔ Documento do mês atual e sem data de corte definido nas regras"])

                    else:
                        # comportamento padrão (inclusive diff==0 quando não há data de corte configurada)
                        if limite is None or (isinstance(limite, str) and not str(limite).strip()):
                            linhas.append([  "✔ Sem limite de meses configurado nas regras (validação de vencimento não aplicada)"])
                        else:
                            if diff <= limite:
                                linhas.append([  f"✔ Dentro do limite de {limite} mês(es)"])
                            else:
                                status = False
                                self.log.debug(f"Status false, competencia vencida")
                                linhas.append([  f"✘ Fora do limite de {limite} mês(es) (vencido)"])
                # Campos no MUA
                self.log.debug("Campos no MUA...")
                self.log.debug(f"PC A EXIBIR: {pc_exibir}")
                
                linhas.append(["Campos no MUA:", ""])
                if self.cnpj_empregador and self.cnpj_empregador != "SEM CNPJ" and not eh_prolabore:
                    linhas.append(["CNPJ do Empregador:", self.format_br.formatar_cnpj(self.cnpj_empregador)])
                
                linhas.append(["Período:", self.periodo_documento])
                grat_med = 0
                if eh_prolabore:
                    if valor_float == 0:
                        if salario_base_float > 0:
                            valor_float = salario_base_float
                            self.valor_documento = self.format_br.formatar_moeda_br(valor_float)
                        status = False
                        self.log.debug(f"Status false, valor float zerado")
                    linhas.append(["Pró-Labore:", self.valor_documento])
                else:
                    if valor_float == 0 and grat_med == 0:
                        if salario_base_float > 0:
                            valor_float = salario_base_float
                            self.valor_documento = self.format_br.formatar_moeda_br(valor_float)
                        status = False
                        self.log.debug(f"Status false, valor float e gratificações zerados")
                    linhas.append(["Salário Líquido:", self.valor_documento])
                
                    # Média (somente no mais recente) — nenhum erro/linha de média nos demais, apenas no ultimo
                    self.media_holerite = "R$ 0,00"
                    if is_mais_recente and tem_competencia:
                        grat_med, has_3, meses_presentes = self.media_grat_3meses(index_por_competencia, ano_competencia, mes_competencia)
                        self.media_holerite = self.format_br.formatar_moeda_br(grat_med)
                        linhas.append(["Gratificações/Comissões (média):", self.media_holerite])

                        # ⚠️ Validação "faltando holerite" — só se existir item que entra em 3
                        if has_3:
                            # usa a data de admissão já computada acima (dt_adm)
                            if data_admissao_formatada:
                                # meses de empresa (contagem por competência, inclusiva)
                                meses_empresa = self.format_br.calcular_meses_entre(ano_competencia, mes_competencia, data_admissao_formatada.year, data_admissao_formatada.month) + 1
                                required = 3 if meses_empresa >= 3 else max(meses_empresa, 1)
                            else:
                                # sem data de admissão → exigir 3
                                required = 3

                            if self.deve_vir_3_para_media and meses_presentes < required:
                                linhas.append([
                                    f"✘ Faltam holerites para a média (vieram {meses_presentes} de {required} necessários)."
                                ])
                            elif not self.deve_vir_3_para_media:
                                linhas.append([
                                    f"✔ Média calculada com {meses_presentes} comprovante(s)."
                                ])
                    

                self.log.debug("Regras...")
                
                # Parecer (usa {media}=0 nos demais)
                regras = {}
                if getattr(self, "regras_mua", None):
                    nomes_auto = nomes_auto_prolabore if eh_prolabore else nomes_auto_holerite
                    regras = self.regras_mua.get_doc(nomes_auto)
                
                linhas.extend(self.exibir_regras_doc(regras))
                doc_origem_regra = (regras.get("Documento Origem") or "Comprovante de renda").strip()
                tipo_ocupacao_regra = (regras.get("Ocupação") or "Empregado").strip()

                # salva os dados para o MUA
                if not eh_prolabore:
                    campos_mua["Salário Líquido"] = self.format_br.converter_valor_para_float(self.valor_documento) or 0.0
                    campos_mua["Gratificações e Comissões"] = self.format_br.converter_valor_para_float(self.media_holerite) or 0.0

                dados_ocupacao = {
                    "tipo": tipo_ocupacao_regra,
                    "cargo": self.cargo,
                    "admissao": data_admissao,
                    "nome_empregador": self.nome_empregador,
                    "cnpj_empregador": self.cnpj_empregador,
                }
                self.dados_mua = {
                    "periodo": self.periodo_documento,
                    "doc_origem": doc_origem_regra,
                    "tipo": "Efetivo",
                    "campos": campos_mua,
                    "ocupacao": dados_ocupacao
                }

                self.log.debug(f"Dados MUA gerados para Holerite: {self.dados_mua}")

                # Aviso opcional (se não houver listas na planilha)
                if sem_itens_cfg and not eh_prolabore:
                    linhas.append([
                        #"Regras do Holerite:",
                        "✘ Sem informações dos itens do holerite na planilha de regras, verificar se os valores informados pela automação estão corretos"
                    ])
                self.log.debug("Finalizando...")

                # Título: âncora destaca “mais recente • CNPJ …”; demais: “HOLERITE MM/AAAA:”
                titulo = (
                    f"{nome_tipo.upper()} - (mais recente • CNPJ {self.format_br.formatar_cnpj(cnpj_norm)})"
                    if is_mais_recente else f"{nome_tipo.upper()} {self.periodo_documento}:"
                )
                if not is_mais_recente and any(
                    h["_comp_tuple"] == pc_exibir["_comp_tuple"]
                    for h in holerites_para_exibir if h is not pc_exibir
                ):
                    titulo = f"{nome_tipo.upper()} {self.periodo_documento} (complementar):"

                # --- Controle de exibição no PDF ---
                # Se deve exibir apenas o último:
                if self.exibir_apenas_ultimo:
                    # mostrar somente se for o mais recente
                    if not is_mais_recente:
                        self._exibir_no_pdf = False
                    else:
                        self._exibir_no_pdf = True
                else:
                    # se exibir todos, então sempre exibe
                    self._exibir_no_pdf = True

                if self._exibir_no_pdf:
                    self.sections.append((titulo, linhas))

                resultados.append({
                    "arquivo": self.file,
                    "status": status,
                    "mensagem": "Validação concluída com sucesso." if status else "Falha na validação.",
                    "dados_extraidos": self.doc,
                    "context": self.context,
                    "dados_mua": getattr(self, "dados_mua", {})
                })



        return self.build_output(
            status_geral=True,
            resultados_docs=resultados
        )


        # ---------------- utils locais ----------------

    def eh_regido_por_lei(self, text: str) -> bool:
        """
        Detecta menção à lei: formatos tipo 'LEI 13.467/2017', 'Lei 13467/2017', 'L. 13.467/2017'.
        """
        if not text:
            return False
        t = normalize(text)
        # precisa ter um marcador de LEI/L.
        if not re.search(r"\b(L|LEI)\b", t):
            return False
        # e um padrão numérico xxxx/xxxx ou x.xxx/xxxx (aceita variações sem ponto)
        return bool(re.search(r"\b\d{3,6}\s*/\s*\d{4}\b", t))

    def _config_listas(self) -> tuple[List[str], List[str], List[str], bool, bool]:
        """
        Lê listas do self.comprovantes (se houver) senão usa defaults.
        Retorna também 'sem_itens_cfg' = True quando a planilha não trouxe NENHUM item
        para NAO_ENTRA / ENTRA_COM_3 / ENTRA_COM_1 (ou as listas estão vazias).
        """
        cfg = getattr(self, "comprovantes", None)
        NAO_ENTRA = [
            "13o", "decimo terceiro", "hora extra", "he", "adicional noturno",
            "adicional de viagem", "ajuda de custo", "auxilio", "vale",
            "dsr sobre hora extra", "premio por assiduidade", "diarias",
        ]
        ENTRA_COM_3 = [
            "comissao", "comissoes", "gratificacao", "gratificacoes",
            "premio", "premios", "variavel", "rv", "bonus", "produtividade",
        ]
        ENTRA_COM_1 = [
            "salario base", "salario", "insalubridade", "periculosidade",
            "adicional de tempo de servico", "anuenio", "trienio", "quinquenio",
            "ts", "periculosidade", "insalubridade", "dsr", "descanso semanal remunerado",
        ]

        def _is_empty_list(x) -> bool:
            if not x:
                return True
            try:
                return len([s for s in x if str(s).strip()]) == 0
            except TypeError:
                return True

        sem_itens_cfg = False

        if cfg:
            raw_nao = getattr(cfg, "holerite_nao_considerar", None)
            raw_3   = getattr(cfg, "holerite_aceito_em_3", None)
            raw_1   = getattr(cfg, "holerite_aceito_em_1", None)
            # Se NENHUMA lista veio preenchida -> marcar flag
            if (raw_nao is None and raw_3 is None and raw_1 is None) or \
            (_is_empty_list(raw_nao) and _is_empty_list(raw_3) and _is_empty_list(raw_1)):
                sem_itens_cfg = True

            # Sobrescreve pelos valores da planilha, se existirem
            if raw_nao:
                NAO_ENTRA = list(raw_nao)
            if raw_3:
                ENTRA_COM_3 = list(raw_3)
            if raw_1:
                ENTRA_COM_1 = list(raw_1)
        else:
            # Não tem aba/objeto de regras -> marcar flag
            self.log.warning("variavel self.comprovantes(regras) não encontrada")
            sem_itens_cfg = True

        # normaliza
        NAO_ENTRA   = [normalize_no_space(x) for x in NAO_ENTRA]
        ENTRA_COM_3 = [normalize_no_space(x) for x in ENTRA_COM_3]
        ENTRA_COM_1 = [normalize_no_space(x) for x in ENTRA_COM_1]

        return NAO_ENTRA, ENTRA_COM_3, ENTRA_COM_1, sem_itens_cfg

    def _categoria_item(self, nome_item: str, NAO_ENTRA: List[str], ENTRA_COM_3: List[str], ENTRA_COM_1: List[str]) -> Optional[str]:
        """
        Retorna:
        - 'NAO'  → não entra (sem lei)
        - '1'    → entra com 1 (apenas mês âncora)
        - '3'    → entra com 3 (média 3 meses)
        - None   → ignora (ex.: sem nome/valor)
        Prioridades:
        1) Se o item estiver em NAO_ENTRA (mesmo parcialmente) → 'NAO'
        2) Se estiver em ENTRA_COM_3 → '3'
        3) Se estiver em ENTRA_COM_1 → '1'
        4) Caso não bata, fallback = '1'
        """
        if not nome_item:
            return None

        t = normalize_no_space(nome_item)

        def contem(lista):
            for chave in lista:
                if normalize_no_space(chave) in t or t in normalize_no_space(chave):
                    return True
            return False

        # 1️⃣ prioridade: NAO_ENTRA
        if contem(NAO_ENTRA):
            self.log.debug(f"Item {nome_item} NÃO ENTRA!")
            if self.considerar_itens_por_lei and self.eh_regido_por_lei(nome_item):
                # promove por lei → tenta 3, depois 1
                self.log.debug(f"Item {nome_item} regído por lei, ENTRA!")

                if contem(ENTRA_COM_3):
                    return "3"
                if contem(ENTRA_COM_1):
                    return "1"
                return "1"
            return "NAO"

        # 2️⃣ entra com 3
        if contem(ENTRA_COM_3):
            self.log.debug(f"Item {nome_item} entra em 3 holerites!")
            return "3"

        # 3️⃣ entra com 1
        if contem(ENTRA_COM_1):
            self.log.debug(f"Item {nome_item} entra em um holerite!")
            return "1"
        
        self.log.debug(f"Item {nome_item} não encontrado em nenhuma lista, usando fallback -> ENTRA_EM_UM")
        # 4️⃣ fallback padrão
        return "1"

    def meses_anteriores_janela(self, ano_base: int, mes_base: int) -> List[Tuple[int, int]]:
        '''
        Retorna uma lista com as competências (ano, mês) dos 3 meses da janela
        em relação ao mês de referência informado (M-2, M-1, M).
        
        Exemplo:
            ano_base = 2025, mes_base = 3
            retorna [(2025, 1), (2025, 2), (2025, 3)]
        '''
        competencias = []
        ano, mes = ano_base, mes_base
        for delta in [2, 1, 0]:
            ano_corrigido = ano if mes - delta > 0 else ano - 1
            mes_corrigido = mes - delta if mes - delta > 0 else (12 + (mes - delta))
            competencias.append((ano_corrigido, mes_corrigido))
        return competencias

    def agrupar_por_cnpj(self, holerites: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
        '''
        Agrupa holerites por CNPJ e anota a competência (ano, mês) em cada item.
        - Normaliza o CNPJ (apenas dígitos; usa "SEM CNPJ" se não houver).
        - Extrai a competência usando diretamente `formatar_data_br`, aceitando:
        "DD/MM/AAAA", "MM/AAAA", "março 2025", "mar/2025" etc.
        - Adiciona campos auxiliares por holerite:
            "_cnpj_norm"  → CNPJ normalizado
            "_comp_tuple" → (ano, mês) ou (0, 0) se não conseguiu interpretar
        Retorna: { cnpj_normalizado: [lista_de_holerites] }
        '''
        grupos: Dict[str, List[Dict[str, Any]]] = {}

        for hol in holerites:
            # CNPJ normalizado
            cnpj_raw = hol.get("CNPJ:") or hol.get("CNPJ") or hol.get("cnpj:") or hol.get("cnpj")
            cnpj_norm = self.format_br.digits(cnpj_raw) or "SEM CNPJ"

            # Texto da competência (várias etiquetas possíveis)
            comp_txt = (
                hol.get("Mês de Referência:") or hol.get("Mes de Referencia:") or
                hol.get("Competência:")       or hol.get("Competencia:")       or
                ""
            )

            # Usa o parser único para obter datetime e extrair (ano, mês)
            dt = self.format_br.formatar_data_br(comp_txt)
            if dt:
                ano, mes = dt.year, dt.month
            else:
                ano, mes = 0, 0  # mantém padrão de fallback

            # Anota campos auxiliares e adiciona no grupo
            hol["_cnpj_norm"]  = cnpj_norm
            hol["_comp_tuple"] = (ano, mes)
            grupos.setdefault(cnpj_norm, []).append(hol)

        return grupos

    def calcular_salario_liquido_mes(self, holerite_mes: Dict[str, Any]) -> float:
        """
        Soma apenas os itens que 'ENTRAM COM 1' do holerite informado.
        ***Somente*** da lista 'Itens de Salário:'.
        Ignora 'Horas Extras:', 'Gratificações:' e 'Comissões:' por definição.
        Regras de referência:
        - Se a referência do item for uma DATA (MM/AAAA etc.) e for diferente da competência do holerite, IGNORA.
        - Se não houver referência ou não for data, inclui normalmente.
        """
        total = 0.0

        # competência do holerite atual (mais confiável que self.periodo_documento)
        ano_comp, mes_comp = holerite_mes.get("_comp_tuple", (0, 0))

        itens_salario = self.extrair_valor(
            holerite_mes, False,
            "Itens de Salário:", "Itens de Salario:", "Itens de salário", "Itens de Salario"
        ) or []
        self.log.debug(f"Itens de salário: {itens_salario}")
        
        for item in itens_salario:
            nome_item = str(item.get("Nome", "")).strip()
            valor_raw = str(item.get("Valor:", "0")).strip()

            # Pega referência do item (todas as variações comuns)
            ref_txt = (
                item.get("Referência:") or item.get("Referência") or
                item.get("Referencia:") or item.get("Referencia") or ""
            )
            ref_txt = str(ref_txt).strip()

            # Se tiver competência identificada e houver referência informada, checa se é data e compara
            # Substitua dentro de calcular_salario_liquido_mes()
            if ano_comp and mes_comp and ref_txt:
                ref_dt = self.format_br.formatar_data_br(ref_txt)
                if ref_dt is not None:
                    categoria = self._categoria_item(
                        nome_item,
                        self.NAO_ENTRA, self.ENTRA_COM_3, self.ENTRA_COM_1
                    )
                    # só ignora se a referência for diferente E o item for categoria "1"
                    if not (ref_dt.year == ano_comp and ref_dt.month == mes_comp) and categoria == "1":
                        self.log.debug(
                            f"Excluindo do salário (ref {ref_txt} != {mes_comp:02d}/{ano_comp}) para item '{nome_item}' (entra em 1)"
                        )
                        continue

                # Se não for data (ref_dt None), segue normal

            # normaliza milhares
            valor_raw = re.sub(r"\.(?=\d{3}(,|$))", "", valor_raw)
            valor = self.format_br.converter_valor_para_float(valor_raw)
            if valor is None:
                continue

            categoria = self._categoria_item(
                nome_item,
                self.NAO_ENTRA, self.ENTRA_COM_3, self.ENTRA_COM_1
            )

            # Apenas itens '1' compõem o salário líquido do mês
            if categoria == "1":
                total += valor

        return total


    def media_grat_3meses(
        self,
        index_por_competencia: Dict[Tuple[int, int], Dict[str, Any]],
        anc_ano: int,
        anc_mes: int
    ) -> tuple[float, bool, int]:
        """
        Calcula a média de itens '3' em M-2, M-1 e M:
        - Inclui TUDO de 'Gratificações:' e 'Comissões:' (desde que a referência, se for DATA, seja do mesmo MM/AAAA do holerite do mês avaliado);
        - Também inclui itens de 'Itens de Salário:' classificados como '3' (mesma regra da referência);
        - Ignora completamente 'Horas Extras:'.
        Retorna: (media_dividida_por_3, tem_itens_3, meses_presentes)
        """
        soma_itens_3 = 0.0
        tem_itens_3 = False
        meses_presentes = 0

        for (yy, mm) in self.meses_anteriores_janela(anc_ano, anc_mes):
            hols = index_por_competencia.get((yy, mm), [])
            if not hols:
                continue

            meses_presentes += 1

            for hol in hols:  # percorre todos os holerites do mês
                # --- 1) GRATIFICAÇÕES E COMISSÕES ---
                itens_grat = self.extrair_valor(hol, False,
                    "Gratificações:", "Gratificacoes:", "Gratificações", "Gratificacoes") or []
                if isinstance(itens_grat, dict):
                    itens_grat = [itens_grat]

                itens_com = self.extrair_valor(hol, False,
                    "Comissões:", "Comissoes:", "Comissões", "Comissoes") or []
                if isinstance(itens_com, dict):
                    itens_com = [itens_com]

                for grupo in (itens_grat, itens_com):
                    for item in grupo:
                        ref_txt = (
                            item.get("Referência:") or item.get("Referência") or
                            item.get("Referencia:") or item.get("Referencia") or ""
                        )
                        ref_txt = str(ref_txt).strip()
                        if ref_txt:
                            ref_dt = self.format_br.formatar_data_br(ref_txt)
                            if ref_dt is not None and not (ref_dt.year == yy and ref_dt.month == mm):
                                self.log.debug(f"Excluindo de média (ref {ref_txt} != {mm:02d}/{yy}) em grat/comm")
                                continue

                        valor_raw = str(item.get("Valor:", "0")).strip()
                        valor_raw = re.sub(r"\.(?=\d{3}(,|$))", "", valor_raw)
                        valor = self.format_br.converter_valor_para_float(valor_raw)
                        if valor is None:
                            continue
                        soma_itens_3 += valor
                        tem_itens_3 = True

                # --- 2) ITENS DE SALÁRIO CLASSIFICADOS COMO "3" ---
                itens_salario = self.extrair_valor(hol, False,
                    "Itens de Salário:", "Itens de Salario:", "Itens de salário", "Itens de Salario") or []
                for item in itens_salario:
                    nome_item = str(item.get("Nome", "")).strip()
                    ref_txt = (
                        item.get("Referência:") or item.get("Referência") or
                        item.get("Referencia:") or item.get("Referencia") or ""
                    )
                    ref_txt = str(ref_txt).strip()
                    valor_raw = str(item.get("Valor:", "0")).strip()
                    valor_raw = re.sub(r"\.(?=\d{3}(,|$))", "", valor_raw)
                    valor = self.format_br.converter_valor_para_float(valor_raw)
                    if valor is None:
                        continue

                    categoria = self._categoria_item(
                        nome_item,
                        self.NAO_ENTRA, self.ENTRA_COM_3, self.ENTRA_COM_1
                    )
                    if categoria == "3":
                        soma_itens_3 += valor
                        tem_itens_3 = True


        media = soma_itens_3 / 3.0  # sempre ÷3
        return media, tem_itens_3, meses_presentes
