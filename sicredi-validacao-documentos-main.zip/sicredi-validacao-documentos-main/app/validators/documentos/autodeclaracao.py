from typing import Optional
from datetime import datetime
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data, normalize

@registrar_validador(
    "autodeclaracao de renda",
    "auto-declaracao de renda",
    "autodeclaração de renda",
    "auto-declaração de renda",
    "auto declaracao de renda",
    "auto declaração de renda",
)
class ValidadorAutodeclaracao(ValidadorBase):
    def validar(self) -> bool:
        self.log.info("Iniciando validação da autodeclaração")
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de Autodeclaração encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_autodeclaracao_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context,
                "dados_mua": getattr(self, "dados_mua", {})
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )
    def validar_autodeclaracao_individual(self):
        self.dados_mua = {
            "periodo": "",
            "doc_origem": "",
            "tipo": "Efetivo",
            "campos": {}
        }
        # 1) nome do documento (se existir no JSON)
        self.nome_documento = self.extrair_valor(self.doc,  False, "Nome", "Nome:", "nome", "nome:").strip()

        linhas = organize_data(self.doc, self.doc_type)
        linhas = [["Documento lido:", self.file]] + linhas
        linhas.append([])

        # 3) período (quatro opções, com impeditivo se emissão for necessária e não encontrada)
        periodo_cfg = getattr(getattr(self, "comprovantes", None), "periodo_auto_declaracao", None)
        hoje = datetime.today()

        mes_atual = self.format_br.extrair_mes_ano(hoje)
        mes_anterior_atual = self.format_br.extrair_mes_ano(self.format_br.mes_anterior(hoje))

        # default legado: mês anterior ao atual
        self.periodo_documento = mes_anterior_atual

        if periodo_cfg:
            p = str(periodo_cfg).strip().lower()
            if "emiss" in p:
                emissao_dt = self._encontrar_data_emissao()
                if not emissao_dt:
                    # IMPEDITIVO para Autodeclaração quando depende da emissão
                    linhas.append([f"✘ Data de emissão não encontrada no arquivo, verificar se o periodo para lançamento no MUA({mes_anterior_atual}) está correto conforme as regras({periodo_cfg})."])
                    self.periodo_documento = mes_anterior_atual
                else:
                    if "anterior" in p:
                        self.periodo_documento = self.format_br.extrair_mes_ano(self.format_br.mes_anterior(emissao_dt))
                    else:
                        self.periodo_documento = self.format_br.extrair_mes_ano(emissao_dt)
            else:
                if "atual" in p and "anterior" not in p:
                    self.periodo_documento = mes_atual
                elif "anterior" in p:
                    self.periodo_documento = mes_anterior_atual
                else:
                    self.periodo_documento = mes_anterior_atual  # legado
        else:
            self.periodo_documento = mes_anterior_atual  # legado
            linhas.append([f"✔ Sem regras definidas para o período da Autodeclaração, considerado mês anterior ao atual"])

        # 4) valor (Renda Mensal Média) → float
        valor_str = self.extrair_valor(self.doc, False, "Renda Mensal Média:", "Renda Mensal Media:")
        self.cargo = self.extrair_valor(self.doc, False, "Cargo:", "Cargo", "cargo:", "cargo")

        if valor_str is None or valor_str == "":
            valor = 0.0
            linhas.append([f"✘ Erro ao extrair o valor da autodeclaração, verificar."])
        else:
            valor = self.format_br.converter_valor_para_float(valor_str)
        self.valor_documento = self.format_br.formatar_moeda_br(valor)

        # Validação do cargo
        cargos_aceitos = getattr(getattr(self, "comprovantes", None), "cargos_aceitos_autodeclaracao", None)
        cargos_nao_aceitos = getattr(getattr(self, "comprovantes", None), "cargos_nao_aceitos_autodeclaracao", None)

        cargo_norm = normalize(self.cargo) if self.cargo else ""

        # -----------------------------
        # 1) PRIORIDADE: CARGOS ACEITOS
        # -----------------------------
        if cargos_aceitos:
            lista_aceitos = [normalize(c) for c in cargos_aceitos]

            if not cargo_norm:
                linhas.append(["✘ Cargo não encontrado, verificar."])

            elif cargo_norm in lista_aceitos:
                linhas.append([f"✔ Cargo aceito ({self.cargo})."])

            else:
                # tentativa de match parcial
                achou_parcial = any(
                    cargo_norm in aceito or aceito in cargo_norm
                    for aceito in lista_aceitos
                )

                if achou_parcial:
                    linhas.append([f"✔ Cargo aceito ({self.cargo})."])
                else:
                    linhas.append([f"✘ Cargo não aceito ({self.cargo}), verificar."])

        # ----------------------------------------
        # 2) NÃO HÁ ACEITOS, MAS HÁ NÃO ACEITOS
        # ----------------------------------------
        elif cargos_nao_aceitos:
            lista_nao_aceitos = [normalize(c) for c in cargos_nao_aceitos]

            if not cargo_norm:
                linhas.append(["✘ Cargo não encontrado, verificar."])

            elif cargo_norm in lista_nao_aceitos:
                linhas.append([f"✘ Cargo não aceito ({self.cargo}), verificar."])
            
            else:
                # permitido se não está na lista de proibidos
                linhas.append([f"✔ Cargo aceito ({self.cargo})."])

        # -----------------------------
        # 3) NENHUMA REGRA DEFINIDA
        # -----------------------------
        else:
            if cargo_norm:
                linhas.append([f"✔ Cargo aceito ({self.cargo})."])
            else:
                linhas.append(["✘ Cargo não encontrado, verificar."])

        # 5) validação de limite (se houver configuração)
        limite_msg = self._validar_limite(valor)

        # 6) validação da data de emissão (se houver configuração de dias)
        validade_msg = self._validar_data_emissao()

        # 7) montar saída
        # mensagens finais
        row = self._nome_validation_row()
        if row:
            linhas.append(row)
        if validade_msg:
            linhas.append([validade_msg])
        if limite_msg:
            linhas.append([limite_msg])
        linhas.append(["Campos no MUA:", ""])
        linhas.append(["Período:", self.periodo_documento])
        linhas.append(["Valor:", self.valor_documento])
        
        # regras (planilha > fallback)
        regras = {}
        if getattr(self, "regras_mua", None):
            nomes_auto = ["autodeclaração","autodeclaracao","auto-declaracao","auto declaração"]
            regras = self.regras_mua.get_doc(nomes_auto) # busca no Excel

        doc_origem_regra = (regras.get("Documento Origem") or "Outros").strip()
        campo_regra = (regras.get("Campo") or "Outros").strip()
        tipo_ocupacao_regra = (regras.get("Ocupação") or "Autônomo").strip()

        dados_ocupacao = {
            "tipo": tipo_ocupacao_regra,
            "cargo": self.cargo,
            "admissao": '',
            "nome_empregador": '',
            "cnpj_empregador": ''
        }
        self.dados_mua = {
            "periodo": self.periodo_documento,
            "doc_origem": doc_origem_regra,
            "tipo": "Efetivo",
            "campos": {
                campo_regra: self.format_br.converter_valor_para_float(self.valor_documento) or 0.0
            },
            "ocupacao": dados_ocupacao
        }
        self.log.debug(f"Dados MUA gerados para Autodeclaração: {self.dados_mua}")

        # regras (planilha > fallback)
        linhas_regras = self.exibir_regras_doc(regras)
        linhas.extend(linhas_regras)

        self.sections.append(("AUTODECLARAÇÃO", linhas))
        self.log.info("Validação da autodeclaração FINALIZADA!")
        return True

    # ----- limites / validade -----
    def _validar_limite(self, valor: float) -> Optional[str]:
        cfg = getattr(self, "comprovantes", None)
        lim = None
        if cfg and hasattr(cfg, "limite_auto_declaracao"):
            try:
                lim = float(cfg.limite_auto_declaracao)
            except Exception:
                lim = None

        if lim is None or not lim or lim == 0 or str(lim).lower() == "nan":
            return (f"✔ Sem limites definidos para Autodeclaração")  # sem configuração

        # a mensagem original mencionava "em mil"; mantenho literal se for seu padrão
        if valor <= lim:
            return (f"✔ DENTRO DO LIMITE DE {int(lim)} MIL")
        else:
            return (f"✘ ACIMA DO LIMITE DE {int(lim)}")

    def _validar_data_emissao(self) -> Optional[str]:
        data_emissao_str = (self.doc.get("Data de Emissão:", "") or "").strip()
        if not data_emissao_str:
            return None

        cfg = getattr(self, "comprovantes", None)
        dias = None
        if cfg and hasattr(cfg, "limite_dias_autodeclaracao"):
            try:
                dias = int(cfg.limite_dias_autodeclaracao)
            except Exception:
                dias = None

        # Se não houver configuração de dias, só informa a data sem validar janela
        if dias is None:
            return (f"✔ Sem limites configurados para data de emissão.")

        try:
            data_emissao = self.format_br.formatar_data_br(data_emissao_str)
            if not data_emissao:
                return (f"✘ Erro ao interpretar a data '{data_emissao_str}'")
            diff = (datetime.today() - data_emissao).days
            if diff <= dias:
                return (f"✔ Data de emissão({data_emissao_str}) está dentro dos {dias} dias")
            else:
                return (f"✘ Data inválida ({data_emissao_str}) - fora dos {dias} dias")
        except Exception:
            return (f"✘ Erro ao interpretar a data '{data_emissao_str}'")

    def _encontrar_data_emissao(self) -> Optional[datetime]:
        chaves = ["Data de Emissão:", "Data de Emissão", "Data de emissão", "Emissão:", "Emissão", "Data:" , "Data"]
        for k in chaves:
            v = self.doc.get(k)
            if v:
                dt = self.format_br.formatar_data_br(str(v))
                if dt: return dt
        return None