# app/validators/recibo_irpf.py
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data

@registrar_validador(
    "recibo irpf",
    "recibo ir",
    "recibo irrf",
    "ir_receipt",
    "recibo imposto de renda",
    "Recibo de IR",
)
class ValidadorReceipt(ValidadorBase):
    """
    Validador inicial para RECIBO:
      - Exibe os campos do JSON usando organize_data (igual ao genérico)
      - Tenta buscar regras com buscar_regras_doc("recibo ir") e exibe se encontrar
      - Ainda não aplica validações: apenas mostra informações
    """

    def validar(self) -> bool:
        self.log.info("Iniciando validação do Recibo do IR")
        # 1) Cabeçalho da seção
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de Recibo encontrado.")
        self.log.debug(f"Lista recebida: {lista_docs}")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_recibo_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )


    def validar_recibo_individual(self):
        houve_erro = False
        self.nome_documento = self.extrair_nome_documento(self.doc)
        linhas = organize_data(self.doc, self.doc_type)
        linhas = [["Documento lido:", self.file]] + linhas

        titulo = str(self.extrair_valor(self.doc, False, "Título", "Título:") or "").upper().strip()
        total_rend = self.extrair_valor(self.doc, False, "Total rendimentos tributaveis:", "Total rendimentos tributáveis")
        saldo_imposto = self.extrair_valor(self.doc, False, "Saldo do imposto a pagar:", "Saldo imposto a pagar")

        # Converte valores numéricos
        try:
            total_rend_float = float(str(total_rend).replace(".", "").replace(",", "."))
        except:
            total_rend_float = 0.0
        try:
            saldo_imposto_float = float(str(saldo_imposto).replace(".", "").replace(",", "."))
        except:
            saldo_imposto_float = 0.0

        # -------------------------------
        # 🔸 1) Verificação das retificadoras
        # -------------------------------
        validar_titulo = self.to_bool(getattr(self.comprovantes, "declaracoes_retificadas", True)) is not False
        titulos_todos = [str(self.extrair_valor(d.get("dados") or {}, False, "Título", "Título:") or "").upper().strip()
                        for d in self.lista]
        self.log.debug(f"titulo_todos: {titulos_todos}")    
        retificadoras = []
        tem_original = any("DECLARAÇÃO ORIGINAL" in t for t in titulos_todos)

        for t in titulos_todos:
            if "RETIFICADORA" in t:
                num = "".join([c for c in t if c.isdigit()])
                if num.isdigit():
                    retificadoras.append(int(num))
        self.log.debug(f"Retificadoras: {retificadoras}")
        if titulo:
            if validar_titulo:
                if "RETIFICADORA" in titulo:
                    try:
                        numero_atual = int("".join([c for c in titulo if c.isdigit()]) or 0)
                    except:
                        numero_atual = 0
                    faltantes = []
                    for i in range(1, numero_atual):
                        if i not in retificadoras:
                            faltantes.append(i)
                    # A original só é obrigatória se não houver a retificadora nº 1
                    if not tem_original and 1 not in retificadoras:
                        faltantes.insert(0, "ORIGINAL")

                    if faltantes:
                        houve_erro = True
                        linhas.append(["✘ Erro:", f"Faltam declarações anteriores: {', '.join(map(str, faltantes))}"])
                    else:
                        linhas.append(["✔ Declarações anteriores presentes:", "OK"])
                else:
                    linhas.append(["✔ Tipo de declaração:", "Original"])
            else:
                linhas.append(["✔ Sem regras definidas para o título"])
        else:
            houve_erro = True
            linhas.append(["✘ Tipo de declaração(original/retificada) não encontrado"])

        # -------------------------------
        # 🔸 2) Validação DARF / NF
        # -------------------------------
        limite_darf_ir = getattr(self.comprovantes, "limite_darf_ir", 0)
        if limite_darf_ir > 0:
            if total_rend_float > limite_darf_ir and saldo_imposto_float > 0:
                docs_tipos = [str(d.get("tipo_documento") or "").lower() for d in self.data]
                tem_nf = any("nota" in t or "invoice" in t for t in docs_tipos)

                if tem_nf:
                    linhas.append(["Atenção:", "Valor elevado e imposto a pagar. Há nota fiscal no processo, verificar se é DARF."])
                else:
                    linhas.append(["✘ Rendimentos acima de 60 mil com imposto a pagar. Deve constar DARF ou comprovante de pagamento."])
            elif total_rend_float > limite_darf_ir:
                linhas.append(["✔ Rendimentos acima de 60 mil porém sem imposto a pagar."])
            elif saldo_imposto_float > 0:
                linhas.append([f"✔ Possui saldo de imposto a pagar porém o valor dos rendimentos tributáveis é menor que {self.format_br.formatar_moeda_br(limite_darf_ir)}."])
            else:
                linhas.append([f"✔ Sem saldo de imposto a pagar e rendimentos menores que {self.format_br.formatar_moeda_br(limite_darf_ir)}."])
        else:
            linhas.append([f"✔ Sem regras definidas para o envio da DARF!"])


        linhas.append([])
        self.sections.append(("RECIBO IR", linhas))
        self.log.info("Validação do RECIBO DO IR FINALIZADA.")
        return (not houve_erro)
