import re
from datetime import datetime
from app.validators.base import ValidadorBase
from app.validators.registro import registrar_validador
from app.utils.helpers import organize_data, normalize
from app.utils.APIs.api_cep import buscar_endereco

@registrar_validador("comprovante de endereço", "comprovante de endereco", "Comprovante de Endereço")
class ValidadorComprovanteEndereco(ValidadorBase):
    def validar(self) -> bool:
        # 1) Nome do documento (se existir)
        self.log.info("Iniciando validação do Comprovante de Endereço")
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de endereço encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_endereco_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )

    def validar_endereco_individual(self):
        self.nome_documento = (self.doc.get("Nome:") or self.doc.get("Nome") or "").strip()

        # 3) Base das linhas
        linhas = organize_data(self.doc, self.doc_type)
        linhas = [["Documento lido:", self.file]] + linhas
        linhas.append([])

        # (opcional) resultado da validação de nome
        row = self._nome_validation_row()
        if row:
            linhas.append(row)

        # 4) Validação do Período de Referência (formato esperado 'MM/AAAA')
        linhas.append([])

        periodo = (
            self.doc.get("Período de Referência:")
            or self.doc.get("Periodo de Referencia:")
            or self.doc.get("Periodo:", None)
        )

        validade_msg = None
        # Config: número de meses aceitos (opcional; default = 3)
        limite_meses = 3
        cfg = getattr(self, "comprovantes", None)
        if cfg is not None:
            limite_meses = getattr(cfg, "limite_meses_endereco", limite_meses)

        if periodo:
            try:
                # espera 'MM/AAAA'
                dt = self.format_br.formatar_data_br(str(periodo))
                data_periodo = dt if dt else None
                self.periodo_documento = self.format_br.extrair_mes_ano(dt) if dt else periodo

                hoje = datetime.today()
                primeiro_dia_mes_atual = datetime(hoje.year, hoje.month, 1)

                # gera a lista dos últimos N meses (excluindo o mês corrente)
                meses_validos = []
                cursor = primeiro_dia_mes_atual
                meses_validos.append(cursor)  # mês corrente

                for _ in range(limite_meses):
                    cursor = self.format_br.mes_anterior(cursor)  # volta 1 mês
                    meses_validos.append(cursor)

                if any(
                    data_periodo.year == m.year and data_periodo.month == m.month
                    for m in meses_validos
                ):

                    validade_msg = f"✔ Período válido dentro dos {limite_meses} meses"
                else:
                    meses_validos_fmt = [self.format_br.extrair_mes_ano(m) for m in meses_validos]
                    validade_msg = f"✘ Período inválido (mais de {limite_meses} meses), válidos: {', '.join(meses_validos_fmt)}"
            except Exception:
                validade_msg = f"✘ Erro ao interpretar o Período: {self.periodo_documento}"
        else:
            validade_msg = "✘ Período de referência do endereço não encontrado"

        linhas.append([validade_msg])

        # 5) Consulta de CEP no ViaCEP (opcional)
        informacoes = (
            self.doc.get("Informações:")
            or self.doc.get("Informacoes:")
            or ""
        )

        cep = None
        if informacoes:
            # aceita padrão 00000-000
            m = re.search(r"\b\d{5}-\d{3}\b", str(informacoes))
            if m:
                cep = m.group()
        #cep = '93224390' #TESTE
        if cep:
            linhas.append([])
            try:
                dados = buscar_endereco(cep)
            except Exception as e:
                dados = None
                
            if dados:
                linhas.append(["Consulta do CEP na internet:", ""])
                # lista de campos para exibir
                campos = {
                    "cep": "CEP",
                    "logradouro": "Logradouro",
                    "complemento": "Complemento",
                    "bairro": "Bairro",
                    "cidade": "Cidade",
                    "estado": "UF",
                }

                for chave, titulo in campos.items():
                    valor = dados.get(chave)
                    if valor:
                        linhas.append([f"{titulo}:", valor])
    
        
        
        # 6) Parecer/Regras (planilha > fallback)
        # regras (planilha > fallback)
        regras = {}
        if getattr(self, "regras_mua", None):
            nomes_auto = ["endereço","endereco","comprovante de endereço","declaração de endereço", "declaração de residencia"]
            regras = self.regras_mua.get_doc(nomes_auto) # busca no Excel

        linhas_regras = self.exibir_regras_doc(regras)
        linhas.extend(linhas_regras)

        # 7) Adiciona seção
        self.sections.append(("COMPROVANTE DE ENDEREÇO", linhas))
        self.log.info("Validação do endereço concluída")
        return True