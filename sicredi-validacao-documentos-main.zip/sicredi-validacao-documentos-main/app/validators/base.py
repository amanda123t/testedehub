# app/validators/base.py
from __future__ import annotations
from typing import Any, Dict, List, Tuple, Optional
from app.utils.helpers import normalize
from collections.abc import Mapping
from datetime import date
import re
from app.utils.rules_docs import RulesMua, RegrasComprovantes
from .helpers.apis import Apis
from app.utils.logger import LoggerManager
import math
from app.utils import format_br
from abc import ABC

class ValidadorBase(ABC):
    """
    Classe-pai de todos os validadores.
    - Guarda o estado comum do documento/processo.
    - Define o contrato: todo validador concreto deve implementar `validar()`.
    - Acumula `sections` (título + linhas) consumidas pelo gerador de PDF.
    """

    def __init__(
        self,
        *,
        doc_type: str,
        data: Dict[str, Any],
        type_name: str,
        process_info: Dict[str, Any],
        numero_processo: Optional[str] = None,
        planilha_regras: Any = None,            
    ) -> None:
        

        # Entrada padrão
        self.context: str = ''
        self.doc_type: str = doc_type
        self.data: Dict[str, Any] = data
        self.file: str = ''
        self.type_name: str = type_name
        self.process_info: Dict[str, Any] = process_info

        # Saída para o PDF
        self.sections: List[Tuple[str, List[List[str]]]] = []

        # Cabeçalho opcional do processo
        self.header_info: Optional[List[List[str]]] = []

        # Campos “coringa” comuns
        self.numero_processo: str = (numero_processo or "").strip()
        self.colaborador = self.process_info.get("colaborador","")
        self.agencia = (self.process_info.get("agencia") or "").strip().upper()
        self.responsavel = (self.process_info.get("responsavel") or "").strip().upper()
        self.valor_documento: str = ""
        self.periodo_documento: str = ""
        self.cargo: str = ""
        self.cbo = ""
        self.nome_empregador: str = ""
        self.cnpj_empregador: str = ""
        self.media_holerite: str = "0"
        self.crc_contador: str = ""
        self.contador: str = ""
        self.aposentadoria: str = ""
        # >>> usados por validar_nome()
        self.nome_processo = normalize(
            (self.process_info.get("nome")
             or self.process_info.get("name")
             or "")
        )        
        self.cnpj = (self.process_info.get("cnpj") or "").strip().upper()

        self.nome_documento: str = ""
        self.nomes_socios: List[str] = []

        #Multiplicar por 1.000 se os valores tiverem em milhares de reais.
        self.valores_em_milhares = False

        # Log simples
        self.log = LoggerManager(__name__)  
        self.apis = Apis()
        self.format_br = format_br

        self.inspecao = True
        self.regras_mua = RulesMua(planilha_regras)
        self.comprovantes = RegrasComprovantes(planilha_regras)

        # Prepara lista de documentos automaticamente
        self._preparar_lista_documentos()

    # ---------------- Hooks/contrato ----------------
    def validar(self) -> bool:
        """Implementar em cada validador concreto."""
        raise NotImplementedError
    
    def _preparar_campos_comuns(self) -> None:
        """Monta o header com os campos do processo e, ao final, adiciona os pareceres padrão."""
        self.header_info = []
        if not self.process_info:
            self.log.debug("Informações do RPA para o processo não foi encontrado!")
            return

        self.log.debug(f"Informações encontradas para o processo atual: {self.process_info}")

        # -------------------------------
        # 1. CAMPOS NORMAIS DO PROCESSO
        # -------------------------------
        for chave, valor in self.process_info.items():
            if valor is None:
                continue
            if isinstance(valor, float) and math.isnan(valor):
                continue
            if isinstance(valor, (list, dict)) and not valor:
                continue
            if isinstance(valor, str) and str(valor).strip().lower() in {"", "null", "nan", "none"}:
                continue

            self.header_info.append([f"{str(chave).strip().title()}:", str(valor).strip()])

        self.log.debug(f"Header info parcial: {self.header_info}")

        # -------------------------------
        # 2. ADICIONAR PARECERES PADRÃO
        # -------------------------------
        pareceres = getattr(self.comprovantes, "parecer_padrao", None)

        if not pareceres:
            return

        # Linha separadora
        self.header_info.append(["----- PARECERES PADRÃO -----", ""])

        for tipo, texto in pareceres.items():
            if not texto:
                continue

            tipo_fmt = str(tipo).upper().strip()
            texto_fmt = str(texto).strip()

            # Se for um texto longo → põe embaixo
            if len(texto_fmt) > 80:
                self.header_info.append([f"{tipo_fmt}:", ""])
                self.header_info.append(["", texto_fmt])
            else:
                self.header_info.append([f"{tipo_fmt}:", texto_fmt])

        self.log.debug(f"Header info final com pareceres: {self.header_info}")

    def _preparar_lista_documentos(self):
        """
        Normaliza automaticamente a entrada (self.data) para gerar self.lista.
        Aceita múltiplos formatos e, agora, busca o type_name ou doc_type de forma case-insensitive.
        """
        lista_docs = []

        if isinstance(self.data, dict):
            # tenta localizar chave correspondente ao type_name ou doc_type (insensível a caixa e espaços)
            chave_encontrada = None
            type_name_norm = normalize(self.type_name).strip().lower()
            doc_type_norm = normalize(self.doc_type).strip().lower()

            for k in self.data.keys():
                k_norm = normalize(k).strip().lower()
                if k_norm in {type_name_norm, doc_type_norm}:
                    chave_encontrada = k
                    break

            if chave_encontrada:
                docs = self.data[chave_encontrada]
                if isinstance(docs, list):
                    lista_docs = docs
                elif isinstance(docs, dict):
                    lista_docs = [docs]

            elif "dados" in self.data:
                lista_docs = [self.data]

            else:
                # detecta se contém campos típicos da IA (Nome, Proprietário, CPF etc)
                tem_nome = any(k.lower().startswith(("nome", "propriet")) for k in self.data.keys())
                if tem_nome:
                    lista_docs = [{"dados": self.data, "arquivo": "", "context": ""}]
                else:
                    raise ValueError(f"Formato inesperado de data recebido em {self.type_name}: {self.data}")

        elif isinstance(self.data, list):
            if all(isinstance(i, dict) and "dados" in i for i in self.data):
                lista_docs = self.data
            else:
                lista_docs = [{"dados": d, "arquivo": "", "context": ""} for d in self.data if isinstance(d, dict)]
        else:
            raise ValueError(f"Formato inválido de entrada para {self.type_name}: {self.data}")

        # 🔹 Normalização final (estrutura padronizada)
        normalizados = []
        for item in lista_docs:
            if not isinstance(item, dict):
                continue
            normalizados.append({
                "dados": item.get("dados") or item.get("dados_extraidos") or item,
                "arquivo": item.get("arquivo", ""),
                "context": item.get("context", ""),
            })

        self.lista = normalizados
        self.log.debug(f"[{self.type_name}] Lista normalizada com {len(self.lista)} documento(s).")

    # ---------------- Utilidades comuns ----------------
    def drop_keys_simples(self, data: dict, campos: list[str]) -> dict:
        """
        Remove do dicionário 'data' todas as chaves que correspondam (de forma aproximada)
        aos nomes de 'campos' informados.

        Regras:
        - Verifica versões com e sem ':'.
        - Normaliza acentuação e caixa.
        - Considera tanto igualdade quanto 'está contido em' nos dois sentidos (chave em campo / campo em chave).
        - Retorna um novo dicionário (não altera o original).
        """
        def normalizar_nome(nome: str) -> str:
            nome = nome.strip().lower()
            nome = nome.replace(":", "").replace("_", "").replace("-", "")
            nome = normalize(nome)
            return nome

        # normaliza a lista de campos a excluir
        campos_norm = [normalizar_nome(c) for c in campos]

        data_limpo = {}
        for chave, valor in data.items():
            chave_norm = normalizar_nome(chave)
            remover = False

            for campo in campos_norm:
                # verifica correspondência direta ou parcial
                if campo in chave_norm or chave_norm in campo:
                    remover = True
                    break

            if not remover:
                data_limpo[chave] = valor

        return data_limpo

    def validar_cnpj(self, cnpj: str) -> bool:
        """Valida CNPJ (14 dígitos, com ou sem formatação)."""
        if not cnpj or cnpj == "SEM CNPJ":
            return False
        
        cnpj_digits = self.format_br.digits(cnpj or "")
        if len(cnpj_digits) != 14:
            return False
        soma = 0
        for number in cnpj_digits:
            soma += int(number)
        if soma <= 1:
            return False

        return True
    
    def _validar_nome(self) -> str | None:
        """Usa nome do processo, do documento e (se houver) lista de sócios."""
        nome_proc = (getattr(self, "nome_processo", "") or "").strip()
        nome_doc  = (getattr(self, "nome_documento", "") or "").strip()
        socios    = getattr(self, "nomes_socios", []) or []

        if not nome_proc and not nome_doc:
            return None

        n_proc = normalize(nome_proc)
        n_doc  = normalize(nome_doc)

        if n_proc and n_doc and (n_doc in n_proc or n_proc in n_doc):
            return "✔ Documento do associado!"

        for s in socios:
            if not s:
                continue
            if normalize(s) in n_doc or n_doc in normalize(s):
                primeiro = (nome_doc.split() or ["Sócio"])[0]
                return f"✔ Documento do sócio: {primeiro}"

        return ""

    def _nome_validation_row(self):
        validacao_nome = self._validar_nome()
        if not validacao_nome:
            return
        return [validacao_nome]
    
    def to_bool(self, value: str) -> bool | None:
        """
        Converte respostas textuais comuns em booleano.
        Retorna:
        - True  → se for equivalente a "sim", "positivo", "x"
        - False → se for equivalente a "não", "nao", "negativo"
        - None  → se não conseguir interpretar
        """
        if value is None:
            return None

        s = str(value).strip().lower()

        true_vals = {"sim", "s", "yes", "y", "positivo", "true", "verdadeiro", "x", "ok"}
        false_vals = {"nao", "não", "n", "no", "negativo", "false", "falso", "-"}

        if s in true_vals:
            return True
        if s in false_vals:
            return False
        return None

    def _parse_valor(self, raw):
        """
        Retorna (valor_float, valor_formatado_em_reais)
        Ex:
            "1.234,56"   -> (1234.56, "R$ 1.234,56")
            2000.0       -> (2000.00, "R$ 2.000,00")
            None         -> (0.0, "R$ 0,00")
        """
        v_float = self.format_br.converter_valor_para_float(raw) or 0.0
        v_br = self.format_br.formatar_moeda_br(v_float)
        return v_float, v_br

    # ----- Funções Para extrair valor do dicionario Data -----

    def extrair_valor(self, item, valor = False, *chaves):
        '''
        Função para extrair valor de um Dicionário:
        Recebe (self.data: Dict, False/True, Nome:, Nome, nome, Nome do associado, nome associado:)
        retorna o valor
        '''
        for chave in chaves:
            if chave in item:
                return item[chave]
        # 2. Busca aproximada por normalização
        chaves_normalizadas = [normalize(chave) for chave in chaves]
        for chave_item in item:
            if normalize(chave_item) in chaves_normalizadas:
                return item[chave_item]
        if valor is True:
            return 0
        return ''

    def extrair_nome_documento(self, data):
        """
        Extrai o nome do documento a partir dos dados fornecidos.
        Se o nome não for encontrado, retorna uma string vazia.
        """
        nome_documento = normalize(self.extrair_valor(data, False,  "Nome", "Nome:", "nome", "nome:", "Proprietario:", "Proprietario", "Proprietário:", "Proprietário"))
        if not nome_documento:
            return "NOME NÃO INFORMADO"

        # Normaliza e remove caracteres especiais
        nome_documento = nome_documento.replace("&", "").strip()
        return nome_documento
    
    # ----- Exibição das regras no PDF  -----

    def exibir_regras_doc(self, regras: Mapping[str, str]) -> list[list[str]]:    
        base: dict[str,str] = {
            "numero_processo": self.numero_processo or "",
            "colaborador": self.colaborador or "",
            "agencia": self.agencia or "",
            "responsavel": self.responsavel or "",
            "valor": self.valor_documento or "",
            "periodo": self.periodo_documento or "",
            "cargo": self.cargo or "",
            "cbo": self.cbo or "",
            "empregador": self.nome_empregador or "",
            "cnpj_empregador": self.cnpj_empregador or "",
            "contador": self.contador or "",
            "crc_contador": self.crc_contador or "",
            "aposentadoria": self.aposentadoria or "",
        }
        return self.comprovantes.exibir_regras(regras=regras, placeholders=base)
    
    def _resolver_placeholders_pareceres(self):
        """Substitui placeholders nos pareceres padrão usando o motor da planilha."""
        pareceres = getattr(self.comprovantes, "parecer_padrao", None)
        if not pareceres:
            return
        base: dict[str,str] = {
            "numero_processo": self.numero_processo or "",
            "colaborador": self.colaborador or "",
            "agencia": self.agencia or "",
            "responsavel": self.responsavel or "",
            "valor": self.valor_documento or "",
            "periodo": self.periodo_documento or "",
            "cargo": self.cargo or "",
            "cbo": self.cbo or "",
            "empregador": self.nome_empregador or "",
            "cnpj_empregador": self.cnpj_empregador or "",
            "contador": self.contador or "",
            "crc_contador": self.crc_contador or "",
            "aposentadoria": self.aposentadoria or "",
        }
        novo = {}
        for tipo, texto in pareceres.items():
            novo[tipo] = self.comprovantes.fill_template(texto, base)

        self.comprovantes.parecer_padrao = novo


    def build_output(
        self,
        *,
        status_geral: bool = True,
        mensagem: str | None = None,
        resultados_docs: list[dict] | None = None,
    ) -> dict:
        """
        Monta a estrutura padronizada de saída de qualquer validador.
        Retorna resultados por documento e seção consolidada.
        """
        self._resolver_placeholders_pareceres()
        self._preparar_campos_comuns()

        saida = {
            "tipo_documento": getattr(self, "type_name", None),
            "status_geral": status_geral,
            "mensagem": mensagem or "Extração concluída com sucesso.",
            "documentos": resultados_docs or [],  # 🔹 status por arquivo individual
            "sections": getattr(self, "sections", []),  # 🔹 section única consolidada
            "header_info": getattr(self, "header_info", {}),
            "campos_mua": getattr(self, "campos_no_mua", {}),
            "cnpjs_consultados": getattr(self.apis, "cnpjs_consultados", []),
            "contadores_consultados": getattr(self.apis, "contadores_consultados", []),
            "referencias": {
                "pessoa": getattr(self, "nome_normalizado", None),
                "cnpj": getattr(self, "cnpj_associado", None),
            },
        }
        
        self.log.debug(f"Saída do validador ({self.type_name}) -> {saida}")
        
        return saida