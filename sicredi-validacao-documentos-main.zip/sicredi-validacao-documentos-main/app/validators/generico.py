# app/utils/criador_de_validador.py
from app.validators.base import ValidadorBase
from app.utils.helpers import organize_data
from app.validators.base import ValidadorBase

class ValidadorGenerico(ValidadorBase):
    def validar(self) -> bool:
        self.log.info("Iniciando validação genérica")
        # 1) Cabeçalho da seção
        lista_docs = self.lista
        if not lista_docs:
            return self.build_output(status_geral=False, mensagem="Nenhum documento de CRLV encontrado.")
        resultados = []
        for doc in lista_docs:
            self.doc = self.extrair_valor(doc, False, "dados", "dados:")
            self.context = self.extrair_valor(doc, False, "context", "context:")
            self.file = self.extrair_valor(doc, False, "arquivo", "arquivo:")
            try:
                status_doc = self.validar_arquivo_individual()
            except Exception as e:
                self.log.error(f"Erro ao validar '{self.file}': {e}")
                status_doc = False

            resultados.append({
                "arquivo": self.file,
                "status": status_doc,
                "mensagem": "Validação concluída com sucesso." if status_doc else "Falha na validação.",
                "dados_extraidos": self.doc,
                "context": self.context
            })

        # Status geral: se ao menos um documento validou com sucesso
        status_geral = any(r["status"] for r in resultados)

        return self.build_output(
            status_geral=status_geral,
            resultados_docs=resultados
        )

    
    def validar_arquivo_individual(self):
        self.nome_documento = self.extrair_nome_documento(self.doc)

        linhas = [["Documento lido:", self.file]] +  organize_data(self.doc, self.doc_type)
        linhas.append([])
        # 2) Exibição dos dados do documento (igual ao genérico, via organize_data)
        #    O organize_data já trata dict/list/None e normaliza chaves/valores.
        regras = {}
        if getattr(self, "regras_mua", None):
            nomes_auto = [self.doc_type, self.type_name]
            regras = self.regras_mua.get_doc(nomes_auto) # busca no Excel

        linhas_regras = self.exibir_regras_doc(regras)
        if linhas_regras:
            linhas.append(["Campos no MUA:", ""])
            linhas.extend(linhas_regras)
        row = self._nome_validation_row()
        if row:
            linhas.append(row)

        linhas.append([])
        #linhas.append(["Validação:", "Nenhuma validação definida para esse documento. Revisar manualmente."])
        self.sections.append((self.type_name.upper(), linhas))
        self.log.info("Validação GENÉRICA FINALIZADA.")
        return True
 