# Auto-importa tudo em app/validators/documentos/ para registrar os validadores
import pkgutil, importlib
from . import documentos as _documentos

for _m in pkgutil.iter_modules(_documentos.__path__):
    importlib.import_module(f"{_documentos.__name__}.{_m.name}")
