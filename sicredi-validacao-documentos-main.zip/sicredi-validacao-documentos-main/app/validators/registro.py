# app/validators/registro.py
from typing import Callable, Dict, Type, Optional
from app.validators.base import ValidadorBase
from app.utils.helpers import normalize  # <<< use sua normalize
from typing import Any, Dict, Optional
import app.validators  # autoimport dos documentos via app/validators/__init__.py
from app.validators.generico import ValidadorGenerico 

_REGISTRO: Dict[str, Type[ValidadorBase]] = {}

def registrar_validador(*chaves: str):
    def deco(cls: Type[ValidadorBase]) -> Type[ValidadorBase]:
        for chave in chaves:
            k = normalize((chave or "").strip()).lower()
            if k:
                _REGISTRO[k] = cls
        return cls
    return deco

def obter_validador_por_tipo(type_name: str) -> Optional[Type[ValidadorBase]]:
    if not type_name:
        return None
    key = normalize(type_name).lower()

    # 1) match exato
    if key in _REGISTRO:
        return _REGISTRO[key]

    # 2) match por “contém” (ex.: "holerite - fev/2025")
    for k, cls in _REGISTRO.items():
        if k in key:
            return cls
    return None

def criar_validador(
    *,
    doc_type: str,
    data: Dict[str, Any],
    type_name: str,
    process_info: Dict[str, Any],
    numero_processo: Optional[str] = None,
    planilha_regras: Any = None,               
) -> ValidadorBase:
    ValidadorClasse = obter_validador_por_tipo(type_name) or ValidadorGenerico
    inst = ValidadorClasse(
        doc_type=doc_type,
        data=data,
        type_name=type_name,
        process_info=process_info,
        numero_processo=numero_processo,
        planilha_regras=planilha_regras,   
    )
    return inst