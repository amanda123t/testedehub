"""
PDF/ Image reader using Azure OCR
"""

from os import getenv
from io import BytesIO
import unicodedata
from azure.core.credentials import AzureKeyCredential
from azure.ai.formrecognizer import DocumentAnalysisClient
from ssl import SSLError
from typing import List, Dict, Optional, Any, Iterable, Tuple
from azure.core.exceptions import ServiceRequestError, HttpResponseError
import time, random, os, tempfile, re
from collections import defaultdict
import statistics
import fitz  # PyMuPDF
from app.utils.helpers import normalize
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Semaphore
import atexit

AZURE_GLOBAL = Semaphore(int(os.getenv("MAX_AZURE_TRAVA", "8")))
_OCR_WORKERS = int(os.getenv("MAX_OCR_POR_PROCESS", "8"))
OCR_POOL = ThreadPoolExecutor(max_workers=_OCR_WORKERS)
#cinto de segurança
atexit.register(lambda: OCR_POOL.shutdown(wait=False))
from app.utils.logger import LoggerManager

def _looks_value(s: str) -> bool:
    VAL_RE = re.compile(r'^(R\$)?\s*[\(\-]?\s*\d{1,3}(\.\d{3})*,\d{2}\s*(DB|CR)?\s*\)?$')
    return bool(VAL_RE.match(s.strip()))

def _join_tokens(tokens):
    # Junta tokens com espaço simples, preservando ordem visual
    return " ".join(t for t in tokens if t and t.strip())

def _is_val(s: str) -> bool:
    if not s: 
        return False
    s = s.strip()
    # R$ opcional; números com . milhar e , centavos; admite parênteses/DB/CR
    return bool(re.match(r'^(R\$)?\s*[\(\-]?\s*\d{1,3}(\.\d{3})*,\d{2}\s*(DB|CR)?\s*\)?$', s))

# 1) helpers de normalização
def _norm_no_space(s: str) -> str:
    s = unicodedata.normalize("NFKD", s).encode("ASCII","ignore").decode("ASCII")
    return re.sub(r"\s+", "", s).upper()

VAL_ONLY = re.compile(r'^[\(\)0-9\.\, \-]+$')  # ex.: "0,00", "(242.716,57)"

def filter_out_dre_items(items):
    # (opcional) filtro pós-itens
    BAD_NORMS = []  

    out = []
    for it in items:
        nome = (it.get("Nome","") or "").strip()
        nome_norm = _norm_no_space(nome)
        if not nome or VAL_ONLY.match(nome):
            continue
        if any(b in nome_norm for b in BAD_NORMS):
            continue
        out.append(it)
    return out

class FileReader:
    def __init__(self):
        endpoint = getenv('AZURE_ENDPOINT', '')
        chave1 = getenv('AZURE_KEY', 'azure_key')
        credential = AzureKeyCredential(chave1)
        self.azure_document_analysis_client = DocumentAnalysisClient(
            endpoint, credential
        )
        self.log = LoggerManager(__name__)  # logger do módulo (task)

    def extract(self, file_path: str) -> str:
        #text = self.__extract_from_pdf(pdf_path=file_path)
        #if len(text.strip()) > 450:
        #    return text

        return self.__extract_from_image(pdf_path=file_path)

    def extract_from_pdf(self, pdf_path: str) -> str:
        document = fitz.open(
            pdf_path,
        )
        full_text = ''

        # Extract text from each page
        for page_num in range(len(document)):
            page = document.load_page(page_num)
            full_text += page.get_text()

        full_text = unicodedata.normalize('NFKC', full_text)

        return full_text

    def score_text_quality(self, text: str, expected_min_chars: int = 0) -> float:
        """
        Score 0..1 (maior é melhor) usando apenas heurísticas gerais:
        - proporção de caracteres válidos
        - taxa de 'combining marks' (acentos soltos)
        - densidade de pontuação
        - proporção de palavras de 1 caractere (fragmentação)
        - presença de stopwords PT (sinal de texto legível)
        - (opcional) tamanho relativo vs expected_min_chars
        """
        if not text:
            return 0.0

        # NÃO chama clean_text_ocr automaticamente para te dar liberdade de comparar
        bruto = text
        t = unicodedata.normalize("NFKC", text)
        t = t.replace("\u00ad", "")
        t = re.sub(r"[\u200b-\u200f\u202a-\u202e]", "", t)
        t = re.sub(r"[ \t]{2,}", " ", t)
        n = max(1, len(t))

        # 1) caracteres “ok” (letras/dígitos/esp/pontuação comum)
        ruins = re.findall(r"[^\w\s\.,;:%/\-()$€R\$ºª°&+]", t, flags=re.UNICODE)
        porc_ruins = min(1.0, len(ruins) / n)

        # 2) combining marks (acentos soltos indicam OCR ruim)
        combining = sum(1 for ch in unicodedata.normalize("NFD", bruto) if unicodedata.combining(ch))
        porc_comb = min(1.0, combining / max(1, len(bruto)))

        # 3) densidade de pontuação (muito alta → ruído)
        punct = len(re.findall(r"[^\w\s]", t))
        dens_punct = min(1.0, punct / n)

        # 4) fragmentação: palavras de 1 caractere (exclui dígitos)
        tokens = re.findall(r"\b\w+\b", t)
        tt = max(1, len(tokens))
        one_char = sum(1 for w in tokens if len(w) == 1 and not w.isdigit())
        porc_one = min(1.0, one_char / tt)

        # 5) stopwords PT genéricas (não dependem de tipo de documento)
        STOP_PT = {
            "de","da","do","em","para","por","com","ao","a","o","os","as","e","ou",
            "que","um","uma","no","na","nos","nas","se","não","dos","das","sua","seu",
            "este","esta","essa","isso","isto","ele","ela","eles","elas","nosso","nossa"
        }
        hits_stop = sum(1 for w in tokens[:min(2000, tt)] if w.lower() in STOP_PT)
        porc_stop = min(1.0, hits_stop / max(1, min(400, tt)))  # janela limitada

        # 6) tamanho relativo (apenas pondera se informado)
        comp_rel = 1.0 if expected_min_chars <= 0 else min(1.0, len(t) / expected_min_chars)

        # Combinação (ajuste empírico estável e genérico)
        score = (
            0.42 * porc_stop +           # mais stopwords → mais “português real”
            0.23 * comp_rel +            # quanto mais próximo do esperado, melhor
            0.35 * (1.0 - min(1.0,       # penalização de ruídos
                0.7*porc_ruins + 0.6*porc_comb + 0.5*dens_punct + 0.4*porc_one))
        )

        # clamp 0..1
        return max(0.0, min(1.0, score))
    
    #retry com backoff e jitter para a chamada Azure
    def _analyze_png_with_retry(self, png_bytes: bytes, max_attempts: int = 5):
        attempt = 1
        while True:
            try:
                # <<< AQUI: limite global *antes* da chamada à Azure >>>
                with AZURE_GLOBAL:
                    poller = self.azure_document_analysis_client.begin_analyze_document(
                        'prebuilt-layout', document=BytesIO(png_bytes)
                    )
                    return poller.result()
            except (ServiceRequestError, HttpResponseError, SSLError, ConnectionError, TimeoutError) as e:
                if attempt >= max_attempts:
                    raise
                # se houver Retry-After, respeite
                retry_after = None
                try:
                    retry_after = getattr(getattr(e, "response", None), "headers", {}).get("Retry-After")
                except Exception:
                    pass
                if retry_after:
                    sleep_s = float(retry_after)
                else:
                    sleep_s = min(6.0, 1.5 * (2 ** (attempt - 1))) * (1 + 0.2 * random.random())
                self.log.error(f"[retry-azure] tentativa {attempt}/{max_attempts} falhou: {e}. nova tentativa em {sleep_s:.1f}s")
                time.sleep(sleep_s)
                attempt += 1
                
    def __extract_from_image(self, pdf_path: str) -> str:
        # Helper: calcula matrix respeitando um teto de pixels no maior lado
        def _matrix_for_page(page, target_dpi, max_px=8000):
            # tamanho da página em pontos (72 dpi)
            w_pt, h_pt = page.rect.width, page.rect.height
            max_side_pt = max(w_pt, h_pt)
            # escala em relação a 72dpi
            scale_dpi = target_dpi / 72.0
            # se estourar max_px, reduza a escala
            max_allowed_scale = max_px / max_side_pt
            scale = min(scale_dpi, max_allowed_scale)
            return fitz.Matrix(scale, scale)

        # Tenta uma lista de dpis com teto de pixels (evita “dimensão do documento”)
        dpi_trials = [300, 240, 200, 150]
        full_text = []

        try:
            doc = fitz.open(filename=pdf_path)
            for idx, page in enumerate(doc, start=1):
                page_text = ''
                last_err = None

                for dpi in dpi_trials:
                    try:
                        mat = _matrix_for_page(page, target_dpi=dpi, max_px=8000)
                        pix = page.get_pixmap(matrix=mat, alpha=False)
                        with BytesIO() as buf:
                            # PNG normalmente é ok; se quiser reduzir tamanho, pode usar JPEG:
                            # pix.pil_save(buf, format='jpeg', optimize=True, quality=85)
                            pix.pil_save(buf, format='png')
                            buf.seek(0)
                            result = self._analyze_png_with_retry(buf.getvalue())

                        page_text = '\n'.join(l.content for l in (result.pages[0].lines if result.pages else []))
                        break  # sucesso: sai do loop de tentativas desta página

                    except (ServiceRequestError, HttpResponseError, SSLError, ConnectionError, TimeoutError) as net_e:
                        last_err = net_e
                        self.log.error(f"⚠ Rede/SSL na pág {idx} (dpi={dpi}): {net_e}. Tentando próximo dpi...")
                        continue
                    except Exception as e:
                        # Se for erro típico de dimensão/tamanho, tentar reduzir dpi
                        last_err = e
                        msg = str(e).lower()
                        if "dimension" in msg or "size" in msg or "too large" in msg or "image" in msg:
                            self.log.error(f"⚠ Dimensão/tamanho na pág {idx} (dpi={dpi}). Diminuindo dpi...")
                            continue
                        else:
                            self.log.error(f"⚠ Erro inesperado na pág {idx} (dpi={dpi}): {e}. Tentando próximo dpi...")
                            continue

                if not page_text:
                    self.log.error(f"⚠ Falha ao extrair pág {idx} de {pdf_path} após {len(dpi_trials)} tentativas. Último erro: {last_err}")
                    full_text.append(f"[ERRO_OCR_PAGINA_{idx}]")
                else:
                    full_text.append(page_text)

        except AttributeError as attribute_error:
            self.log.error(attribute_error)
            return ''
        except Exception as e1:
            self.log.error(f"⚠ Erro no OCR do arquivo {pdf_path}: {e1}")
            return '\n'.join(full_text) if full_text else ''
        return '\n'.join(full_text)

    def _is_valor_ou_linha_numerica(self, linha: str) -> bool:
        return bool(re.search(r"\d", linha))

    def renomear_campos_duplicados(self, contexto: str) -> str:
        contexto = (contexto or "").upper().strip()
        linhas = contexto.splitlines()
        contador = defaultdict(int)
        novas_linhas = []
        for linha in linhas:
            ls = linha.strip()
            if ls and not self._is_valor_ou_linha_numerica(ls):
                contador[ls] += 1
                if contador[ls] > 1:
                    ls = f"{ls}({contador[ls]})"
            novas_linhas.append(ls)
        return "\n".join(novas_linhas)

    def recortar_context(self, context: str, tipo: str):
        original = context or ""
        if not original.strip():
            return original, False

        # Palavras-chave (dentro da função, para não poluir módulo)
        palavras_dre = [
            "DEMONSTRAÇÃO DO RESULTADO DO EXERCÍCIO","DEMONSTRACAO DO RESULTADO DO EXERCICIO",
            "DEMONSTRAÇÃO DE RESULTADOS","DEMONSTRACAO DE RESULTADOS",
            "DEMONSTRATIVO DE RESULTADOS","DEMONSTRATIVO DO RESULTADO",
            "RENDA OPERACIONAL BRUTA","RECEITA OPERACIONAL BRUTA","RECEITA BRUTA",
            "LUCRO LÍQUIDO DO EXERCÍCIO","LUCRO LIQUIDO DO EXERCICIO"
        ]
        palavras_balanco = [
            "BALANÇO PATRIMONIAL","BALANCO PATRIMONIAL","BALANÇO","BALANCO",
            "ATIVO CIRCULANTE","ATIVO NÃO CIRCULANTE","ATIVO NAO CIRCULANTE",
            "PASSIVO CIRCULANTE","PASSIVO NÃO CIRCULANTE","PASSIVO NAO CIRCULANTE",
            "PATRIMÔNIO LÍQUIDO","PATRIMONIO LIQUIDO","PATRIMÔNIO","PATRIMONIO"
        ]

        def tem_cabecalho(txt: str) -> bool:
            # aceita Empresa:, CNPJ, C.N.P.J, NIRE com ou sem dois pontos
            return bool(re.search(r"(EMPRESA\s*:|C\.?N\.?P\.?J\s*:?|NIRE\s*:?)", txt, flags=re.IGNORECASE))

        t = (tipo or "").lower()
        up = original.upper()

        try:
            # ============================================================
            # 1) COM \f: recorte por página (mais assertivo quando disponível)
            # ============================================================
            if "\f" in original:
                paginas_up = original.upper().split("\f")
                paginas    = original.split("\f")

                def encontra_pagina(palavras):
                    for i, pag in enumerate(paginas_up):
                        for p in palavras:
                            if re.search(rf"\b{re.escape(p)}\b", pag, flags=re.IGNORECASE):
                                return i
                    return -1

                if "balance" in t:
                    pag_dre = encontra_pagina(palavras_dre)
                    if pag_dre == -1:
                        return original, False
                    recorte = "\f".join(paginas[:pag_dre])
                    if tem_cabecalho(recorte):
                        return recorte, True
                    return original, False

                if "dre" in t:
                    pag_dre = encontra_pagina(palavras_dre)
                    if pag_dre == -1:
                        return original, False
                    pag_bal = encontra_pagina(palavras_balanco)
                    fim = pag_bal if (pag_bal != -1 and pag_bal > pag_dre) else len(paginas)
                    recorte = "\f".join(paginas[pag_dre:fim])
                    if tem_cabecalho(recorte):
                        return recorte, True
                    return original, False

                return original, False

            # ============================================================
            # 2) SEM \f: recorte por posição global + reforço de cabeçalho
            # ============================================================
            patt_dre = re.compile("|".join(rf"\b{re.escape(p)}\b" for p in palavras_dre), re.IGNORECASE)
            patt_bal = re.compile("|".join(rf"\b{re.escape(p)}\b" for p in palavras_balanco), re.IGNORECASE)

            m_dre = patt_dre.search(up)
            m_bal = patt_bal.search(up)

            if "balance" in t:
                if m_dre:
                    ini, fim = 0, m_dre.start()
                else:
                    ini, fim = 0, len(original)

            elif "dre" in t:
                if not m_dre:
                    return original, False
                ini = m_dre.start()
                fim = m_bal.start() if (m_bal and m_bal.start() > ini) else len(original)

            else:
                return original, False

            recorte = original[ini:fim]

            # Cabeçalho presente? ok
            if tem_cabecalho(recorte):
                return recorte, True

            # Cabeçalho ausente: procurar CNPJ antes do ponto de corte e puxar 5 linhas acima
            patt_cnpj = re.compile(r"C\.?N\.?P\.?J", re.IGNORECASE)
            ultimo = None
            for m in patt_cnpj.finditer(original, 0, max(0, ini)):
                ultimo = m

            if ultimo:
                pos = ultimo.start()
                # sobe 5 quebras de linha
                linhas = 0
                new_start = 0
                for i in range(pos - 1, -1, -1):
                    if original[i] == "\n":
                        linhas += 1
                        if linhas >= 5:
                            new_start = i + 1
                            break
                recorte2 = original[new_start:fim]
                if tem_cabecalho(recorte2):
                    return recorte2, True

            # Se nada deu certo, devolve o original
            return original, False

        except Exception:
            # Qualquer erro → texto original
            return original, False

    def texto_por_pagina_threaded(self, caminho_arquivo: str, qtde_paginas: int | None = None, qtde_caracteres_por_pagina: int = 300, preferencia_ocr: bool = False) -> list[str]:
        """
        Extrai texto do PDF página por página, em paralelo, e retorna LISTA [p1, p2, ...].
        Fluxo: tenta texto nativo (page.get_text); se vazio, faz OCR apenas daquela página via self.extract,
        protegendo a chamada com o semáforo global AZURE_GLOBAL.
        """
        if not caminho_arquivo.lower().endswith(".pdf"):
            raise ValueError("Somente PDFs são suportados.")

        # Quantas páginas processar
        try:
            with fitz.open(caminho_arquivo) as _doc:
                total = _doc.page_count
        except Exception:
            total = 1
        n_pages = total if qtde_paginas is None else max(0, min(total, int(qtde_paginas)))
        if n_pages <= 0:
            return []

        # helper interno: extrai UMA página
        def _extrair_uma_pagina(idx: int) -> tuple[int, str]:
            if not preferencia_ocr:
                # 1) tenta texto nativo
                try:
                    with fitz.open(caminho_arquivo) as doc:
                        page = doc.load_page(idx)
                        txt = (page.get_text() or "").strip()
                        if txt and len(txt) > qtde_caracteres_por_pagina:
                            return idx, txt
                except Exception:
                    pass

            # 2) fallback OCR só desta página (PDF temporário de 1 página)
            one = fitz.open()
            tmp_path = None
            try:
                with fitz.open(caminho_arquivo) as doc:
                    one.insert_pdf(doc, from_page=idx, to_page=idx)
                fd, tmp_path = tempfile.mkstemp(suffix=".pdf"); os.close(fd)
                one.save(tmp_path)
            finally:
                try: one.close()
                except: pass

            ocr_txt = ""
            try:
                ocr_txt = (self.extract(tmp_path) or "").strip()
            except Exception:
                ocr_txt = ""
            finally:
                if tmp_path:
                    try: os.remove(tmp_path)
                    except: pass

            return idx, ocr_txt

        # executa em threads com limite por documento
        resultados: dict[int, str] = {}

        # executa em threads com limite por documento (fan-out controlado pelo OCR_POOL global)
        trabalhos = []
        for i in range(n_pages):
            trabalhos.append(OCR_POOL.submit(_extrair_uma_pagina, i))

        resultados: dict[int, str] = {}
        for fut in trabalhos:
            try:
                idx, texto = fut.result()
            except Exception:
                # opcional: logar a página que falhou
                idx, texto = -1, ""
            if idx >= 0 and len(texto) > 20:
                resultados[idx] = texto

        # retorna em ordem
        return [resultados.get(i, "") for i in range(n_pages)]

    def extract_tables_from_pdf(self, pdf_path: str) -> List[Dict[str, Any]]:
        """
        Extrai todas as TABELAS do PDF (todas as páginas) usando prebuilt-layout.
        Retorna uma lista com dicts por tabela: {page, row_count, column_count, cells: [[...]]}
        As 'cells' vêm normalizadas linha-a-linha (row, col).
        """
        tables_all: List[Dict[str, Any]] = []
        mat = fitz.Matrix(300/72, 300/72)  # 300dpi
        doc = fitz.open(filename=pdf_path)

        for idx, page in enumerate(doc, start=1):
            # render -> PNG -> Azure
            pix = page.get_pixmap(matrix=mat)
            with BytesIO() as buf:
                pix.pil_save(buf, format="png")
                buf.seek(0)
                result = self._analyze_png_with_retry(buf.getvalue())

            if not result or not getattr(result, "tables", None):
                continue

            # Normaliza as tables do Azure em grade [linhas][colunas]
            for t in result.tables:
                # cria matriz vazia
                rows = t.row_count or 0
                cols = t.column_count or 0
                grid = [["" for _ in range(cols)] for _ in range(rows)]
                for cell in t.cells or []:
                    r = getattr(cell, "row_index", 0)
                    c = getattr(cell, "column_index", 0)
                    txt = (cell.content or "").strip()
                    grid[r][c] = txt
                tables_all.append({
                    "page": idx,
                    "row_count": rows,
                    "column_count": cols,
                    "cells": grid
                })
        return tables_all

    @staticmethod
    def map_table_columns(table: Dict[str, Any]) -> Dict[str, int]:
        """
        Descobre índices de colunas por cabeçalho aproximado.
        Ex.: {"referencia": 2, "proventos": 3, "descontos": 4}
        """
        if not table.get("cells"):
            return {}
        header = table["cells"][0]  # primeira linha como cabeçalho

        colmap = {}
        for i, h in enumerate(header):
            H = normalize(h).upper()
            if any(k in H for k in ["REF", "REFER", "BASE", "QTDE", "QTD", "HORAS", "%"]):
                colmap["referencia"] = i
            elif any(k in H for k in ["PROVENT", "VENCIM", "CREDITO"]):
                colmap["proventos"] = i
            elif any(k in H for k in ["DESCON", "DEDU"]):
                colmap["descontos"] = i
            elif any(k in H for k in ["RUBRICA", "EVENTO", "DESCR", "NOME"]):
                colmap["descricao"] = i
            elif any(k in H for k in ["VALOR", "TOTAL", "SALDO", "DEBITO", "CRÉDITO", "CREDITO"]):
                colmap["valor"] = i
        return colmap

    @staticmethod
    def iterate_items_from_table(table: Dict[str, Any]) -> List[Dict[str, str]]:
        """
        Lê a tabela normalizada e devolve itens [{Nome, Valor:, Tipo}], já
        usando a coluna PROVENTOS/ DESCONTOS. Se só houver uma, assume PROVENTOS.
        """
        cells = table.get("cells") or []
        if len(cells) < 2:
            return []

        header_map = FileReader.map_table_columns(table)
        out: List[Dict[str, str]] = []
        for row in cells[1:]:
            nome = (row[header_map.get("descricao", 0)] if row else "").strip()
            val_prov = row[header_map["proventos"]] if "proventos" in header_map and header_map["proventos"] < len(row) else ""
            val_desc = row[header_map["descontos"]] if "descontos" in header_map and header_map["descontos"] < len(row) else ""
            val = (val_prov or val_desc or "").strip()
            if not nome or not val:
                continue
            # normaliza formato "R$ x.xxx,yy"
            if "," in val and not val.startswith("R$"):
                val = f"R$ {val}"
            out.append({
                "Nome": nome,
                "Valor:": val,
                "Tipo": "Desconto" if val_desc else "Provento"
            })
        return out
    
    @staticmethod
    def iterate_balance_items_from_table(table: dict) -> list[dict[str, str]]:
        """
        Interpreta tabelas de Balanço em formatos comuns:
          - 4 colunas: [nome_ativo, valor_ativo, nome_passivo, valor_passivo]
          - 2 colunas: [nome, valor] (lado único na página)
        Retorna [{Nome, Valor:, Tipo}] com Tipo = "Ativo"/"Passivo" quando possível.
        """
        cells = table.get("cells") or []
        if len(cells) < 2:
            return []

        out: list[dict[str, str]] = []
        cols = len(cells[0])

        def emit(nome: str, val: str, tipo: str):
            nome = (nome or "").strip()
            val = (val or "").strip()
            if not nome or not val:
                return
            if "," in val and not val.startswith("R$"):
                val = f"R$ {val}"
            out.append({"Nome": nome, "Valor:": val, "Tipo": tipo})

        if cols >= 4:
            # Par a par: (0,1) = Ativo; (2,3) = Passivo
            for row in cells[1:]:
                la = row[0] if len(row) > 0 else ""
                va = row[1] if len(row) > 1 else ""
                lp = row[2] if len(row) > 2 else ""
                vp = row[3] if len(row) > 3 else ""

                if la and _is_val(va): emit(la, va, "Ativo")
                if lp and _is_val(vp): emit(lp, vp, "Passivo")

        elif cols == 2:
            # Duas colunas: assume descrição + valor
            for row in cells[1:]:
                ln = row[0] if len(row) > 0 else ""
                vv = row[1] if len(row) > 1 else ""
                if ln and _is_val(vv):
                    # Heurística leve: se linha contém palavras de passivo/PL, marca como Passivo, senão Ativo
                    L = normalize(ln).upper()
                    tipo = "Passivo" if any(k in L for k in ["PASSIVO","OBRIGACOES","FORNECEDOR","PATRIMONIO"]) else "Ativo"
                    emit(ln, vv, tipo)

        return out

    def extract_balance_items_two_columns(self, pdf_path: str, y_tol: float = 2.5):
        # termos que disparam o corte (sem espaços)
        DRE_KEYS = [
            #"DEMONSTRAÇÃODORESULTADODOEXERCÍCIO","DEMONSTRACAODORESULTADODOEXERCICIO",
            "DEMONSTRAÇÃODERESULTADOS","DEMONSTRACAODERESULTADOS",
            "DEMONSTRATIVODERESULTADOS","DEMONSTRATIVODORESULTADO",
            "RENDAOPERACIONALBRUTA","RECEITAOPERACIONALBRUTA","RECEITABRUTA"
        ]
        DRE_KEYS_NORM = [_norm_no_space(k) for k in DRE_KEYS]
        DRE_KEYS_SET = set(DRE_KEYS_NORM)

        doc = fitz.open(pdf_path)
        items = []
        found_stop_in_this_page = False
        for page in doc:
            # === 1) palavras (com bbox) e linhas visuais
            words = page.get_text("words")
            if not words:
                continue
            words.sort(key=lambda w: (round(w[1], 1), w[0]))

            lines = []
            current = []
            last_y = None
            for (x0, y0, x1, y1, txt, *_rest) in words:
                if not txt.strip():
                    continue
                if last_y is None or abs(y0 - last_y) <= y_tol:
                    current.append({"x0": x0, "x1": x1, "y0": y0, "txt": txt})
                    last_y = y0 if last_y is None else (last_y + y0) / 2.0
                else:
                    lines.append(current)
                    current = [{"x0": x0, "x1": x1, "y0": y0, "txt": txt}]
                    last_y = y0
            if current:
                lines.append(current)

            # === 2) detecta início do DRE (mesmo se vier E S P A Ç A D O)
            dre_y_start = None
            for ln in lines:
                ln_txt = " ".join(t["txt"] for t in ln)
                ln_norm = _norm_no_space(ln_txt)
                if any(key in ln_norm for key in DRE_KEYS_SET):
                    dre_y_start = sum(t["y0"] for t in ln) / len(ln)
                    found_stop_in_this_page = True

                    self.log.debug(f"[two-cols] DRE na y={dre_y_start:.1f}")
                    break
            # se achou DRE nesta página, já finaliza aqui (não lê as próximas páginas)
            if found_stop_in_this_page:
                break            
            # === 3) corta as linhas abaixo do DRE, se encontrado
            if dre_y_start is not None:
                lines = [ln for ln in lines if (sum(t["y0"] for t in ln) / len(ln)) < dre_y_start]
                if not lines:
                    # nada antes do DRE nesta página
                    # como achamos DRE, não devemos processar páginas seguintes
                    break

            # === 4) calcula gutter com base nos valores (acima do DRE)
            value_centers = []
            for ln in lines:
                for t in ln:
                    if _looks_value(t["txt"]):
                        cx = (t["x0"] + t["x1"]) / 2.0
                        value_centers.append(cx)
            gutter_x = statistics.median(value_centers) if value_centers else None

            # === 5) extrai pares por linha (esq=Ativo / dir=Passivo)
            i = 0
            while i < len(lines):
                ln_sorted = sorted(lines[i], key=lambda t: t["x0"])

                left_tokens, right_tokens = [], []
                if gutter_x is None:
                    left_tokens = [t["txt"] for t in ln_sorted]
                else:
                    for t in ln_sorted:
                        ((left_tokens if ((t["x0"] + t["x1"]) / 2.0) <= gutter_x else right_tokens)
                        .append(t["txt"]))

                def _emit_from_side(tokens, tipo_label: str):
                    if not tokens:
                        return None, False
                    # mesma linha
                    value_idx = None
                    for idx in reversed(range(len(tokens))):
                        if _looks_value(tokens[idx]):
                            value_idx = idx
                            break
                    if value_idx is not None:
                        nome = _join_tokens(tokens[:value_idx]).strip()
                        val  = tokens[value_idx].strip()
                        if nome and val:
                            if "," in val and not val.startswith("R$"):
                                val = f"R$ {val}"
                            return {"Nome": nome, "Valor:": val, "Tipo": tipo_label}, False
                    # próxima linha (valor sozinho)
                    if i + 1 < len(lines):
                        nxt_sorted = sorted(lines[i+1], key=lambda t: t["x0"])
                        nxt_side = []
                        if gutter_x is None:
                            nxt_side = [t["txt"] for t in nxt_sorted]
                        else:
                            for t in nxt_sorted:
                                ((nxt_side if ((t["x0"] + t["x1"]) / 2.0) <= gutter_x else nxt_side)
                                .append(t["txt"]))
                        if len(nxt_side) == 1 and _looks_value(nxt_side[0]):
                            nome = _join_tokens(tokens).strip()
                            val  = nxt_side[0].strip()
                            if nome and val:
                                if "," in val and not val.startswith("R$"):
                                    val = f"R$ {val}"
                                return {"Nome": nome, "Valor:": val, "Tipo": tipo_label}, True
                    return None, False

                left_item, use_next_l = _emit_from_side(left_tokens, "Ativo")
                if left_item: items.append(left_item)

                right_item, use_next_r = _emit_from_side(right_tokens, "Passivo")
                if right_item: items.append(right_item)

                i += 2 if (use_next_l or use_next_r) else 1

        # === 6) filtro pós-itens (qualquer sobra de DRE)
        items = filter_out_dre_items(items)

        # normalização final R$
        for it in items:
            v = it.get("Valor:", "").strip()
            if v and "," in v and not v.startswith("R$"):
                it["Valor:"] = f"R$ {v}"
        return items