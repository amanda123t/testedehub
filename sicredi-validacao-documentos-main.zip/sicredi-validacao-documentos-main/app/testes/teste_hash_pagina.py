import fitz
import hashlib
from pathlib import Path

def hash_pagina(page, dpi=150):
    """Gera uma hash visual estável para a página renderizada."""
    mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    return hashlib.sha256(pix.samples).hexdigest()

def verificar_paginas_iguais(caminho_pdf: str):
    caminho_pdf = Path(caminho_pdf)
    if not caminho_pdf.exists():
        print(f"❌ Arquivo não encontrado: {caminho_pdf}")
        return

    doc = fitz.open(caminho_pdf)
    print(f"📄 Arquivo: {caminho_pdf.name} ({doc.page_count} páginas)\n")

    hashes = {}
    repetidas = []

    for i, page in enumerate(doc, start=1):
        h = hash_pagina(page)
        print(f"Página {i:02d} → hash: {h}...")

        if h in hashes:
            print(f"⚠️ Página {i} é IDÊNTICA à página {hashes[h]}")
            repetidas.append((hashes[h], i))
        else:
            hashes[h] = i

    if repetidas:
        print("\n✅ Resultado: Há páginas repetidas!")
        for a, b in repetidas:
            print(f"→ Página {a} == Página {b}")
    else:
        print("\n✅ Resultado: Nenhuma página idêntica detectada.")

    doc.close()

# === Exemplo de uso ===
if __name__ == "__main__":
    caminho = r"C:\Users\guilherme.sette\Downloads\declaracao_matheus - comprovante_de_renda.pdf"
    verificar_paginas_iguais(caminho)
