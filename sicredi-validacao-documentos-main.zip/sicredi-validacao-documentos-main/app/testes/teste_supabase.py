from app.modules.supabase import SupabaseClient

from dateutil import parser
from datetime import datetime, timezone, timedelta


from supabase import create_client
import pandas as pd
from openpyxl import Workbook
import os

from supabase import create_client
import pandas as pd
import os
from math import ceil

url = os.getenv("SUPABASE_URL")
key = os.getenv("SUPABASE_KEY")

supabase = create_client(url, key)

TABLE = "documentos"
PAGE_SIZE = 1000

# 1️⃣ Buscar quantidade total de linhas
count_resp = supabase.table(TABLE).select("id", count="exact").execute()
total_rows = count_resp.count
print(f"Total de linhas: {total_rows}")

# 2️⃣ Paginar toda a tabela
pages = ceil(total_rows / PAGE_SIZE)
all_data = []

for page in range(pages):
    start = page * PAGE_SIZE
    end = start + PAGE_SIZE - 1
    print(f"Carregando registros {start} → {end}")

    resp = (
        supabase.table(TABLE)
        .select("*")
        .range(start, end)
        .execute()
    )

    all_data.extend(resp.data)

df = pd.DataFrame(all_data)

# 3️⃣ Função de conversão segura com format='mixed'
def format_date(col):
    if col in df.columns:
        df[col] = (
            pd.to_datetime(df[col], format="mixed", utc=True, errors="coerce")
            .dt.tz_convert("America/Sao_Paulo")
            .dt.strftime("%d/%m/%Y")
        )

format_date("created_at")
format_date("updated_at")

# 4️⃣ Gerar o XLSX final
df.to_excel("documentos.xlsx", index=False)
print("✔ Arquivo documentos.xlsx gerado com sucesso!")




'''
created_at_str = "2025-11-07 02:17:28+00"
created_at = parser.isoparse(created_at_str)  # vira um datetime com timezone UTC
print("UTC:", created_at)

# Converter para horário local (Brasil)
created_local = created_at.astimezone()
print("Local:", created_local.strftime("%d/%m/%Y %H:%M:%S"))

# Calcular quantos dias se passaram
dias = (datetime.now(timezone.utc) - created_at).days
print("Dias desde a criação:", dias)



supabase = SupabaseClient()

def main():

    # Exemplo de dado de teste
    consultas_receita = {
        "00000000000100": {
            "nome": "Empresa Teste Ltda",
            "situacao": "ATIVA"
        }
    }

    # Inserindo o registro de teste
    for cnpj, dados in consultas_receita.items():
        registro = {"cnpj": cnpj, "dados": {**dados}}
        print("Inserindo:", registro)
        supabase.insert("consultas_receita", registro)

    # Lendo o registro para confirmar
    resultado = supabase.select("consultas_receita", {"cnpj": "00000000000100"})
    print("\n🔍 Resultado encontrado no banco:")
    print(resultado)

    # Excluindo o registro de teste
    #print("\n🗑️ Removendo registro de teste...")
    #supabase.delete("consultas_receita", {"cnpj": "00000000000100"})

    print("\n✅ Teste finalizado com sucesso.")

if __name__ == "__main__":
    main()
'''