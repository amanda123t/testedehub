import os

def contar_linhas_app():
    base_path = os.path.join(os.getcwd(), "app")  # Caminho da pasta app
    ignorar_pastas = {"docs", "models"}  # Pastas a ignorar
    total_linhas = 0
    relatorio = []

    for root, dirs, files in os.walk(base_path):
        # Remove pastas que não devem ser percorridas
        dirs[:] = [d for d in dirs if d not in ignorar_pastas]

        for file in files:
            if file.endswith(".py"):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        linhas = sum(1 for _ in f)
                        total_linhas += linhas
                        relatorio.append((file_path.replace(base_path + os.sep, ""), linhas))
                except Exception as e:
                    print(f"⚠ Erro ao ler {file_path}: {e}")

    print("\n📊 RELATÓRIO DE LINHAS (somente pasta app)")
    print("-" * 60)
    for nome, qtd in sorted(relatorio, key=lambda x: x[0]):
        print(f"{nome:<60} {qtd:>6} linhas")

    print("-" * 60)
    print(f"✅ Total geral de linhas na pasta 'app' (sem docs/models): {total_linhas}\n")

if __name__ == "__main__":
    contar_linhas_app()
