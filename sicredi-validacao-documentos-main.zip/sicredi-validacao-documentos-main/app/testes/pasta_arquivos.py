import os, shutil

#pasta_mae = r"C:\caminho\para\sua\pasta_mae"

pasta_mae = r"C:\Users\guilherme.sette\Downloads\pastamae"


#Código para pegar todos arquivos das subpastas e mover para a pasta mãe, deixando todos enfileirados
for raiz, _, arquivos in os.walk(pasta_mae):
    for arquivo in arquivos:
        origem = os.path.join(raiz, arquivo)
        destino = os.path.join(pasta_mae, arquivo)

        if origem == destino:
            continue

        base, ext = os.path.splitext(arquivo)
        contador = 1
        while os.path.exists(destino):
            destino = os.path.join(pasta_mae, f"{base}_{contador}{ext}")
            contador += 1

        shutil.move(origem, destino)
