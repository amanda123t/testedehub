from app.utils.APIs.api_crc import CRC
from app.validators.base import ValidadorBase

# RODAR SEMPRE PELO TERMINAL COM python -m app.testes.test_crc

#Os dados devem ser passados em dict, contendo pelo menos um dos dados(nome, crc, cpf ou cnpj) preenchido.
#Se tiver mais de um, a API irá verificar todos caso não encontre no primeiro.
dados_contador = {"Nome": "michell Boeira Novinski", "CRC": "", "CPF": "","CNPJ": ""}

dados = CRC().get_situacao_contador(dados_contador)

if dados:
    print(f"dados: {dados}")
    #Os dados vem dentro de 'dados' e dentro de 'data'
    print((dados.get('dados')).get('data'))

breakpoint()
#No validator possui funções auxiliares para validações comuns na receita
base = ValidadorBase( #Dados falsos para iniciar a classe
    context= "",
    doc_type="",
    data={},
    file="",
    type_name="",
    process_info={},
    numero_processo="",
    planilha_regras= "",
    colaborador="",
    consultas_receita={},
    consultas_crc={} 
)


#Função para capturar os dados e checar consultas salvas na classe para evitar consultar duas vezes.

dados = base.apis.buscar_dados_crc(dados_contador)
print((dados.get('dados')).get('data'))

breakpoint()