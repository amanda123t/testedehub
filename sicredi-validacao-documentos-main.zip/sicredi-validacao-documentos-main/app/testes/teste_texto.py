
import time
from dotenv import load_dotenv
load_dotenv()

from app.modules.document_processor import DocumentsProcessor
from app.text_extractor.models.vision_ocr import GoogleOCRExtractor
from app.text_extractor.models.document_ia_ocr import DocumentAIOCRExtractor
from app.text_extractor.models.easy_ocr import EasyOCRExtractor
from app.text_extractor.models.tesseract_ocr import TesseractOCRExtractor

caminho_arquivo = r"C:\Users\guilherme.sette\Downloads\IR - MAIRA.pdf"

ocr_easy = EasyOCRExtractor()
ocr_google = GoogleOCRExtractor()
documents = DocumentsProcessor()
ocr_document_ia = DocumentAIOCRExtractor()
ocr_tesseract = TesseractOCRExtractor()

# ------------------------------
# GET TEXT
# ------------------------------
inicio_get_text = time.perf_counter()
resultado_extracao_get_text = documents.reader.pdf_text.extract_with_blocks(caminho_arquivo)
fim_get_text = time.perf_counter()

texto_get_text = resultado_extracao_get_text.text
tempo_get_text = fim_get_text - inicio_get_text

breakpoint()

# ------------------------------
# AZURE OCR
# ------------------------------
inicio_azure = time.perf_counter()
resultado_extracao_azure = documents.reader.azure_ocr.extract_with_blocks(caminho_arquivo)
fim_azure = time.perf_counter()

texto_azure = resultado_extracao_azure.text
tempo_azure = fim_azure - inicio_azure
# ------------------------------
# OCR DOCUMENT IA
# ------------------------------
inicio_document_ia = time.perf_counter()
resultado_extracao_document_ia = ocr_document_ia.extract_with_blocks(caminho_arquivo)
fim_document_ia = time.perf_counter()

texto_document_ia = resultado_extracao_document_ia.text
tempo_document_ia = fim_document_ia - inicio_document_ia
breakpoint()
# ------------------------------
# VISION OCR (GOOGLE)
# ------------------------------
inicio_google = time.perf_counter()
resultado_extracao_google = ocr_google.extract_with_blocks(caminho_arquivo)
fim_google = time.perf_counter()

texto_google = resultado_extracao_google.text
tempo_google = fim_google - inicio_google

# ------------------------------
# TESSERACT
# ------------------------------
inicio_tesseract = time.perf_counter()
resultado_extracao_tesseract = ocr_tesseract.extract_with_blocks(caminho_arquivo)
fim_tesseract = time.perf_counter()
texto_tesseract = resultado_extracao_tesseract.text
tempo_tesseract = fim_tesseract - inicio_tesseract

# ------------------------------
# EASY OCR
# ------------------------------
inicio_easy = time.perf_counter()
resultado_extracao_easy = ocr_easy.extract_with_blocks(caminho_arquivo)
fim_easy = time.perf_counter()

texto_easy = resultado_extracao_easy.text
tempo_easy = fim_easy - inicio_easy

print(f"⏱ Tempo Get text: {tempo_get_text:.2f} segundos")
print(f"⏱ Tempo Tesseract:  {tempo_tesseract:.2f} segundos")
print(f"⏱ Tempo easyOCR:  {tempo_easy:.2f} segundos")
print(f"⏱ Tempo Azure OCR:  {tempo_azure:.2f} segundos")
print(f"⏱ Tempo Google OCR: {tempo_google:.2f} segundos")
print(f"⏱ Tempo Document IA:  {tempo_document_ia:.2f} segundos")

breakpoint()

from app.text_extractor.models.textract_ocr import TextractOCRExtractor

ocr_textract = TextractOCRExtractor()

# ------------------------------
# TEXTRACT OCR BÁSICO
# ------------------------------
inicio_textract = time.perf_counter()
resultado_extracao_textract = ocr_textract.extract(caminho_arquivo)
fim_textract = time.perf_counter()

texto_textract = resultado_extracao_textract.text
tempo_textract = fim_textract - inicio_textract

breakpoint()