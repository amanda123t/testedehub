import os
import tempfile
import json
from docling.document_converter import DocumentConverter
import pandas as pd
import re, time

def extract_markdown_from_bytes(file_bytes: bytes, file_ext: str) -> str:
    with tempfile.NamedTemporaryFile(delete=False, suffix=file_ext) as tmp:
        tmp.write(file_bytes)
        tmp_path = tmp.name

    converter = DocumentConverter()
    doc = converter.convert(tmp_path)
    return doc.document.export_to_markdown()

def extract_markdown(file_path: str) -> str:
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    converter = DocumentConverter()
    doc = converter.convert(file_path)
    return doc.document.export_to_markdown()

def extract_json(file_path: str) -> str:
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    converter = DocumentConverter()
    doc = converter.convert(file_path)

    # Converte o dicionário para uma string JSON
    doc_dict = doc.document.export_to_dict()
    json_str = json.dumps(doc_dict, indent=2, ensure_ascii=False)
    return json_str

def write_md_file(markdown_output):
    with open("output.md", "w", encoding="utf-8") as f:
        f.write(markdown_output)

def write_json_file(json_output):
    with open("output.json", "w", encoding="utf-8") as f:
        f.write(json_output)

def extrair_campos_valores(df: pd.DataFrame) -> list:
    """
    Recebe um DataFrame exportado do Docling e retorna uma lista de dicionários com código, campo e valor.
    """
    resultados = []

    if df.shape[1] < 3:
        return resultados  # ignora tabelas com menos de 3 colunas

    col_codigo = df.columns[0]
    col_campo = df.columns[1]
    col_valor = df.columns[2]

    for _, row in df.iterrows():
        codigo = str(row[col_codigo]).strip()
        campo = str(row[col_campo]).strip()
        valor_raw = str(row[col_valor]).strip()
        valor = converte_valor(valor_raw)
        if campo and valor_raw:
            resultados.append({
                "codigo": codigo,
                "campo": campo,
                "valor_bruto": valor_raw,
                "valor": valor
            })

    return resultados

def formatar(valor):
    return f"{abs(valor):,.2f}".replace(".", ",")

def carregar_lista(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def extrair_campos_valores_docling_json(data: dict) -> list:
    """
    Lê os pares campo → valor diretamente do JSON estruturado Docling
    """
    resultados = []
    textos = {t["self_ref"]: t["text"] for t in data.get("texts", [])}
    
    for grupo in data.get("groups", []):
        if grupo.get("label") != "key_value_area":
            continue
        filhos = grupo.get("children", [])
        if len(filhos) < 2:
            continue

        for i in range(0, len(filhos)-1, 2):
            ref_campo = filhos[i].get("$ref")
            ref_valor = filhos[i+1].get("$ref")

            campo = textos.get(ref_campo, "").strip()
            valor_raw = textos.get(ref_valor, "").strip()
            valor = converte_valor(valor_raw)

            if campo and valor_raw:
                resultados.append({
                    "codigo": "",  # não tem código nesse tipo de estrutura
                    "campo": campo,
                    "valor_bruto": valor_raw,
                    "valor": valor
                })
    
    return resultados

def converte_valor(s: str) -> float:
    match = re.search(r"[\d\.]+,\d{2}[DC]?", s)
    if not match:
        return 0.0
    texto_valor = match.group()
    negativo = texto_valor.endswith("C")
    texto_valor = texto_valor.replace("D", "").replace("C", "").replace(".", "").replace(",", ".")
    valor = float(texto_valor)
    return -valor if negativo else valor

def extrair_texto_das_tabelas(doc_dict: dict) -> list:
    """
    Lê todas as células de todas as tabelas do Docling e retorna os textos encontrados.
    """
    textos = []
    for tabela in doc_dict.get("tables", []):
        for celula in tabela.get("cells", []):
            texto = celula.get("text", "").strip()
            if texto and texto != "<unknown>":
                textos.append(texto)
    return textos


# --- MAIN ---
if __name__ == "__main__":
    file_path = r"C:\Users\guilherme.sette\Downloads\4d57e37d.pdf"
    tempo_inicio = time.perf_counter()
    print("--- Transforming document to Markdown ---\n")
    markdown_output = extract_markdown(file_path)
    write_md_file(markdown_output)
    print("✅ Markdown content generated.\n")
    fim_processo = time.perf_counter()
    dur_total_s = round(fim_processo - tempo_inicio, 3)
    breakpoint()

    def extrair_texto_table_cells(doc_dict: dict) -> list:
        """
        Extrai os textos contidos em data["table_cells"]
        """
        textos = []
        for celula in doc_dict.get("data", {}).get("table_cells", []):
            texto = celula.get("text", "").strip()
            if texto and texto != "<unknown>":
                textos.append(texto)
        return textos

    
    # === EXECUÇÃO ===

    # Gera e salva o JSON bruto do Docling
    print("--- Transforming document to JSON ---")
    json_output = extract_json(file_path)
    write_json_file(json_output)
    print("✅ JSON content generated.")

    with open("output.json", "r", encoding="utf-8") as f:
        doc_dict = json.load(f)

    breakpoint()

    textos = extrair_texto_table_cells(doc_dict)

    print("\n--- Textos extraídos do 'data.table_cells' ---\n")
    for linha in textos:
        print(linha)

    breakpoint()
    # Textos soltos (fora das tabelas)
    textos_livres = [t["text"].strip() for t in doc_dict.get("texts", []) if t.get("text", "").strip()]

    # Textos dentro das tabelas (campos contábeis)
    textos_tabelas = extrair_texto_das_tabelas(doc_dict)

    # Unifica todos os textos visíveis
    linhas = textos_livres + textos_tabelas

    # Exibe os textos visíveis
    for linha in linhas:
        print(linha)

    
    breakpoint()

    # Extrai os campos diretamente do JSON salvo
    todos = extrair_campos_valores_docling_json(doc_dict)

    print("\n--- Campos e valores extraídos ---")
    for item in todos:
        print(f"[{item['codigo']}] {item['campo']}: {item['valor_bruto']} → {item['valor']}")

    with open("campos_extraidos.json", "w", encoding="utf-8") as f:
        json.dump(todos, f, indent=2, ensure_ascii=False)

    print("\n✅ JSON salvo como 'campos_extraidos.json'")

    breakpoint()
    