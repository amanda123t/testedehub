# compilar_registros.py
from __future__ import annotations
import os
import unicodedata
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
import pandas as pd

from app.modules.sharepoint import SharePointClient



# ----------- COLUNAS PADRÃO -----------
COLS_PROCESSOS = [
    "data", "processo", "colaborador", "data_hora_inicio", "data_hora_fim",
    "duracao_total_s", "cooperativa", "qtd_documentos", "qtd_por_tipo",
    "qtd_uso_ocr", "qtd_com_validator_false", "quantidade_consultas_receita",
    "CNPJs_consultados"
]

COLS_DOCUMENTOS = [
    "horario_lido", "processo", "arquivo", "cooperativa", "colaborador",
    "tipo", "tokens", "caracteres", "paginas", "metodo_extracao",
    "metodo_classificacao", "duracao_extracao(s)", "validou_ok",
    "contagem_validacao", "mensagem"
]


# ----------- HELPERS -----------
def normalizar_texto(s: str) -> str:
    if not isinstance(s, str):
        return ""
    s = s.strip().lower()
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = s.replace(" ", "").replace("_", "").replace("-", "")
    return s


def normalizar_colunas(df: pd.DataFrame) -> pd.DataFrame:
    df = df.rename(columns=lambda x: normalizar_texto(x))
    return df


def corresponde(parcial: str, lista_referencia: list[str]) -> bool:
    return any(parcial.startswith(normalizar_texto(ref)) for ref in lista_referencia)


def identificar_tipo_aba(df: pd.DataFrame) -> str | None:
    cols = list(df.columns)
    if sum(corresponde(c, COLS_PROCESSOS) for c in cols) >= 6:
        return "processos"
    if sum(corresponde(c, COLS_DOCUMENTOS) for c in cols) >= 6:
        return "documentos"
    return None


def formatar_datas(df: pd.DataFrame, colunas: list[str]) -> pd.DataFrame:
    """Aceita datas em AAAA-MM-DD, AAAA-MM-DD HH:MM:SS ou DD/MM/AAAA."""
    from datetime import datetime

    def _parse_data(valor):
        if pd.isna(valor):
            return pd.NA
        if isinstance(valor, datetime):
            return valor
        if isinstance(valor, (int, float)):
            return pd.to_datetime(valor, errors="coerce")
        texto = str(valor).strip()
        # tenta diferentes formatos manualmente
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
            try:
                return datetime.strptime(texto, fmt)
            except Exception:
                continue
        # fallback do pandas
        try:
            return pd.to_datetime(texto, errors="coerce", dayfirst=True)
        except Exception:
            return pd.NA

    for col in colunas:
        for c in df.columns:
            if normalizar_texto(c) == normalizar_texto(col):
                df[c] = df[c].apply(_parse_data)
                # converte tudo para dd/mm/aa
                df[c] = df[c].dt.strftime("%d/%m/%y")
    return df


def adicionar_quantidade_por_pessoa(df: pd.DataFrame):
    col_match = None
    for c in df.columns:
        if normalizar_texto(c) == "colaborador":
            col_match = c
            break
    if col_match:
        contagem = df[col_match].value_counts()
        df["quantidade_por_pessoa"] = df[col_match].map(contagem)
    else:
        df["quantidade_por_pessoa"] = pd.NA
    return df


# ----------- PRINCIPAL -----------
def main():
    load_dotenv()

    BASE_DIR = Path(__file__).resolve().parent
    OUT_DIR = BASE_DIR / "output"
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    secret = {
        "clientId": os.getenv('SHAREPOINT_CLIENT_ID'),
        "clientSecret": os.getenv('SHAREPOINT_CLIENT_SECRET'),
        "tenantId": os.getenv('SHAREPOINT_TENANT_ID'),
        "authority": os.getenv('SHAREPOINT_AUTHORITY'),
        "scope": os.getenv('SHAREPOINT_SCOPE'),
        "sharepointUrl": os.getenv('SHAREPOINT_URL')
    }

    ctx = SharePointClient(secret)
    site_id = ctx.search_sites('grupometa', 'servicos-sicredi')
    caminho_sharepoint = '06. Excelência Operacional/AUTOMACOES/cooperativas'

    coops = [c for c in (ctx.search_folder_children(site_id, caminho_sharepoint) or []) if "folder" in c]
    print(f"🔎 Cooperativas encontradas: {[c['name'] for c in coops]}")

    todos_proc, todos_doc = [], []

    for coop in coops:
        coop_name = coop["name"]
        pasta_logs = f"{caminho_sharepoint}/{coop_name}/PROCESSADOS/REGISTROS"
        print(f"\n==== COOP {coop_name} ====")
        arquivos = ctx.search_folder_children(site_id, pasta_logs) or []
        planilhas = [a for a in arquivos if a["name"].lower().endswith(".xlsx")]
        for item in planilhas:
            nome = item["name"]
            print(f"  📥 lendo {nome}")
            try:
                url = ctx.search_file_data(site_id, f"{pasta_logs}/{nome}")
                book = pd.read_excel(url, sheet_name=None, dtype=object)
                for aba, df in book.items():
                    if not isinstance(df, pd.DataFrame) or df.empty:
                        continue
                    df = normalizar_colunas(df)
                    tipo = identificar_tipo_aba(df)
                    if tipo == "processos":
                        df = formatar_datas(df, ["data_hora_inicio", "data_hora_fim"])
                        df = adicionar_quantidade_por_pessoa(df)
                        df["cooperativa"] = coop_name
                        todos_proc.append(df)
                    elif tipo == "documentos":
                        df = formatar_datas(df, ["horario_lido"])
                        df = adicionar_quantidade_por_pessoa(df)
                        df["cooperativa"] = coop_name
                        todos_doc.append(df)
            except Exception as e:
                print(f"    ⚠ erro ao ler '{nome}': {e}")

        # ------------------ CONCATENAR E SALVAR ------------------
    data_tag = datetime.now().strftime("%Y%m%d")
    out_xlsx = OUT_DIR / f"REGISTROS_COMPILADOS_{data_tag}.xlsx"

    print("\n🧩 Gerando planilha final...")
    with pd.ExcelWriter(out_xlsx, engine="openpyxl") as writer:
        # --- aba 1: Processos ---
        if todos_proc:
            processos = pd.concat(todos_proc, ignore_index=True)
        else:
            processos = pd.DataFrame(columns=COLS_PROCESSOS + ["quantidade_por_pessoa"])
        processos.to_excel(writer, index=False, sheet_name="Processos")

        # --- aba 2: Documentos ---
        if todos_doc:
            documentos = pd.concat(todos_doc, ignore_index=True)
        else:
            documentos = pd.DataFrame(columns=COLS_DOCUMENTOS + ["quantidade_por_pessoa"])
        documentos.to_excel(writer, index=False, sheet_name="Documentos")

        # --- aba 3: Ranking ---
        print("📊 Gerando aba de Ranking...")
        ranking = pd.DataFrame()

        # cria ranking de Processos
        if not processos.empty and "colaborador" in processos.columns:
            rank_proc = (
                processos.groupby("colaborador", dropna=True)
                .size()
                .reset_index(name="quantidade_processos")
            )
        else:
            rank_proc = pd.DataFrame(columns=["colaborador", "quantidade_processos"])

        # cria ranking de Documentos
        if not documentos.empty and "colaborador" in documentos.columns:
            rank_doc = (
                documentos.groupby("colaborador", dropna=True)
                .size()
                .reset_index(name="quantidade_documentos")
            )
        else:
            rank_doc = pd.DataFrame(columns=["colaborador", "quantidade_documentos"])

        # une ambos
        ranking = pd.merge(rank_proc, rank_doc, on="colaborador", how="outer").fillna(0)
        ranking["total"] = ranking["quantidade_processos"] + ranking["quantidade_documentos"]

        # ordena do maior para o menor
        ranking = ranking.sort_values(by="total", ascending=False).reset_index(drop=True)

        ranking.to_excel(writer, index=False, sheet_name="Ranking")

    print(f"\n✅ Arquivo gerado com sucesso:")
    print(f"   → {out_xlsx}")
    print(f"   • Linhas Processos: {len(todos_proc)}")
    print(f"   • Linhas Documentos: {len(todos_doc)}")
    print(f"   • Pessoas no Ranking: {len(ranking)}")



if __name__ == "__main__":
    main()
