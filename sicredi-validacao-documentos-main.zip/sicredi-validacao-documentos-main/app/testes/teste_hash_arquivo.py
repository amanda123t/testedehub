import hashlib
import fitz  # PyMuPDF
from pathlib import Path
import os 

def gerar_hash_arquivo(file_path: str) -> str:
    """
    Gera uma hash única e estável considerando:
      - bytes brutos do arquivo,
      - número de páginas,
      - bounding boxes das imagens,
      - metadados principais.
    """
    file_path = Path(file_path)
    hash_md5 = hashlib.md5()

    try:
        # 🔹 Base: bytes brutos (garante unicidade mesmo em PDFs-imagem)
        with open(file_path, "rb") as f:
            hash_md5.update(f.read())

        if file_path.suffix.lower() == ".pdf":
            doc = fitz.open(file_path)
            hash_md5.update(str(doc.page_count).encode())

            # 🔹 Acrescenta bounding boxes das imagens
            for page in doc:
                for img in page.get_images(full=True):
                    xref = img[0]
                    info = doc.extract_image(xref)
                    bbox = str(img[1:5])  # (x, y, w, h)
                    size = len(info["image"])
                    hash_md5.update(f"{bbox}-{size}".encode())

            # 🔹 Metadados (creation date, producer, etc.)
            meta = doc.metadata or {}
            meta_str = f"{meta.get('producer','')}-{meta.get('creationDate','')}-{meta.get('modDate','')}"
            hash_md5.update(meta_str.encode())

        return hash_md5.hexdigest()

    except Exception as e:
        print(f"Erro ao gerar hash: {e}")
        return None

if __name__ == "__main__":
    pasta_arquivos = r"C:\Users\guilherme.sette\Downloads\hash"  # Altere para o caminho do seu arquivo
    cache_hashes = []
    for arquivo in os.listdir(pasta_arquivos):
        caminho_arquivo = os.path.join(pasta_arquivos, arquivo)
        hash_resultado = gerar_hash_arquivo(caminho_arquivo)
        if hash_resultado:
            cache_hashes.append(hash_resultado)
            print(f"Hash do arquivo '{caminho_arquivo}': {hash_resultado}")
        else:
            print("Falha ao gerar o hash do arquivo.")

    hash1 = cache_hashes[0] if cache_hashes else None
    hash2 = cache_hashes[1] if len(cache_hashes) > 1 else None
    if hash1 and hash2:
        if hash1 == hash2:
            print("Os arquivos são idênticos (mesmo hash).")
        else:
            print("Os arquivos são diferentes (hashes distintos).")