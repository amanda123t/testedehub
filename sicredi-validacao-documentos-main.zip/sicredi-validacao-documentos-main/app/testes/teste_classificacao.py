from dotenv import load_dotenv
load_dotenv()
from app.modules.document_processor import DocumentsProcessor

from app.models.paycheck import PaycheckList

from app.modules.classifier.simple_classifier import SimpleClassifier

import os
documents = DocumentsProcessor()
simples = SimpleClassifier()
caminho =  r"C:\Users\igor.leal\Downloads\testes_extratos"

com_ia = True
classificar = True
extrair_dados = True
resultados_por_arquivo = []
import fitz

for arquivo in os.listdir(caminho):
    try:
        tipos = []
        print("-" * 40)
        print(f"Iniciando processamento do arquivo {arquivo}")
        texto = documents.reader.texto_por_pagina_threaded(os.path.join(caminho, arquivo))
        texto = texto.text
        print(f"Texto extraído do arquivo {arquivo} (primeiros 3000 caracteres):\n{texto}")
        breakpoint()
        if classificar:
            for limiar in (7, 6, 5):
                tipos = simples.classificar(texto, limiar=limiar)
                if tipos and "None" not in tipos:
                    print(f"Tipo classificado pela classificação simples: {tipos}")
                    print(f"Contagem: {simples.contagem}")
                    break
            if not tipos or 'None' in tipos or None in tipos:
                tipos = documents.classify_document_type(texto, 'GERAL')
                print(f"Tipo classificado pela IA: {tipos}")
    except Exception as e:
        print(f"Erro para o arquivo {arquivo}: {e}")
        continue
    if extrair_dados:
        from app.models.bank_statement import BankStatement
        resp = documents.extract_data(texto, BankStatement)
        dados = documents.extractor.clean_json(resp)
        print(f"Dados extraídos para o arquivo {arquivo}: {dados}")
        dict = {'arquivo': arquivo, 'texto': texto, 'tipo': tipos, 'dados': dados}
    else:
        dict = {'arquivo': arquivo, 'texto': texto, 'tipo': tipos, 'dados': ''}
    resultados_por_arquivo.append(dict)

breakpoint()
 