
from app.validators.registro import criar_validador
import os

validador = criar_validador(
        doc_type='invoice',
        data={'Faturamento': {
            'dados': {}, 
            'context': []
            }},  # 👈 recebe tudo
        type_name='Faturamento',
        process_info={"colaborador": 'Guilherme', "cooperativa": 'Teste'},
        numero_processo='1234',
        planilha_regras=os.path.join('output', 'regras.xlsx'),
    )