from app.utils.APIs.api_receita import Receita
from app.validators.base import ValidadorBase
import os

# RODAR SEMPRE PELO TERMINAL COM python -m app.testes.test_receita

cnpj = '59.619.490/0001-51'

#Chamar direto a função se quiser apenas os dados da receita
dados = Receita().get_cnpj(cnpj)

print(f"Dados da receita para o cnpj {cnpj}: {dados}")

#No validator possui funções auxiliares para validações comuns na receita
base = ValidadorBase( #Dados falsos para iniciar a classe
    doc_type="",
    data={"Holerite": {}},
    type_name="Holerite",
    process_info={},
    numero_processo="",
    planilha_regras= os.path.join("output", "REGRAS.xlsx"),
)

situacao_cnpj = base.apis.validar_situacao_cnpj(cnpj) #Retorna uma lista, cada item é uma linha, para exibição no PDF
print(f"Validação situação do CNPJ na receita:")
for linha in situacao_cnpj: print(linha)

associado = "CLAUDIA CRISTINA SOUSA MORAES" #Nome que deseja verificar se é sócio
eh_socio, dados_receita = base.apis.validar_associado_em_cnpj(cnpj, associado)
print(f"Associado encontrado como sócio?: {eh_socio}")

#Função para capturar o porte na receita (MEI, MEI CAMINHONEIRO, ME, EPP, DEMAIS)
porte_empresa = base.apis.capturar_porte_receita(cnpj)
print(f"Porte da empresa na receita: {porte_empresa}")
