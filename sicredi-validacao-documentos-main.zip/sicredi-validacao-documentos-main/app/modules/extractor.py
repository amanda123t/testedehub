from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from langchain.output_parsers import PydanticOutputParser
from pydantic import BaseModel
import time, random, os
import tiktoken

# importe seus prompts
from app.prompts.prompt_padrao import extractor
from app.prompts.prompt_balance import prompt_balance
from app.prompts.prompt_dre import prompt_dre
from app.prompts.prompt_nota_fiscal import prompt_nota_fiscal
from app.prompts.prompt_faturamento import prompt_faturamento
from app.prompts.prompt_irpf import (
    prompt_irpf_pj, 
    prompt_irpf_pf, 
    prompt_irpf_summary,
    prompt_irpf_agricultural,
    prompt_rendimentos_isentos,
    prompt_rendimentos_tributados,
    prompt_bens,
    prompt_irpf_receipt)
from app.prompts.prompt_matricula import prompt_matricula
from app.prompts.prompt_procuracao import prompt_procuracao
from app.prompts.prompt_holerite import (
    paychecks_count,
    prompt_holerite,  
)
from langfuse import Langfuse
from langfuse.langchain import CallbackHandler
from threading import Semaphore
LLM_GLOBAL = Semaphore(int(os.getenv("MAX_LLM_TRAVA", "10")))

from app.utils.logger import LoggerManager
LLM = ChatOpenAI(model='gpt-4o-mini', temperature=0)

# <Your Langchain code here>
# Add handler to run/invoke/call/chat
class DataExtractor:
    def __init__(self, api_key: str) -> None:
        self.model = LLM
        self.langfuse = Langfuse()  
        self.lf_handler = CallbackHandler() 
        self.log = LoggerManager(__name__)  # logger do módulo (task)
    # invocação com retry e backoff
    def _invoke_with_retry(self, chain, payload: dict, max_attempts: int = 5):
        attempt = 1
        while True:
            try:
                with LLM_GLOBAL:
                    return chain.invoke(payload, config={"callbacks": [self.lf_handler]})
            except Exception as e:
                if attempt >= max_attempts:
                    raise
                sleep_s = (1.5 * (2 ** (attempt - 1))) + random.random() * 0.8
                self.log.error(f"[retry-llm] tentativa {attempt}/{max_attempts} falhou: {e}. nova tentativa em {sleep_s:.1f}s")
                time.sleep(sleep_s)
                attempt += 1
    
    def extract(self, query: str, context: str, document: BaseModel) -> dict:
        parser = PydanticOutputParser(pydantic_object=document)
        model_name = getattr(document, "__name__", str(document)).upper()
        self.log.info(f"🔎 Modelo de extração encontrado: {model_name}")

        # 1) Se for Holerite, primeiro descubra quantos existem no contexto
        # 1) Se for Holerite, primeiro descubra quantos existem no contexto (já existe no seu código)
        number_of_items = "There are one item in the context"
        '''
        if "PAYCHECK" in model_name:  # cobre PAYCHECK e PAYCHECKLIST
            count_prompt = PromptTemplate(
                template=paychecks_count,
                input_variables=['query'],
                partial_variables={'context': context},
            )
            count_chain = count_prompt | self.model
            count_resp = self._invoke_with_retry(count_chain, {'query': query, 'context': context})
            number_of_items = count_resp.content
            self.log.info(f"🧮 Contagem de holerites: {number_of_items}")
        '''
        # 2) Escolha do prompt final por tipo de modelo (ADICIONE ESTE 'elif')
        if model_name == "DRE":
            base_template = prompt_dre
            self.log.info('✅ Usando prompt especializado para DRE!')
        elif "BALANCE" in model_name:
            base_template = prompt_balance
            self.log.info('✅ Usando prompt especializado para Balanço!')
        elif "NOTA_FISCAL" in model_name:
            base_template = prompt_nota_fiscal
            self.log.info('✅ Usando prompt especializado para Notas fiscais!')
        elif "PAYCHECK" in model_name:
            base_template = prompt_holerite
            self.log.info('✅ Usando prompt especializado para Holerite!')
        elif "INVOICE" in model_name:
            base_template = prompt_faturamento
            self.log.info('✅ Usando prompt especializado para Faturamento!')
        elif model_name == "INDIVIDUALFOREIGNEARNINGS":
            base_template = prompt_irpf_pf
            self.log.info('✅ Usando prompt especializado para Rendimentos PF do IRPF!')
        elif model_name == "EARNINGS":
            base_template = prompt_irpf_pj
            self.log.info('✅ Usando prompt especializado para Rendimentos PJ do IRPF!')
        elif model_name == "NONTAXABLEINCOME":
            base_template = prompt_rendimentos_isentos
            self.log.info('✅ Usando prompt especializado para os Rendimentos Isentos do IRPF!')
        elif model_name == "TAXABLEINCOME":
            base_template = prompt_rendimentos_tributados
            self.log.info('✅ Usando prompt especializado para os Rendimentos Tributados do IRPF!')
        elif model_name == "IRPFBEM":
            base_template = prompt_bens
            self.log.info('✅ Usando prompt especializado para IRPF Bens!')
        elif model_name == "IRPFOTHERS":
            base_template = prompt_irpf_summary
            self.log.info('✅ Usando prompt especializado para IRPF Resumo!')
        elif "RECEIPT" in model_name:
            base_template = prompt_irpf_receipt
            self.log.info('✅ Usando prompt especializado para Recibo IRPF!')
        elif "PROCURACAO" in model_name:
            base_template = prompt_procuracao
            self.log.info('✅ Usando prompt especializado para Procuração!')
        elif "PROPERTYREGISTRATION" in model_name:
            base_template = prompt_matricula
            self.log.info('✅ Usando prompt especializado para Matrícula!')
        elif "AGRICULTURAL" in model_name:
            base_template = prompt_irpf_agricultural
            self.log.info('✅ Usando prompt especializado para Renda AGRO do IRPF!')
        else:
            base_template = extractor
            self.log.info('✅ Usando prompt padrão!')

        # 3) partials dinâmicos (já está no seu código) – mantém {number_of_items} quando existir no template
        partials = {
            'format_instructions': parser.get_format_instructions(),
            'context': context,
        }
        if '{number_of_items}' in base_template:
            partials['number_of_items'] = number_of_items

        prompt = PromptTemplate(
            template=base_template,
            input_variables=['query'],
            partial_variables=partials,
        )
        chain = prompt | self.model
        response = self._invoke_with_retry(chain, {'query': query})
        return response.content
    
    def contar_tokens(self, texto, modelo="gpt-4o-mini"):
        try:
            enc = tiktoken.encoding_for_model(modelo)
        except Exception:
            try:
                enc = tiktoken.get_encoding("cl100k_base")
            except Exception:
                return 0
        return len(enc.encode(texto or 0))
    
    def clean_json(self, s: str) -> str:
        if not isinstance(s, str):
            return s
        return s.replace("```json", "").replace("```", "").strip()