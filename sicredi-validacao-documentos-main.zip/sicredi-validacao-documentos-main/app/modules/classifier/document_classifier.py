"""
Classifies documents (Address, Income, IRPF, IRPF Receipt, Paycheck, ProLabore, CRLV, Property Registration) using an LLM (gpt-4o-mini) 

Attributes:
    document_content = A string that contains the document content extracted using OCR.

Methods:
    __data_output(self, doc_type): Opens example documents to help the LLM classify the input.
"""
from pathlib import Path
from langchain.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from app.prompts.documents_classifier import pf_prediction, address_validation, pj_prediction, irpf_validation,geral_prediction
from app.utils.logger import LoggerManager

log = LoggerManager(__name__)  # logger do módulo (task)
class DocumentClassifier:
    def __init__(self, api_key: str)->None:
        self.model = ChatOpenAI(model='gpt-4o-mini', temperature=0,)
        
    def get_document_type(self, process: str,document_content: str)-> str:
       
        if 'PJ' in process:
            class_name = self.__predict_pj(document_content)
        
        elif 'PF-AGRO' in process:
            #class_name = self.__predict_1_agro(document_content)
            pass
        
        if 'PF' in process:
            class_name = self.__predict_1(document_content)

            if class_name in ("Paycheck"):
                class_name = self.__predict_2(document_content)
            
            elif 'irpf' in class_name.lower():
                class_name = self.__predict_3(document_content)
        
        if 'GERAL' in process:
            class_name = self.__predict_geral(document_content)
        return class_name
    
    '''Classifies the document for PF processes'''    
    def __predict_1(self, document_content: str)-> str:
        prompt = PromptTemplate(
        template= pf_prediction,
        input_variables=['input_document'],
        partial_variables={
            'address': self.__data_output('address'),
            'address2': self.__data_output('address2'),
            'nota_fiscal': self.__data_output('nota_fiscal'),
            'income': self.__data_output('income'),
            'inss': self.__data_output('inss'),
            'self_declaration': self.__data_output('self_declaration'),
            'ir_receipt': self.__data_output('ir_receipt'),
            'irpf': self.__data_output('irpf'),
            'paycheck': self.__data_output('paycheck'),
            'prolabore': self.__data_output('prolabore'),
            'crlv': self.__data_output('crlv'),
            'property_registration': self.__data_output('property_registration'),
            'pricing': self.__data_output('pricing'),
            'registration_pj': self.__data_output('registration_pj'),
            'registration_pf': self.__data_output('registration_pf')
        },

    )
        chain = prompt | self.model
        
        response = chain.invoke({
            'input_document': document_content
        })
                
        return response.content
    
    '''Two-step classification for Paycheck and Address documents'''
    def __predict_2(self, document_content: str)-> str:
        prompt = PromptTemplate(
        template=address_validation,
        input_variables=['input_document'],
        partial_variables={
            'address': self.__data_output('address'),
            'address2': self.__data_output('address2'),
            'paycheck': self.__data_output('paycheck'),
        },
    )
        chain = prompt | self.model
        
        response = chain.invoke({
            'input_document': document_content
        })
                
        return response.content
    
    def __predict_3(self, document_content: str)-> str:
        prompt = PromptTemplate(
        template=irpf_validation,
        input_variables=['input_document'],
        partial_variables={
            'ir_receipt': self.__data_output('ir_receipt'),
            'irpf': self.__data_output('irpf'),
            'irpf_receipt_declaration':  self.__data_output('irpf_receipt_declaration'),
        },
    )
        chain = prompt | self.model
        
        response = chain.invoke({
            'input_document': document_content
        })
        
        
        return response.content
    
    '''Predicts the document type for PJ processes'''
    def __predict_pj(self, document_content: str)-> str:
        prompt = PromptTemplate(
            template= pj_prediction,
            input_variables=['input_document'],
            partial_variables={
                'minute': self.__data_output('minute'),
                'invoice': self.__data_output('invoice'),
                'invoice2': self.__data_output('invoice2'),
                'nota_fiscal': self.__data_output('nota_fiscal'),
                'presumed_billing': self.__data_output('presumed_billing'),
                'simples': self.__data_output('simples'),
                'contract': self.__data_output('contract'),
                'balance': self.__data_output('balance'),
                'dre': self.__data_output('dre'),
                'dre2': self.__data_output('dre2'),
            },
        )
        chain = prompt | self.model
        
        response = chain.invoke({
            'input_document': document_content
        })
        
        
        return response.content

    def __predict_geral(self, document_content: str)-> str:
        prompt = PromptTemplate(
            template= geral_prediction,
            input_variables=['input_document'],
            partial_variables={
                'minute': self.__data_output('minute'),
                'invoice': self.__data_output('invoice'),
                'invoice2': self.__data_output('invoice2'),
                'invoice3': self.__data_output('invoice3'),
                'nota_fiscal': self.__data_output('nota_fiscal'),
                'address': self.__data_output('address'),
                'address2': self.__data_output('address2'),
                'self_declaration_address': self.__data_output('self_declaration_address'),
                'self_declaration_address2': self.__data_output('self_declaration_address2'),
                'income': self.__data_output('income'),
                'inss': self.__data_output('inss'),
                'self_declaration': self.__data_output('self_declaration'),
                'paycheck': self.__data_output('paycheck'),
                'prolabore': self.__data_output('prolabore'),
                'property_registration': self.__data_output('property_registration'),
                'bank_statement': self.__data_output('bank_statement'),
            },
        )
        chain = prompt | self.model
        
        response = chain.invoke({
            'input_document': document_content
        })
    
        
        return response.content
    
    def __predict_agro(self, document_content: str)-> str:
        pass
    
    def __data_output(self, doc_type: str) -> str:
        # este arquivo está em app/documents_classifier.py → base_dir = /.../app
        base_dir = Path(__file__).resolve().parents[2]
        path = base_dir / "docs" / f"{doc_type}.txt"
        try:
            return path.read_text(encoding="utf-8")
        except FileNotFoundError:
            log.error(f"Erro ao extrair o texto do arquivo -> {path}")
            # Evite quebrar classificação caso algum exemplo não exista
            return ""
