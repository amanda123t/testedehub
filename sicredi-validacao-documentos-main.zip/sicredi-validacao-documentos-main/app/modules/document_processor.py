import os
from json import loads, dump
from dotenv import load_dotenv
from app.modules.extractor import DataExtractor
from app.modules.classifier.document_classifier import DocumentClassifier
from app.text_extractor.manager import PDFTextManager

class DocumentsProcessor:
    """
    Responsável por:
      - Ler texto de arquivos (PDF/Imagem) -> FileReader
      - Classificar o tipo de documento -> DocumentClassifier
      - Extrair dados conforme um 'modelo' -> DataExtractor
    As chaves de API e variáveis de ambiente são carregadas no __init__.
    """

    def __init__(self):
        # Carrega variáveis de ambiente (API keys, caminhos, etc.)
        load_dotenv()

        self.api_key_openai = os.getenv("OPENAI_API_KEY")

        # Metadados do processo (se existirem no ambiente)
        self.base_folder = os.getenv("FOLDER")
        self.process_id = os.getenv("PROCESS_ID")
        self.process_type = os.getenv("PROCESS_TYPE")
        self.cooperative_code = os.getenv("COOP")

        # Componentes principais
        self.reader = PDFTextManager()
        self.classifier = DocumentClassifier(self.api_key_openai)
        self.extractor = DataExtractor(self.api_key_openai)

        # Prompt genérico para extração (pode ser sobrescrito por chamadores)
        self.default_extraction_instruction = "Extract the information from the document"

    # --------- Operações de alto nível ---------

    def extract_text_from_image(self, file_path: str) -> str:
        """Extrai texto (OCR/parse) de um arquivo."""
        return self.reader.azure_ocr.extract(file_path)

    def classify_document_type(self, document_text: str, process_kind: str) -> str:
        """
        Classifica o tipo de documento com base no texto e no 'tipo de processo' (PF/PJ).
        Retorna um label como 'balance', 'paycheck', etc.
        """
        return self.classifier.get_document_type(
            process=process_kind,
            document_content=document_text
        )

    def extract_data(self, document_text: str, model_class) -> str:
        """
        Aplica o extrator com o 'modelo' apropriado do documento (schema/pydantic)
        e devolve a resposta (string JSON ou equivalente).
        """
        return self.extractor.extract(
            self.default_extraction_instruction,
            document_text,
            model_class
        )

    # --------- Utilitário opcional ---------

    def json_storage(data, document_type: str, process_name: str, file_basename: str) -> str:
        """
        Salva JSON no disco em 'output/<processo>/<tipo>_<processo>.json',
        evitando sobrescrever.
        """
        json_path = f"output/{process_name.lower()}/{document_type.lower()}_{process_name}.json"
        if os.path.exists(json_path):
            json_path = f"output/{process_name.lower()}/{document_type.lower()}_{process_name.lower()}_{file_basename}.json"

        with open(json_path, "w", encoding="utf-8") as f:
            dump(data, f, ensure_ascii=False, indent=4)
        return json_path
