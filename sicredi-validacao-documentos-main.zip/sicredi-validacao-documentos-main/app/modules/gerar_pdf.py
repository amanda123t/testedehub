from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from app.utils.logger import LoggerManager
import re

def deve_inserir_doispontos(key: str) -> bool:
    key_strip = key.strip()
    if not key_strip:
        return False
    # 1) Se JÁ termina com ":" → não insere
    if key_strip.endswith(":"):
        return False

    # 2) NÃO inserir se termina com número
    if re.search(r"\d$", key_strip):
        return False

    # 3) NÃO inserir se termina com símbolo especial
    if re.search(r"[-=/#*]+$", key_strip):
        return False

    # 5) NÃO inserir se key é tabular/indentada
    if key.startswith("   "):
        return False

    return True

def wrap_by_width(c, text, max_width, font_name, font_size):
    """
    Divide o texto em linhas que cabem exatamente dentro da largura em pixels.
    Usa stringWidth — muito mais preciso que textwrap.
    """
    words = text.split()
    lines = []
    current = ""

    for word in words:
        test = f"{current} {word}".strip()
        if c.stringWidth(test, font_name, font_size) <= max_width:
            current = test
        else:
            lines.append(current)
            current = word

    if current:
        lines.append(current)

    return lines

def wrap_with_indent(text, indent, max_width, canvas_obj, font_name, font_size):
    """
    Quebra linhas preservando EXATAMENTE os espaços do texto original.
    Não usa .split(), então não destrói tabulação feita com f-strings.
    """
    largura_util = max_width - canvas_obj.stringWidth(indent, font_name, font_size)

    linhas = []
    atual = ""

    for ch in text:
        teste = atual + ch
        # mede já com indent na frente
        if canvas_obj.stringWidth(teste, font_name, font_size) <= largura_util:
            atual = teste
        else:
            # fecha a linha atual com indent
            if atual:
                linhas.append(indent + atual)
            # começa nova linha com o caractere que estourou
            atual = ch

    if atual:
        linhas.append(indent + atual)

    return linhas

log = LoggerManager(__name__)  # logger do módulo (task)
class PDFGenerator:
    def __init__(self, output_path):
        self.output_path = output_path
        self.sections = []
        self.header_section = None

    def add_section(self, title, data):
        if title == "Resultados do Processamento:":
            self.header_section = (title, data)
        else:
            self.sections.append((title, data))

    def save(self):
        c = canvas.Canvas(self.output_path, pagesize=letter)
        width, height = letter
        y_position = height - 50
        line_height = 17

        c.setFont("Helvetica-Bold", 12)
        c.drawString(30, y_position, "Resultados do Processamento:")
        y_position -= 20

        def draw_data(data):
            nonlocal y_position
            for linha in data:
                if isinstance(linha, list) and len(linha) == 2:
                    key, value = linha

                    if deve_inserir_doispontos(key):
                        text = f"{key}: {value}"
                    else:
                        text = f"{key} {value}"
                else:
                    text = " ".join(str(x) for x in linha if x is not None)


                # COR & ESTILO
                if "✔" in text:
                    c.setFillColor(colors.green)
                    c.setFont("Helvetica-Bold", 12)
                elif "✘" in text:
                    c.setFillColor(colors.red)
                    c.setFont("Helvetica-Bold", 12)
                elif any(palavra in text.upper() for palavra in ["RECEITA BRUTA DO PA", "RECEITA BRUTA ACUMULADA NO ANO", "TOTAL DE RECEITAS BRUTAS ANTERIORES", "CONTADOR:", "SÓCIOS:", "SOCIOS", "CABEÇALHO", "RENDIMENTOS ISENTOS E NÃO TRIBUTÁVEIS:","IDENTIFICAÇÃO DO CONTRIBUINTE:", "DEMONSTRATIVO DE ATIVIDADE RURAL:", "RENDIMENTOS SUJEITOS", "RENDIMENTOS TRIBUTÁVEIS", "RENDIMENTOS RECEBIDOS DE PESSOA","APURAÇÃO DO RESULTADO","DECLARAÇÃO DE BENS E DIREITOS:", "TOTAL POR TIPO","VALIDAÇÃO DE DATAS", "SOMA TOTAL", "DESCONTOS","DESCONTOS:","ITENS DE SALARIO","PARECER PADRÃO","PARECERES PADRÃO", "REGRAS CONFORME GUIA","CARÊNCIA", "DADOS EXTRAÍDOS DA RECEITA FEDERAL", "DEMONSTRAÇÕES CONTÁBEIS OBRIGATÓRIAS", "ATIVO TOTAL", "PASSIVO TOTAL", "PATRIMÔNIO LÍQUIDO", "MUA", "FIPE (CONSULTA NO SITE", "CONSULTA POR PLACA NO SITE"]):
                    c.setFont("Helvetica-Bold", 12)
                    c.setFillColor(colors.black)
                elif any(palavra in text.upper() for palavra in ["ALERTA PRO-LABORE"]): 
                        c.setFont("Helvetica-Bold", 12)  # Define o texto em negrito
                        c.setFillColor(colors.orangered)    # Cor LARANJA    
                else:
                    c.setFillColor(colors.black)
                    c.setFont("Helvetica", 11)

                # --- CORREÇÃO DO /n: preservar a indentação original para TODAS as linhas ---
                raw_lines = text.split('\n')

                # indentação da primeira linha real
                first_line = raw_lines[0]
                base_indent = ""
                for ch in first_line:
                    if ch == " ":
                        base_indent += " "
                    else:
                        break

                # reaplicar a indentação nas linhas quebradas
                processed_lines = []
                for i, ln in enumerate(raw_lines):
                    # se for a primeira linha, usa a indentação original dela
                    if i == 0:
                        processed_lines.append(ln)
                    else:
                        # se a linha não começa com espaços, forçamos a indentação herdada
                        if not ln.startswith(" "):
                            processed_lines.append(base_indent + ln)
                        else:
                            processed_lines.append(ln)

                # agora iteramos sobre processed_lines com indentação garantida
                for line in processed_lines:


                    # --- Salvar estilo ANTES ---
                    font_name_before = c._fontname
                    font_size_before = c._fontsize
                    fill_color_before = c._fillColorObj

                    # Detectar indentação real da linha
                    indent = ""
                    for char in line:
                        if char == " ":
                            indent += " "
                        else:
                            break

                    is_indentada = len(indent) > 0

                    if is_indentada:
                        # --- Mantém o estilo (negrito, verde, vermelho, laranja etc) ---
                        font_original = font_name_before
                        size_original = font_size_before
                        color_original = fill_color_before

                        # Se a linha deveria ser bold, deixamos bold
                        if "Bold" in font_original or font_original.endswith("-Bold"):
                            c.setFont("Courier-Bold", 13)
                        else:
                            c.setFont("Courier", 11)

                        c.setFillColor(color_original)

                        # remove indentação para medir texto
                        conteudo = line[len(indent):]

                        wrapped = wrap_with_indent(
                            conteudo,
                            indent,  
                            max_width=width - 40,
                            canvas_obj=c,
                            font_name=c._fontname,
                            font_size=c._fontsize
                        )

                        # Agora TODAS as linhas quebradas terão a indentação preservada
                        for w in wrapped:
                            c.drawString(30, y_position, w)
                            y_position -= line_height

                            if y_position < 50:
                                # manter estilo mesmo após page break
                                c.showPage()
                                y_position = height - 50

                                if "Bold" in font_original or font_original.endswith("-Bold"):
                                    c.setFont("Courier-Bold", 13)
                                else:
                                    c.setFont("Courier", 11)

                                c.setFillColor(color_original)

                        # restaura estilo anterior
                        c.setFont(font_original, size_original)
                        c.setFillColor(color_original)

                        continue


                    # caso normal (não tabular)
                    font_name = c._fontname
                    font_size = c._fontsize

                    wrapped_lines = wrap_by_width(
                        c,
                        line,
                        max_width=width - 60,  # margem total (30 esquerda + 30 direita)
                        font_name=font_name,
                        font_size=font_size,
                    )

                    for wrapped in wrapped_lines:
                        c.drawString(30, y_position, wrapped)
                        y_position -= line_height
                        if y_position < 50:
                            # salva estilo atual
                            font_name_atual = c._fontname
                            font_size_atual = c._fontsize
                            color_atual = c._fillColorObj

                            c.showPage()
                            y_position = height - 50

                            # restaura estilo APÓS abrir nova página
                            c.setFont(font_name_atual, font_size_atual)
                            c.setFillColor(color_atual)


        # Desenha cabeçalho primeiro
        if self.header_section:
            _, data = self.header_section
            draw_data(data)
            y_position -= 10  # espaço extra antes das seções

        # Desenha seções de documentos
        for title, data in self.sections:
            # Título da seção em negrito
            c.setFont("Helvetica-Bold", 12)
            c.setFillColor(colors.black)
            c.drawString(30, y_position, title)
            y_position -= 20
            draw_data(data)
            y_position -= 10

        c.save()
        log.info(f"✅ PDF salvo com sucesso: {self.output_path}")
        return self.output_path
