# app/utils/supabase_client.py
from supabase import create_client, Client
import os
import time
from dotenv import load_dotenv
from threading import Semaphore

load_dotenv()

SUPABASE_SEMAFORO = Semaphore(5)


class SupabaseClient:
    def __init__(self):
        self.url = os.getenv("SUPABASE_URL")
        self.key = os.getenv("SUPABASE_KEY")
        self.client: Client = create_client(self.url, self.key)

    # ================================================================
    # 🔥 FUNÇÃO CENTRAL — SEMAPHORE + RETRY
    # ================================================================
    def request_with_retry(self, fn, erros=(Exception,), tentativas=3, espera=0.3):
        for i in range(1, tentativas + 1):
            try:
                with SUPABASE_SEMAFORO:
                    return fn()

            except erros as e:
                print(f"⚠️ Erro Supabase (tentativa {i}/{tentativas}): {e}")

                if i == tentativas:
                    raise

                time.sleep(espera)

    # ================================================================
    # INSERT
    # ================================================================
    def insert(self, table: str, data: dict):
        return self.request_with_retry(
            lambda: self.client.table(table).insert(data).execute().data
        )

    # ================================================================
    # UPSERT
    # ================================================================
    def upsert(self, table: str, data: dict, on_conflict=None):
        try:
            conflict = None
            if on_conflict:
                if isinstance(on_conflict, (list, tuple)):
                    conflict = ",".join(on_conflict)
                else:
                    conflict = ",".join([c.strip() for c in on_conflict.split(",")])

            return self.request_with_retry(
                lambda: self.client.table(table)
                    .upsert(data, on_conflict=conflict)
                    .execute()
                    .data
            )

        except Exception as e:
            print(f"⚠️ Falha ao inserir/atualizar em {table}: {e}")
            return None

    # ================================================================
    # SELECT
    # ================================================================
    def select(self, table: str, filters: dict = None):
        def fn():
            query = self.client.table(table).select("*")
            if filters:
                for field, value in filters.items():
                    query = query.eq(field, value)
            return query.execute().data

        return self.request_with_retry(fn)

    # ================================================================
    # DELETE
    # ================================================================
    def delete(self, table: str, filters: dict):
        def fn():
            query = self.client.table(table)
            for field, value in filters.items():
                query = query.eq(field, value)
            return query.delete().execute().data

        return self.request_with_retry(fn)

    # ================================================================
    # UPDATE FIELDS
    # ================================================================
    def update_fields(self, table: str, filters: dict, fields: dict):
        """
        Atualiza campos específicos de um registro no Supabase aplicando filtros.
        Exemplo:
            update_fields("processos", {"processo": chave}, {"status": "CONCLUIDO"})
        """

        def fn():
            query = self.client.table(table).update(fields)

            # Aplica os filtros ANTES do execute()
            for field, value in filters.items():
                query = query.eq(field, value)

            resp = query.execute()
            return resp.data

        return self.request_with_retry(fn)

