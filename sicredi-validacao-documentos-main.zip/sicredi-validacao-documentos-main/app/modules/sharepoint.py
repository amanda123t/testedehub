# sharepoint.py
from io import BytesIO
import pandas as pd
import requests
from msal import ConfidentialClientApplication
from urllib.parse import quote
from email.utils import parsedate_to_datetime
from datetime import datetime, timedelta, timezone
import random, time as _time
import glob, os, re
from typing import Dict, Optional
from pathlib import Path
import atexit
from threading import Semaphore, Lock
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_EXCEPTION
import time
from app.utils.logger import LoggerManager

#Trava global
SP_GLOBAL = Semaphore(int(os.getenv("MAX_SP_TRAVA", "50")))

# Cria um executor global do sharepoint, todas threads puxam desse executor
SP_DOWNLOAD_WORKERS = int(os.getenv("MAX_DOWNLOAD_SP_POR_PROCESSO", "5"))
SP_DOWNLOAD_POOL = ThreadPoolExecutor(max_workers=max(1, min(SP_DOWNLOAD_WORKERS, 10)) )

#cinto de segurança do executor(sempre vai encerrar o executor quando terminar)
atexit.register(lambda: SP_DOWNLOAD_POOL.shutdown(wait=False))

#timeout para mover os arquivos
MOVE_TIMEOUT_S = int(os.getenv("SP_MOVE_TIMEOUT_S", "120"))

class SharePointClient:
    """
    Cliente de conexão com o Microsoft SharePoint via Microsoft Graph API.

    Essa classe cuida de toda a autenticação (token de acesso), comunicação HTTP e manipulação
    de pastas/arquivos dentro do SharePoint. Inclui mecanismos de retry automáticos e logs detalhados.
    """

    def __init__(self, secret: dict[str, str]):
        """
        Inicializa o cliente com as credenciais necessárias para autenticação no Azure AD.

        Args:
            secret: Dicionário contendo as credenciais do aplicativo registradas no Azure.
                    Exemplo:
                    {
                        "clientId": "...",
                        "clientSecret": "...",
                        "tenantId": "...",
                        "scope": "https://graph.microsoft.com/.default"
                    }
        """
        self.secret = secret

        # Credenciais do aplicativo registrado no Azure AD
        self.__client_id = secret['clientId']           # ID do aplicativo
        self.__client_secret = secret['clientSecret']   # Senha (chave secreta) do aplicativo
        self.__tenant_id = secret['tenantId']           # ID do diretório (empresa/tenant)
        self.__authority = f'https://login.microsoftonline.com/{self.__tenant_id}'  # Endpoint de login
        self.__scope = secret['scope']                  # Escopo de permissão (geralmente o Graph API)

        # Controle interno de criação de pastas (para não recriar as mesmas várias vezes)
        self._ensured_folders: set[str] = set()         # Cache de pastas já garantidas
        self._folders_lock = Lock()                     # Evita corrida de threads ao criar pastas

        # Sistema de logs centralizado
        self.log = LoggerManager(__name__)

        # Autentica automaticamente ao iniciar a classe (gera e guarda o token)
        self.__token = self.__authenticate_to_azure()
        self.__headers = {'Authorization': f'Bearer {self.__token}'}  # Cabeçalho padrão para todas as requisições

    # =============================
    # Helpers de Limpeza e normalização para caminhos/arquivos do sharepoint
    # =============================
    @staticmethod
    def _normalize_sharepoint_path(path: str) -> str:
        """
        Corrige e codifica um caminho de pasta/arquivo para o formato que o SharePoint entende.

        Exemplo:
            Entrada:  "Pasta Principal/Documentos Finais/arquivo final (1).pdf"
            Saída:    "Pasta%20Principal/Documentos%20Finais/arquivo%20final%20(1).pdf"

        Por que isso é necessário:
            URLs não aceitam espaços, acentos e alguns símbolos. Essa função "ajeita" o caminho,
            mantendo as barras '/' e removendo sobras de espaços ou caracteres inválidos.

        Args:
            path: Caminho original (com ou sem acentos e espaços).

        Returns:
            str: Caminho limpo e seguro para ser usado nas requisições da API.
        """
        if not path:
            return ""

        # Remove barras duplas e espaços no início/fim de cada parte do caminho
        partes = [p.strip() for p in str(path).strip("/").split("/")]
        caminho_limpo = "/".join(partes)

        # Codifica caracteres especiais, mas mantém as barras '/'
        caminho_codificado = quote(caminho_limpo, safe="/")

        return caminho_codificado

    @staticmethod
    def clean_sharepoint_name(name: str, replacement: str = "_") -> str:
        invalid_name_chars = set('"*:<>?/\\|#%')  # abrangente e seguro para todos tenants
        # troca caracteres inválidos
        cleaned = "".join((c if c not in invalid_name_chars else replacement) for c in (name or ""))
        # remove controles, normaliza espaços, trim de pontos e espaços finais/iniciais
        cleaned = re.sub(r"[\x00-\x1f]", "", cleaned)
        cleaned = re.sub(r"\s+", " ", cleaned).strip(" .")
        # SharePoint limita ~255 no name
        return cleaned[:255] or "item"
    # =============================
    # 🔐 Autenticação no Azure AD
    # =============================
    def __authenticate_to_azure(self) -> str:
        """
        Faz login no Azure AD e obtém o token de acesso (Bearer Token) necessário
        para autorizar chamadas à API do Microsoft Graph.

        Resumo simples:
        - Pensa como um "login automático".
        - Ele pega o crachá (token) para que o SharePoint saiba que você tem permissão para entrar.

        Returns:
            str: Token de acesso válido para uso na API do SharePoint.

        Raises:
            Exception: Se houver falha ao autenticar (credenciais erradas, tenant inválido, etc.)
        """
        try:
            # Cria um "cliente confidencial" usando as credenciais do Azure
            app = ConfidentialClientApplication(
                self.__client_id,
                authority=self.__authority,
                client_credential=self.__client_secret,
            )

            # Solicita um token de acesso válido ao Azure AD
            token_response = app.acquire_token_for_client(scopes=[self.__scope])

            if 'access_token' in token_response:
                token = token_response['access_token']

                # Atualiza o cabeçalho padrão com o novo token
                self.__headers = {'Authorization': f'Bearer {token}'}
                self.log.debug("✅ Token obtido com sucesso no Azure AD (autenticação realizada).")

                return token

            # Se não veio token, lança o erro completo para facilitar o diagnóstico
            raise Exception(token_response)

        except Exception as e:
            self.log.error(f"❌ Falha na autenticação com o Azure AD: {e}")
            raise

    def __request_with_retry(self, method: str, url: str, *,
                             headers: Optional[dict] = None,
                             timeout: int = 30,
                             max_tries: int = 3,
                             refresh_on_401: bool = True,
                             **kwargs) -> Optional[requests.Response]:
        """
        Envia uma requisição HTTP resiliente com:
        - Retentativas automáticas para 408/429/5xx e falhas de rede.
        - Backoff exponencial com jitter.
        - Renovação de token automática em 401.
        """
        headers = {**self.__headers, **(headers or {})}
        backoff_base = 0.6

        for attempt in range(1, max_tries + 1):
            try:
                with SP_GLOBAL:
                    resp = requests.request(method, url, headers=headers, timeout=(10, timeout), **kwargs)

                # 401 → renova token e tenta novamente
                if resp.status_code == 401 and refresh_on_401:
                    self.log.warning("🔄 Token expirado (401). Renovando...")
                    self.__token = self.__authenticate_to_azure()
                    headers['Authorization'] = f'Bearer {self.__token}'
                    resp = requests.request(method, url, headers=headers, timeout=(10, timeout), **kwargs)

                # Sucesso
                if 200 <= resp.status_code < 300:
                    return resp

                # Requisição não encontrada → None
                if resp.status_code == 404:
                    return None

                # Erros temporários → retry
                if attempt < max_tries and (resp.status_code in (408, 429) or 500 <= resp.status_code < 600):
                    retry_after = resp.headers.get("Retry-After")
                    wait = 0.0
                    if retry_after:
                        try:
                            wait = float(retry_after)
                        except ValueError:
                            try:
                                dt = parsedate_to_datetime(retry_after)
                                if dt.tzinfo is None:
                                    dt = dt.replace(tzinfo=timezone.utc)
                                wait = max(0, (dt - datetime.now(timezone.utc)).total_seconds())
                            except Exception:
                                pass
                    if not wait:
                        wait = backoff_base * (2 ** (attempt - 1)) + random.uniform(0, 0.4)
                    self.log.warning(f"⏳ Retentando ({attempt}/{max_tries}) após {wait:.1f}s — {url}")
                    _time.sleep(wait)
                    continue
                # Erro definitivo
                if resp.status_code == 409 and "children" in url:
                    # 409 em criação de pasta → não é erro real
                    self.log.debug(f"📂 Pasta já existia (409) — {url}")
                    return resp

                self.log.error(f"❌ HTTP {resp.status_code} — {url}")
                return resp        

            except Exception as e:
                self.log.warning(f"⚠️ Erro na tentativa {attempt}/{max_tries}: {e}")
                if attempt < max_tries:
                    _time.sleep(backoff_base * (2 ** (attempt - 1)) + random.uniform(0, 0.4))
                    continue
                self.log.error(f"🚨 Falha definitiva após {max_tries} tentativas: {e}")
                return None

        return None

    def __make_api_request(self, method, url, **kwargs):
        """Wrapper de conveniência que usa retry e retorna JSON ou None."""
        resp = self.__request_with_retry(method, url, **kwargs)
        if resp is None:
            return None
        try:
            return resp.json() if resp.status_code < 300 else {}
        except Exception:
            return {}

    # =============================
    # Operações de alto nível (Graph)
    # =============================
    def search_sites(self, site: str, site_name: str) -> Optional[str]:
        """Procura site pelo nome e retorna o ID."""
        q = quote(site or "")
        result = self.__make_api_request('GET', f'https://graph.microsoft.com/v1.0/sites?search={q}')
        if result and 'value' in result:
            matches = [s.get('id') for s in result['value'] if site_name.lower() in s.get('name', '').lower()]
            if matches and matches[0]:
                self.log.debug(f'Successfully searched for {site_name}: {matches[0]}')
                return matches[0]
            self.log.warning(f'Site not found: {site_name}')
        else:
            self.log.error('search_sites returned no results or invalid payload')
        return None

    def search_folder_children(self, site_id: str, folder: str):
        '''
        Percorre @odata.nextLink para listar TODAS as páginas
        Reduz payload com $select
        Retorna [] se pasta existir porém vazia; None se erro
        '''
        base = (
            f'https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{self._normalize_sharepoint_path(folder)}'
            f':/children?$top=200&$select='
            'id,name,lastModifiedDateTime,createdBy,lastModifiedBy,folder,file,parentReference'
        )
        url = base
        out = []
        while url:
            page = self.__make_api_request('GET', url)
            if page is None:
                return None
            out.extend(page.get('value', []))
            url = page.get('@odata.nextLink')

        if out:
            try:
                self.log.debug(f'Successfully retrieved {len(out)} children of {folder}')
            except Exception:
                pass
            return out
        self.log.warning(f'Folder "{folder}" is empty')
        return []

    def search_file_data(self, site_id: str, file_path: str) -> Optional[str]:
        """Retorna a downloadUrl de um arquivo (se existir)."""
        url = f'https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{self._normalize_sharepoint_path(file_path)}'
        result = self.__make_api_request('GET', url)
        if result and '@microsoft.graph.downloadUrl' in result:
            self.log.debug(f'Successfully retrieved download URL for {file_path}')
            return result['@microsoft.graph.downloadUrl']
        return None

    def read_workbook(self, url: str) -> Dict[str, pd.DataFrame]:
        """
        Baixa o Excel (binário) e retorna TODAS as abas como {nome_aba: DataFrame} (dtype=object).
        """
        resp = self.__request_with_retry('GET', url, timeout=60, max_tries=3, refresh_on_401=False)
        if resp is None or resp.status_code != 200:
            code = resp.status_code if resp is not None else 'NO-RESP'
            txt = resp.text[:500] if (resp is not None and hasattr(resp, 'text')) else ''
            raise RuntimeError(f'Failed to read workbook ({code}): {url} - {txt}')
        # lida com várias abas
        sheets = pd.read_excel(BytesIO(resp.content), sheet_name=None, dtype=object)
        # garante dict[str, DataFrame]
        return {str(k): v for k, v in (sheets or {}).items()}

    def download_file_by_path(self, site_id: str, sp_path: str, local_path: str) -> str | None:
        """
        Baixa um arquivo do SharePoint a partir do caminho (sp_path).
        - Procura a URL de download do arquivo.
        - Cria a pasta local se não existir.
        - Faz o download do arquivo e salva em local_path.
        Retorna o caminho do arquivo salvo ou None se não encontrar.
        """
        url = self.search_file_data(site_id, sp_path)
        if not url:
            self.log.error(f"Download URL not found for {sp_path}")
            return None
        os.makedirs(os.path.dirname(local_path), exist_ok=True)
        try:
            resp = self.__request_with_retry('GET', url, timeout=60, max_tries=3, refresh_on_401=False, stream=True)
            if resp is not None and resp.status_code == 200:
                os.makedirs(os.path.dirname(local_path), exist_ok=True)
                with open(local_path, 'wb') as f:
                    for chunk in resp.iter_content(chunk_size=65536):
                        if chunk:
                            f.write(chunk)
                self.log.info(f'Successfully downloaded file from {url} to {local_path}!')
                return local_path
            else:
                code = resp.status_code if resp is not None else 'NO-RESP'
                text = resp.text[:500] if (resp is not None and hasattr(resp, 'text')) else ''
                self.log.error(f'Failed to download ({code}): {url} - {text}')
                return None
        except Exception as e:
            self.log.error(f'Download exception: {e}')
            return None

    # baixar e extrair ZIP com segurança (path traversal safe)
    def download_and_extract_zip(self, site_id: str, sp_file_path: str, extract_to: str) -> str:
        """
        Baixa um arquivo ZIP do SharePoint e o extrai de forma segura.
        - Protege contra path traversal e symlinks maliciosos.
        - Limita tempo, quantidade de membros e bytes descompactados (anti zip-bomb).
        - Ignora entradas ocultas e __MACOSX.
        - Sempre remove o ZIP local (sucesso ou erro).
        Retorna o diretório de extração.
        """
        import os, zipfile, time, stat
        from datetime import datetime

        os.makedirs(extract_to, exist_ok=True)
        base_name = os.path.splitext(os.path.basename(sp_file_path))[0]
        local_zip = os.path.join("download", f"{base_name}_{int(datetime.now().timestamp())}.zip")
        os.makedirs(os.path.dirname(local_zip), exist_ok=True)

        if not self.download_file_by_path(site_id, sp_file_path, local_zip):
            raise RuntimeError(f"URL de download não encontrada: {sp_file_path}")

        base_dir = os.path.realpath(extract_to) + os.sep
        start = time.monotonic()
        max_secs = 45                 # orçamento de tempo
        max_members = 5000            # orçamento de quantidade
        max_uncompressed_mb = 500     # orçamento de bytes descompactados
        max_uncompressed = max_uncompressed_mb * 1024 * 1024

        total_members = 0
        total_uncompressed = 0

        self.log.info(f"[ZIP] Iniciando extração de '{sp_file_path}' → {extract_to}")

        try:
            with zipfile.ZipFile(local_zip, 'r') as zf:
                # itere por ZipInfo para ter metadados (tamanho, atributos, etc.)
                for zi in zf.infolist():
                    name = zi.filename

                    # filtros básicos
                    if (name.endswith('/') or
                        name.startswith('__MACOSX/') or
                        name.startswith('.')):
                        continue

                    # symlink? (evita extração de links)
                    mode = (zi.external_attr >> 16) & 0xFFFF
                    if stat.S_IFMT(mode) == stat.S_IFLNK:
                        self.log.debug(f"[ZIP] Ignorando symlink: {name}")
                        continue

                    # destino seguro
                    dest = os.path.realpath(os.path.join(extract_to, name))
                    if not dest.startswith(base_dir):
                        raise RuntimeError(f"Entrada insegura no zip: {name}")

                    # orçamentos
                    total_members += 1
                    total_uncompressed += int(getattr(zi, "file_size", 0))

                    if total_members % 200 == 0:
                        self.log.debug(f"[ZIP] extraídos {total_members} itens...")

                    if total_members > max_members:
                        self.log.error(f"[ZIP] Limite de {max_members} entradas atingido; abortando extração.")
                        break

                    if total_uncompressed > max_uncompressed:
                        mb = total_uncompressed / (1024 * 1024)
                        self.log.error(f"[ZIP] Limite de {max_uncompressed_mb} MB ({mb:.1f} MB usados) atingido; abortando extração.")
                        break

                    if (time.monotonic() - start) > max_secs:
                        self.log.error(f"[ZIP] Timeout de {max_secs}s na extração; abortando.")
                        break

                    # garante pasta do destino e extrai apenas este membro
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    zf.extract(zi, extract_to)

        finally:
            try:
                os.remove(local_zip)
            except Exception:
                pass

        mb = total_uncompressed / (1024 * 1024)
        self.log.info(f"[ZIP] Extração finalizada ({total_members} itens, {mb:.1f} MB).")
        return extract_to

   # --- Árvores e downloads paralelos ---

    def list_files_recursive(self, site_id: str, sp_root: str) -> list[dict]:
        """
        Lista recursivamente todos os arquivos a partir de sp_root.
        Retorna itens no formato {"name": ..., "sp_path": ..., "rel": ...}.
        """
        pilha: list[tuple[str, str]] = [(sp_root, "")]  # (sp_path_atual, relpath_atual)
        out: list[dict] = []
        while pilha:
            base, rel = pilha.pop()
            children = self.search_folder_children(site_id, base) or []
            for it in children:
                name = it.get("name", "")
                if "folder" in it:
                    pilha.append((f"{base}/{name}", f"{rel}/{name}".strip("/")))
                else:
                    out.append({
                        "name": name,
                        "sp_path": f"{base}/{name}",
                        "rel": f"{rel}/{name}".strip("/")
                    })
        return out

    def download_tree_parallel(self, site_id: str, sp_root: str, local_root: str, exts: set[str] | None = None, overall_timeout_s: int | None = None) -> int:
        t0 = time.monotonic()
        os.makedirs(local_root, exist_ok=True)
        arquivos = []
        tentativas = 0
        ultimo_total = -1

        while tentativas < 3:
            arquivos = self.list_files_recursive(site_id, sp_root)
            total = len(arquivos)

            self.log.info(
                f"📂 Listagem tentativa {tentativas+1}: {total} arquivos em {sp_root}"
            )

            if total > 0 and total == ultimo_total:
                break

            # 👇 se for a primeira tentativa e já tem arquivos, marca e testa mais uma
            ultimo_total = total
            tentativas += 1
            time.sleep(1.2)

        if not arquivos:
            self.log.warning(
                f"⚠ Nenhum arquivo encontrado após retry de listagem em {sp_root}"
            )

        exts = {e.lower() for e in (exts or {".pdf",".png",".jpg",".jpeg",".jfif",".tif",".tiff",".bmp",".webp"})}

        def _one_download(sp_path: str, dest: str):
            Path(dest).parent.mkdir(parents=True, exist_ok=True)
            return self.download_file_by_path(site_id, sp_path, dest)

        futures = []
        for arq in arquivos:
            ext = os.path.splitext(arq["name"])[1].lower()
            if exts and ext not in exts:
                self.log.info(f"extensão não permitida, pulando esse arquivo...")
                continue
            local_path = os.path.join(local_root, arq["rel"])
            futures.append(SP_DOWNLOAD_POOL.submit(_one_download, arq["sp_path"], local_path))

        ok = 0
        pending = set(futures)

        while pending:
            # timeout “curto” para ir liberando o loop e checar tempo total
            done, pending = wait(pending, timeout=30, return_when=FIRST_EXCEPTION)

            for f in done:
                try:
                    if f.result():
                        ok += 1
                except Exception:
                    pass  # log opcional por arquivo

            if overall_timeout_s is not None and (time.monotonic() - t0) > overall_timeout_s:
                # cancela o que sobrar e sai
                for f in pending:
                    f.cancel()
                break

        self.log.info(f"📥 Downloads concluídos ({ok}/{len(futures)}) em {sp_root}")
        return ok

    def get_last_modified_file_name(self, site_id: str, folder: str) -> Optional[str]:
        # 1) Busca os filhos da pasta (mesmo payload de antes)
        children = self.search_folder_children(site_id, folder)
        if not children:
            return None

        # 2) Em vez de ordenar tudo, percorre 1x guardando o "mais recente"
        last_ts = None
        last_name = None
        for ch in children:
            ts = ch.get("lastModifiedDateTime")  # ISO 8601, comparável como string
            if ts and (last_ts is None or ts > last_ts):
                last_ts, last_name = ts, ch.get("name")

        if last_name:
            self.log.debug(f"Successfully retrieved last modified file name: {last_name}")
        return last_name
    
    def upload_item(self, site_id: str, folder_path: str, file_path: str) -> dict | None:
        """
        Faz upload de qualquer arquivo para o SharePoint, automaticamente escolhendo o método:
        - Upload simples (<= 4 MB)
        - Upload grande em partes (> 4 MB)

        Retorna o JSON do item criado ou None em caso de falha.
        """
        try:
            if not os.path.exists(file_path):
                self.log.error(f"Arquivo não encontrado: {file_path}")
                return None

            # Garante que a pasta existe (cache interno evita recriação)
            self.ensure_folder_path(site_id, folder_path)

            # Limpa e prepara nomes e caminhos
            file_name = self.clean_sharepoint_name(os.path.basename(file_path))
            full_path = self._normalize_sharepoint_path(f"{folder_path}/{file_name}")
            size = os.path.getsize(file_path)

            # Escolhe automaticamente o tipo de upload
            if size <= 4 * 1024 * 1024:
                # Upload direto (simples)
                upload_url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{full_path}:/content"
                with open(file_path, 'rb') as fh:
                    resp = self.__request_with_retry(
                        'PUT',
                        upload_url,
                        headers={'Content-Type': 'application/octet-stream', **self.__headers},
                        data=fh,
                        timeout=120,
                        max_tries=3
                    )
            else:
                # Upload em partes (grande)
                sess_url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{full_path}:/createUploadSession"
                sess = self.__make_api_request('POST', sess_url, json={"item": {"@microsoft.graph.conflictBehavior": "replace"}})
                if not sess:
                    self.log.error(f"❌ Falha ao criar sessão de upload para {file_name}")
                    return None

                upload_url = sess.get('uploadUrl')
                chunk_size = 16 * 1024 * 1024
                sent = 0
                with open(file_path, 'rb') as fh:
                    while sent < size:
                        data = fh.read(chunk_size)
                        if not data:
                            break
                        start = sent
                        end = sent + len(data) - 1
                        headers = {
                            'Content-Length': str(len(data)),
                            'Content-Range': f'bytes {start}-{end}/{size}',
                        }
                        resp = self.__request_with_retry(
                            'PUT', upload_url, headers=headers, data=data, timeout=300, refresh_on_401=False
                        )
                        if resp is None or resp.status_code not in (200, 201, 202):
                            self.log.error(f"❌ Falha no envio de chunk ({file_name}): {resp.text if resp else 'NO-RESP'}")
                            return None
                        sent = end + 1

            # Finaliza
            if resp is not None and resp.status_code in (200, 201):
                self.log.info(f"✅ Upload concluído: {folder_path}/{file_name}")
                try:
                    return resp.json()
                except ValueError:
                    return {}
            else:
                code = resp.status_code if resp is not None else 'NO-RESP'
                txt = resp.text[:500] if (resp is not None and hasattr(resp, 'text')) else ''
                self.log.error(f"❌ Falha ao enviar arquivo ({code}): {txt}")
                return None

        except Exception as e:
            self.log.error(f"🚨 Erro no upload de {file_path}: {e}")
            return None
        
    def create_folder(self, site_id, path, folder_name):
        safe_name = self.clean_sharepoint_name(folder_name)
        base = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root"
        url = f"{base}/children" if not path else f"{base}:/{self._normalize_sharepoint_path(path)}:/children"
        folder_data = {"name": safe_name, "folder": {}, "@microsoft.graph.conflictBehavior": "fail"}

        resp = self.__request_with_retry('POST', url, headers=self.__headers, json=folder_data, max_tries=3)
        if resp is not None:
            if resp.status_code == 201:
                self.log.debug(f"📁 Pasta criada: {folder_name} em {path or '/'}")
                return resp.json()
            elif resp.status_code == 409:
                self.log.debug(f"📂 Pasta já existia: {folder_name} em {path or '/'}")
                return None

        code = resp.status_code if resp is not None else 'NO-RESP'
        txt = resp.text[:500] if (resp is not None and hasattr(resp, 'text')) else ''
        self.log.error(f"❌ Erro ao criar pasta ({code}): {txt}")
        return None

    def get_item_metadata(self, site_id: str, path: str) -> dict | None:
        """Retorna metadados do item pelo path (inclui createdBy/lastModifiedBy se existirem)."""
        url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/root:/{self._normalize_sharepoint_path(path)}"
        return self.__make_api_request("GET", url)

    def delete_item(self, site_id: str, item: str) -> bool:
        """
        Apaga um item (arquivo ou pasta) no SharePoint.
        `item` pode ser um ID OU um path (ex.: 'Coops/123/PASTA_MONITORADA/abc.pdf').

        Retorna True se excluiu (204), False caso contrário.
        """
        # 1) tenta resolver como path (mais seguro; se não for path válido, cai para ID)
        meta = self.get_item_metadata(site_id, item) or {}
        item_id = meta.get("id", None)

        # 2) se não resolveu como path, interpretamos `item` como ID
        if not item_id:
            item_id = item

        url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/items/{item_id}"
        resp = self.__request_with_retry('DELETE', url, headers=self.__headers, max_tries=3)
        if resp is not None and resp.status_code in (204, 200, 202):
            self.log.info(f"Deleted: {item}")
            return True
        self.log.error(f"Error deleting '{item}': {resp.text if resp else 'NO-RESP'}")
        return False

    def rename_file_by_id(self, site_id: str, item_id: str, new_name: str):
        """
        Renomeia um arquivo no SharePoint usando seu ID (evita problemas com paths).
        Usa retry.
        """
        url = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/items/{item_id}"
        payload = {"name": new_name}
        resp = self.__request_with_retry('PATCH', url, headers=self.__headers, json=payload, max_tries=3)
        if resp is not None and resp.status_code in (200, 201, 204):
            self.log.info(f"✅ Arquivo renomeado para: {new_name}")
            return True
        else:
            self.log.warning(f"❌ Falha ao renomear o arquivo: {(resp.text if resp is not None else 'NO-RESP')}")
            return False

    def ensure_folder_path(self, site_id: str, full_path: str) -> None:
        """
        Garante que toda a hierarquia de pastas exista no SharePoint.
        - Usa cache interno (_ensured_folders) para não recriar o mesmo caminho.
        - Verifica existência antes de chamar create_folder() para evitar 409.
        """
        norm = "/".join(p.strip() for p in str(full_path).strip("/").split("/")).strip("/")
        if not norm:
            return

        base = ""
        for name in norm.split("/"):
            base_next = f"{base}/{name}".strip("/")

            # já marcada em cache? pula
            with self._folders_lock:
                if base_next in self._ensured_folders:
                    base = base_next
                    continue

            # checa se a pasta já existe no SharePoint
            meta = self.get_item_metadata(site_id, base_next)
            if meta and meta.get("id"):
                # já existe → adiciona ao cache
                with self._folders_lock:
                    self._ensured_folders.add(base_next)
                base = base_next
                continue

            # cria a pasta (somente se não existir)
            self.create_folder(site_id, base, name)
            with self._folders_lock:
                self._ensured_folders.add(base_next)
            base = base_next


    def move_items_older_than(self, site_id: str, coop_base: str, hours: int = 24) -> None:
        def _parse_dt(iso_str: str):
            return datetime.fromisoformat(iso_str.replace("Z", "+00:00"))

        def _older_than(dt_iso: str):
            try:
                dt = _parse_dt(dt_iso)
            except Exception:
                return False
            now = datetime.now(timezone.utc)
            return (now - dt) > timedelta(hours=hours)

        pasta_monitorada = f"{coop_base}/PASTA_MONITORADA"
        pasta_resultados = f"{coop_base}/PASTA_RESULTADOS"

        proc_arquivos   = f"{coop_base}/PROCESSADOS/ARQUIVOS"
        proc_resultados = f"{coop_base}/PROCESSADOS/RESULTADOS"

        self.ensure_folder_path(site_id, proc_arquivos)
        self.ensure_folder_path(site_id, proc_resultados)

        itens_monitorada = self.search_folder_children(site_id, pasta_monitorada) or []
        itens_resultados = self.search_folder_children(site_id, pasta_resultados) or []

        futs = []

        # ===============================
        # MONITORADA → PROCESSADOS/ARQUIVOS
        # ===============================
        for item in itens_monitorada:
            if not _older_than(item.get("lastModifiedDateTime", "")):
                continue

            name = item["name"]
            src = f"{pasta_monitorada}/{name}"
            futs.append(
                SP_DOWNLOAD_POOL.submit(self.move, site_id, src, proc_arquivos)
            )

        # ===============================
        # RESULTADOS → PROCESSADOS/RESULTADOS
        # (arquivos e pastas)
        # ===============================
        for item in itens_resultados:
            if not _older_than(item.get("lastModifiedDateTime", "")):
                continue

            name = item["name"]
            src = f"{pasta_resultados}/{name}"
            futs.append(
                SP_DOWNLOAD_POOL.submit(self.move, site_id, src, proc_resultados)
            )

        done, pending = wait(futs, timeout=MOVE_TIMEOUT_S)

        for f in done:
            try:
                f.result()
            except Exception as e:
                self.log.error("Move exception: %s", e)

        for p in pending:
            p.cancel()
            self.log.error("Move timeout: cancelado após %ss", MOVE_TIMEOUT_S)


    def upload_results_bundle(
        self,
        site_id: str,
        pasta_resultados: str,
        numero_processo: str,
        output_dir: str = "output"
    ) -> list[str]:

        enviados = []
        pasta_processo_sp = f"{pasta_resultados}/{numero_processo}_resultado"

        # 1️⃣ garante pasta de resultados do processo
        self.ensure_folder_path(site_id, pasta_processo_sp)

        cooperativa = pasta_resultados.strip("/").split("/")[-2]

        # caminhos candidatos (flat e dentro da pasta do processo)
        candidatos = [
            os.path.join(output_dir, f"{numero_processo}_resultado.pdf"),
            os.path.join(output_dir, numero_processo, f"{numero_processo}_resultado.pdf"),
            os.path.join(output_dir, f"pessoas_{numero_processo}.json"),
            os.path.join(output_dir, numero_processo, f"pessoas_{numero_processo}.json"),
            os.path.join(output_dir, "dados_mua_*.json"),
            os.path.join(output_dir, numero_processo, "dados_mua_*.json"),
            os.path.join(output_dir, cooperativa, numero_processo, f"{numero_processo}_resultado.pdf"),
            os.path.join(output_dir, cooperativa, numero_processo, f"pessoas_{numero_processo}.json"),
            os.path.join(output_dir, cooperativa, numero_processo, "dados_mua_*.json"),
            os.path.join(output_dir, cooperativa, numero_processo, f"Relatorio ITI - *.pdf"),
            os.path.join(output_dir, cooperativa, numero_processo, f"Erro ITI - *.png"),
            os.path.join(output_dir, cooperativa, numero_processo, f"funarpen_*.png"),
            os.path.join(output_dir, cooperativa, numero_processo, f"funarpen_*.pdf"),
            os.path.join(output_dir, cooperativa, numero_processo, f"CRC CONTADOR - *.pdf"),
            os.path.join(output_dir, cooperativa, numero_processo, f"CRC CONTADOR - *.png"),
            os.path.join(output_dir, cooperativa, numero_processo, f"qsa-*.pdf"),
            os.path.join(output_dir, cooperativa, numero_processo, f"qsa-*.png"),
            os.path.join(output_dir, cooperativa, numero_processo, f"cartao-*.pdf"),
            os.path.join(output_dir, cooperativa, numero_processo, f"cartao-*.png"),
        ]

        arquivos = []
        vistos = set()

        for padrao in candidatos:
            for caminho in glob.glob(padrao):
                if os.path.isfile(caminho) and caminho not in vistos:
                    vistos.add(caminho)
                    arquivos.append(caminho)

        # 2️⃣ upload arquivo por arquivo
        for caminho in arquivos:
            nome = os.path.basename(caminho)
            try:
                ok = self.upload_item(site_id, pasta_processo_sp, caminho)
                if ok:
                    enviados.append(nome)
                    os.remove(caminho)
                    self.log.info(f"📤 Upload OK: {nome}")
                else:
                    self.log.error(f"❌ Upload falhou: {nome}")
            except Exception as e:
                self.log.error(f"❌ Erro no upload {nome}: {e}")

        # 3️⃣ valida se pelo menos o PDF principal subiu
        if not any(nome.endswith("_resultado.pdf") for nome in enviados):
            self.log.error("❌ PDF principal não enviado. Mantendo arquivos locais.")
            return []

        return enviados

    # --- 1) renomear com sufixo incremental
    def try_rename_increment(self, site_id: str, item_id: str, desired_name: str, max_attempts: int = 5) -> bool:
        """
        Tenta renomear um arquivo no SharePoint para o nome desejado.
        - Se o nome já existir, adiciona um sufixo incremental (ex: "arquivo (2).pdf").
        - Tenta até max_attempts vezes.
        Retorna True se conseguiu renomear, False caso contrário.
        """
        base, ext = os.path.splitext(desired_name)
        for attempt in range(max_attempts):
            new_name = desired_name if attempt == 0 else f"{base} ({attempt+1}){ext}"
            ok = self.rename_file_by_id(site_id, item_id, new_name)
            if ok:
                return True
        self.log.error(f"❌ Não foi possível renomear {desired_name} após {max_attempts} tentativas.")
        return False

    def mark_error(self, site_id, item, prefixo: str, max_tentativas=5):
        """
        Marca um arquivo no SharePoint como erro, adicionando um prefixo no nome.
        - Exemplo: "[ERRO]arquivo.pdf"
        - Usa try_rename_increment para evitar conflitos de nome.
        Retorna True se conseguiu renomear, False caso contrário.
        """
        try:
            nome_remoto = item.get("name", "")
            novo_nome = nome_remoto if nome_remoto.startswith(prefixo) else f"{prefixo}{nome_remoto}"
            return self.try_rename_increment(site_id, item["id"], novo_nome, max_tentativas)
        except Exception as e:
            self.log.error(f"⚠ Falha ao renomear no SharePoint ({prefixo.strip()}): {e}")
            return False
    
    def _pick(self, d: dict | None, *keys):
        """
        Função utilitária para navegar em dicionários aninhados.
        - Recebe um dicionário e uma sequência de chaves.
        - Retorna o valor encontrado ou None se não existir.
        """
        cur = d or {}
        for k in keys:
            cur = cur.get(k, {})
        return cur or None

    def responsavel_do_item(self, site_id: str, path_parent: str, item: dict) -> Optional[str]:
        """
        Retorna o Nome do criador ou último modificador do item.
        1) Tenta direto do payload de /children
        2) Se não houver, faz um GET de metadados do item para buscar createdBy/lastModifiedBy
        """
        # 1) tenta direto do item retornado pelo /children
        nome = (
            self._pick(item, "createdBy", "user", "displayName") or
            self._pick(item, "lastModifiedBy", "user", "displayName")
        )
        if nome:
            return nome

        # 2) fallback: consulta metadados do item individualmente (via path)
        name = item.get("name")
        if not name:
            return None

        meta = self.get_item_metadata(site_id, f"{path_parent}/{name}") or {}
        return (
            self._pick(meta, "createdBy", "user", "displayName") or
            self._pick(meta, "lastModifiedBy", "user", "displayName")
        )

    def move(self, site_id: str, item: str, pasta_destino: str,
            novo_nome: str | None = None, max_attempts: int = 10) -> bool:
        """
        Move/renomeia um item aceitando 'item' como path OU como id.
        - pasta_destino: pasta de destino (por PATH)
        - novo_nome: opcional (se None, usa o nome atual)
        - max_attempts: nº máximo de nomes alternativos a tentar em caso de conflito
        Retorna True em sucesso.
        """
        # 1) Resolve ID do item (tenta PATH primeiro; senão trata como ID)
        item_id = None
        item_name = None

        try:
            meta_item = self.get_item_metadata(site_id, item)
            if meta_item and isinstance(meta_item, dict) and "id" in meta_item:
                item_id = meta_item["id"]
                item_name = meta_item.get("name")
        except Exception:
            item_id = None

        if not item_id:
            item_id = item
            try:
                url_item = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/items/{item_id}"
                resp = self.__request_with_retry("GET", url_item, headers=self.__headers, max_tries=2)
                if resp is not None and resp.status_code in (200, 201):
                    j = resp.json()
                    item_name = j.get("name")
            except Exception:
                pass

        # 2) Resolve ID do PARENT destino
        meta_parent = self.get_item_metadata(site_id, pasta_destino)
        if not meta_parent or "id" not in meta_parent:
            self.log.error(f"Destino inválido (pasta_destino): {pasta_destino}")
            return False
        new_parent_id = meta_parent["id"]

        # 3) Nome final
        final_name = novo_nome if novo_nome is not None else (item_name or "")
        try:
            final_name = self.clean_sharepoint_name(final_name) if final_name else final_name
        except Exception:
            pass

        url_move = f"https://graph.microsoft.com/v1.0/sites/{site_id}/drive/items/{item_id}"

        # 4) Gera candidatos com base no max_attempts
        candidates: list[str | None] = []

        # Se você NÃO passou novo_nome, primeiro tentamos sem "name" no payload (mantém o atual)
        if not final_name:
            candidates.append(None)  # mantém o nome atual

        # Base para sufixos: usa final_name se informado, senão o item_name atual
        base_for_conflict = final_name or (item_name or "")
        base, ext = os.path.splitext(base_for_conflict)

        # Se temos um nome base, tente ele e sufixos (2..N)
        if base_for_conflict:
            # tenta explicitamente o nome base (caso final_name tenha sido informado)
            if final_name:
                candidates.append(final_name)
            for i in range(2, max_attempts + 1):
                candidates.append(f"{base} ({i}){ext}")
            # fallback com timestamp
            candidates.append(f"{base} [{datetime.now().strftime('%Y%m%d-%H%M%S')}]"+ext)

        def _payload(name_opt: str | None):
            p = {"parentReference": {"id": new_parent_id}}
            if name_opt:
                try:
                    name_opt = self.clean_sharepoint_name(name_opt)
                except Exception:
                    pass
                p["name"] = name_opt
            return p

        for name_try in candidates:
            resp = self.__request_with_retry('PATCH', url_move, headers=self.__headers,
                                            json=_payload(name_try), max_tries=3, timeout=120)
            if resp is None:
                continue

            if resp.status_code in (200, 201, 204):
                self.log.info(f"Moved to '{pasta_destino}' as '{name_try or final_name or item_name or '<same>'}'")
                return True

            if resp.status_code == 202:
                # operação assíncrona → faz poll
                loc = resp.headers.get("Location")
                if not loc:
                    return True
                import time as _t
                deadline = _t.time() + int(os.getenv("SP_MOVE_POLL_TIMEOUT_S", "90"))
                ok = False
                while _t.time() < deadline:
                    r = self.__request_with_retry('GET', loc, headers=self.__headers, max_tries=1, timeout=30)
                    if r is None:
                        _t.sleep(2)
                        continue
                    if r.status_code in (200, 201, 204):
                        ok = True
                        break
                    if r.status_code != 202:
                        break
                    _t.sleep(2)
                if ok:
                    return True
                continue

            if resp.status_code == 409:
                continue  # conflito de nome, tenta próximo candidate

            self.log.error(f"Move falhou ({resp.status_code}): {resp.text[:300]}")
            return False

        self.log.error("Move falhou após múltiplas tentativas/conflitos.")
        return False