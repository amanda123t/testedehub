
from importlib import import_module
from app.utils.helpers import normalize


# MAPA DE MODELOS
MODEL_MAPPING = {
    "ir_receipt": ("ir_receipt", "IR_Receipt", "Recibo de IR"),
    "irpf": ("irpf", "IRPF", "IRPF"),
    "inss": ("inss", "INSSList", "INSS"),
    "address": ("address", "Address", "Comprovante de Endereço"),
    "prolabore": ("prolabore", "ProLabore", "Pró-Labore"),
    "income": ("income", "Income", "Renda Presumida"),
    "paycheck": ("paycheck", "PaycheckList", "Holerite"),
    "crlv": ("crlv", "Crlv", "CRLV"),
    "self_declaration": ("declaration", "SelfDeclaration", "Autodeclaração de Renda"),
    "property_registration": ("property_registration", "PropertyRegistration", "Matrícula"),
    "pricing": ("pricing", "Pricing", "Precificação"),
    "balance": ("balance", "BalanceSheetList", "Balanço"),
    "dre": ("dre", "DRE", "DRE"),
    "registration_pj": ("registration_pj", "Registration_Pj", "Cadastro PJ"),
    "registration_pf": ("registration_pf", "Registration_Pf", "Cadastro PF"),
    "invoice": ("invoice", "Invoice", "Faturamento"),
    "presumedbilling": ("presumed_billing", "PresumedBilling", "Faturamento Presumido"),
    "contract": ("contract", "Contract", "Alteração Contratual"),
    "nota_fiscal": ("nota_fiscal", "Nota_Fiscal", "Nota Fiscal"),
    "receita": ("receita", "Receita", "Receita"),
    "serasa": ("serasa", "Serasa", "Serasa"),
    "cartao_cnpj": ("cartao_cnpj", "CartaoCNPJ", "Cartao CNPJ"),
    "simples": ("simples", "Simples", "Simples Nacional"),
    "pgdas": ("pgdas", "PGDAS", "PGDAS"),
    "recibo_pgdas": ("recibo_pgdas", "Recibo_PGDAS", "Recibo PGDAS"),
    "consulta_optantes": ("consulta_optantes", "Consulta_Optantes", "Consulta Optantes"),
    "minute": ("minute", "Minute", "Ata de eleição"),
    "certificado_mei": ("certificado_mei", "Certificado_MEI", "Certificado MEI"),
    "cnh": ("cnh", "CNH","CNH"),
    "bank_statement": ("bank_statement", "BankStatement", "Extrato Bancário"),
    "RG": ("rg", "RG", "RG"),
    "procuracao": ("procuracao", "Procuracao", "Procuração"),
    "avaliacao": ("avaliacao", "Avaliacao", "Laudo de Avaliação"),
    "car": ("car", "CAR", "CAR"),
    "carteira_trabalho": ("carteira_trabalho", "WorkCard", "Carteira de Trabalho"),
    "casamento": ("casamento", "Casamento", "Certidão de Casamento"),
    "uniao_estavel": ("uniao_estavel", "StableUnion", "União Estável"),
    "nascimento": ("nascimento", "Nascimento", "Certidão de Nascimento"),
    "obito": ("obito", "Obito", "Certidão de Óbito"),
    "croqui": ("croqui", "Croqui", "Croqui"),
    "fipe": ("fipe", "FipeTable", "Fipe"),
    "cpf_receita_federal": ("cpf_receita_federal", "CpfReceitaFederal", "Comprovante Situação Cadastral - CPF"),
    "midas": ("midas", "Midas", "MIDAS"),
    "rpr": ("rpr", "RPR", "RPR - Relatório Produtor Rural"),
    "self_declaration_address": ("self_declaration_address", "SelfDeclarationAddress", "Autodeclaração de Endereço"),
    "consent": ("consent", "Consent", "Anuência"),
    "arrendamento": ("arrendamento", "Arrendamento", "Contrato de Arrendamento"),
    "comodato": ("comodato", "Comodato", "Contrato de Comodato"),
    "locacao": ("locacao", "Locacao", "Contrato de Locação"),
    }

def obter_modelo_por_tipo(tipo_documento: str) -> type:
    """
    Retorna a classe do modelo de extração (pydantic/dataclass)
    com base no dicionário MODEL_MAPPING.

    Exemplo:
        MODEL_MAPPING['paycheck'] = ('paycheck', 'PaycheckList', 'Holerite')
    """
    chave = normalize(tipo_documento)

    for key, (modulo_nome, classe_nome, rotulo) in MODEL_MAPPING.items():
        candidatos = map(normalize, [key, modulo_nome, classe_nome, rotulo])
        if any(chave == c for c in candidatos):
            modulo = import_module(f"app.models.{modulo_nome}")
            return getattr(modulo, classe_nome)

    raise ValueError(f"Modelo não encontrado para o tipo: {tipo_documento}")

def get_model_info(doc_type: str) -> tuple[str, str]:
    """
    Retorna (doc_type_normalizado, type_name_bonito) com base no MODEL_MAPPING.
    Exemplo:
        get_model_info("paycheck") -> ("paycheck", "Holerite")
    """
    chave = normalize(doc_type)

    for key, (modulo_nome, classe_nome, rotulo) in MODEL_MAPPING.items():
        candidatos = map(normalize, [key, modulo_nome, classe_nome, rotulo])
        if any(chave == c for c in candidatos):
            # Retorna o nome normalizado e o rótulo amigável
            return normalize(key), rotulo

    # fallback seguro se nada encontrado
    return normalize(doc_type), doc_type.capitalize()
