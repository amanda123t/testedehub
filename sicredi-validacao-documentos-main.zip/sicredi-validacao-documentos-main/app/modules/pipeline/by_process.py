# app/modules/pipeline/by_process.py
from __future__ import annotations
from typing import Dict, Any, List
import os, re, time, traceback, atexit
from pathlib import Path
from threading import Semaphore
from dotenv import load_dotenv
from datetime import datetime
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import app.utils.arquives as arquive
from app.modules.document_processor import DocumentsProcessor
from app.modules.gerar_pdf import PDFGenerator
from app.utils.helpers import similar, normalize
from app.handlers.generico import HandlerGenerico
from app.handlers.base import ResultadoHandler
from app.handlers.nota_fiscal import HandlerNotaFiscal
from app.handlers.irpf import HandlerIRPFUnified
from app.handlers.bank_statement import HandlerBankStatement
from app.modules.classifier.simple_classifier import SimpleClassifier
from app.utils.logger import LoggerManager
from app.utils.APIs.api_receita import _CACHE_RECEITA
from app.modules.pipeline.validation_helper import validar_grupos
from app.modules.pipeline.model_mapping import get_model_info
from app.modules.supabase import SupabaseClient
from app.utils.gerar_html.gerar_html_receita import gerar_documentos_receita
from app.utils.gerar_html.gerar_html_crc import gerar_html_crc
from app.utils.assinaturas.validar_assinaturas import validar_assinatura_digital
log = LoggerManager(__name__)  # logger do módulo (task)
load_dotenv()

EXTENSOES_SUPORTADAS = {".pdf",".png",".jpg",".jpeg",".jfif",".tif",".tiff",".bmp",".webp"}
IGNORED_NAMES = {"__MACOSX", ".DS_Store", "Thumbs.db"}

# Registry simples de handlers especiais
HANDLERS_ESPECIAIS = {
    "nota_fiscal":  HandlerNotaFiscal,
    #"balance":     HandlerBalanco,
    #"dre":         HandlerDRE,
    "irpf":        HandlerIRPFUnified,
    "both":        HandlerIRPFUnified,
    "bank_statement": HandlerBankStatement,
    #"irpf_receipt":HandlerIRPFUnified,
    #"irpfreceipt": HandlerIRPFUnified,

}

# Paralelismo
MAX_DOC_POR_PROCESSO = int(os.getenv("MAX_DOC_POR_PROCESSO", "10"))
POOL_DOCUMENTOS = ThreadPoolExecutor(max_workers=MAX_DOC_POR_PROCESSO)
atexit.register(lambda: POOL_DOCUMENTOS.shutdown(wait=False))
MAX_DOC_POR_PROCESSO_TRAVA = int(os.getenv("MAX_DOC_POR_PROCESSO_TRAVA", "8"))
SEMAFORO = Semaphore(MAX_DOC_POR_PROCESSO_TRAVA)

processador_documentos = DocumentsProcessor()
classificador_simples = SimpleClassifier()
supabase = SupabaseClient()

VERSAO_EXTRATOR__TEXTO = "v1.2"  # muda sempre que alterar extração DE TEXTO, para o banco não reaproveitar textos com erros antigos, se a versão mudou valida de novo.

# Versão dos documentos para controle de mudanças na extração DOS DADOS
VERSAO_EXTRATOR__DADOS = { # Preencher com os mesmo nome colocado no model_mapping(nome: (x,y,z))
    "irpf": "v1.6",
    "ir_receipt": "v1.1",
    "nota_fiscal": "v1.0",
    "balance": "v1.0",
    "dre": "v1.0",
    "invoice": "v1.3",
    "paycheck": "v1.0",
    "prolabore": "v1.0",
    "income": "v1.1",
    "property_registration": "v1.1",
    "cnh": "v1.1",
    "rg": "v1.1",
    "certificado_mei": "v1.1",
    "default": "v1.0",
}
def tentar_classificar(texto: str, num_paginas: int) -> tuple[list[str], str]:
    for limiar in (7, 6, 5):
        tipos = classificador_simples.classificar(texto, limiar=limiar, num_paginas=num_paginas)
        if tipos and "None" not in tipos:
            return tipos, "SIMPLES"
    tipo_processo = 'GERAL'
    log.debug(f"Tentando classificação via IA (tipo {tipo_processo})...")
    tipo = processador_documentos.classify_document_type(texto, tipo_processo)
    return ([tipo] if isinstance(tipo, str) else tipo), "IA"

def gerar_saida(resultados_processo: dict, cabecalho: list[list[str]], caminho_pdf: Path, caminho_json_pessoas: Path) -> None:
    """Gera o PDF consolidado do processo a partir do resultados_processo['validacoes_por_pessoa']."""

    pdf = PDFGenerator(str(caminho_pdf))
    pdf.add_section("Resultados do Processamento:", cabecalho)

    validacoes_por_pessoa = resultados_processo.get("validacoes_por_pessoa", {})
    log.debug(f"Validações por pessoa final: {validacoes_por_pessoa.keys()}")

    for pessoa, dados in validacoes_por_pessoa.items():

        # --------------------------------------------------------
        # CASO 1 — Nome único (não contém " | ")
        # --------------------------------------------------------
        if " | " not in pessoa:
            titulo_pessoa = f"===== {pessoa.upper()} ====="
            pdf.add_section(titulo_pessoa, [" "])

        # --------------------------------------------------------
        # CASO 2 — Documento relacionado a várias pessoas
        # --------------------------------------------------------
        else:
            nomes = [n.strip() for n in pessoa.split("|") if n.strip()]
            nomes = list(dict.fromkeys(nomes))  # remove duplicatas mantendo ordem
            qtd = len(nomes)

            # Título especial
            titulo_pessoa = f"===== DOCUMENTO RELACIONADO A {qtd} PESSOAS ====="
            pdf.add_section(titulo_pessoa, [" "])

            # Lista de nomes para exibir embaixo
            lista_formatada = [f"- {n.upper()}" for n in nomes]
            log.debug(f"Nomes(lista_Formatada): {lista_formatada}")
            # Section explicando visualmente
            pdf.add_section("Pessoas envolvidas:", [" "])
            for n in nomes:
                pdf.add_section(f"- {n.upper()}", "")

        # --------------------------------------------------------
        # Agora exibe todas as validações para essa pessoa
        # --------------------------------------------------------
        for doc in dados.get("jsons", []):
            for titulo, linhas in doc.get("sections", []):
                pdf.add_section(titulo, linhas)

    pdf.save()

    #try:
    #    with open(caminho_json_pessoas, "w", encoding="utf-8") as arquivo_json:
    #        json.dump(validacoes_por_pessoa, arquivo_json, ensure_ascii=False, indent=4)
    #    log.info(f"JSON final de pessoas salvo em: {caminho_json_pessoas}")
    #except Exception as erro_gravacao:
    #    log.error(f"⚠ Não foi possível gravar {caminho_json_pessoas.name}: {erro_gravacao}")

def registrar_documento(dados_tipo: dict):
    tipo_norm, type_name = get_model_info(dados_tipo.get("tipo"))
    registro = {
        #"horario_lido": time.strftime("%Y-%m-%d"),
        "processo": dados_tipo.get("processo"),
        "arquivo": dados_tipo.get("arquivo"),
        "hash": dados_tipo.get("hash", ""),
        "cooperativa": dados_tipo.get("cooperativa"),
        "colaborador": dados_tipo.get("colaborador"),
        "tipo": type_name,
        "identificador": dados_tipo.get("identificador") or f"GEN{int(time.time()*1000)}",
        "tokens": dados_tipo.get("tokens", 0),
        "dados": dados_tipo.get("dados", {}),
        "nome_pessoa": dados_tipo.get("nome_pessoa", ""),
        "caracteres": dados_tipo.get("qtde_caracteres", 0),
        "paginas": dados_tipo.get("num_paginas", 0),
        "metodo_extracao": dados_tipo.get("metodo_extracao", ""),
        "metodo_classificacao": dados_tipo.get("metodo_classificacao", ""),
        "duracao_extracao": round(dados_tipo.get("duracao_extracao", 0), 3) if isinstance(dados_tipo.get("duracao_extracao"), (int, float)) else 0,
        "validou_ok": dados_tipo.get("validou_ok"),
        "contagem_validacao": dados_tipo.get("contagem_validacao", 0),
        "mensagem": dados_tipo.get("mensagem", 'OK'),
        "versao_dados": VERSAO_EXTRATOR__DADOS.get(tipo_norm,VERSAO_EXTRATOR__DADOS["default"]),
    }
    try:
        supabase.upsert("documentos", registro, on_conflict=["processo", "hash", "tipo", "identificador"])
        log.info(f"✅ Documento registrado no Supabase!")
    except Exception as e:
        log.error(f"⚠ Falha ao inserir documento no Supabase: {e}")
        

def registrar_arquivo(dados_arquivo: dict):
    registro = {
        #"horario_lido": time.strftime("%Y-%m-%d"),
        "processo": dados_arquivo.get("processo"),
        "cooperativa": dados_arquivo.get("cooperativa"),
        "colaborador": dados_arquivo.get("colaborador"),
        "arquivo": os.path.basename(dados_arquivo.get("arquivo", "")),
        "hash": dados_arquivo.get("hash", ""),
        "texto": dados_arquivo.get("texto_paginas", []),
        "metodo_extracao": dados_arquivo.get("metodo_extracao", ""),
        "metodo_classificacao": dados_arquivo.get("metodo_classificacao", ""),
        "paginas": dados_arquivo.get("numero_paginas", 0),
        "caracteres": dados_arquivo.get("quantidade_caracteres", 0),
        "tokens": dados_arquivo.get("tokens", 0),
        "tipos": ", ".join(dados_arquivo.get("tipos", [])),
        "mensagem": dados_arquivo.get("mensagem", 'OK'),
        "versao_extrator": VERSAO_EXTRATOR__TEXTO,
    }
    try:
        supabase.upsert("arquivos", registro, on_conflict=["cooperativa", "processo", "colaborador", "hash"])
        log.info(f"✅ Arquivo registrado no Supabase!")
    except Exception as e:
        log.error(f"⚠ Falha ao inserir documento no Supabase: {e}")

def registrar_processo(dados_processo: dict):
    """
    Registra o processo na tabela PROCESSOS do Supabase
    usando apenas o dict 'dados_processo'.
    
    O dict deve conter:
        processo, cooperativa, colaborador,
        duracao_total_s, qtd_docs, qtd_uso_ocr,
        qtd_validator_false, qtd_consultas_receita, status
    """

    registro = {
        "data": datetime.now().strftime("%Y-%m-%d"),
        "processo": dados_processo.get("processo"),
        "cooperativa": dados_processo.get("cooperativa"),
        "colaborador": dados_processo.get("colaborador"),
        "duracao_total_s": dados_processo.get("duracao_total_s", 0),
        "qtd_documentos": dados_processo.get("qtd_docs", 0),
        "qtd_uso_ocr": dados_processo.get("qtd_uso_ocr", 0),
        "qtd_com_validator_false": dados_processo.get("qtd_validator_false", 0),
        "quantidade_consultas_receita": dados_processo.get("qtd_consultas_receita", 0),

        # Se não vier nada, calcula automático
        "status": dados_processo.get(
            "status",
            "OK" if dados_processo.get("qtd_docs", 0) > 0 else "ERRO GERAL"
        ),
    }

    try:
        supabase.upsert(
            "processos",
            registro,
            on_conflict=["processo", "cooperativa", "colaborador"]
        )
        log.info(f"✅ Processo registrado no Supabase!")
    except Exception as e:
        log.error(f"⚠ Falha ao inserir processo no Supabase: {e}")

def extrair_numero_processo(nome: str) -> str:
    # pega todos os grupos contínuos de números
    grupos = re.findall(r"\d+", nome)

    if not grupos:
        return ""

    # tamanho do maior grupo
    max_len = max(len(g) for g in grupos)

    # grupos que têm o maior tamanho
    maiores = [g for g in grupos if len(g) == max_len]

    # se só um é maior, retorna ele
    if len(maiores) == 1:
        return maiores[0]

    # se todos têm o mesmo tamanho, junta
    return "".join(maiores)

def by_process(
    caminho_processo: str,
    informacoes_processo: Dict[str, Any],
    *,
    caminho_planilha_regras: str,
    coletor_erros: Any,
) -> None:
    """
    Executa o pipeline completo de validação por processo.

    Etapas:
        1. Varre arquivos do processo e extrai texto (OCR/pdf_text)
        2. Classifica documentos (simple_classifier / IA)
        3. Executa handlers especializados
        4. Agrega resultados por pessoa e tipo de documento
        5. Executa validadores específicos (cadastro, IRPF, holerite, nota, etc.)
        6. Gera PDF e planilha de resultados
    """
    log.info(f"📄 Iniciando processamento na pasta {caminho_processo}")
    # ✅ snapshot do cache global antes do processo
    cache_inicial = set(_CACHE_RECEITA.keys())
    tempo_inicio = time.perf_counter()
    # Caminhos de saída
    nome_processo_base = Path(caminho_processo).name
    
    # NOVO: saída por cooperativa e processo
    cooperativa = informacoes_processo.get("cooperativa") or ""
    nome_colaborador = informacoes_processo.get("colaborador", "")

    pasta_output = Path(__file__).resolve().parents[3] / "output" / cooperativa / nome_processo_base
    pasta_output.mkdir(parents=True, exist_ok=True)

    caminho_pdf_resultado = pasta_output / f"{nome_processo_base}_resultado.pdf"
    caminho_json_pessoas  = pasta_output / f"pessoas_{nome_processo_base}.json"

    # Número de processo (se a pasta tiver apenas números)
    numero_processo = extrair_numero_processo(nome_processo_base)

    cabecalho_processo: List[List[str]] = []
    # Descobrir arquivos
    caminhos_arquivos = arquive.listar_arquivos_validos(caminho_processo)
    resultados_processo = {}
    resultados_processo['informacoes_processos'] = informacoes_processo
    resultados_processo['arquivos'] = {}
    resultados_processo['numero_processo'] = numero_processo
    resultados_processo['cooperativa'] = cooperativa
    resultados_processo['colaborador'] = nome_colaborador

    def _processar_um(caminho_arquivo: str):
        def _wrapper():
            inicio_documento = time.perf_counter()
            arquivo = os.path.relpath(caminho_arquivo, caminho_processo)
            resultados_arquivo = {"arquivo": arquivo, "mensagem": "OK", "processo": nome_processo_base, "cooperativa": cooperativa, "colaborador": nome_colaborador}
            texto_inicial: str = ''
            texto_paginas: list[str] = []
            qtd_tokens: int = 0
            tipos_documento: list[str] = []
            num_paginas: int = 0
            qtde_caracteres: int = 0
            metodo_extracao = "PDF_TEXT"  # use variável local em vez de compartilhar nome externo
            metodo_classificacao = "SIMPLES"
            max_pag = 30
            try:
                with SEMAFORO:
                    log.info(f"📂 Processando arquivo: {arquivo}")
                    num_paginas = arquive.contar_paginas(caminho_arquivo)
                    log.info(f"📄 Páginas detectadas para '{arquivo}': {num_paginas}")
                    hash_arquivo = arquive.gerar_hash_arquivo(caminho_arquivo)
                    log.info(f"🔑 Hash calculada para '{arquivo}': {hash_arquivo}")
                    resultados_arquivo['numero_paginas'] = num_paginas
                    resultados_arquivo["hash"] = hash_arquivo
                    # ♻️ 1️⃣ Tenta reaproveitar o texto salvo no Supabase
                    is_teste = "teste" in (cooperativa or "").lower()
                    registro_existente = supabase.select("arquivos", {"hash": hash_arquivo})
                    registro_existente = registro_existente[0] if registro_existente else None

                    if registro_existente:
                        versao_banco = registro_existente.get("versao_extrator")

                        # 🔥 Se for cooperativa de teste, sempre ignorar o cache.
                        if is_teste:
                            log.info("🔁 Cooperativa em modo de teste — ignorando cache de texto do Supabase.")
                            registro_existente = None

                        # Caso contrário, valida versão normalmente
                        elif versao_banco != VERSAO_EXTRATOR__TEXTO:
                            log.warning(f"⚠️ Versão do extrator mudou ({versao_banco} → {VERSAO_EXTRATOR__TEXTO}) — ignorando cache de texto.")
                            registro_existente = None

                        else:
                            # Cache válido → reutiliza
                            metodo_extracao = registro_existente.get("metodo_extracao", "")
                            texto_paginas = registro_existente.get("texto", [])
                            texto_inicial = "\n".join(texto_paginas or [])

                            if not texto_paginas or not texto_inicial.strip():
                                log.warning(f"⚠️ Texto ausente ou inválido no banco para '{arquivo}' — reextraindo normalmente.")
                                registro_existente = None
                            else:
                                resultados_arquivo.update({
                                    "texto_paginas": texto_paginas,
                                    "metodo_extracao": metodo_extracao,
                                })
                                log.info(f"♻️ Texto reaproveitado do banco ({metodo_extracao}, {qtde_caracteres} caracteres).")

                    if not registro_existente:  # 1) Extração normal
                        log.info("📂 Nenhum texto existente no banco — prosseguindo com extração normal.")
                        log.info(f"🔍 Extraindo texto...")
                        try:
                            # política simples: amostra se >30, senão todas as páginas
                            if num_paginas > max_pag:
                                resultado_extracao = processador_documentos.reader.texto_por_pagina_threaded(caminho_arquivo, qtde_paginas=7)
                                metodo_extracao = "AMOSTRA"
                            else:
                                resultado_extracao = processador_documentos.reader.texto_por_pagina_threaded(caminho_arquivo)
                                if resultado_extracao.meta.get("ocr_count", 0) == 0 and any(m == "pdf_text" for m in resultado_extracao.methods):
                                    metodo_extracao = "PDF_TEXT"
                                elif resultado_extracao.meta.get("pdf_text_count", 0) == 0 and any(m == "ocr" for m in resultado_extracao.methods):
                                    metodo_extracao = "OCR"
                                else:
                                    metodo_extracao = "MISTO"
                        except Exception as e_ocr:
                            log.error(f"⚠ Erro na reextração OCR com cache: {e_ocr}")
                            coletor_erros.marcar("ERRO OCR - ")
                            resultados_arquivo["mensagem"] = "ERRO OCR"
                            resultados_processo["arquivos"][os.path.basename(caminho_arquivo)] = resultados_arquivo
                            return {}
                        
                        resultados_arquivo["metodos"] = resultado_extracao.methods  # salva os metodos por pagina, com isso sabemos quais paginas usaram OCR
                        texto_paginas = resultado_extracao.pages              # sempre disponível (lista por página)
                        texto_inicial = resultado_extracao.text               # concat para quem ainda precisa string
                        qtde_caracteres = len(texto_inicial)

                        log.info(
                            f"🔎 Texto extraído com {qtde_caracteres} caracteres! "
                            f"(metodo={metodo_extracao}, ocr={resultado_extracao.meta.get('ocr_count')}, pdf={resultado_extracao.meta.get('pdf_text_count')})"
                        )
                        log.debug(f"pages -> {texto_paginas}")

                    resultados_arquivo['quantidade_caracteres'] = qtde_caracteres
                    resultados_arquivo['texto_paginas'] = texto_paginas
                    resultados_arquivo['metodo_extracao'] = metodo_extracao

                    if not texto_inicial.strip():
                        log.error(f"⚠ Erro ao extrair texto de '{arquivo}'")
                        coletor_erros.marcar("ERRO OCR - ")
                        resultados_arquivo["mensagem"] = "ERRO OCR"
                        resultados_processo["arquivos"][os.path.basename(caminho_arquivo)] = resultados_arquivo #Salva o resultado parcial
                        return {}

                    log.debug(f"DEBUG: texto_inicial do arquivo '{arquivo}': \n{texto_inicial}")   
                    # 4) Classificação
                    try:
                        tipos_documento, metodo_classificacao = tentar_classificar(texto_inicial, num_paginas)
                    except Exception as e_cls:
                        log.error(f"⚠ Falha ao classificar '{arquivo}': {e_cls}")

                    resultados_arquivo['tipos'] = tipos_documento
                    resultados_arquivo['metodo_classificacao'] = metodo_classificacao
                    # 🔁 Se não classificou e ainda não passou por OCR, refaz a extração via OCR (com cache por página)
                    if (not tipos_documento or "None" in tipos_documento) and "OCR" not in metodo_extracao.upper():
                        try:
                            if num_paginas > max_pag:
                                log.info("🔁 Documento não classificado — reextraindo as 7 páginas da amostra via OCR (cache por página ativado)...")
                                metodo_extracao = "AMOSTRA"
                                resultado_ocr = processador_documentos.reader.texto_por_pagina_threaded(
                                    caminho_arquivo,
                                    qtde_paginas=7,
                                    modo="AZURE_OCR",
                                )
                            else:
                                log.info("🔁 Documento não classificado — reextraindo documento completo via OCR (cache por página ativado)...")
                                metodo_extracao = "OCR"
                                resultado_ocr = processador_documentos.reader.texto_por_pagina_threaded(
                                    caminho_arquivo,
                                    modo="AZURE_OCR",
                                )
                        except Exception as e_ocr:
                            log.error(f"⚠ Erro na reextração OCR com cache: {e_ocr}")
                            coletor_erros.marcar("ERRO OCR - ")
                            resultados_arquivo["mensagem"] = "ERRO OCR"
                            resultados_processo["arquivos"][os.path.basename(caminho_arquivo)] = resultados_arquivo
                            return {}
                        texto_paginas = resultado_ocr.pages
                        texto_inicial = resultado_ocr.text
                        qtde_caracteres = len(texto_inicial)

                        resultados_arquivo.update({
                            "texto_paginas": texto_paginas,
                            "quantidade_caracteres": qtde_caracteres,
                            "metodo_extracao": metodo_extracao,
                        })

                        log.info(
                            f"🔎 OCR concluído ({qtde_caracteres} caracteres). "
                            f"(ocr={resultado_ocr.meta.get('ocr_count')}, pdf={resultado_ocr.meta.get('pdf_text_count')})"
                        )

                        # 🔁 Reclassifica com o texto completo/atualizado
                        try:
                            tipos_documento, metodo_classificacao = tentar_classificar(texto_inicial, num_paginas)
                        except Exception as e_cls:
                            log.error(f"⚠ Falha ao classificar '{arquivo}' após OCR completo: {e_cls}")
                        resultados_arquivo["tipos"] = tipos_documento
                        resultados_arquivo["metodo_classificacao"] = metodo_classificacao
                    
                    if not tipos_documento or "None" in tipos_documento: # Se mesmo assim não classificou, erro
                        log.info("Tipo do documento não encontrado, encerramento")
                        coletor_erros.marcar("ERRO CLASSIFICACAO - ")
                        resultados_arquivo["mensagem"] = "ERRO CLASSIFICACAO"
                        resultados_processo["arquivos"][os.path.basename(caminho_arquivo)] = resultados_arquivo #Salva o resultado parcial
                        return {}
                    
                    log.info(f"📌 Tipos do documento classificados: {tipos_documento} para o arquivo: {arquivo}")
                    log.info("🔐 Validando se possui assinatura digital...")
                    resultado_ass = validar_assinatura_digital(
                        caminho_arquivo=caminho_arquivo,
                        texto=texto_inicial,
                        tipos_documento=tipos_documento,
                        pasta_output=str(pasta_output)
                    )

                    resultados_arquivo["resultado_assinatura"] = resultado_ass

                    # (opcional) contagem de tokens para log
                    qtd_tokens = processador_documentos.extractor.contar_tokens(texto_inicial or "")
                    log.info(f"🔢 Documento com {qtd_tokens} tokens (após normalização básica).")
                    resultados_arquivo['tokens'] = qtd_tokens
                    # Regra de documentos muito grandes: só processa nota_fiscal
                    if num_paginas > max_pag:
                        if not any("nota_fiscal" in t.lower() or "irpf" in t.lower() or 'receipt' in t.lower() for t in tipos_documento):
                            resultados_processo["arquivos"][os.path.basename(caminho_arquivo)] = resultados_arquivo #Salva o resultado parcial
                            resultados_arquivo["mensagem"] = "ERRO TOKENS"
                            return {}
                        tipos_documento = [t for t in tipos_documento if 'receipt' in t.lower() or 'irpf' in t.lower() or 'fiscal' in t.lower()]
                        try:
                            log.info("📄 Documento identificado como Nota Fiscal/IR, extraindo da página 5 até o final...")
                            pages_indices = list(range(6, num_paginas))  # 0-based: começa na 5ª página
                            resultado_restante = processador_documentos.reader.texto_por_pagina_threaded(
                                caminho_arquivo,
                                pages_indices=pages_indices
                            )
                            # 🔹 Junta o resultado inicial (1–4) com o restante (5–fim)
                            resultado_extracao = resultado_extracao.merge(resultado_restante)

                            texto_paginas = resultado_extracao.pages
                            texto_inicial = resultado_extracao.text
                            qtde_caracteres = len(texto_inicial)
                            if resultado_restante.meta.get("ocr_count", 0) == 0 and any(m == "pdf_text" for m in resultado_restante.methods):
                                metodo_extracao = "PDF_TEXT"
                            elif resultado_restante.meta.get("pdf_text_count", 0) == 0 and any(m == "ocr" for m in resultado_restante.methods):
                                metodo_extracao = "OCR"
                            else:
                                metodo_extracao = "MISTO"
                            log.info(f"📜 Texto re-extraído de {len(pages_indices)} páginas (5 até {num_paginas}).")
                        except Exception as e_nf:
                            log.error(f"⚠ Falha ao extrair páginas da nota fiscal: {e_nf}")
                        resultados_arquivo["tipos"] = tipos_documento
                        resultados_arquivo["context"] = texto_paginas

                # 5) Executar um handler para CADA tipo e agregar resultados
                duracao_inicial_tipo = time.perf_counter() - inicio_documento
                resultados_arquivo["documentos"] = {}
                documentos = {} # lista de documentos dentro do arquivo.
                for tipo in tipos_documento:
                    doc_type_norm, type_name = get_model_info(tipo)
                    documentos[type_name] = []
                    inicio_tipo = time.perf_counter()
                    chave = normalize(tipo)

                    # ♻️ Verifica se já existem documentos no banco para este arquivo e tipo
                    docs_existentes = supabase.select("documentos", {
                        "hash": hash_arquivo,
                        "tipo": type_name
                    })
                    docs_filtrados = {}
                    for d in docs_existentes:
                        ident = d.get("identificador")
                        if not ident:
                            continue

                        if ident not in docs_filtrados:
                            docs_filtrados[ident] = d
                        else:
                            # mantém sempre o mais recente
                            c1 = d.get("created_at")
                            c2 = docs_filtrados[ident].get("created_at")

                            if c1 and (not c2 or c1 > c2):
                                docs_filtrados[ident] = d

                    docs_existentes = list(docs_filtrados.values())

                    if is_teste:
                        log.info("🔁 Cooperativa em modo de teste — ignorando cache de dados do Supabase.")
                        docs_existentes = []
                    else:
                        # 🔁 Verifica versão da extração de dados
                        versao_banco = (docs_existentes[0].get("versao_dados") if docs_existentes else None)
                        versao_local = VERSAO_EXTRATOR__DADOS.get(type_name.lower(), VERSAO_EXTRATOR__DADOS["default"])

                        if versao_banco != versao_local:
                            log.warning(f"⚠️ Versão dos dados mudou para '{type_name}' ({versao_banco} → {versao_local}) — ignorando cache de dados.")
                            docs_existentes = []
                    if docs_existentes:
                        log.info(f"♻️ Reaproveitando {len(docs_existentes)} documentos do banco ({type_name}) para '{arquivo}'")
                        resultados_arquivo["documentos"].setdefault(type_name, []).extend(docs_existentes)

                        for d in resultados_arquivo["documentos"][type_name]:
                            # ✅ Atualiza campos técnicos
                            d["qtde_caracteres"] = d.get("qtde_caracteres") or resultados_arquivo.get("quantidade_caracteres") or qtde_caracteres
                            d["num_paginas"] = d.get("num_paginas") or resultados_arquivo.get("numero_paginas") or num_paginas
                            d["metodo_extracao"] = d.get("metodo_extracao") or resultados_arquivo.get("metodo_extracao")
                            d["metodo_classificacao"] = d.get("metodo_classificacao") or resultados_arquivo.get("metodo_classificacao")
                        continue  # ✅ pula o handler, reaproveitando completamente

                    # 🔹 Se não existe no banco, executa o handler normalmente
                    handler_class = HANDLERS_ESPECIAIS.get(chave, HandlerGenerico)
                    handler = handler_class(
                        caminho_arquivo,
                        texto_paginas=texto_paginas,
                        tipo_documento_pre=tipo,
                    )
                    log.info(f"📄 Processando '{arquivo}' com handler '{handler_class.__name__}' para tipo '{type_name}'")
                    parcial: ResultadoHandler = handler.processar() or {}

                    duracao_tipo = round(time.perf_counter() - inicio_tipo, 3)
                    duracao_total = duracao_inicial_tipo + duracao_tipo
                    doc_type_norm, type_name = get_model_info(tipo)

                    for doc in parcial.get("documentos", []):
                        doc.update({
                            "arquivo": os.path.basename(caminho_arquivo),
                            "hash": hash_arquivo,  # ✅ salva hash também nos documentos
                            "metodo_extracao": parcial.get("modelo_extracao") or metodo_extracao,
                            "metodo_classificacao": metodo_classificacao,
                            "tokens": qtd_tokens,
                            "qtde_caracteres": qtde_caracteres,
                            "num_paginas": num_paginas,
                            "duracao_extracao": duracao_total,
                            "tipo": type_name,
                            "mensagem": "OK",
                            "processo": nome_processo_base, 
                            "cooperativa": cooperativa,
                            "colaborador": nome_colaborador,
                        })
                    log.debug(f"Parcial documentos para '{type_name}': {parcial.get('documentos', [])}")
                    resultados_arquivo["documentos"].setdefault(type_name, []).extend(parcial.get("documentos", []))
                    log.debug(f"Documentos acumulados para '{type_name}': {resultados_arquivo['documentos']}")

                resultados_processo["arquivos"][os.path.basename(caminho_arquivo)] = resultados_arquivo #Salva o resultado parcial
                return True

            except Exception as erro_worker:
                log.error(f"❌ Erro inesperado ao processar '{arquivo}': {erro_worker}")
                traceback.print_exc()
                coletor_erros.marcar("ERRO PROCESSO - ")
                resultados_arquivo["mensagem"] = "ERRO PROCESSO"
                resultados_processo["arquivos"][os.path.basename(caminho_arquivo)] = resultados_arquivo #Salva o resultado parcial
                return {}

        return POOL_DOCUMENTOS.submit(_wrapper)

    # Disparar
    tarefas = {_processar_um(c): c for c in caminhos_arquivos}

    # Agregar resultados
    for futuro in as_completed(tarefas):
        caminho_arquivo = tarefas.get(futuro, None)
        try:
            futuro.result() or {}
        except Exception as erro_future:
            nome_arquivo = os.path.basename(caminho_arquivo or "desconhecido")
            log.error(f"⚠ Thread falhou no arquivo '{nome_arquivo}': {erro_future}")
            coletor_erros.marcar("ERRO PROCESSO - ")

            # 🛑 Evita duplicar se o mesmo arquivo já foi registrado nesta execução
            if any(a.get("arquivo") == nome_arquivo for a in resultados_processo.get("arquivos", {}).values()):
                continue
            resultados_processo["arquivos"][nome_arquivo]["mensagem"] = "ERRO THREAD"
            continue
    
    log.info("Finalizado loop de validação dos arquivos...")

    nomes_coletados = []
    grupos_por_pessoa: Dict[str, Dict[str, Any]] = {}
    for arquivo, dados in resultados_processo["arquivos"].items():
        for tipo, lista_docs in dados.get("documentos", {}).items():
            for d in lista_docs:
                nome = d.get("nome_pessoa") or "DESCONHECIDO"
                grupos_por_pessoa.setdefault(nome, {}).setdefault(tipo, []).append(d)
                if nome and nome.upper() != "DESCONHECIDO":
                    nomes_coletados.append(nome) # 🔹 Identificar pessoa principal do processo

    if nomes_coletados:
        contagem = Counter(nomes_coletados)
        mais_comuns = contagem.most_common()

        # Verifica se há um nome que aparece mais vezes que os demais
        if len(mais_comuns) == 1 or mais_comuns[0][1] > mais_comuns[1][1]:
            nome_principal = mais_comuns[0][0]
            informacoes_processo["nome"] = nome_principal
            resultados_processo["nome_principal"] = nome_principal
            log.info(f"👤 Pessoa principal identificada no processo: {nome_principal}")
        else:
            log.warning(
                f"⚠ Nenhum nome predominante encontrado. Distribuição: {dict(contagem)}"
            )
    else:
        log.warning("⚠ Nenhum nome válido identificado nos documentos do processo.")



    validar_grupos(
        grupos_por_pessoa,
        informacoes_processo=informacoes_processo,
        numero_processo=numero_processo,
        caminho_planilha_regras=caminho_planilha_regras,
        resultados_processo=resultados_processo,
        process_path=caminho_processo
    )
    # ✅ Após validação, registrar tudo (OK ou erro)
    for arquivo, dados in resultados_processo.get("arquivos", {}).items():
        registrar_arquivo(dados)
        for tipo, lista_docs in dados.get("documentos", {}).items():
            for d in lista_docs:
                registrar_documento(d)
                log.debug(f"Documento registrado: {d.get('arquivo')} - {d.get('tipo')}")


    for pessoa_data in resultados_processo.get("validacoes_por_pessoa", {}).values():
        for saida in pessoa_data.get("jsons", []):
            if saida.get("header_info"):
                cabecalho_processo = saida["header_info"]
                break
        if cabecalho_processo:
            break

    # ✅ Fallback: se nenhum header_info foi encontrado, usa informacoes_processo
    if not cabecalho_processo:
        cabecalho_processo = [[f"{k.capitalize()}:", str(v)] for k, v in informacoes_processo.items()]
        log.info(f"📋 Nenhum header_info encontrado nos validadores — usando informacoes_processo: {cabecalho_processo}")


    tem_sections = any(
        any(doc.get("sections") for doc in pessoa.get("jsons", []))
        for pessoa in resultados_processo.get("validacoes_por_pessoa", {}).values()
    )
    # 🔹 Geração do PDF + JSON se houver sections
    if tem_sections:
        try:
            gerar_saida(resultados_processo, cabecalho_processo, caminho_pdf_resultado, caminho_json_pessoas)
        except Exception as e_pdf:
            log.error(f"⚠ Falha ao salvar PDF final: {e_pdf}")
            coletor_erros.marcar("ERRO PROCESSO - ")
    else:
        log.warning("⚠ Nenhum documento válido foi encontrado. PDF não será gerado.")
        coletor_erros.marcar("ERRO SEM DOC. VALIDO - ")

    # 🔹 Contagens e registro do processo — sempre executa, mesmo com erro
    todos_docs = [
        d
        for dados_arquivo in resultados_processo["arquivos"].values()
        for tipo_docs in dados_arquivo.get("documentos", {}).values()
        for d in tipo_docs
    ]

    qtd_docs = len(todos_docs)
    qtd_ocr = sum(1 for d in todos_docs if d.get("metodo_extracao") == "OCR")
    qtd_validator_false = sum(1 for d in todos_docs if d.get("validou_ok") is False)

    fim_processo = time.perf_counter()
    dur_total_s = round(fim_processo - tempo_inicio, 3)
    # 🔹 Calcula apenas as novas consultas feitas neste processo
    consultas_finais = set(_CACHE_RECEITA.keys())
    novas_consultas = consultas_finais - cache_inicial
    qtd_novas_consultas = len(novas_consultas)
    dados_processo = {
        "processo": nome_processo_base,
        "cooperativa": cooperativa,
        "colaborador": nome_colaborador,
        "duracao_total_s": dur_total_s,
        "qtd_docs": qtd_docs,
        "qtd_uso_ocr": qtd_ocr,
        "qtd_validator_false": qtd_validator_false,
        "qtd_consultas_receita": qtd_novas_consultas,
        "status": "OK" if qtd_docs > 0 else "ERRO GERAL"
    }


    registrar_processo(dados_processo)
    # ============================================================
    # GERAÇÃO FINAL: CNPJs + CRCs (salva na pasta_output do processo)
    # ============================================================
    try:
        consultas_proc = resultados_processo.get("consultas") or {}
        lista_cnpjs = consultas_proc.get("cnpjs") or []
        lista_contadores = consultas_proc.get("contadores") or []

        # -----------------------------
        # CNPJs (gera QSA + Cartão)
        # -----------------------------
        for item in lista_cnpjs:
            if not isinstance(item, dict) or not item:
                continue

            # cada item é { "cnpj_so_digitos": {dados} }
            for cnpj_key, dados_receita in item.items():
                if not isinstance(dados_receita, dict) or not dados_receita:
                    continue  # "gerar apenas se tiver algum dado"

                try:
                    log.info(f"🧾 Gerando QSA/Cartão CNPJ para {cnpj_key}...")
                    gerar_documentos_receita(
                        d=dados_receita,
                        pasta_destino=str(pasta_output),
                        pdf=True,
                        png=False,
                    )
                except Exception as e:
                    log.error(f"⚠ Falha ao gerar documentos do CNPJ {cnpj_key}: {e}")
                    traceback.print_exc()

        # -----------------------------
        # Contadores (gera CRC)
        # -----------------------------
        for item in lista_contadores:
            if not isinstance(item, dict) or not item:
                continue

            # cada item é { "cpf_ou_nome": {"data":[...], "totalCount": N} }
            for contador_key, payload_crc in item.items():
                if not isinstance(payload_crc, dict) or not payload_crc:
                    continue

                dados_crc = payload_crc.get("dados") or {}

                total = dados_crc.get("totalCount", 0) or payload_crc.get("total", 0) or 0
                resultados = dados_crc.get("data") or []

                # "apenas se total count for maior que 1"
                if total <= 1:
                    continue

                if not isinstance(resultados, list) or not resultados:
                    continue

                try:
                    log.info(f"📄 Gerando CRC do contador ({contador_key}) - totalCount={total}...")
                    gerar_html_crc(
                        resultados=resultados,
                        pasta_destino=str(pasta_output),
                        pdf=True,
                        png=False,
                    )
                except Exception as e:
                    log.error(f"⚠ Falha ao gerar CRC do contador {contador_key}: {e}")
                    traceback.print_exc()

    except Exception as e_doc:
        log.error(f"⚠ Falha geral ao gerar documentos finais (CNPJ/CRC): {e_doc}")
        traceback.print_exc()


    log.info(f"⏱️ Processo '{nome_processo_base}' finalizado em {dur_total_s:.1f}s")

