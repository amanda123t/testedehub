# app/modules/pipeline/validation_helper.py
from __future__ import annotations
import json
from typing import Dict, Any, List
from app.validators.registro import criar_validador
from app.utils.logger import LoggerManager
import os
from app.utils.helpers import normalize_no_space
from app.validators.helpers.balance import extract_balance_items_two_columns, extrair_dados_principais_balanco
from app.modules.document_processor import DocumentsProcessor
from app.handlers.generico import HandlerGenerico
from app.handlers.base import ResultadoHandler
from app.handlers.nota_fiscal import HandlerNotaFiscal
from app.modules.pipeline.model_mapping import get_model_info
from app.utils.threads import run_with_timeout
from app.handlers.irpf import HandlerIRPFUnified
import atexit
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FutTimeout
from threading import Lock

LOCK_CONSULTAS = Lock()
MAX_VALIDACOES = int(os.getenv("MAX_VALIDACOES_PARALELAS", "6"))
POOL_VALIDACOES = ThreadPoolExecutor(max_workers=MAX_VALIDACOES)
atexit.register(lambda: POOL_VALIDACOES.shutdown(wait=False))
TIMEOUT_POR_VALIDACAO = int(os.getenv("TIMEOUT_POR_VALIDACAO", "1200"))  # 20 min

# Instância global do processador de documentos
PROCESSADOR_DOCUMENTOS = DocumentsProcessor()
log = LoggerManager(__name__)
# Registry simples de handlers especiais
HANDLERS_ESPECIAIS = {
    "nota_fiscal":  HandlerNotaFiscal,
    "irpf":        HandlerIRPFUnified,
    "both":        HandlerIRPFUnified,

}
def agregar_resultado(saida: Dict[str, Any], lista_cnpjs: list, lista_contadores: list) -> None:
    """
    Agrega CNPJs e contadores ao nível do processo,
    garantindo unicidade pela chave do dict.
    """

    cnpjs_saida = saida.get("cnpjs_consultados") or []
    contadores_saida = saida.get("contadores_consultados") or []

    with LOCK_CONSULTAS:
        # -----------------------------
        # 🔹 CNPJs (unicidade por chave)
        # -----------------------------
        chaves_cnpjs_existentes = {
            next(iter(item.keys()))
            for item in lista_cnpjs
            if isinstance(item, dict) and item
        }

        for item in cnpjs_saida:
            if not isinstance(item, dict) or not item:
                continue

            chave = next(iter(item.keys()))
            if chave not in chaves_cnpjs_existentes:
                lista_cnpjs.append(item)
                chaves_cnpjs_existentes.add(chave)

        # --------------------------------
        # 🔹 Contadores (unicidade por chave)
        # --------------------------------
        chaves_contadores_existentes = {
            next(iter(item.keys()))
            for item in lista_contadores
            if isinstance(item, dict) and item
        }

        for item in contadores_saida:
            if not isinstance(item, dict) or not item:
                continue

            chave = next(iter(item.keys()))
            if chave not in chaves_contadores_existentes:
                lista_contadores.append(item)
                chaves_contadores_existentes.add(chave)

    log.debug(
        f"[CONSULTAS] Processo agregadas (únicas) | "
        f"CNPJs={len(lista_cnpjs)} | Contadores={len(lista_contadores)}"
    )

def processar_pessoa(doc_type, nome_pessoa, lista_docs, grupos, 
    informacoes_processo, numero_processo, caminho_planilha_regras, 
    resultados_processo, process_path, lista_cnpjs, lista_contadores) -> None:

    doc_type_norm = doc_type.lower()
    if "cadastro" in doc_type_norm and "pf" in doc_type_norm:
        # pula o cadastro PF para validar no final
        log.debug(f"[VALID] Ignorando {doc_type} na primeira passagem (será validado ao final).")
        return
    doc_type_norm, type_name = get_model_info(doc_type)

    type_name = type_name

    docs_lista = [d for d in (lista_docs or []) if isinstance(d, dict)]
    if not docs_lista:
        return

    # ⚙️ MUDANÇA: Envia o dicionário completo da pessoa (todos os tipos) em vez de apenas o tipo atual
    data_payload = grupos  # 👈 agora contém todos os tipos da pessoa
    file_tag = f"{doc_type_norm}_{nome_pessoa.replace(' ', '_')}"
    log.debug(f"[VALID] Payload enviado ao validador ({type_name}) -> {list(data_payload.keys())}")
    log.debug(f"[VALID] Payload enviado ao validador ({type_name}) -> {data_payload}")
    log.info(f"[VALID-START] {type_name} | {nome_pessoa} | docs={len(docs_lista)}")

    # 🔹 Cria o validador
    validador = criar_validador(
        doc_type=doc_type_norm,
        data=data_payload,  # 👈 recebe tudo
        type_name=type_name,
        process_info=informacoes_processo,
        numero_processo=numero_processo,
        planilha_regras=caminho_planilha_regras,
    )
    setattr(validador, "dados_por_pessoa", resultados_processo.get("validacoes_por_pessoa", {}))

    try:
        saida = run_with_timeout(
            validador.validar,
            TIMEOUT_POR_VALIDACAO,
            use_process=False
        ) or {}
        agregar_resultado(saida, lista_cnpjs, lista_contadores)
        status_geral = bool(saida.get("status_geral"))
        docs_resultados = saida.get("documentos") or []
        log.info(f"[VALID] {type_name} | {nome_pessoa} -> {status_geral}")

        # Atualiza log
        for arquivo, dados_arq in resultados_processo.get("arquivos", {}).items():
            for tipo, lista_docs in dados_arq.get("documentos", {}).items():
                for doc in lista_docs:
                    if (
                        (doc.get("nome_pessoa") or "").strip().lower() == (nome_pessoa or "").strip().lower()
                        and (doc.get("tipo") or "").strip().lower() == (type_name or "").strip().lower()
                    ):
                        doc["validou_ok"] = status_geral
                        doc["contagem_validacao"] = doc.get("contagem_validacao", 0) + 1



        if saida.get("sections"):
            resultados_processo.setdefault("validacoes_por_pessoa", {}).setdefault(nome_pessoa, {"jsons": []})
            resultados_processo["validacoes_por_pessoa"][nome_pessoa]["jsons"].append(saida)


        # 🔁 --- REVALIDAÇÃO COM OCR ---
        if any(not d.get("status") for d in docs_resultados):
            docs_falhos = [d for d in docs_resultados if not d.get("status")]
            if not docs_falhos:
                return

            if len(docs_falhos) == len(docs_resultados):
                revalidar_lista = docs_lista
            else:
                arqs_falhos = {d.get("arquivo") for d in docs_falhos}
                revalidar_lista = [d for d in docs_lista if d.get("arquivo") in arqs_falhos]

            log.warning(f"[RETRY OCR] {type_name} | {nome_pessoa} ({len(revalidar_lista)} docs)")

            for doc_falho in revalidar_lista:
                try:
                    metodo_extracao_atual = str(doc_falho.get("metodo_extracao", "")).upper().strip()
                    if any(k in metodo_extracao_atual for k in ["OCR", "AZURE", "TABELA"]):
                        log.info(
                            f"[RETRY BLOQUEADO] {type_name} | {nome_pessoa} | "
                            f"{doc_falho.get('arquivo')} já extraído via {metodo_extracao_atual}, não será reenviado."
                        )
                        continue

                    caminho_arquivo = os.path.join(process_path, doc_falho["arquivo"])
                    log.info(f"[RETRY OCR] Reextraindo documento completo via OCR (cache ativo por página)...")

                    try:
                        resultado_ocr = PROCESSADOR_DOCUMENTOS.reader.texto_por_pagina_threaded(
                            caminho_arquivo,
                            modo="AZURE_OCR",
                        )
                    except Exception as e_ocr:
                        log.error(f"[RETRY OCR ERRO] Falha ao reextrair '{doc_falho['arquivo']}' via OCR: {e_ocr}")
                        continue

                    texto_ocr = resultado_ocr.text or ""
                    texto_paginas = resultado_ocr.pages or []
                    metodos_atualizados = resultado_ocr.methods or []

                    if not texto_ocr.strip():
                        log.warning(f"[RETRY OCR] Texto OCR vazio em '{doc_falho['arquivo']}'")
                        continue

                    # 🧭 Atualiza informações do arquivo
                    dados_arquivo = resultados_processo["arquivos"].get(os.path.basename(caminho_arquivo))
                    if dados_arquivo:
                        dados_arquivo.update({
                            "texto_paginas": texto_paginas,
                            "metodos": metodos_atualizados,
                            "metodo_extracao": "OCR",
                            "quantidade_caracteres": len(texto_ocr),
                            "tokens": PROCESSADOR_DOCUMENTOS.extractor.contar_tokens(texto_ocr),
                        })

                        log.debug(f"[RETRY OCR] Arquivo '{caminho_arquivo}' atualizado com novos métodos e texto.")

                    # 🔹 Reprocessa o documento via handler
                    handler_class = HANDLERS_ESPECIAIS.get(str(doc_type_norm), HandlerGenerico)
                    handler = handler_class(caminho_arquivo, texto_paginas=texto_paginas, tipo_documento_pre=doc_type)
                    parcial: ResultadoHandler = handler.processar() or {}

                    documentos_handler = parcial.get("documentos") or []
                    if not documentos_handler:
                        log.warning(f"[RETRY OCR] Handler não retornou documentos para {doc_falho['arquivo']}")
                        continue

                    novo_doc = documentos_handler[0]

                    # ✅ Atualiza diretamente o documento (doc_falho)
                    doc_falho.update({
                        "dados": novo_doc.get("dados"),
                        "context": novo_doc.get("context"),
                        "metodo_extracao": "OCR",
                        "qtde_caracteres": dados_arquivo.get("quantidade_caracteres", len(texto_ocr)) if dados_arquivo else len(texto_ocr),
                        "tokens": dados_arquivo.get("tokens") if dados_arquivo else PROCESSADOR_DOCUMENTOS.extractor.contar_tokens(texto_ocr),
                        "validou_ok": False,
                        "contagem_validacao": doc_falho.get("contagem_validacao", 0) + 1,
                    })

                    log.info(f"[RETRY OCR] Documento '{doc_falho['arquivo']}' reextraído e atualizado com sucesso.")

                except Exception as e:
                    log.error(f"[RETRY OCR ERRO] {type_name} | {nome_pessoa}: {e}")
                    continue

                # ⚙️ MUDANÇA: Reenvia todos os documentos da pessoa, mas com o contexto dos falhos atualizado
                data_payload = grupos  # 👈 envia tudo novamente, inclusive os corrigidos
                # ⚙️ Revalida com o texto novo (envia todos os docs da pessoa, mas com os falhos atualizados)
                validador = criar_validador(
                    doc_type=doc_type_norm,
                    data=grupos,  # contém todos os documentos, incluindo o doc_falho já corrigido
                    type_name=type_name,
                    process_info=informacoes_processo,
                    numero_processo=numero_processo,
                    planilha_regras=caminho_planilha_regras,
                )
                saida_ocr = run_with_timeout(validador.validar, TIMEOUT_POR_VALIDACAO, use_process=False) or {}
                agregar_resultado(saida_ocr, lista_cnpjs, lista_contadores)
                # ✅ Atualiza o status direto no doc_falho
                doc_val = next(
                    (d for d in saida_ocr.get("documentos", []) 
                    if (d.get("arquivo") or "").strip().lower() == (doc_falho.get("arquivo") or "").strip().lower()),
                    {}
                )
                doc_falho["validou_ok"] = bool(doc_val.get("status"))
                doc_falho["contagem_validacao"] = doc_falho.get("contagem_validacao", 0) + 1

                if doc_falho["validou_ok"]:
                    log.info(f"[RETRY OCR SUCESSO] {type_name} | {nome_pessoa} | {doc_falho['arquivo']}")
                else:
                    log.warning(f"[RETRY OCR] {type_name} | {nome_pessoa} | {doc_falho['arquivo']} ainda falhou.")


                # 🧠 Atualiza o JSON de validações da pessoa para o PDF
                pessoa_validacoes = resultados_processo.setdefault("validacoes_por_pessoa", {}).setdefault(nome_pessoa, {"jsons": []})

                tipo_novo = (saida_ocr.get("tipo_documento") or type_name or "").lower()
                arquivo_novo = ""
                try:
                    arquivo_novo = (saida_ocr.get("documentos") or [{}])[0].get("arquivo") or ""
                except Exception:
                    pass

                # Procura se já existe uma validação para o mesmo tipo e arquivo
                for json_antigo in pessoa_validacoes["jsons"]:
                    tipo_antigo = (json_antigo.get("tipo_documento") or "").lower()
                    arquivo_antigo = (json_antigo.get("documentos") or [{}])[0].get("arquivo") or ""
                    if tipo_antigo == tipo_novo and arquivo_antigo == arquivo_novo:
                        json_antigo.clear()
                        json_antigo.update(saida_ocr)
                        log.debug(f"[RETRY OCR] Atualizado JSON existente de '{arquivo_novo}' ({tipo_novo})")
                        break
                else:
                    pessoa_validacoes["jsons"].append(saida_ocr)
                    log.debug(f"[RETRY OCR] Adicionado novo JSON de '{arquivo_novo}' ({tipo_novo})")

                continue


        # Retry especial: balanço com tabela (sem alteração)
        if not status_geral and "balance" in doc_type_norm:
            docs_falhos = [d for d in docs_lista if not d.get("validou_ok")]
            if not docs_falhos:
                return

            for doc_falho in docs_falhos:
                metodo_extracao = str(doc_falho.get("metodo_extracao", "")).upper()
                if "TABELA" in metodo_extracao or "TABELAS" in metodo_extracao:
                    log.info(f"[RETRY BLOQUEADO] {type_name} | {nome_pessoa} | {doc_falho['arquivo']} já possui extração com tabelas ({metodo_extracao}), pulando.")
                    continue

                log.info(f"[RETRY BALANÇO TABELAS] {type_name} | {nome_pessoa} | {doc_falho['arquivo']}")
                caminho_arquivo = os.path.join(process_path, doc_falho["arquivo"])
                if not caminho_arquivo:
                    continue

                try:
                    coord_items = run_with_timeout(
                        extract_balance_items_two_columns,
                        TIMEOUT_POR_VALIDACAO,
                        caminho_arquivo,
                        use_process=False,
                    ) or []
                    log.debug(f"[RETRY BALANÇO] Itens extraídos da tabela: {coord_items}")
                    if not coord_items:
                        log.warning(f"[RETRY BALANÇO] Nenhum item de tabela encontrado para {doc_falho['arquivo']}")
                        continue

                    # 🧩 Reorganiza os itens em grupos ATIVO/PASSIVO
                    from collections import defaultdict
                    grp = defaultdict(list)
                    for it in coord_items:
                        nome = str(it.get("Nome", "")).strip()
                        valor = str(it.get("Valor:", "")).strip()
                        tipo = str(it.get("Tipo", "")).strip().lower()
                        if not nome or not valor:
                            continue
                        grupo = "PASSIVO" if "passivo" in tipo else "ATIVO"
                        grp[grupo].append({"Nome": nome, "Valor:": valor})

                    agrupado = {"ATIVO": grp["ATIVO"], "PASSIVO": grp["PASSIVO"]}
                    tabela_json = json.dumps(agrupado, ensure_ascii=False)
                    dados_principais = extrair_dados_principais_balanco(doc_falho.get("dados"))
                    texto_documento = f"{dados_principais}\n[TABELAS_NORMALIZADAS]\n{tabela_json}\n[/TABELAS_NORMALIZADAS]"

                    # 🧠 Valida novamente com o texto atualizado
                    validador = criar_validador(
                        doc_type="balance",
                        data={type_name: [{"dados": doc_falho.get("dados"), "context": texto_documento, "arquivo": doc_falho.get("arquivo")}]},
                        type_name="Balanço",
                        process_info=informacoes_processo,
                        numero_processo=numero_processo,
                        planilha_regras=caminho_planilha_regras,
                    )
                    saida_balance = validador.validar()
                    agregar_resultado(saida_balance, lista_cnpjs, lista_contadores)
                    status_geral = bool(saida_balance.get("status_geral"))

                    # ✅ Atualiza o doc_falho diretamente (reflete no resultados_processo)
                    doc_falho.update({
                        "context": texto_documento,
                        "dados": saida_balance.get("documentos", [{}])[0].get("dados", {}),
                        "metodo_extracao": "TABELA_BALANCO",
                        "qtde_caracteres": len(texto_documento),
                        "tokens": PROCESSADOR_DOCUMENTOS.extractor.contar_tokens(texto_documento),
                        "validou_ok": status_geral,
                        "contagem_validacao": doc_falho.get("contagem_validacao", 0) + 1,
                    })

                    # ✅ Atualiza também no nível do arquivo
                    dados_arquivo = resultados_processo["arquivos"].get(os.path.basename(caminho_arquivo))
                    if dados_arquivo:
                        dados_arquivo.update({
                            "metodo_extracao": "TABELA_BALANCO",
                            "texto_paginas": [texto_documento],
                            "quantidade_caracteres": len(texto_documento),
                            "tokens": PROCESSADOR_DOCUMENTOS.extractor.contar_tokens(texto_documento),
                        })

                    # ✅ Atualiza o JSON da pessoa (para o PDF)
                    pessoa_validacoes = resultados_processo.setdefault("validacoes_por_pessoa", {}).setdefault(nome_pessoa, {"jsons": []})
                    tipo_novo = (saida_balance.get("tipo_documento") or "balance").lower()
                    arquivo_novo = (saida_balance.get("documentos") or [{}])[0].get("arquivo") or ""

                    for json_antigo in pessoa_validacoes["jsons"]:
                        tipo_antigo = (json_antigo.get("tipo_documento") or "").lower()
                        arquivo_antigo = (json_antigo.get("documentos") or [{}])[0].get("arquivo") or ""
                        if tipo_antigo == tipo_novo and arquivo_antigo == arquivo_novo:
                            json_antigo.clear()
                            json_antigo.update(saida_balance)
                            log.debug(f"[RETRY BALANÇO] JSON atualizado de '{arquivo_novo}' ({tipo_novo})")
                            break
                    else:
                        pessoa_validacoes["jsons"].append(saida_balance)
                        log.debug(f"[RETRY BALANÇO] JSON adicionado para '{arquivo_novo}' ({tipo_novo})")

                    if status_geral:
                        log.info(f"[RETRY BALANÇO SUCESSO] {nome_pessoa} | {doc_falho['arquivo']}")
                    else:
                        log.warning(f"[RETRY BALANÇO] {nome_pessoa} | {doc_falho['arquivo']} ainda falhou.")

                except Exception as e:
                    log.error(f"[RETRY BALANÇO ERRO] {type_name} | {nome_pessoa}: {e}")

        log.info(f"[VALID-END] {type_name} | {nome_pessoa}")
        log.debug(f"[VALID-END] Resultados processo atualizado: {resultados_processo}")
        return None
    except Exception as e:
        log.error(f"❌ Falha ao validar '{type_name}' de {nome_pessoa}: {e}")
        log.info(f"[VALID-END] ERRO {type_name} | {nome_pessoa}")
        
def validar_grupos(
    grupos_por_pessoa: Dict[str, Dict[str, Any]],
    *,
    informacoes_processo: Dict[str, Any],
    numero_processo: str,
    caminho_planilha_regras: str,
    resultados_processo: Dict[str, Any],
    process_path: str
) -> tuple[list[bool], list[list[str]]]:

    """
    Executa a validação de todos os grupos de documentos por pessoa.
    Agora cada validador recebe o dicionário completo da pessoa (todos os tipos),
    e não apenas o grupo atual.
    """
    futures = []
    consultas_proc = resultados_processo.setdefault("consultas", {})
    lista_cnpjs = consultas_proc.setdefault("cnpjs", [])
    lista_contadores = consultas_proc.setdefault("contadores", [])
    for nome_pessoa, grupos in grupos_por_pessoa.items():
        for doc_type, lista_docs in grupos.items():
            futures.append(
                POOL_VALIDACOES.submit(
                    processar_pessoa,
                    doc_type,
                    nome_pessoa,
                    lista_docs,
                    grupos,
                    informacoes_processo,
                    numero_processo,
                    caminho_planilha_regras,
                    resultados_processo,
                    process_path,
                    lista_cnpjs,
                    lista_contadores,
                )
            )
    # Espera todas as threads terminarem
    for future in as_completed(futures):
        try:
            future.result(timeout=TIMEOUT_POR_VALIDACAO)
        except Exception as e:
            log.error(f"[THREAD ERRO] {e}")
    for nome_pessoa, grupos in grupos_por_pessoa.items():
        log.debug(f"Documentos por pessoa final (antes de validar o cadastro pf): {resultados_processo.get('validacoes_por_pessoa', {})}")
        # === 🔁 SEGUNDA PASSAGEM: validação do Cadastro PF no final ===
        cadastro_keys = [k for k in grupos if normalize_no_space(k) in ("cadastropf", "cadastro_pf", "cadastro pf")]
        for key in cadastro_keys:
            docs_lista = [d for d in (grupos.get(key) or []) if isinstance(d, dict)]
            if not docs_lista:
                continue

            log.info(f"[CADASTRO PF] Revalidando {nome_pessoa} após todos os documentos...")

            validador = criar_validador(
                doc_type=key.lower(),
                data=grupos,  # 👈 todos os dados da pessoa
                type_name="Cadastro PF",
                process_info=informacoes_processo,
                numero_processo=numero_processo,
                planilha_regras=caminho_planilha_regras,
            )
            setattr(validador, "dados_por_pessoa", resultados_processo.get("validacoes_por_pessoa", {}))

            try:
                saida_cadastro = validador.validar() or {}
                agregar_resultado(saida_cadastro, lista_cnpjs, lista_contadores)
                pessoa_validacoes = resultados_processo.setdefault("validacoes_por_pessoa", {}).setdefault(nome_pessoa, {"jsons": []})
                pessoa_validacoes["jsons"].append(saida_cadastro)
                log.info(f"[CADASTRO PF] Validação final concluída para {nome_pessoa}.")
            except Exception as e:
                log.error(f"[CADASTRO PF] Erro ao validar cadastro de {nome_pessoa}: {e}")

    return None
