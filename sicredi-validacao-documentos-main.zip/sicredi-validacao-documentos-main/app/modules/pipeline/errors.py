# app/modules/pipeline/errors.py
from __future__ import annotations
from threading import Lock

class ColetorErros:
    """
    Interface simples para 'marcar erro'.
    Pode ser Noop (não faz nada) ou apontar para SharePoint/local/etc.
    """
    def mark(self, prefixo: str) -> None:  # pragma: no cover
        pass


class ColetorErrosNulo(ColetorErros):
    """Não realiza nenhuma ação ao marcar erro."""
    def mark(self, prefixo: str) -> None:
        return


class ColetorErrosSharePoint(ColetorErros):
    """Encapsula a chamada de mark_error do SharePoint, evitando renomear duas vezes."""
    def __init__(self, ctx, site_id, item):
        self.ctx = ctx
        self.site_id = site_id
        self.item = item
        self._ja_renomeado = False
        self._lock = Lock()

    def marcar(self, prefixo: str) -> bool:
        # 1) evita renomear se já tiver "ERRO" no nome atual
        try:
            nome_atual = self.item.get("name","")
            if nome_atual.upper().startswith("ERRO"):
                return False

            with self._lock:
                if self._ja_renomeado:
                    return False
                ok = self.ctx.mark_error(self.site_id, self.item, prefixo)
                if ok:
                    self._ja_renomeado = True
                return ok
        except Exception as e:
            return False
