
# rules.py
from __future__ import annotations
from typing import Any, Callable, Dict, List, Optional, Union, Mapping
import pandas as pd
from app.utils.helpers import normalize
import re  # para regex
from math import isnan
Scalar = Union[str, float, int, bool, None]
Workbook = Union[str, Mapping[str, pd.DataFrame]]  # <- NOVO

# ------------------------- HELPERS ROBUSTOS -------------------------

def _get_sheet(book: Workbook, sheet: str) -> Optional[pd.DataFrame]:
    """
    Retorna a aba `sheet`:
      - Se book for str (caminho), lê do Excel (dtype=object).
      - Se book for dict-like (ex.: {'Holerite': df, 'IRPF': df}), retorna book[sheet] se existir.
    """
    try:
        if isinstance(book, str):
            return pd.read_excel(book, sheet_name=sheet, dtype=object)
        # dict / Mapping de abas -> DF
        df = book.get(sheet) if hasattr(book, "get") else None
        if df is None:
            return None
        # garante dtype=object para ficar alinhado ao caminho
        return df.astype(object, copy=False)
    except Exception:
        return None


# --- helper que "fortalece" a normalize() removendo pontuação e espaços repetidos ---
def _soft_norm(s: str) -> str:
    """
    Normaliza como o helpers.normalize e, além disso, remove pontuação/sinais,
    deixando só [a-z0-9]. Ex.: 'Mês da emissão?' -> 'mes da emissao' -> 'mesdaemissao'.
    """
    s = normalize(str(s))            # tira acento, lowercase, strip
    s = re.sub(r"[^a-z0-9]+", " ", s)  # remove pontuação/sinais
    return s.strip().replace(" ", "")  # cola para igualar "mes da" e "mes-da"

# --- helper para resolver nome de coluna por normalização (ignora acentos/caixa/pontuação) ---
def _resolve_col(df: Optional[pd.DataFrame], col_name: str) -> Optional[str]:
    """
    Retorna o nome REAL da coluna em df cujo _soft_norm(col) == _soft_norm(col_name).
    Se não encontrar, retorna None.
    """
    if df is None or not isinstance(df, pd.DataFrame) or not len(df.columns):
        return None
    alvo = _soft_norm(col_name)
    for c in df.columns:
        if _soft_norm(c) == alvo:
            return c
    return None

def _col_list_or_none(df: Optional[pd.DataFrame], col: str) -> Optional[List[Any]]:
    """
    Retorna lista de valores não nulos da coluna `col` (dropna).
    Resolve o nome por normalização e descarta strings vazias pós-trim.
    """
    if df is None:
        return None
    col_real = _resolve_col(df, col)
    if col_real is None:
        return None
    serie = df[col_real].dropna()
    if serie.empty:
        return None
    # remove strings vazias (tipo "   ")
    out = []
    for v in serie.tolist():
        if isinstance(v, str):
            vv = v.strip()
            if not vv:
                continue
            out.append(vv)
        else:
            out.append(v)
    return out or None

def _safe_get_val(
    df: Optional[pd.DataFrame],
    nome: str,
    col_key: str = "variavel",
    col_val: str = "valor",
    cast: Optional[Callable[[Any], Any]] = None,
) -> Scalar:
    """
    Busca df[col_val] na linha em que df[col_key] == `nome`.
    - 1º EXATO; 2º NORMALIZADO (acentos/caixa/pontuação).
    - Duplicatas: devolve a ÚLTIMA não nula.
    - Resolve colunas por normalização (_resolve_col).
    """
    if df is None:
        return None

    key_real = _resolve_col(df, col_key)
    val_real = _resolve_col(df, col_val)
    if key_real is None or val_real is None:
        return None

    try:
        alvo_exato = str(nome).strip()

        # 1) MATCH EXATO
        m = df[df[key_real].astype(str).str.strip() == alvo_exato]
        if not m.empty:
            for _, row in reversed(list(m.iterrows())):
                val = row[val_real]
                if pd.isna(val):
                    continue
                if cast is not None:
                    try:
                        return cast(val)
                    except Exception:
                        return None
                return val

        # 2) MATCH NORMALIZADO (ignora acento/caixa/pontuação)
        alvo_norm = _soft_norm(alvo_exato)
        for idx in range(len(df) - 1, -1, -1):
            k = df.iloc[idx][key_real]
            if pd.isna(k):
                continue
            if _soft_norm(k) == alvo_norm:
                val = df.iloc[idx][val_real]
                if pd.isna(val):
                    continue
                if cast is not None:
                    try:
                        return cast(val)
                    except Exception:
                        return None
                return val

        return None

    except Exception:
        return None

def _map_from_cols_or_none(
    df: Optional[pd.DataFrame],
    key_col: str,
    val_col: str,
    cast_key: Callable[[Any], Any] = lambda x: x,
    cast_val: Callable[[Any], Any] = lambda x: x,
) -> Optional[Dict[Any, Any]]:
    """
    Constrói dict a partir de duas colunas (resolvidas por normalização).
    """
    if df is None:
        return None

    key_real = _resolve_col(df, key_col)
    val_real = _resolve_col(df, val_col)
    if key_real is None or val_real is None:
        return None

    tmp = df[[key_real, val_real]].dropna(subset=[key_real, val_real])
    if tmp.empty:
        return None

    out: Dict[Any, Any] = {}
    for _, row in tmp.iterrows():
        k_raw = row[key_real]
        v_raw = row[val_real]

        if isinstance(k_raw, str) and not k_raw.strip():
            continue
        if isinstance(v_raw, str) and not v_raw.strip():
            continue

        k = cast_key(k_raw)
        v = cast_val(v_raw)

        if k is None or v is None:
            continue
        out[k] = v

    return out or None

def _to_int_or_none(v: Any) -> Optional[int]:
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    try:
        s = str(v).strip().replace(",", ".")
        return int(float(s))
    except Exception:
        return None

def _to_float_or_none(v: Any) -> Optional[float]:
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    try:
        # aceita "1.234,56" -> 1234.56, "1234,56" -> 1234.56, "1234.56" -> 1234.56
        s = str(v).strip()
        # remove separadores de milhar e normaliza decimal para ponto
        s = s.replace(".", "").replace(",", ".")
        return float(s)
    except Exception:
        return None

def _str_or_none(v: Any) -> Optional[str]:
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    s = str(v).strip()
    return s if s else None


# ------------------------- CLASSES DE REGRAS -------------------------

class RegrasComprovantes:
    """
    Todas as variáveis são criadas. Se faltarem na planilha ou vierem vazias, ficam como None.
    Para campos booleanos, retornamos o TEXTO original (ex.: "sim", "nao", "true", "false") — não convertidos para True/False aqui.
    """

    def __init__(self, caminho_excel: Workbook):
        # ---------------------- HOLERITE ----------------------
        df_holerite = _get_sheet(caminho_excel, "Holerite")
        self.holerite_nao_considerar: Optional[List[Any]] = _col_list_or_none(df_holerite, "nao_considerar")
        self.holerite_aceito_em_1: Optional[List[Any]] = _col_list_or_none(df_holerite, "aceito_em_1")
        self.holerite_aceito_em_3: Optional[List[Any]] = _col_list_or_none(df_holerite, "aceito_em_3")
        self.feriados: Optional[List[Any]] = _col_list_or_none(df_holerite, "Feriados")
        # booleans como TEXTO (ou None)
        self.exibir_descontos: Optional[str] = _safe_get_val(df_holerite, "Exibir os descontos?", cast=str)
        self.exibir_apenas_ultimo: Optional[str] = _safe_get_val(df_holerite, "Exibir apenas o ultimo holerite?", cast=str)
        self.limite_meses_holerite: Optional[int] = _to_int_or_none(_safe_get_val(df_holerite, "Limite competência(em meses)"))
        self.aceitar_sempre_mes_atual: Optional[str] = _safe_get_val(df_holerite, "Aceitar sempre o mês atual?", cast=str)
        self.aviso_sobre_mes_atual: Optional[str] = _safe_get_val(df_holerite, "Aviso sobre o mês atual", cast=str)
        self.considerar_itens_por_lei: Optional[str] = _safe_get_val(df_holerite, "Considerar sempre itens por lei?", cast=str)
        self.deve_vir_3_para_media: Optional[str] = _safe_get_val(df_holerite, "Deve vir sempre 3 holerites para média?", cast=str)
        self.data_virada_mes_holerite: Optional[int] = _to_int_or_none(_safe_get_val(df_holerite, "Data virada do mês"))
        if not self.data_virada_mes_holerite:
            self.data_virada_mes_holerite: Optional[int] = _to_int_or_none(_safe_get_val(df_holerite, "Dara virada do mês"))
        self.obrigatorio_data_admissao: Optional[str] = _safe_get_val(df_holerite, "Data de admissão é obrigatório?", cast=str)

        
        
        # ---------------------- PRO LABORE ----------------------
        df_prolabore = _get_sheet(caminho_excel, "Prolabore")

        self.validar_situacao_do_cnpj_prolabore: Optional[str] = _safe_get_val(df_prolabore, "Validar situação do CNPJ na receita?", cast=str)
        self.limite_meses_prolabore: Optional[int] = _to_int_or_none(_safe_get_val(df_prolabore, "Limite competência(em meses)"))
        self.aceitar_sempre_mes_atual_prolabore: Optional[str] = _safe_get_val(df_prolabore, "Aceitar sempre o mês atual?", cast=str)
        self.data_virada_mes_prolabore: Optional[int] = _to_int_or_none(_safe_get_val(df_prolabore, "Data virada do mês"))
        if not self.data_virada_mes_prolabore:
            self.data_virada_mes_prolabore: Optional[int] = _to_int_or_none(_safe_get_val(df_prolabore, "Dara virada do mês"))
    
        self.validar_crc_contador_prolabore: Optional[str] = _safe_get_val(df_prolabore, "Validar o crc do contador(se houver)?", cast=str)
        self.validar_socio_qsa_prolabore: Optional[str] = _safe_get_val(df_prolabore, "Validar se o associado consta no QSA?", cast=str)
        self.validar_total_com_o_porte_prolabore: Optional[str] = _safe_get_val(df_prolabore, "Validar valor total com o porte na receita?", cast=str)
        self.limite_darf: Optional[int] = _to_int_or_none(_safe_get_val(df_prolabore, "Limite para darf"))
        self.recibo_pro_labore_para_mei: Optional[str] = _safe_get_val(df_prolabore, "Recibo de Pró-Labore só pode aceitar para empresas MEI?", cast=str)

        # ---------------------- RENDA PRESUMIDA ----------------------
        df_presumida = _get_sheet(caminho_excel, "Renda_presumida")

        # Mapa carteiras -> limite (float)
        self.limites_por_carteira = _map_from_cols_or_none(
            df_presumida, "carteiras/porte/risco", "limites",
            cast_key=lambda x: x,
            cast_val=_to_float_or_none,
        )

        # fallback: usar a antiga coluna "carteiras"
        if self.limites_por_carteira is None:
            self.limites_por_carteira = _map_from_cols_or_none(
                df_presumida, "carteiras", "limites",
                cast_key=lambda x: x,
                cast_val=_to_float_or_none,
            )


        self.limite_renda_presumida: Optional[float] = _to_float_or_none(
            _safe_get_val(df_presumida, "Limite renda")
        )

        # booleans como TEXTO (ou None)
        self.considerar_limite: Optional[str] = _safe_get_val(df_presumida, "Considerar o valor do Limite caso ultrapasse?", cast=str)

        # Percentual: manter TEXTO cru (ex.: "100%", "1%", "100") — validação/conversão acontece fora
        self.percentual_valor: Optional[str] = _safe_get_val(df_presumida, "percentual_valor", cast=str)
        self.periodo_renda_presumida: Optional[str] = _str_or_none(_safe_get_val(df_presumida, "Periodo no MUA"))
        self.data_virada_mes_renda_presumida: Optional[int] = _to_int_or_none(_safe_get_val(df_presumida, "Data virada do mês"))

        # ---------------------- IMÓVEIS ----------------------
        df_imoveis = _get_sheet(caminho_excel, "Imóveis")
        self.maiusculo_sem_acentos: Optional[str] = _safe_get_val(df_imoveis, "Dados sempre em maíusculo e sem acentos?", cast=str)
        self.descricao_imovel_urbano: Optional[str]= _safe_get_val(df_imoveis, "Descrição padrão para Imóveis Urbanos", cast=str)
        self.descricao_imovel_rural: Optional[str]= _safe_get_val(df_imoveis, "Descrição padrão para Imóveis Rurais", cast=str)

        # ---------------------- LIMITES POR PORTE ----------------------
        df_limites_porte = _get_sheet(caminho_excel, "LIMITES POR PORTE")

        # Mapa carteiras -> limites por porte (float)
        self.limites_por_porte: Optional[Dict[Any, float]] = _map_from_cols_or_none(
            df_limites_porte, "Porte", "Limites",
            cast_key=lambda x: x,  # mantém como está (str/int)
            cast_val=_to_float_or_none,
        )
        self.limite_adicional_MEI: Optional[float] = _to_float_or_none(
            _safe_get_val(df_limites_porte, "Limite Adicional do MEI")
        )

        # ---------------------- FATURAMENTO ----------------------
        df_faturamento = _get_sheet(caminho_excel, "Faturamento")

        self.limite_dias_faturamento: Optional[int] = _to_int_or_none(_safe_get_val(df_faturamento, "Limite data de emissão (em dias)"))
        self.limite_meses_ult_mes_faturado: Optional[int] = _to_int_or_none(_safe_get_val(df_faturamento, "Limite ultimo mês faturado (em meses)"))

        # boolean como TEXTO (ou None)
        self.permitido_fat_no_mes_da_emissao: Optional[str] = _safe_get_val(
            df_faturamento, "Permitido faturamento no mês da emissão?", cast=str
        )
        self.tolerancia_permitida_fat: Optional[float] = _to_float_or_none(_safe_get_val(df_faturamento, "Tolerância aceita para o valor total(em reais)"))
        self.data_corte_fat: Optional[int] = _to_int_or_none(_safe_get_val(df_faturamento, "Data de corte para o faturamento"))
        self.validar_titulo_fat: Optional[str] = _safe_get_val(df_faturamento, "Validar título do faturamento?", cast=str)
        self.validar_situacao_do_cnpj_fat: Optional[str] = _safe_get_val(df_faturamento, "Validar situação do CNPJ na receita?", cast=str)
        self.validar_valores_antes_da_abertura_fat: Optional[str] = _safe_get_val(df_faturamento, "Validar se possui valores antes da data de abertura?", cast=str)
        self.validar_se_possui_12_meses_fat: Optional[str] = _safe_get_val(df_faturamento, "Validar se possui 12 meses?", cast=str)
        self.validar_total_com_os_meses_fat: Optional[str] = _safe_get_val(df_faturamento, "Validar o valor total com a soma dos meses?", cast=str)
        self.validar_total_com_o_porte_fat: Optional[str] = _safe_get_val(df_faturamento, "Validar valor total com o porte na receita?", cast=str)
        self.validar_assinaturas_fat: Optional[str] = _safe_get_val(df_faturamento, "Validar as assinaturas?", cast=str)
        
        # ---------------------- BALANÇO PATRIMONIAL  ----------------------
        df_balanco = _get_sheet(caminho_excel, "Balanço")
        self.balanco_resumido: Optional[str] = _safe_get_val(df_balanco, "Balanço resumido?", cast=str)
        self.validar_assinaturas_balanco: Optional[str] = _safe_get_val(df_balanco, "Validar as assinaturas?", cast=str)
        self.validar_situacao_do_cnpj_balanco: Optional[str] = _safe_get_val(df_balanco, "Validar situação do CNPJ na receita?", cast=str)

        # ---------------------- FATURAMENTO PRESUMIDO ----------------------
        df_faturamento_presumido = _get_sheet(caminho_excel, "Faturamento Presumido")

        self.limite_dias_faturamento_presumido: Optional[int] = _to_int_or_none(_safe_get_val(df_faturamento_presumido, "Limite data de emissão (em dias)"))
        self.limite_mensal_fat_presumido: Optional[float] = _to_float_or_none(_safe_get_val(df_faturamento_presumido, "Limite Fixo Mensal do Faturamento Presumido"))
        self.limite_anual_fat_presumido: Optional[float] = _to_float_or_none(_safe_get_val(df_faturamento_presumido, "Limite Fixo Anual do Faturamento Presumido"))
        self.validar_situacao_do_cnpj_fat_presumido: Optional[str] = _safe_get_val(df_faturamento_presumido, "Validar situação do CNPJ na receita?", cast=str)
        self.validar_total_com_o_porte_fat_presumido: Optional[str] = _safe_get_val(df_faturamento_presumido, "Validar valor total com o porte na receita?", cast=str)
        self.dividir_por: Optional[str] = _safe_get_val(df_faturamento_presumido, "Dividir valor total por:", cast=str)
        # ---------------------- IRPF ----------------------
        df_irpf = _get_sheet(caminho_excel, "IRPF")

        self.regras_pj: Optional[List[tuple[str, str]]] = None
        if df_irpf is not None and "Rendimentos_PJ" in df_irpf.columns and "Campo_mua(PJ)" in df_irpf.columns:
            df_pj_filtrado = df_irpf.dropna(subset=["Rendimentos_PJ", "Campo_mua(PJ)"])
            if not df_pj_filtrado.empty:
                    self.regras_pj = list(zip(
                    df_pj_filtrado["Rendimentos_PJ"].astype(str),
                    df_pj_filtrado["Campo_mua(PJ)"].astype(str)
        ))
        self.rendimentos_pf: Optional[Dict[str, str]] = _map_from_cols_or_none(
            df_irpf, "Rendimentos_PF", "Campo_mua(PF)", cast_key=_str_or_none, cast_val=_str_or_none
        )
        self.rendimentos_isentos: Optional[Dict[str, str]] = _map_from_cols_or_none(
            df_irpf, "Rendimentos_Isentos", "Campo_mua(isentos)", cast_key=_str_or_none, cast_val=_str_or_none
        )
        self.rendimentos_tributados: Optional[Dict[str, str]] = _map_from_cols_or_none(
            df_irpf, "Rendimentos_Tributados", "Campo_mua(tributados)", cast_key=_str_or_none, cast_val=_str_or_none
        )

        self.rendimentos_pj: Optional[Dict[str, str]] = _map_from_cols_or_none(
            df_irpf, "Rendimentos_PJ", "Campo_mua(PJ)", cast_key=_str_or_none, cast_val=_str_or_none
        )

        # booleans como TEXTO (ou None)
        #self.considerar_bens_ir: Optional[str] = _safe_get_val(df_irpf, "considerar_bens", cast=str)
        self.considerar_despesas_agro: Optional[str] = _str_or_none(_safe_get_val(df_irpf, "Considerar Despesas Agro"))
        self.exibir_despesas_em_rs: Optional[str] = _str_or_none(_safe_get_val(df_irpf, "Exibir o valor das despesas em R$?"))
        self.validar_sigilo_fiscal: Optional[str] = _safe_get_val(df_irpf, "Validar o selo 'PROTEGIDO POR SIGILO FISCAL'?")
        self.considerar_cooperativas: Optional[str] = _safe_get_val(df_irpf, "Considerar cooperativas nos rendimentos PJ?")
        self.rendas_agro: Optional[str] = _str_or_none(_safe_get_val(df_irpf, "Considerar Renda Agropecuária?"))
        self.tipo_declaracao_regra: Optional[str] = _str_or_none(_safe_get_val(df_irpf, "Tipo de declaração(Retificadora/Original) tem que bater com o recibo?"))
        self.desconsiderar_rendas_item_04: Optional[str] = _str_or_none(_safe_get_val(df_irpf, "Desconsiderar valores ligados ao item 04?"))
        self.exibir_resumo: Optional[str] = _safe_get_val(df_irpf, "Exibir Resumo?", cast=str)
        self.considerar_13: Optional[str] = _safe_get_val(df_irpf, "Considerar décimo terceiro?", cast=str)
        self.limite_darf_ir: Optional[int] = _to_int_or_none(_safe_get_val(df_irpf, "limite rendimentos tributaveis para envio da DARF"))
        self.declaracoes_retificadas: Optional[str] = _safe_get_val(df_irpf, "declarações retificadas deve vir todas anteriores?", cast=str)
        self.desconsiderar_rendimentos_dependentes: Optional[str] = _safe_get_val(df_irpf, "Desconsiderar rendimentos isentos e tributáveis ligados ao dependente?", cast=str)
        self.desconsiderar_99_seguros: Optional[str] = _safe_get_val(df_irpf, "Desconsiderar item 99 se tiver ligação com Seguros?", cast=str)
        self.ano_calendario_limite: Optional[str] = _to_int_or_none(_safe_get_val(df_irpf, "Ano calendário limite"))
        
        # ---------------------- ENDEREÇO ----------------------
        df_endereco = _get_sheet(caminho_excel, "Endereco")
        self.limite_meses_endereco: Optional[int] = _to_int_or_none(_safe_get_val(df_endereco, "Limite competência(em meses)"))

        # ---------------------- AUTODECLARACAO ----------------------
        df_autodeclaracao = _get_sheet(caminho_excel, "Autodeclaracao")
        self.limite_dias_autodeclaracao: Optional[int] = _to_int_or_none(_safe_get_val(df_autodeclaracao, "Limite data de emissão(dias)"))
        self.limite_auto_declaracao: Optional[float] = _to_float_or_none(_safe_get_val(df_autodeclaracao, "Limite renda"))
        self.periodo_auto_declaracao: Optional[str] = _str_or_none(_safe_get_val(df_autodeclaracao, "Periodo no MUA"))
        self.cargos_aceitos_autodeclaracao: Optional[List[Any]] = _col_list_or_none(df_autodeclaracao, "Cargos aceitos")
        self.cargos_nao_aceitos_autodeclaracao: Optional[List[Any]] = _col_list_or_none(df_autodeclaracao, "Cargos NÃO aceitos")

        # ---------------------- NOTA FISCAL ----------------------
        df_nf = _get_sheet(caminho_excel, "Nota_Fiscal")
        self.produtos_validos_nota: Optional[List[Any]] = _col_list_or_none(df_nf, "Produtos")

        # ---------------------- PARECER PADRÃO ----------------------
        df_parecer = _get_sheet(caminho_excel, "Parecer Padrão")

        self.parecer_padrao: Optional[Dict[str, str]] = _map_from_cols_or_none(
            df_parecer,
            "tipo",
            "parecer",
            cast_key=_str_or_none,
            cast_val=_str_or_none,
        )
    def get_rules(self) -> dict:
        return self.__dict__

    # ---------- Funções para captura das informações de cada documento da planilha de Regras ----------
    def parse_percent_to_decimal_and_label(self, raw) -> tuple[float, str]:
        """
        Converte um valor de percentual em (decimal, label_formatado).
        Exemplos de entrada -> saída:
          - None      -> (1.0, "100%")
          - "70%"     -> (0.7, "70%")
          - "70"      -> (0.7, "70%")
          - "0,7"     -> (0.7, "70%")
          - 0.7       -> (0.7, "70%")
        """
        if raw is None or str(raw).strip() == "":
            return 1.0, "100%"

        raw_str = str(raw)

        # 1) Caso moeda: manter exatamente como está no texto
        #    (aceita espaços antes de R$ e maiúsc/minúsc)
        if re.match(r'^\s*R\$', raw_str, flags=re.IGNORECASE):
            return 1.0, raw_str.strip()

        # 2) Percentual normal
        s = raw_str.strip().replace(" ", "")
        s = s.replace(",", ".")

        has_rs = s.lower().startswith("r$")
        if has_rs:
            return 1.0, f"{str(s)}"
        
        has_pct = s.endswith("%")
        if has_pct:
            s = s[:-1]

        try:
            v = float(s)
        except Exception:
            # não conversível → trata como 100%
            return 1.0, "100%"

        # se >= 1, assume que é "70" → 70%
        if v >= 1.0:
            pct = v
            dec = v / 100.0
        else:
            # v em [0,1]
            pct = v * 100.0
            dec = v

        # label bonitinho
        if abs(pct - round(pct)) < 1e-9:
            label = f"{int(round(pct))}%"
        else:
            label = f"{pct:.2f}%"
        return dec, label

    def __is_missing(self, val) -> bool:
        # None
        if val is None:
            return True

        # NaN float (ex.: pandas lê célula vazia como float('nan'))
        try:
            if isinstance(val, float) and isnan(val):
                return True
        except Exception:
            pass

        # pandas.NA / pandas.NaT (sem depender do import do pandas)
        tname = type(val).__name__
        if tname in ("NAType", "NaTType"):
            return True

        # String "vazia" ou equivalentes
        s = str(val).strip().lower()
        return s in {"", "nan", "none", "null", "na", "n/a", "-"}

    def fill_template(self, template: str, placeholders: dict) -> str:
        """
        Substitui placeholders no texto do parecer padrão.
        - Trata duplicação de "R$" APENAS para o placeholder {valor}:
        Se o template tiver "R$ {valor}" (com ou sem espaço) e o valor também começar com "R$",
        remove o "R$" do valor para evitar "R$ R$ ...".
        """
        out = str(template)

        def _ajusta_moeda_se_duplicar(_tpl: str, _k: str, _v: str) -> str:
            if _k != "valor":
                return _v
            if _v is None:
                return _v
            s_v = str(_v).strip()

            # template contém "R$ {valor}" (com espaços opcionais)
            tpl_tem_rs_antes_de_valor = re.search(r"R\$\s*\{valor\}", _tpl) is not None
            # valor começa com "R$"
            valor_comeca_com_rs = re.match(r"^\s*R\$\s*", s_v) is not None

            if tpl_tem_rs_antes_de_valor and valor_comeca_com_rs:
                # remove APENAS o prefixo "R$" do valor
                s_v = re.sub(r"^\s*R\$\s*", "", s_v)
            return s_v

        for k, v in placeholders.items():
            if v is not None and str(v).strip() != "":
                v_ajustado = _ajusta_moeda_se_duplicar(out, k, str(v))
                out = out.replace(f"{{{k}}}", v_ajustado)

        return out
    
    def exibir_regras(self, regras: Mapping[str, str], placeholders: dict | None) -> list[list[str]]:
        if placeholders is None:
            placeholders = {}
        ph = placeholders

        linhas: list[list[str]] = []
        for item, valor in (regras or {}).items():
            if self.__is_missing(valor):
                continue
            key_lower = str(item).lower()

            # Colunas de "despesa": mantém a lógica de percentual
            if "despesa" in key_lower:
                _, pct_label = self.parse_percent_to_decimal_and_label(valor)
                linhas.append([item, pct_label])
                continue

            # Para TODAS as demais colunas, tenta substituir placeholders se houverem
            texto = str(valor)
            # Se tiver {chave}, preenche; se não tiver, o fill_template simplesmente retorna o mesmo texto
            texto_preenchido = self.fill_template(texto, ph)

            # (Opcional) quebra de linha à frente, só quando é texto “longo” ou tem placeholder
            prefixo = "\n" if len(texto) > 60 else ""
            linhas.append([item, f"{prefixo}{texto_preenchido}"])
        return linhas


class RulesMua:
    def __init__(self, caminho_excel: Workbook):
        df_mua = _get_sheet(caminho_excel, "Regras_MUA")
        if df_mua is None or "tipo" not in df_mua.columns:
            raise ValueError("A aba 'Regras_MUA' precisa ter a coluna 'tipo'.")

        # Dicionários internos:
        # - docs_raw: chave = texto exato do Excel (case/pontuação idênticos)
        # - docs:     chave = normalizada (lower + strip) para busca sem case
        self.docs_raw: dict[str, dict] = {}
        self.docs: dict[str, dict] = {}

        # Se houver linhas repetidas do mesmo 'tipo', a ÚLTIMA linha prevalece.
        for _, row in df_mua.iterrows():
            tipo_raw = row.get("tipo")
            if pd.isna(tipo_raw) or not str(tipo_raw).strip():
                continue

            regras = {}
            for col in df_mua.columns:
                if col == "tipo":
                    continue
                val = row.get(col)
                if pd.isna(val):
                    continue
                regras[str(col).strip()] = val

            key_raw = str(tipo_raw).strip()
            key_norm = normalize(tipo_raw)

            self.docs_raw[key_raw] = regras
            self.docs[key_norm] = regras
    def get_rules(self) -> dict:
        return self.__dict__

    def get_doc(self, nomes: str | list[str]) -> dict:
        """
        Busca regras para um ou mais nomes possíveis.
        Aceita string única ou lista de strings.
        Retorna {} se não encontrar.
        """
        if isinstance(nomes, str):
            nomes = [nomes]

        for nome in nomes:
            regras = self.docs.get(normalize(nome))
            if regras:
                return regras
        return {}
    
    def get_doc_exact(self, nome_documento_exato: str) -> dict:
        """Busca pelo nome exatamente como está no Excel (case-sensitive)."""
        return self.docs_raw.get(nome_documento_exato.strip(), {})

    def has_doc(self, nome_documento: str) -> bool:
        return normalize(nome_documento) in self.docs

    def list_docs(self) -> list[str]:
        """Lista os nomes exatamente como estão no Excel (útil para debug/UI)."""
        return list(self.docs_raw.keys())

#regras = os.path.join("output", "regras.xlsx")
#rules = RegrasComprovantes(regras)
#breakpoint()