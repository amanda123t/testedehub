import unicodedata
from difflib import SequenceMatcher
from shutil import rmtree

def similar(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()
    
def normalize(text: str) -> str: 
    if not isinstance(text, str):
        return ""
    text = unicodedata.normalize("NFKC", text)
    return unicodedata.normalize("NFKD", text).encode("ASCII", "ignore").decode().lower().strip()

def normalize_no_space(text: str) -> str:
    return normalize(text).replace(" ", "")

def formatar_brasileiro(valor):
    if isinstance(valor, (int, float)):
        return f"{valor:,.2f}".replace(",", "v").replace(".", ",").replace("v", ".")
    return valor

def organize_data(data, doc_type):
    body = []

    for key, value in data.items():
        # 🚫 Ignora chaves auxiliares internas (começam com "_")
        if str(key).startswith("_"):
            continue

        # Pula campos completamente vazios
        if value is None or (isinstance(value, str) and value.strip() == "") or (isinstance(value, list) and not value):
            continue
        
        if isinstance(value, str):
            # Se tiver ponto e vírgula, considerar como múltiplos itens
            if ";" in value:
                body.append([key])
                for item in value.split(";"):
                    item = item.strip()
                    if item:
                        body.append([f"- {item}"])
            else:
                body.append([key, value])

        elif isinstance(value, (float, int)):
            body.append([key, formatar_brasileiro(value)])

        elif isinstance(value, list):
            if not value:
                continue
            body.append([])
            body.append([key])
            for item in value:
                if isinstance(item, dict):
                    if doc_type.lower() == 'holerite':
                        # Mapeia os nomes que vêm da IA
                        nome = (item.get("Nome") or item.get("type") or "").strip()
                        valor = (item.get("Valor:") or item.get("Valor") or item.get("amount") or "").strip()
                        ref = (item.get("Referência:") or item.get("Referência") or
                               item.get("Referencia:") or item.get("Referencia") or "").strip()

                        # Se tiver referência, agrega ao rótulo; senão, só o nome
                        rotulo = f"{nome} (Ref: {ref})" if ref else nome
                        body.append([rotulo, valor])

                    else:
                        body.append([])  # quebra entre blocos
                        for subkey, subvalue in item.items():
                            # 🚫 Ignora chaves internas
                            if str(subkey).startswith("_"):
                                continue
                            if subvalue is not None and str(subvalue).strip():
                                valor_formatado = formatar_brasileiro(subvalue) if isinstance(subvalue, (float, int)) else str(subvalue).strip()
                                body.append([subkey.strip(), valor_formatado])

        elif isinstance(value, dict):
            body.append([])
            body.append([key])
            for subkey, subvalue in value.items():
                # 🚫 Ignora chaves internas
                if str(subkey).startswith("_"):
                    continue
                if subvalue is None or (isinstance(subvalue, str) and not subvalue.strip()):
                    continue
                if isinstance(subvalue, dict):
                    body.append([subkey])
                    for _subkey, _subvalue in subvalue.items():
                        # 🚫 Ignora chaves internas
                        if str(_subkey).startswith("_"):
                            continue
                        if _subvalue:
                            body.append([_subkey, formatar_brasileiro(_subvalue) if isinstance(_subvalue, (float, int)) else _subvalue])
                elif isinstance(subvalue, list):
                    for item_dict in subvalue:
                        if isinstance(item_dict, dict):
                            body.append([])  # quebra visual
                            for k, v in item_dict.items():
                                if not v:
                                    continue
                                if str(k).startswith("_"):
                                    continue
                                valor_fmt = (
                                    formatar_brasileiro(v)
                                    if isinstance(v, (float, int))
                                    else str(v).strip()
                                )
                                body.append([k.strip(), valor_fmt])

                else:
                    body.append([subkey, formatar_brasileiro(subvalue) if isinstance(subvalue, (float, int)) else subvalue])
            body.append([])

    return body
