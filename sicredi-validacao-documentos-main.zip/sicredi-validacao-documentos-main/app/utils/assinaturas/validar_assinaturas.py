from dotenv import load_dotenv
from app.utils.helpers import normalize
load_dotenv()
from app.utils.assinaturas.ITI import SiteITI
import time, os
from threading import Semaphore
from app.utils.logger import LoggerManager
from app.modules.pipeline.model_mapping import get_model_info
log = LoggerManager(__name__)  # logger do módulo (task)
SEMAFORO_GLOBAL = Semaphore(3)
# SHAREPOINT

def excluir_arquivo(arquivo):
    if os.path.exists(arquivo):
        os.remove(arquivo)

def validar_arquivo_iti(caminho_arquivo: str, output_path: str) -> str:
    with SEMAFORO_GLOBAL:
        iti = SiteITI(output_path= output_path, modo_headlees=True)
        if not os.path.exists(caminho_arquivo):
            log.debug("Arquivo não encontrado para validar a assinatura eletrônica.")
            return None
        iti.acessar_url()
        #DEFINIÇÃO DOS CAMINHOS
        nome_arquivo = os.path.splitext(os.path.basename(caminho_arquivo))[0] if os.path.exists(caminho_arquivo) else "NÃO ENCONTRADO"
        #Exclui se existir para não dar conflito
        excluir_arquivo(os.path.join(output_path, f"Relatorio ITI - {nome_arquivo}.pdf"))
        excluir_arquivo(os.path.join(output_path, f"Erro ITI - {nome_arquivo}.png")) 
        #VALIDAÇÃO NO SITE ITI
        return iti.validar_arquivo(caminho_arquivo)

def validar_assinatura_digital(
    caminho_arquivo: str,
    texto: str,
    tipos_documento: list[str] | None,
    pasta_output: str
):
    """
    3 resultados possíveis:
        - False → documento não tem assinatura válida (ou tipo não permitido)
        - 'OK'  → assinatura validada com sucesso no ITI
        - 'ERRO'→ tentativa de validar no ITI, mas assinatura inválida / erro
    """

    if not texto:
        log.debug("Texto vazio; não é possível validar se possui assinatura digital.")
        return False

    txt_norm = normalize(texto)

    # --------------------------
    # 1. PALAVRAS PROIBIDAS (SPED / DOCUMENTOS SISTÊMICOS)
    # --------------------------
    palavras_proibidas = [
        "sistema publico de escrituracao digital",
        "este relatorio foi gerado pelo sistema publico",
        "este documento e parte integrante de escrituracao",
        "cuja autenticacao se comprova pelo recibo de numero",
        "digital – sped",
        "digital - sped",
        "numero de ordem do livro",
    ]

    if any(p in txt_norm for p in palavras_proibidas):
        log.debug("Documento contém palavras proibidas; não será validado no ITI.")
        return False  # JAMAS validar no ITI

    # --------------------------
    # 2. TIPOS PERMITIDOS
    # --------------------------
    tipos_permitidos = {
        "prolabore",
        "self_declaration",
        "self_declaration_address",
        "balance",
        "dre",
        "invoice",
        "presumed_billing",
        "rpr",
        "consent",
        "arrendamento",
        "comodato",
        "locacao",
    }

    if not tipos_documento or not isinstance(tipos_documento, list):
        tipos_documento = []

    doc_types = []
    type_names = []
    for tipo in tipos_documento:
        if tipo:
            doc_type, type_name = get_model_info(tipo)
            doc_types.append(doc_type)
            type_names.append(type_name)
    doc_types = [normalize(t) for t in (doc_types or [])]
    type_names = [normalize(t) for t in (type_names or [])]

    if not any(t in tipos_permitidos for t in doc_types) and not any(t in tipos_permitidos for t in type_names):
        log.debug("Tipo de documento não está na lista de tipos permitidos para validação no ITI.")
        return False

    # --------------------------
    # 3. PALAVRAS QUE INDICAM ASSINATURA DIGITAL
    # --------------------------
    palavras_assinatura = [
        "assinado digitalmente por",
        "assinado eletronicamente por",
        "ou=",
        "o=icp-brasil",
        "razao: eu sou autor deste documento",
        "assinatura digital",
        "assinado de forma digital por",
        "Verifique em https://validar.iti.gov.br",
        "Documento assinado digitalmente",
    ]

    tem_assinatura = any(p in txt_norm for p in palavras_assinatura)

    if not tem_assinatura:
        log.debug("Nenhuma palavra indicativa de assinatura digital encontrada no texto.")
        return False

    # --------------------------
    # 4. TEM ASSINATURA → já chamar o ITI automaticamente
    # --------------------------
    log.debug("Palavras indicativas de assinatura digital encontradas; validando no ITI...")
    try:
        resultado = validar_arquivo_iti(
            caminho_arquivo=caminho_arquivo,
            output_path=pasta_output
        )

        if resultado:
            return "OK"
        else:
            return "ERRO"

    except Exception as e:
        log.error(f"[Assinatura] Erro ao validar no ITI: {e}")
        return "ERRO"