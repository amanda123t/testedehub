from app.utils.navegadores.navegador_playwright import Navegador
from time import sleep
from playwright.sync_api import TimeoutError
import os



class SiteITI(Navegador):
    def __init__(self, output_path: str = None, modo_headlees: bool = True):
        self.output_path = output_path
        self.headlees = modo_headlees
        super().__init__(output_path=self.output_path, headless=self.headlees)

    def acessar_url(self):
        self.navegador.goto("https://validar.iti.gov.br/index.html")
        sleep(0.5)

    def validar_arquivo(self, caminho_arquivo):
        xpath_escolher_arquivo = '//*[@id="buttaum"]'
        cookies = '//*[@id="cookie"]/div/div[2]/button[2]'
        termos = '//*[@id="acceptTerms"]'
        btn_validar = '//*[@id="submitValidar"]'
        css_input = "input[type='file']"
        xpath_visualizar_relatorio = '//*[@id="botaoVisualizarConf"]'
        xpath_baixar_relatorio = '//*[@id="bnt-pdf"]'

        nome_arquivo = os.path.splitext(os.path.basename(caminho_arquivo))[0]
        output_pdf = os.path.join(self.output_path, f"Relatorio ITI - {nome_arquivo}.pdf")
        erro_pdf = os.path.join(self.output_path, f"Erro ITI - {nome_arquivo}.png")

        try:
            # Aceitar cookies (se existir)
            self.clicar(cookies, time=3)

            # Rola até botão e envia arquivo
            self.rolar_ate_elemento(xpath_escolher_arquivo, time=10)
            self.selecionar_arquivo_css(css_input, caminho_arquivo, time=10)

            # Aceitar termos e validar
            self.clicar(termos, time=2)
            self.clicar(btn_validar, time=2)

            # Visualizar relatório
            self.rolar_ate_elemento(xpath_visualizar_relatorio, time=5)
            self.clicar(xpath_visualizar_relatorio, time=5)

            # Baixar PDF com segurança usando expect_download
            self.rolar_ate_elemento(xpath_baixar_relatorio, time=5)

            with self.navegador.expect_download(timeout=5000) as download_info:
                self.clicar(xpath_baixar_relatorio, time=5)

            download = download_info.value
            download.save_as(output_pdf)

            print(f"PDF baixado em: {output_pdf}")
            return output_pdf

        except TimeoutError as e:
            print("⚠ Timeout durante a validação:", e)
            self.tirar_print_tela(f"Erro ITI - {nome_arquivo}.png")
            return erro_pdf

        except Exception as e:
            print("Erro ao validar o arquivo:", e)
            self.tirar_print_tela(f"Erro ITI - {nome_arquivo}.png")
            return erro_pdf
