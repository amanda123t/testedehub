import fitz  # PyMuPDF
from pyzbar.pyzbar import decode
from PIL import Image, ImageEnhance
import json
import re
import string
import os

def qr_valido(texto: str) -> bool:
    if not texto:
        return False

    if "http://" in texto or "https://" in texto:
        return True

    try:
        json.loads(texto)
        return True
    except:
        pass

    if re.search(r"[A-Za-z0-9]+=+[A-Za-z0-9]+", texto):
        return True

    ascii_chars = sum(c in string.printable for c in texto)
    taxa_ascii = ascii_chars / max(len(texto), 1)
    if taxa_ascii < 0.6:
        return False

    if len(texto) < 10:
        return False

    return True


def tentar(img: Image.Image) -> list[str]:
    """Tenta extrair QR de forma rápida."""
    resultados = []

    # tentativa normal
    for qr in decode(img):
        t = qr.data.decode("utf-8", errors="ignore")
        if qr_valido(t):
            resultados.append(t)

    if resultados:
        return resultados

    # tentativa com contraste levemente melhorado
    img2 = ImageEnhance.Contrast(img).enhance(1.8)
    for qr in decode(img2):
        t = qr.data.decode("utf-8", errors="ignore")
        if qr_valido(t):
            resultados.append(t)

    if resultados:
        return resultados

    # tentativa rotacionada 90º
    img3 = img.rotate(90, expand=True)
    for qr in decode(img3):
        t = qr.data.decode("utf-8", errors="ignore")
        if qr_valido(t):
            resultados.append(t)

    return resultados


def extrair_qr_code(path: str) -> list[str]:
    resultados = []

    ext = os.path.splitext(path)[1].lower()

    # =========================
    # Se for imagem (rápido)
    # =========================
    if ext in (".png", ".jpg", ".jpeg", ".bmp", ".tiff"):
        try:
            img = Image.open(path).convert("RGB")
            achados = tentar(img)
            return list(set(achados))
        except:
            return []

    # =========================
    # Se for PDF (rápido)
    # =========================
    try:
        doc = fitz.open(path)
        page = doc.load_page(doc.page_count - 1)

        # 1) DPI leve (2x) — rápido
        for z in (2, 4):  
            pix = page.get_pixmap(matrix=fitz.Matrix(z, z))
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)

            achados = tentar(img)
            if achados:
                resultados.extend(achados)
                break  # rápido: achou → para

        return list(set(resultados))

    except:
        return []
