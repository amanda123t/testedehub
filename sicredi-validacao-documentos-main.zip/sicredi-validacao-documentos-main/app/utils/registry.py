
from filelock import FileLock, Timeout
from openpyxl import Workbook, load_workbook
from zipfile import BadZipFile
from openpyxl.utils.exceptions import InvalidFileException
from app.utils.logger import LoggerManager
import os, time, re
from pathlib import Path
import pandas as pd

log = LoggerManager(__name__)  # logger do módulo (task)

def consultar_infos_processo(workbook: dict, process_folder: str) -> dict | None:
    """
    Lê todas as sheets mensais (ex.: 'SEPTEMBER_2025', 'OCTOBER_2025') do workbook
    e retorna um dicionário com os dados do processo (sem a coluna de ID) da sheet mais recente.
    Se não encontrar, retorna None.
    """
    if not isinstance(workbook, dict) or not workbook or not process_folder:
        return None

    # 1) extrai só dígitos do nome da pasta (processo)
    proc_digits = re.sub(r"\D+", "", str(process_folder))
    if not proc_digits:
        return None

    # 2) ordenar sheets por (ano, mês) desc — assume padrão MONTH_YYYY
    month_map = {
        "JANUARY": 1, "FEBRUARY": 2, "MARCH": 3, "APRIL": 4,
        "MAY": 5, "JUNE": 6, "JULY": 7, "AUGUST": 8,
        "SEPTEMBER": 9, "OCTOBER": 10, "NOVEMBER": 11, "DECEMBER": 12,
        #Caso esteja em portugues:
        "JANEIRO": 1, "FEVEREIRO": 2, "MARÇO": 3, "ABRIL": 4,
        "MAIO": 5, "JUNHO": 6, "JULHO": 7, "AGOSTO": 8,
        "SETEMBRO": 9, "OUTUBRO": 10, "NOVEMBRO": 11, "DEZEMBRO": 12,
    }
    def sheet_key(sname: str) -> tuple[int, int]:
        s = str(sname).strip().upper()
        m = re.match(r"^([A-Z]+)_(\d{4})$", s)
        if m and m.group(1) in month_map:
            return (int(m.group(2)), month_map[m.group(1)])
        return (0, 0)

    ordered = sorted(workbook.keys(), key=sheet_key, reverse=True)

    # 3) varrer da mais recente para a mais antiga
    candidatos_id = {
        "process_id", "processid", "processo", "n do processo", "nº do processo",
        "process", "process_if", "process_if"
    }

    for sheet in ordered:
        df = workbook.get(sheet)
        if df is None or df.empty:
            continue

        # achar coluna de id (ou a primeira se não achar)
        cols_norm = {str(c).strip().lower(): c for c in df.columns}
        col_id = next((cols_norm[n] for n in candidatos_id if n in cols_norm), df.columns[0])

        # comparar apenas dígitos
        col_norm = df[col_id].astype(str).str.replace(r"\D+", "", regex=True)
        hits = col_norm[col_norm == proc_digits].index
        if len(hits) == 0:
            continue

        # monta retorno (remove coluna de id; converte NaN -> None)
        row = df.loc[hits[0]].to_dict()
        row.pop(col_id, None)
        out = {str(k).strip(): (None if pd.isna(v) else v) for k, v in row.items()}
        out.setdefault("mes_referencia", sheet)
        return out

    return None

def upsert_planilha_mensal(cooperativa: str, registro_processo: dict, documentos_log: list[dict], pasta_arquivo: Path):
    log.debug(f"Cooperativa recebida para planilha de logs: {cooperativa}")
    cooperativa_sanit = cooperativa.replace("(", "").replace(")","").replace(",", "").replace(".", "").replace("-", "")
    arquivo_xlsx = pasta_arquivo / f"resultado_validacoes_{cooperativa_sanit}_{time.strftime('%Y%m')}.xlsx"

    # === headers dinâmicos ===
    process_headers = list(registro_processo.keys())                
    document_headers = list(documentos_log[0].keys()) if documentos_log else []

    lock = FileLock(str(arquivo_xlsx) + ".lock", timeout=120)
    try:
        with lock:
            # Abrir/criar workbook
            if arquivo_xlsx.exists():
                try:
                    if os.path.getsize(arquivo_xlsx) < 100:
                        raise InvalidFileException("Arquivo XLSX muito pequeno (prov. corrompido).")
                    workbook = load_workbook(arquivo_xlsx)
                except (BadZipFile, InvalidFileException, KeyError) as e:
                    log.warning(f"Planilha mensal inválida ('{arquivo_xlsx}'). Recriando. Detalhe: {e}")
                    try: arquivo_xlsx.unlink(missing_ok=True)
                    except Exception: pass
                    workbook = Workbook()
            else:
                workbook = Workbook()

            # Sheets
            if "Processos" not in workbook.sheetnames and "Sheet" in workbook.sheetnames:
                workbook.active.title = "Processos"
            aba_processos   = workbook["Processos"]   if "Processos"   in workbook.sheetnames else workbook.create_sheet("Processos")
            aba_documentos  = workbook["Documentos"]  if "Documentos"  in workbook.sheetnames else workbook.create_sheet("Documentos")

            # Cabeçalho da aba Processos (dinâmico, como veio)
            if aba_processos.max_row == 1 and [c.value for c in aba_processos[1]] != process_headers:
                aba_processos.delete_rows(1, aba_processos.max_row)
                aba_processos.append(process_headers)

            # Cabeçalho da aba Documentos (dinâmico, como veio, baseado no PRIMEIRO doc)
            if aba_documentos.max_row == 1 and [c.value for c in aba_documentos[1]] != document_headers:
                aba_documentos.delete_rows(1, aba_documentos.max_row)
                aba_documentos.append(document_headers)

            # === UPSERT: PROCESSOS ===
            # chave é sempre a 1ª coluna (primeiro header do registro_processo)
            if process_headers:
                # Usa sempre o campo 'processo' como chave primária (única)
                if "processo" in process_headers:
                    col_chave_idx = process_headers.index("processo") + 1
                else:
                    col_chave_idx = 1  # fallback
                linha_alvo = None
                chave_processo = registro_processo.get("processo")

                for r in range(2, aba_processos.max_row + 1):
                    if str(aba_processos.cell(row=r, column=col_chave_idx).value) == str(chave_processo):
                        linha_alvo = r
                        break
                valores_processo = [registro_processo.get(k) for k in process_headers]
                if linha_alvo:
                    for c, v in enumerate(valores_processo, 1):
                        aba_processos.cell(row=linha_alvo, column=c, value=v)
                else:
                    aba_processos.append(valores_processo)

            # === UPSERT: DOCUMENTOS (simples; usa (processo, arquivo, tipo) se existirem, senão append) ===
            def col_idx(nome: str) -> int | None:
                try:    return document_headers.index(nome) + 1
                except ValueError: return None

            col_processo = col_idx("processo")
            col_arquivo  = col_idx("arquivo")
            col_tipo     = col_idx("tipo")

            indice_existentes = {}
            if col_processo and col_arquivo and col_tipo:
                for r in range(2, aba_documentos.max_row + 1):
                    proc = aba_documentos.cell(row=r, column=col_processo).value
                    arq  = aba_documentos.cell(row=r, column=col_arquivo).value
                    tip  = aba_documentos.cell(row=r, column=col_tipo).value or ""
                    indice_existentes[(proc, arq, tip)] = r

            for doc in (documentos_log or []):
                valores_doc = [doc.get(k) for k in document_headers]
                if col_processo and col_arquivo and col_tipo:
                    chave = (doc.get("processo"), doc.get("arquivo"), doc.get("tipo") or "")
                    if chave in indice_existentes:
                        r = indice_existentes[chave]
                        for c, v in enumerate(valores_doc, 1):
                            aba_documentos.cell(row=r, column=c, value=v)
                    else:
                        aba_documentos.append(valores_doc)
                else:
                    # sem colunas-chaves? só append
                    aba_documentos.append(valores_doc)

            # Salvar de forma atômica
            caminho_tmp = arquivo_xlsx.with_suffix(arquivo_xlsx.suffix + ".tmp")
            workbook.save(caminho_tmp)
            os.replace(caminho_tmp, arquivo_xlsx)

    except Timeout:
        log.error(f"⚠ Timeout ao tentar lock em '{arquivo_xlsx}'. Registro deste processo não foi escrito.")
