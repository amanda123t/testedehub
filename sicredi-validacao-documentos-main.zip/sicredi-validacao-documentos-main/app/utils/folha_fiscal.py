from typing import Dict, List, Tuple

class FolhaFiscal:
    """
    2025 apenas. Calcula INSS e IRRF para empregado e sócio.
    Regras pedidas:
      - Usa SEMPRE salário já abatido internamente: salario_ref = bruto - outros_descontos
      - INSS calculado sobre salario_ref
      - IR tradicional: base = salario_ref - INSS - dependentes*deducao
      - IR simplificado: base = salario_ref - desconto_simplificado_fixo
    """

    # 2025 (vigente a partir de mai/2025)
    TETO_INSS = 8157.41
    TABELA_INSS_2025: List[Tuple[float, float]] = [
        (1518.00, 0.075),
        (2793.88, 0.09),
        (4190.83, 0.12),
        (8157.41, 0.14),
    ]
    TABELA_IR_2025: List[Tuple[float, float, float]] = [
        (2428.80, 0.00, 0.00),
        (2826.65, 0.075, 182.16),
        (3751.05, 0.15, 394.16),
        (4664.68, 0.225, 675.49),
        (999999.99, 0.275, 908.73),
    ]
    DEDUCAO_DEPENDENTE = 189.59
    DESCONTO_SIMPLIFICADO_FIXO = 607.20  # 2025 mai–dez

    @staticmethod
    def calcular_inss_e_irrf(
        salario_bruto: float,
        outros_descontos: float = 0.0,   # ex.: horas falta/atraso etc.
        dependentes: int = 0,
        regime_inss: str = "empregado",  # "empregado" | "socio"
    ) -> Dict:

        def clamp(x: float) -> float:
            return round(x if x > 0 else 0.0, 2)

        def calc_inss_progressivo(sal: float):
            total = 0.0
            restante = sal
            inicio = 0.0
            detalhe = []
            for limite, aliquota in FolhaFiscal.TABELA_INSS_2025:
                faixa = min(restante, limite - inicio)
                if faixa > 0:
                    contrib = faixa * aliquota
                    total += contrib
                    detalhe.append((round(faixa, 2), aliquota, round(contrib, 2)))
                    restante -= faixa
                    inicio = limite
                if restante <= 0:
                    break
            return round(total, 2), detalhe

        def irrf_progressivo_com_deducao(base: float):
            base = max(base, 0.0)
            faixa_info = {"limite": None, "aliquota": 0.0, "deducao": 0.0}
            for limite, aliquota, deducao in FolhaFiscal.TABELA_IR_2025:
                if base <= limite:
                    faixa_info = {"limite": limite, "aliquota": aliquota, "deducao": deducao}
                    break
            imposto = base * faixa_info["aliquota"] - faixa_info["deducao"]
            return round(max(imposto, 0.0), 2), faixa_info

        # ========= 1) Salário de referência (abatido internamente) =========
        salario_ref = clamp(salario_bruto - outros_descontos)

        # ========= 2) INSS =========
        if regime_inss.lower() == "socio":
            base_inss = min(salario_ref, FolhaFiscal.TETO_INSS)
            inss = round(base_inss * 0.11, 2)
            inss_detalhe = [(round(base_inss, 2), 0.11, inss)]
        else:
            inss, detalhes = calc_inss_progressivo(salario_ref)
            inss_detalhe = detalhes

        aliquota_inss_efetiva = round(((inss / salario_ref) * 100), 2) if salario_ref > 0 else 0.0

        # ========= 3) IR (tradicional) =========
        base_ir_trad = clamp(salario_ref - inss - dependentes * FolhaFiscal.DEDUCAO_DEPENDENTE)
        irrf_trad, faixa_trad = irrf_progressivo_com_deducao(base_ir_trad)

        # ========= 4) IR (simplificado) =========
        base_ir_simpl = clamp(salario_ref - FolhaFiscal.DESCONTO_SIMPLIFICADO_FIXO)
        irrf_simpl, faixa_simpl = irrf_progressivo_com_deducao(base_ir_simpl)

        # ========= 5) Automático =========
        irrf_auto = min(irrf_trad, irrf_simpl)

        return {
            "INSS": inss,
            "aliquota_inss_efetiva": aliquota_inss_efetiva,
            "INSS_detalhe_faixas": [
                {"base_faixa": b, "aliquota": a, "contribuicao": c} for (b, a, c) in inss_detalhe
            ],
            "Base_IR_tradicional": base_ir_trad,
            "IRRF_tradicional": irrf_trad,
            "irrf_faixa_tradicional": faixa_trad,
            "Base_IR_simplificada": base_ir_simpl,
            "IRRF_simplificado": irrf_simpl,
            "irrf_faixa_simplificado": faixa_simpl,
            "IRRF_automatico": irrf_auto,
            "meta": {"tabelas": "OK", "modo_socio": regime_inss.lower()},
        }

'''
# ===================== TESTES =====================
if __name__ == "__main__":
    testes = [
        # salário base 7053,62 | desconto faltas 300,84 | empregado
        ("Empregado", 2264.52, 260.39, 0, "empregado"),

        # pró-labore (sócio)
    ]
    for nome, sal, desc, dep, tipo in testes:
        print(f"\n=== {nome.upper()} ===")
        r = FolhaFiscal.calcular_inss_e_irrf(sal, desc, dep, tipo)
        print(f'IRpf automatico {r['IRRF_automatico']}')
        for k, v in r.items():
            print(f"{k}: {v}")
'''