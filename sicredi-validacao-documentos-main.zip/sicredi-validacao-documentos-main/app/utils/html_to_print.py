from playwright.sync_api import sync_playwright

def gerar_print_html(
    html_string: str,
    caminho_png: str = None,
    caminho_pdf: str = None,
    largura: int = 1280,
    altura: int = 2000
):
    """
    Renderiza o HTML em um navegador headless e gera:
    - PNG (screenshot)
    - PDF
    """

    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        context = browser.new_context(
            viewport={"width": largura, "height": altura}
        )
        page = context.new_page()

        # Renderização do HTML
        page.set_content(html_string, wait_until="networkidle")

        # Screenshot
        if caminho_png:
            page.screenshot(path=caminho_png, full_page=True)

        # PDF
        if caminho_pdf:
            page.pdf(path=caminho_pdf, format="A4", print_background=True)

        browser.close()
