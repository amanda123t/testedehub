from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import concurrent.futures as cf


def run_with_timeout(fn, timeout_s, *args, use_process=False, **kwargs):
    """
    Executa uma função com timeout.
    - use_process=False: roda em thread (cancelamento leve)
    - use_process=True: roda em subprocesso (mata de verdade)
    """
    Executor = ProcessPoolExecutor if use_process else ThreadPoolExecutor
    ex = Executor(max_workers=1)
    try:
        fut = ex.submit(fn, *args, **kwargs)
        return fut.result(timeout=timeout_s)
    except cf.TimeoutError as e:
        # Cancela o que for possível e encerra com segurança
        try:
            fut.cancel()
        except Exception:
            pass
        ex.shutdown(wait=True, cancel_futures=True)
        raise e
    except Exception as e:
        # erro real da função
        ex.shutdown(wait=True, cancel_futures=True)
        raise e
