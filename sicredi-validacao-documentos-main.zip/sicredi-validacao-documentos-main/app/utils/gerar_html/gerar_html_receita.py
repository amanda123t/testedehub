import pathlib
from app.utils.html_to_print import gerar_print_html

# ============================================================
# CARREGAR BRASÃO (USADO NO CARTÃO CNPJ)
# ============================================================
def carregar_imagem_base64(path):
    import base64
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")

img_brasao = carregar_imagem_base64("app/utils/gerar_html/brasao.gif")


def formatar_cnae_secundario(item):
    code = item["code"].strip()
    text = item["text"].strip()

    if code == "00.00-0-00":
        return text

    return f"{code} - {text}"


def mapear_dados_receita(r):
    return {
        "cnpj": r["cnpj"],
        "matriz_filial": r["tipo"],
        "data_abertura": r["abertura"],
        "nome_empresarial": r["nome"],
        "nome_fantasia": r.get("fantasia", ""),
        "porte": r.get("porte", ""),
        "cnae_principal": f"{r['atividade_principal'][0]['code']} - {r['atividade_principal'][0]['text']}",
        "cnaes_secundarios": [formatar_cnae_secundario(i) for i in r["atividades_secundarias"]],
        "natureza_juridica": r["natureza_juridica"],
        "logradouro": r["logradouro"],
        "numero": r["numero"],
        "complemento": r["complemento"],
        "cep": r["cep"],
        "bairro": r["bairro"],
        "municipio": r["municipio"],
        "uf": r["uf"],
        "email": r.get("email", ""),
        "telefone": r.get("telefone", ""),
        "efr": r.get("efr", ""),
        "situacao_cadastral": r["situacao"],
        "data_situacao": r["data_situacao"],
        "situacao_especial": r.get("situacao_especial", ""),
        "data_situacao_especial": r.get("data_situacao_especial", ""),
        "emitido_em": "11/12/2025 12:56:00",
        "pagina": "1/1",
        "capital_social": r["capital_social"],
        "qsa": r["qsa"]
    }

# ============================================================
# FORMATADORES AUXILIARES
# ============================================================
def campo(v):
    if v is None or str(v).strip() == "":
        return "********"
    return v


def converter_porte(p):
    p = p.upper().strip()
    if "MICRO" in p:
        return "ME"
    if "PEQUENO" in p or "EPP" in p:
        return "EPP"
    return "DEMAIS"


# ============================================================
# 1) QSA – agora gera PDF/PNG automaticamente
# ============================================================
def gerar_qsa_html(d, caminho_html, caminho_pdf=None, caminho_png=None, pdf = True, png = True):

    # (SEU CSS E HTML IDENTICOS – NÃO ALTEREI NADA)
    CSS = """
    <style>
        body {
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
            font-size: 14px;
            color: #333;
        }
        .container { width: 17cm; }
        h2 { font-size: 22px; font-weight: 500; margin-top: 10px; margin-bottom: 10px; }
        p { font-size: 14px; margin-top: 10px; margin-bottom: 10px; }
        .row { width: 100%; display: flex; flex-wrap: nowrap; margin-bottom: 6px; }
        .col-label { width: 25%; font-weight: bold; white-space: nowrap; }
        .col-val { width: calc(75% - 70px); padding-left: 70px; }
        .col-mid { width: calc(41.666% - 70px); padding-left: 70px; }
        .col-empty { width: 16.666%; }
        .alert-info { background-color: #d9edf7; padding: 15px; border-radius: 4px; border: 1px solid #bce8f1; }
        .alert-warning { background-color: #fcf8e3; padding: 15px; border-radius: 4px; border: 1px solid #faebcc; margin-bottom: 15px; }
    </style>
    """

    socios_html = ""
    for s in d["qsa"]:
        socios_html += f"""
        <div class="alert-warning">
            <div class="row">
                <div class="col-label"><b>Nome/Nome Empresarial:</b></div>
                <div class="col-val">{s['nome']}</div>
            </div>
            <div class="row">
                <div class="col-label"><b>Qualificação:</b></div>
                <div class="col-mid">{s['qual']}</div>
                <div class="col-empty">&nbsp;</div>
                <div class="col-empty">&nbsp;</div>
            </div>
        </div>
        """

    html = f"""
    <html>
    <head>{CSS}</head>
    <body>
        <div class="container">
            <h2>Consulta Quadro de Sócios e Administradores - QSA</h2>

            <div class="alert-info">
                <div class="row"><div class="col-label">CNPJ:</div><div class="col-val">{d['cnpj']}</div></div>
                <div class="row"><div class="col-label">NOME EMPRESARIAL:</div><div class="col-val">{d['nome_empresarial']}</div></div>
                <div class="row"><div class="col-label">CAPITAL SOCIAL:</div><div class="col-val">R$ {float(d['capital_social']):,.2f}</div></div>
            </div>

            <br>

            <p>O Quadro de Sócios e Administradores consta na base do CNPJ:</p>

            {socios_html}

            <p>Emitido em {d['emitido_em']}.</p>
        </div>
    </body>
    </html>
    """

    # Salvar HTML temporário
    pathlib.Path(caminho_html).write_text(html, encoding="utf-8")
    # GERAR PRINT AUTOMATICAMENTE
    if not pdf and not png:
        return {"html": str(caminho_html)}
    elif not pdf:
        caminho_pdf = None
    elif not png:
        caminho_png = None
    # GERAR PRINT AUTOMATICAMENTE
    gerar_print_html(
        html_string=html,
        caminho_png=str(caminho_png) if caminho_png else None,
        caminho_pdf=str(caminho_pdf) if caminho_pdf else None,
    )

    return caminho_html


# ============================================================
# 2) CARTÃO CNPJ – também gera PDF/PNG automaticamente
# ============================================================
def gerar_cartao_cnpj_html(d, caminho_html, caminho_pdf=None, caminho_png=None, pdf = True, png = True):

    CSS = """
    <style>
        body { font-family: Arial; }
        table { border-collapse: collapse; line-height: 9pt; }
        .bord { border: 0.5pt solid black; padding-left: 3.5pt; padding-bottom: 3.5pt; }
        .titulo { font-size: 6pt; }
        .valor { font-size: 8pt; font-weight: bold; }
        .linha { margin: 0; padding: 0; }
    </style>
    """

    # CNAEs secundários como múltiplas linhas
    cnaes_sec = "".join(f"<font class='valor'>{c}</font><br>" for c in d["cnaes_secundarios"])

    # HTML completo
    html = f"""
    <html>
    <head>{CSS}</head>
    <body>

    <table border="1" cellspacing="0" style="width:17cm;">
        <tr>
            <td style="padding:5.65pt">

                <!-- Cabeçalho -->
                <table width="100%">
                    <tr>
                        <td width="60" valign="middle">
                            <img src="data:image/gif;base64,{img_brasao}" width="60" height="60">
                        </td>
                        <td align="center">
                            <p class="linha">&nbsp;</p>
                            <font size="4"><b>REPÚBLICA FEDERATIVA DO BRASIL</b></font>
                            <p class="linha">&nbsp;</p>
                            <font><b>CADASTRO NACIONAL DA PESSOA JURÍDICA</b></font>
                        </td>
                        <td width="60"></td>
                    </tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- Número de inscrição -->
                <table width="100%">
                    <tr>
                        <td width="24%" class="bord">
                            <font class="titulo">NÚMERO DE INSCRIÇÃO</font><br>
                            <font class="valor">{d['cnpj']}</font><br>
                            <font class="valor">{d['matriz_filial']}</font>
                        </td>

                        <td width="52%" class="bord" style="border-left:none">
                            <center>
                                <font style="font-size:10pt;"><b>COMPROVANTE DE INSCRIÇÃO E DE SITUAÇÃO CADASTRAL</b></font>
                            </center>
                        </td>

                        <td width="24%" class="bord">
                            <font class="titulo">DATA DE ABERTURA</font><br>
                            <font class="valor">{d['data_abertura']}</font>
                        </td>
                    </tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- Nome empresarial -->
                <table width="100%">
                    <tr>
                        <td class="bord">
                            <font class="titulo">NOME EMPRESARIAL</font><br>
                            <font class="valor">{d['nome_empresarial']}</font>
                        </td>
                    </tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- Nome fantasia + porte -->
                <table width="100%">
                    <tr>
                        <td width="88%" class="bord">
                            <font class="titulo">TÍTULO DO ESTABELECIMENTO (NOME DE FANTASIA)</font><br>
                            <font class="valor">{campo(d['nome_fantasia'])}</font>
                        </td>
                        <td width="2%"></td>
                        <td width="10%" class="bord">
                            <font class="titulo">PORTE</font><br>
                            <font class="valor">{converter_porte(d['porte'])}</font>
                        </td>
                    </tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- CNAE principal -->
                <table width="100%">
                    <tr>
                        <td class="bord">
                            <font class="titulo">CÓDIGO E DESCRIÇÃO DA ATIVIDADE ECONÔMICA PRINCIPAL</font><br>
                            <font class="valor">{d['cnae_principal']}</font>
                        </td>
                    </tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- CNAE secundário -->
                <table width="100%">
                    <tr><td class="bord">
                        <font class="titulo">CÓDIGO E DESCRIÇÃO DAS ATIVIDADES ECONÔMICAS SECUNDÁRIAS</font><br>
                        {cnaes_sec}
                    </td></tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- Natureza jurídica -->
                <table width="100%">
                    <tr><td class="bord">
                        <font class="titulo">CÓDIGO E DESCRIÇÃO DA NATUREZA JURÍDICA</font><br>
                        <font class="valor">{d['natureza_juridica']}</font>
                    </td></tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- Endereço -->
                <table width="100%">
                    <tr>
                        <td width="50%" class="bord">
                            <font class="titulo">LOGRADOURO</font><br>
                            <font class="valor">{campo(d['logradouro'])}</font>
                        </td>

                        <td width="2%"></td>

                        <td width="10%" class="bord">
                            <font class="titulo">NÚMERO</font><br>
                            <font class="valor">{campo(d['numero'])}</font>
                        </td>

                        <td width="2%"></td>

                        <td width="36%" class="bord">
                            <font class="titulo">COMPLEMENTO</font><br>
                            <font class="valor">{campo(d['complemento'])}</font>
                        </td>
                    </tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- CEP / Bairro / Município / UF -->
                <table width="100%">
                    <tr>
                        <td width="18%" class="bord">
                            <font class="titulo">CEP</font><br>
                            <font class="valor">{d['cep']}</font>
                        </td>

                        <td width="2%"></td>

                        <td width="30%" class="bord">
                            <font class="titulo">BAIRRO/DISTRITO</font><br>
                            <font class="valor">{d['bairro']}</font>
                        </td>

                        <td width="2%"></td>

                        <td width="38%" class="bord">
                            <font class="titulo">MUNICÍPIO</font><br>
                            <font class="valor">{d['municipio']}</font>
                        </td>

                        <td width="2%"></td>

                        <td width="10%" class="bord">
                            <font class="titulo">UF</font><br>
                            <font class="valor">{d['uf']}</font>
                        </td>
                    </tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- Email / Telefone -->
                <table width="100%">
                    <tr>
                        <td width="50%" class="bord">
                            <font class="titulo">ENDEREÇO ELETRÔNICO</font><br>
                            <font class="valor">{campo(d['email'])}</font>
                        </td>

                        <td width="2%"></td>

                        <td width="48%" class="bord">
                            <font class="titulo">TELEFONE</font><br>
                            <font class="valor">{campo(d['telefone'])}</font>
                        </td>
                    </tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- EFR -->
                <table width="100%">
                    <tr><td class="bord">
                        <font class="titulo">ENTE FEDERATIVO RESPONSÁVEL (EFR)</font><br>
                        <font class="valor">{campo(d['efr'])}</font>
                    </td></tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- Situação Cadastral -->
                <table width="100%">
                    <tr>
                        <td width="64%" class="bord">
                            <font class="titulo">SITUAÇÃO CADASTRAL</font><br>
                            <font class="valor">{campo(d['situacao_cadastral'])}</font>
                        </td>

                        <td width="2%"></td>

                        <td width="24%" class="bord">
                            <font class="titulo">DATA DA SITUAÇÃO CADASTRAL</font><br>
                            <font class="valor">{campo(d['data_situacao'])}</font>
                        </td>
                    </tr>
                </table>

                <p class="linha">&nbsp;</p>

                <!-- Situação Especial -->
                <table width="100%">
                    <tr>
                        <td width="64%" class="bord">
                            <font class="titulo">SITUAÇÃO ESPECIAL</font><br>
                            <font class="valor">{campo(d['situacao_especial'])}</font>
                        </td>

                        <td width="2%"></td>

                        <td width="24%" class="bord">
                            <font class="titulo">DATA DA SITUAÇÃO ESPECIAL</font><br>
                            <font class="valor">{campo(d['data_situacao_especial'])}</font>
                        </td>
                    </tr>
                </table>

                <br><br>

                <font size="2">Documento gerado automaticamente com dados públicos da Receita Federal.</font>

                <table width="100%" style="line-height:15pt;">
                    <tr>
                        <td align="left">
                            <font size="2">Emitido no dia <b>{d['emitido_em']}</b></font>
                        </td>
                        <td align="right">
                            <font size="2">Página: <b>{d['pagina']}</b></font>
                        </td>
                    </tr>
                </table>

            </td>
        </tr>
    </table>

    </body>
    </html>
    """

    pathlib.Path(caminho_html).write_text(html, encoding="utf-8")

    # GERAR PRINT AUTOMATICAMENTE
    if not pdf and not png:
        return {"html": str(caminho_html)}
    elif not pdf:
        caminho_pdf = None
    elif not png:
        caminho_png = None

    gerar_print_html(
        html_string=html,
        caminho_png=str(caminho_png) if caminho_png else None,
        caminho_pdf=str(caminho_pdf) if caminho_pdf else None,
    )
    return caminho_html


# ============================================================
# 3) FUNÇÃO FINAL – agora retorna PNG/PDF em vez de HTML
# ============================================================
def gerar_documentos_receita(d, pasta_destino, pdf = True, png = True):
    if not d or (isinstance(d,dict) and d.get('status') in ['ERROR', False]):
        return None    
    print(f"valor do d: {d}")
    d = mapear_dados_receita(d)
    pasta_destino = pathlib.Path(pasta_destino)
    pasta_destino.mkdir(parents=True, exist_ok=True)

    cnpj_limpo = d["cnpj"].replace(".", "").replace("/", "").replace("-", "")

    caminho_qsa_html = pasta_destino / f"qsa-{cnpj_limpo}.html"
    caminho_cart_html = pasta_destino / f"cartao-{cnpj_limpo}.html"

    caminho_qsa_pdf = pasta_destino / f"qsa-{cnpj_limpo}.pdf"
    caminho_cart_pdf = pasta_destino / f"cartao-{cnpj_limpo}.pdf"

    caminho_qsa_png = pasta_destino / f"qsa-{cnpj_limpo}.png"
    caminho_cart_png = pasta_destino / f"cartao-{cnpj_limpo}.png"
    
    gerar_qsa_html(d, caminho_qsa_html, caminho_qsa_pdf, caminho_qsa_png, pdf, png)
    gerar_cartao_cnpj_html(d, caminho_cart_html, caminho_cart_pdf, caminho_cart_png, pdf, png)

    return {
        "qsa_pdf": str(caminho_qsa_pdf),
        "qsa_png": str(caminho_qsa_png),
        "cartao_pdf": str(caminho_cart_pdf),
        "cartao_png": str(caminho_cart_png),
    }
