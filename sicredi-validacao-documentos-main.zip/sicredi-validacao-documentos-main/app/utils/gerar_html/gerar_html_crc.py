import pathlib
from datetime import datetime
from app.utils.html_to_print import gerar_print_html

CSS = """
<style>
body {
    font-family: Arial, sans-serif;
    background-color: #f5f6fa;
    margin: 0;
    padding: 0;
}
.card {
    background: white;
    border-radius: 6px;
    margin: 30px auto;
    width: 95%;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
.header {
    background: #0275d8;
    color: white;
    padding: 16px;
    border-radius: 6px 6px 0 0;
    font-size: 20px;
    font-weight: bold;
}
.card-body {
    padding: 20px;
}
.info-row {
    margin-bottom: 10px;
    font-size: 14px;
}
.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}
.table th {
    background: #f0f0f5;
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}
.table td {
    padding: 10px;
    border-bottom: 1px solid #eee;
}
.table tr:nth-child(even) {
    background: #fafafa;
}
</style>
"""


def gerar_html_crc(resultados, pasta_destino, pdf: bool = True, png: bool = True):
    """
    Gera CRC (HTML + PDF + PNG)
    Nome fixo:
    CRC CONTADOR - NOME DO CONTADOR
    """

    pasta_destino = pathlib.Path(pasta_destino)
    pasta_destino.mkdir(parents=True, exist_ok=True)

    # pega o nome do contador do primeiro registro
    nome_contador = resultados[0].get("Nome", "DESCONHECIDO").strip()
    nome_contador = nome_contador.replace("/", "-")

    base_nome = f"CRC CONTADOR - {nome_contador}"

    caminho_html = pasta_destino / f"{base_nome}.html"
    caminho_pdf  = pasta_destino / f"{base_nome}.pdf"
    caminho_png  = pasta_destino / f"{base_nome}.png"

    data_pesquisa = datetime.now().strftime("%d/%m/%Y")
    qtd = len(resultados)

    linhas = ""
    for r in resultados:
        linhas += f"""
        <tr>
            <td>{r.get('Nome','')}</td>
            <td>{r.get('Registro','')}</td>
            <td style='text-align:center'>{r.get('Descricao_Tipo_Registro','')}</td>
            <td style='text-align:center'>{r.get('Descricao_Categoria','')}</td>
            <td style='text-align:center'>{r.get('EstadoConselho','')}</td>
            <td style='text-align:center'>{r.get('SituacaoCadastral','')}</td>
        </tr>
        """

    html = f"""
    <html>
    <head>{CSS}</head>
    <body>
        <div class="card">
            <div class="header">Consulta Nacional</div>

            <div class="card-body">
                <div class="info-row">
                    <span style="color:#d9534f; font-weight:bold;">
                        Quantidade de registros encontrados: {qtd}.
                    </span>
                </div>

                <div class="info-row">
                    <span>Data da Pesquisa: {data_pesquisa}</span>
                </div>

                <table class="table">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Nº Registro</th>
                            <th>Tipo Situação</th>
                            <th>Categoria</th>
                            <th>CRC</th>
                            <th>Situação</th>
                        </tr>
                    </thead>
                    <tbody>
                        {linhas}
                    </tbody>
                </table>

            </div>
        </div>
    </body>
    </html>
    """

    # salva HTML
    caminho_html.write_text(html, encoding="utf-8")
    if not pdf and not png:
        return {"html": str(caminho_html)}
    elif not pdf:
        caminho_pdf = None
    elif not png:
        caminho_png = None
    # gera PDF + PNG (CTRL+P)
    gerar_print_html(
        html_string=html,
        caminho_png=str(caminho_png) if caminho_png else None,
        caminho_pdf=str(caminho_pdf) if caminho_pdf else None,
    )

    return {
        "html": str(caminho_html),
        "pdf": str(caminho_pdf),
        "png": str(caminho_png),
    }
