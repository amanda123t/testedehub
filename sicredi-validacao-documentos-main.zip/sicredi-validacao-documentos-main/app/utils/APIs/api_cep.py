import os
import time
import random
import requests
import urllib.parse
from threading import Semaphore
from typing import Optional, Dict, Any
from app.utils.logger import LoggerManager

log = LoggerManager(__name__)

# ================================================================
# SEMÁFORO GLOBAL (limita requisições simultâneas)
# ================================================================
API_CEP_GLOBAL = Semaphore(int(os.getenv("API_CEP_TRAVA", "3")))

# ================================================================
# CACHE EM MEMÓRIA
# ================================================================
_CACHE_CEP: Dict[str, Any] = {}

def get_cached(key: str):
    return _CACHE_CEP.get(key)

def set_cached(key: str, value):
    _CACHE_CEP[key] = value

# ================================================================
# FUNÇÃO GENÉRICA DE REQUISIÇÃO COM RETRY
# ================================================================
def fetch_retry(
    url,
    *,
    params=None,
    headers=None,
    timeout=3,
    max_retries=2,
    chave_cache=None,
):
    """
    GET com retry CONTROLADO para APIs instáveis (CEP).
    - Máx 2 tentativas
    - Timeout curto
    - Falha rápida
    """

    # Cache
    if chave_cache and (cache := get_cached(chave_cache)):
        log.debug(f"✔ Cache usado: {chave_cache}")
        return cache

    for attempt in range(1, max_retries + 1):
        try:
            with API_CEP_GLOBAL:
                resp = requests.get(
                    url,
                    params=params,
                    headers=headers,
                    timeout=timeout,
                )

            status = resp.status_code

            if status == 200:
                data = resp.json()
                if chave_cache:
                    set_cached(chave_cache, data)
                return data

            # ❌ 4xx → não insiste
            if status in (400, 401, 403, 404):
                log.warning(f"❌ HTTP {status} — falha definitiva")
                return None

            # ❌ 5xx → não insiste para CEP
            log.warning(f"❌ HTTP {status} — sem retry (CEP)")
            return None

        except requests.exceptions.ReadTimeout:
            log.warning(f"⏱ Timeout ({attempt}/{max_retries})")
            if attempt >= max_retries:
                return None

        except Exception as e:
            log.error(f"❌ Erro inesperado: {e}")
            return None

    return None

# ================================================================
# BUSCAR ENDEREÇO PELO CEP (ViaCEP — estável)
# ================================================================
def buscar_endereco(cep: str) -> Optional[Dict[str, Any]]:
    cep = cep.replace("-", "").strip()

    if not (cep.isdigit() and len(cep) == 8):
        log.error(f"CEP inválido: {cep}")
        return None

    chave = f"viacep:{cep}"
    url = f"https://viacep.com.br/ws/{cep}/json/"

    data = fetch_retry(
        url,
        headers={"User-Agent": "Mozilla/5.0"},
        chave_cache=chave,
    )

    if not data:
        return None

    if "erro" in data:
        log.warning(f"CEP não encontrado: {cep}")
        return None

    return {
        "logradouro": data.get("logradouro"),
        "complemento": data.get("complemento"),
        "bairro": data.get("bairro"),
        "cidade": data.get("localidade"),
        "estado": data.get("uf"),
        "cep": data.get("cep"),
    }


# ================================================================
# BUSCAR CEP A PARTIR DO ENDEREÇO (OpenStreetMap)
# ================================================================
def buscar_cep(endereco: str) -> Optional[str]:
    endereco_cod = urllib.parse.quote(endereco)
    chave = f"cepfromaddr:{endereco_cod}"

    url = (
        f"https://nominatim.openstreetmap.org/search"
        f"?q={endereco_cod}&format=json&addressdetails=1"
    )

    data = fetch_retry(
        url,
        headers={"User-Agent": "Mozilla/5.0"},
        chave_cache=chave,
    )

    if not data or not isinstance(data, list) or len(data) == 0:
        return None

    return data[0]["address"].get("postcode")
