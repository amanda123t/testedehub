import os, re
import time
import json
import random
import requests
from bs4 import BeautifulSoup
from threading import Semaphore
from typing import Optional, Dict, Any
from app.utils.logger import LoggerManager
from app.utils.html_to_print import gerar_print_html

log = LoggerManager(__name__)

# ================================================================
# SEMÁFORO (limita requisições paralelas)
# ================================================================
API_CERTIDOES_GLOBAL = Semaphore(int(os.getenv("API_CERTIDOES_TRAVA", "3")))

# ================================================================
# CACHE EM MEMÓRIA (válido durante a execução)
# ================================================================
_CACHE_CERTIDOES: dict[str, dict] = {}

def get_cached(key: str) -> Optional[Dict[str, Any]]:
    return _CACHE_CERTIDOES.get(key)

def set_cached(key: str, value: dict) -> None:
    _CACHE_CERTIDOES[key] = value

# ================================================================
# PARSER Retry-After
# ================================================================
def parse_retry_after(resp: requests.Response) -> Optional[float]:
    if "Retry-After" in resp.headers:
        v = resp.headers["Retry-After"].strip()
        if v.isdigit():
            return max(1.0, float(v))
    return None

# ================================================================
# FUNÇÃO GENÉRICA DE REQUISIÇÃO COM RETRY
# ================================================================
def fetch_with_retry(
    url: str,
    params=None,
    headers=None,
    max_retries=6,
    timeout=15.0,
    chave_cache: str = None,
):
    """
    Implementa retry/backoff idêntico ao da Receita.
    Usa:
      - cache memória
      - semáforo global
    """

    # --- cache em memória ---
    if chave_cache and (cache := get_cached(chave_cache)):
        log.debug(f"✔ Usando cache memória para {chave_cache}")
        return cache

    rng = random.Random(int(str(hash(chave_cache))[-6:].replace("-", "1")))

    for attempt in range(1, max_retries + 1):
        try:
            with API_CERTIDOES_GLOBAL:
                time.sleep(0.5 + rng.uniform(0, 0.5))  # microdelay

                resp = requests.get(url, params=params, headers=headers, timeout=timeout)
                status = resp.status_code

                # Sucesso
                if status == 200:
                    return resp

                # 429 — muita requisição
                if status == 429:
                    ra = parse_retry_after(resp)
                    wait_s = max(5.0, ra) if ra else 5.0
                    log.warning(f"⚠ 429 — aguardando {wait_s}s (tentativa {attempt})…")
                    time.sleep(wait_s)
                    continue

                # 5xx — servidor do outro lado com problema
                if 500 <= status < 600:
                    if attempt < max_retries:
                        log.warning(f"⚠ {status} — retry em 3s (tentativa {attempt})…")
                        time.sleep(3)
                        continue
                    break

                # 4xx — erro permanente
                if status in (400, 401, 403, 404):
                    log.error(f"❌ HTTP {status} sem retry.")
                    return resp

                log.error(f"⚠ HTTP {status} inesperado.")
                return resp

        except Exception as e:
            if attempt < max_retries:
                log.error(f"⚠ Exceção {type(e).__name__}: {e} — retry 3s (tentativa {attempt})")
                time.sleep(3)
                continue
            else:
                log.error(f"❌ Exceção final {e}")
                return None

    return None


# ================================================================
# FUNARPEN
# ================================================================
from app.utils.html_to_print import gerar_print_html

def consultar_funarpen(matricula: str, output_path: str, nome_arquivo: str, pdf: bool = True, png: bool = True) -> dict:
    """
    Consulta a FUNARPEN, salva o print usando o nome do arquivo original,
    e aplica validação de matrícula antes da consulta.
    """

    # ---------------------------------------------------------
    # 🔒 1) Validação da matrícula — evita consultas erradas
    # ---------------------------------------------------------
    matricula_limpa = re.sub(r"\D", "", matricula or "").replace(" ","")

    if not matricula_limpa.isdigit() or len(matricula_limpa) < 15:
        return {
            "valido": False,
            "matricula": matricula,
            "mensagem": "Matrícula inválida (menos de 15 dígitos ou contém letras)",
            "print": None,
        }

    matricula = matricula_limpa  # passa a usar só o número limpo
    chave = f"funarpen:{matricula}"

    # ---------------------------------------------------------
    # 🔒 2) Sanitiza nome do arquivo para salvar prints
    # ---------------------------------------------------------
    nome_sanitizado = re.sub(r"[^a-zA-Z0-9_-]", "_", nome_arquivo)
    caminho_png = os.path.join(output_path, f"funarpen_{nome_sanitizado}.png")
    caminho_pdf = os.path.join(output_path, f"funarpen_{nome_sanitizado}.pdf")

    # ---------------------------------------------------------
    # 🔗 3) Consulta via request
    # ---------------------------------------------------------
    url = "https://www.funarpen.com.br/funarpen/ResultadoConsulta.php"
    headers = {"User-Agent": "Mozilla/5.0"}

    resp = fetch_with_retry(
        url=url,
        params={"matricula": matricula},
        headers=headers,
        chave_cache=chave,
    )

    if not resp:
        return {
            "valido": False,
            "mensagem": "Erro de comunicação",
            "matricula": matricula,
            "print": None,
        }

    html = resp.text

    # ---------------------------------------------------------
    # 📸 4) Salvar print do HTML (PNG + PDF)
    # ---------------------------------------------------------
    if not pdf:
        caminho_pdf = None
    if not png:
        caminho_png = None
    
    try:
        gerar_print_html(html, str(caminho_png) if caminho_png else None, str(caminho_pdf) if caminho_pdf else None)
    except Exception as e:
        print("Erro ao gerar print FUNARPEN:", e)

    # ---------------------------------------------------------
    # 🔍 5) Parser
    # ---------------------------------------------------------
    soup = BeautifulSoup(html, "html.parser")
    texto = soup.get_text(" ", strip=True).upper()

    # matrícula inexistente
    if "NÚMERO DE MATRÍCULA DIGITADO É VÁLIDO" not in texto:
        result = {
            "valido": False,
            "matricula": matricula,
            "mensagem": "Não encontrada",
            "print": caminho_pdf,
        }
        set_cached(chave, result)
        return result

    def pegar_valor(label):
        td = soup.find("strong", string=lambda t: t and label in t)
        if td:
            next_td = td.find_parent("td").find_next_sibling("td")
            if next_td:
                return next_td.get_text(strip=True)
        return None

    dados = {
        "valido": True,
        "matricula": matricula,
        "fonte": "FUNARPEN",
        "print": caminho_pdf,
        "numero_matricula_formatado": pegar_valor("Numero de Matr"),
        "acervo": pegar_valor("Acervo"),
        "tipo": pegar_valor("Tipo"),
        "ano": pegar_valor("Ano"),
        "livro": pegar_valor("Livro"),
        "folha": pegar_valor("Folha"),
        "termo": pegar_valor("Termo"),
    }

    set_cached(chave, dados)
    return dados

# ================================================================
# SEL0 TJRS
# ================================================================
def consultar_selo_tjrs(chave_selo: str, output_path: str, nome_arquivo: str, pdf: bool = True, png: bool = True) -> dict:
    """
    Consulta o Selo Digital do TJRS, gera print HTML (PNG + PDF)
    e usa o mesmo estilo de sanitização simples da chave que o Guilherme já usa.
    """

    # ---------------------------------------------------------
    # 1) Sanitização igual à que você já usa
    # ---------------------------------------------------------
    chave_selo = chave_selo.replace(" ", "").replace(".", "").strip()
    chave_cache = f"selo:{chave_selo}"

    # ---------------------------------------------------------
    # 2) Sanitiza nome do arquivo para salvar prints
    # ---------------------------------------------------------
    nome_sanitizado = re.sub(r"[^a-zA-Z0-9_-]", "_", nome_arquivo)

    caminho_png = os.path.join(output_path, f"selo_{nome_sanitizado}.png")
    caminho_pdf = os.path.join(output_path, f"selo_{nome_sanitizado}.pdf")

    # ---------------------------------------------------------
    # 3) Requisição
    # ---------------------------------------------------------
    url = "https://www.tjrs.jus.br/servicos/selo/consulta_selo_chave.php"
    headers = {"User-Agent": "Mozilla/5.0"}

    resp = fetch_with_retry(
        url=url,
        params={"c": chave_selo},
        headers=headers,
        chave_cache=chave_cache,
    )

    if not resp:
        return {
            "valido": False,
            "mensagem": "Erro de comunicação",
            "chave": chave_selo,
            "print": None,
        }

    html = resp.text

    # ---------------------------------------------------------
    # 4) Gera print (PNG + PDF)
    # ---------------------------------------------------------
    if not pdf:
        caminho_pdf = None
    if not png:
        caminho_png = None

    try:
        gerar_print_html(html, str(caminho_png) if caminho_png else None, str(caminho_pdf) if caminho_pdf else None)
    except Exception as e:
        print("Erro ao gerar print TJRS:", e)

    # ---------------------------------------------------------
    # 5) Parser
    # ---------------------------------------------------------
    soup = BeautifulSoup(html, "html.parser")

    # selo inexistente
    if "document.location" in html or not soup.find(string=lambda t: t and "Selo Digital" in t):
        result = {
            "valido": False,
            "mensagem": "Selo inexistente",
            "chave": chave_selo,
            "print": caminho_pdf,
        }
        set_cached(chave_cache, result)
        return result

    dados = {
        "valido": True,
        "chave": chave_selo,
        "print": caminho_pdf,
    }

    # captura do número do selo
    selo_td = soup.find("td", string=lambda t: t and "Selo Digital" in t)
    if selo_td:
        dados["selo_digital"] = selo_td.get_text(strip=True)

    # Tabelas
    for row in soup.find_all("tr"):
        cols = row.find_all(["th", "td"])
        if len(cols) == 2:
            label = cols[0].get_text(strip=True).replace(":", "").lower()
            valor = cols[1].get_text(strip=True)

            mapping = {
                "serventia": "serventia",
                "endereço": "endereco",
                "emissão": "emissao",
                "ato": "ato",
                "cobrança": "cobranca",
                "emolumento": "emolumento",
                "talão/nota": "talao_nota",
            }
            if label in mapping:
                dados[mapping[label]] = valor

    # Valor Selo
    for td in soup.find_all("td"):
        texto = td.get_text(strip=True)
        if texto.startswith("Valor Selo:"):
            dados["valor_selo"] = texto.replace("Valor Selo:", "").strip()

    set_cached(chave_cache, dados)
    return dados
