import os, time, re, json, random, requests
import difflib
from typing import Optional, Dict, Any
from threading import Semaphore
from app.utils.logger import LoggerManager

log = LoggerManager(__name__)
API_CRC_GLOBAL = Semaphore(int(os.getenv("API_CRC_TRAVA", "3")))

# -------------------------------------------------------
# CACHE GLOBAL COM TTL (24h)
# -------------------------------------------------------
_CACHE_CRC: dict[str, tuple[float, dict]] = {}
CACHE_TTL = 86400  # 24 horas


def _normalize(s: Optional[str]) -> str:
    s = (s or "").strip()
    s = re.sub(r"\s+", " ", s)
    return s


def _digits(s: Optional[str]) -> str:
    return re.sub(r"\D", "", s or "")


def _similar(a: str, b: str) -> float:
    a = _normalize(a).upper()
    b = _normalize(b).upper()
    return difflib.SequenceMatcher(None, a, b).ratio()


# ======================================================
#  CLASSE PRINCIPAL — CONSULTA API CRC OTIMIZADA
# ======================================================
class CRC:

    URL = "https://www3.cfc.org.br/spw/consultanacionalcfcbeta/api/CFC/ListarProfissional"
    URL_EMPRESA = "https://www3.cfc.org.br/spw/consultanacionalcfcbeta/api/CFC/ListarEmpresa"

    HEADERS = {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Sicredi-Automacoes/1.0"
    }

    # ------------------------- CACHE -------------------------
    @classmethod
    def get_cached(cls, key: str):
        if key in _CACHE_CRC:
            ts, data = _CACHE_CRC[key]
            if time.time() - ts < CACHE_TTL:
                log.debug(f"✔ Usando cache CRC para {key}")
                return data
            else:
                del _CACHE_CRC[key]
        return None

    @classmethod
    def set_cached(cls, key: str, value: dict):
        _CACHE_CRC[key] = (time.time(), value)

    # -------------------- NORMALIZADOR CRC --------------------
    @staticmethod
    def _parse_crc(raw: str) -> Optional[str]:
        r = _normalize(raw).upper()
        m_uf = re.search(r"\b([A-Z]{2})\s*[-/]?\s*(\d{3,})", r)
        if not m_uf:
            m_uf = re.search(r"\b([A-Z]{2})\b.*?(\d{3,})", r)
        if not m_uf:
            return None

        uf = m_uf.group(1)
        nums = re.sub(r"\D", "", m_uf.group(2))
        if len(nums) < 6:
            return None

        return f"{uf}-{nums[:6]}"

    # ============================================================
    #                       MÉTODO PRINCIPAL
    # ============================================================
    def get_situacao_contador(
        self,
        pessoa: Dict[str, str],
        *,
        max_retries: int = 4,          # << reduzido!
        timeout_connect: float = 5.0,  # << novo
        timeout_read: float = 7.0      # << reduzido!
    ) -> Optional[Dict[str, Any]]:

        nome = _normalize(pessoa.get("Nome") or pessoa.get("nome") or "")
        cpf = _digits(pessoa.get("CPF") or pessoa.get("cpf") or "")
        cnpj = _digits(pessoa.get("CNPJ") or pessoa.get("cnpj") or "")
        crc_norm = self._parse_crc(pessoa.get("CRC") or pessoa.get("crc") or "")

        cache_key = cpf or cnpj or crc_norm or nome
        if cache_key and (cached := self.get_cached(cache_key)):
            return cached

        # ========== Função interna para requisição ==========
        def _request(url: str, params: dict):
            try:
                resp = requests.get(
                    url,
                    params=params,
                    headers=self.HEADERS,
                    timeout=(timeout_connect, timeout_read)  # << NOVO
                )
                status = resp.status_code
                data = resp.json() if status == 200 else None
                return status, data, resp

            except requests.Timeout as e:
                raise e
            except requests.RequestException as e:
                raise e

        # ------------------------------------------------------
        # FUNÇÃO DE TENTATIVA COM BACKOFF + JITTER
        # ------------------------------------------------------
        def _do_attempt(url: str, params: dict, criterio: str):

            for attempt in range(1, max_retries + 1):
                try:
                    with API_CRC_GLOBAL:

                        # Jitter: evita sincronização entre threads
                        time.sleep(random.uniform(0.1, 0.5))

                        status, data, resp = _request(url, params)

                        # 200 OK --------------------------------------------
                        if status == 200:
                            total = data.get("totalCount") or data.get("total") or len(data.get("data") or [])
                            if total:
                                result = {
                                    "ok": True,
                                    "criterio": criterio,
                                    "entrada": params.get("value"),
                                    "total": total,
                                    "dados": data,
                                }
                                if cache_key:
                                    self.set_cached(cache_key, result)
                                return result
                            return None

                        # 429 Too Many Requests ------------------------------
                        if status == 429:
                            wait = random.uniform(2, 4)
                            log.warning(f"⚠ 429 do CRC. Esperando {wait:.1f}s...")
                            time.sleep(wait)
                            continue

                        # 5xx Erros do servidor ------------------------------
                        if 500 <= status < 600:
                            wait = random.uniform(2, 4)
                            log.error(f"⚠ HTTP {status} do CRC. Retry em {wait:.1f}s")
                            time.sleep(wait)
                            continue

                        # Erros não recuperáveis -----------------------------
                        if status in (400, 401, 403, 404):
                            log.error(f"⚠ HTTP {status} sem retry ({criterio}).")
                            return None

                except requests.Timeout:
                    wait = random.uniform(2, 4)
                    log.error(f"⏳ Timeout CRC ({criterio}) tentativa {attempt}/{max_retries}. Backoff {wait:.1f}s")
                    time.sleep(wait)

                except Exception as e:
                    log.error(f"❌ Erro inesperado CRC ({criterio}): {e}")
                    break

            return None

        # ============================================================
        #                     ORDEM DE CONSULTAS
        # ============================================================

        # PRIORIDADE 1 — CPF (mais preciso)
        if len(cpf) == 11:
            params = {
                "skip": 0,
                "take": 10,
                "requireTotalCount": "true",
                "sort": '[{"selector":"Nome","desc":false}]',
                "filter": "[]",
                "value": f"{cpf[:3]}.{cpf[3:6]}.{cpf[6:9]}-{cpf[9:11]}"
            }
            if r := _do_attempt(self.URL, params, "cpf_profissional"):
                return r

        # PRIORIDADE 2 — Nome
        if nome:
            params = {
                "skip": 0,
                "take": 10,
                "requireTotalCount": "true",
                "sort": '[{"selector":"Nome","desc":false}]',
                "filter": json.dumps(["Nome", "startswith", nome]),
            }
            if r := _do_attempt(self.URL, params, "nome_profissional"):
                return r

        # PRIORIDADE 3 — CNPJ empresa
        if len(cnpj) == 14:
            params = {
                "skip": 0, "take": 10,
                "requireTotalCount": "true",
                "sort": '[{"selector":"Nome","desc":false}]',
                "filter": "[]",
                "value": f"{cnpj[:2]}.{cnpj[2:5]}.{cnpj[5:8]}/{cnpj[8:12]}-{cnpj[12:14]}"
            }
            if r := _do_attempt(self.URL_EMPRESA, params, "cnpj_empresa"):
                return r

        # PRIORIDADE 4 — CRC normalizado
        if crc_norm:
            params = {
                "skip": 0,
                "take": 10,
                "requireTotalCount": "true",
                "sort": '[{"selector":"Nome","desc":false}]',
                "filter": json.dumps(["Registro", "contains", crc_norm])
            }
            if r := _do_attempt(self.URL, params, "crc_profissional"):
                return r

        # ------------------ Falha total ------------------
        result = {"ok": False, "criterio": "falha_total", "entrada": None, "total": None, "dados": None}
        if cache_key:
            self.set_cached(cache_key, result)
        return result
