
import requests

API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiIyd2lPUDlsM3lHWWhSSGdzaGkwT0NmYm9mdjdQSzhNWWZqd0hpMk5JRzZRa0NwR19Xem0xU2h0MzJoY0NWVVBXR0drdGVjclRKRWNCRTJSMSIsImlhdCI6MTc2NTM3NDY5OH0.0JNzOLQ3roecjlbmtgpM48T5AbAme4pIXjgdBpcn4LA"

HEADERS = {
    "accept": "application/json",
    "chave-api-dados-abertos": API_KEY
}

BASE_URL = "https://dados.gov.br/dados/api/publico/conjuntos-dados"

# ===============================================================
# 1. Buscar todas as páginas de datasets
# ===============================================================
def listar_todos_os_datasets(max_paginas=300):
    print("🔎 Buscando datasets em todas as páginas...")
    todos = []

    for pagina in range(1, max_paginas + 1):
        resp = requests.get(
            BASE_URL,
            headers=HEADERS,
            params={"isPrivado": "false", "pagina": str(pagina)}
        )

        if resp.status_code != 200:
            print(f"⚠ Página {pagina}: erro HTTP {resp.status_code}")
            break

        data = resp.json()
        if not data:
            print(f"✓ Fim da listagem na página {pagina}")
            break

        print(f"📄 Página {pagina}: {len(data)} itens")
        todos.extend(data)

    print(f"\n💾 Total de datasets encontrados: {len(todos)}\n")
    return todos


# ===============================================================
# 2. Buscar por RAIS em todos os datasets
# ===============================================================
def buscar_rais(datasets):
    resultados = []

    for d in datasets:
        nome = d.get("nome", "").lower()
        titulo = d.get("title", "").lower()

        if "rais" in nome or "rais" in titulo:
            resultados.append(d)

    print(f"\n📌 Encontrados {len(resultados)} datasets relacionados à RAIS.\n")
    return resultados


# ===============================================================
# 3. Obter detalhes do dataset RAIS e baixar o arquivo
# ===============================================================
def baixar_arquivo_rais(dataset):
    dataset_id = dataset["id"]
    print(f"🔎 Obtendo detalhes do dataset RAIS: {dataset_id}")

    url = f"{BASE_URL}/{dataset_id}"

    resp = requests.get(url, headers=HEADERS)
    if resp.status_code != 200:
        print("❌ Erro ao acessar os detalhes do dataset.")
        return

    detalhes = resp.json()

    recursos = detalhes.get("recursos", [])
    if not recursos:
        print("❌ Nenhum arquivo encontrado dentro do dataset RAIS.")
        return

    # Preferir um arquivo ZIP ou CSV
    recurso = None
    for r in recursos:
        if r.get("formato", "").lower() in ("zip", "csv", "txt"):
            recurso = r
            break

    if not recurso:
        print("❌ Nenhum arquivo ZIP/CSV encontrado.")
        return

    link = recurso["link"]
    nome_arquivo = recurso["titulo"].replace(" ", "_") + "." + recurso["formato"].lower()

    print(f"⬇ Baixando arquivo: {nome_arquivo}")
    print(f"🔗 URL: {link}")

    conteudo = requests.get(link).content

    with open(nome_arquivo, "wb") as f:
        f.write(conteudo)

    print(f"\n✅ Download concluído: {nome_arquivo}\n")
    return nome_arquivo


# ===============================================================
# EXECUÇÃO PRINCIPAL
# ===============================================================
if __name__ == "__main__":
    # 1. Listar tudo
    datasets = listar_todos_os_datasets(max_paginas=300)

    # 2. Encontrar RAIS
    rais_encontrados = buscar_rais(datasets)

    if not rais_encontrados:
        print("❌ Nenhum dataset da RAIS encontrado.")
        exit()

    # Vamos pegar a RAIS mais recente (último ID normalmente é o mais novo)
    rais_mais_recente = rais_encontrados[0]
    print("📌 Dataset RAIS selecionado:")
    print(rais_mais_recente["id"], "|", rais_mais_recente["title"], "\n")

    # 3. Baixar arquivo
    baixar_arquivo_rais(rais_mais_recente)