import http.client
import time, re, os, json, random
from typing import Optional, Dict, Any
from threading import Semaphore
from datetime import datetime, timezone
from dateutil import parser
from app.utils.logger import LoggerManager
from app.modules.supabase import SupabaseClient

log = LoggerManager(__name__)
API_RECEITA_GLOBAL = Semaphore(int(os.getenv("API_RECEITA_TRAVA", "1")))

# ---------------------------------------------------------------
# CACHE GLOBAL (válido durante a execução do processo)
# ---------------------------------------------------------------
_CACHE_RECEITA: dict[str, dict] = {}


class Receita:
    """
    Classe responsável por consultar a API da ReceitaWS,
    armazenar resultados no cache global e também no banco Supabase.
    """

    HOST = "www.receitaws.com.br"

    def __init__(self):
        self.db = SupabaseClient()  # conexão supabase

    # -----------------------------------------------------------
    # Métodos utilitários
    # -----------------------------------------------------------
    @staticmethod
    def _digits(s: str) -> str:
        """Remove todos os caracteres não numéricos de uma string."""
        return re.sub(r"\D", "", s or "")

    @staticmethod
    def _parse_retry_after(headers) -> Optional[float]:
        """Tenta extrair o tempo de espera (Retry-After) dos cabeçalhos HTTP."""
        try:
            for k, v in headers or []:
                if k.lower() == "retry-after":
                    v = v.strip()
                    if v.isdigit():
                        return max(1.0, float(v))
        except Exception:
            pass
        return None

    # -----------------------------------------------------------
    # Métodos de cache global
    # -----------------------------------------------------------
    @classmethod
    def get_cached(cls, cnpj: str) -> Optional[Dict[str, Any]]:
        """Retorna dados do cache global, se disponíveis."""
        return _CACHE_RECEITA.get(cls._digits(cnpj))

    @classmethod
    def set_cached(cls, cnpj: str, dados: Dict[str, Any]) -> None:
        """Salva dados no cache global."""
        _CACHE_RECEITA[cls._digits(cnpj)] = dados

    # -----------------------------------------------------------
    # Busca no banco Supabase
    # -----------------------------------------------------------
    def _buscar_supabase(self, cnpj: str) -> Optional[Dict[str, Any]]:
        """Tenta buscar o CNPJ no Supabase e validar se ainda é recente (<30 dias)."""
        try:
            result = self.db.select("consultas_receita", {"cnpj": cnpj})
            if not result:
                return None  # não encontrado no banco

            registro = result[0]
            updated_at = parser.isoparse(registro["updated_at"])
            delta_dias = (datetime.now(timezone.utc) - updated_at).days

            if delta_dias <= 15:
                log.debug(f"✔ Dados recentes do Supabase usados ({delta_dias} dias): {cnpj}")
                self.set_cached(cnpj, registro["dados"])
                return registro["dados"]
            else:
                log.debug(f"⚠️ Dados antigos ({delta_dias} dias) — nova consulta será feita: {cnpj}")
                return None
        except Exception as e:
            log.error(f"⚠️ Erro ao consultar Supabase: {e}")
            return None

    def _salvar_supabase(self, cnpj: str, dados: Dict[str, Any]) -> None:
        """Salva ou atualiza o CNPJ no Supabase."""
        try:
            registro = {"cnpj": cnpj, "dados": dados}
            self.db.upsert("consultas_receita", registro, on_conflict="cnpj")
            log.info(f"💾 Dados salvos no Supabase: {cnpj}")
        except Exception as e:
            log.error(f"⚠️ Falha ao salvar no Supabase: {e}")


    # -----------------------------------------------------------
    # Método principal
    # -----------------------------------------------------------
    def get_cnpj(
        self,
        cnpj: str,
        max_retries: int = 9,
        timeout: float = 15.0,
    ) -> Optional[Dict[str, Any]]:
        """
        Consulta os dados de um CNPJ.
        1. Verifica cache em memória.
        2. Verifica banco Supabase (e validade de 30 dias).
        3. Se não houver ou estiver desatualizado, busca na ReceitaWS e salva novamente.
        """
        cnpj = self._digits(cnpj)
        if len(cnpj) != 14:
            log.error("❌ CNPJ inválido.")
            return None

        # 🔍 1. Tenta cache global
        if cached := self.get_cached(cnpj):
            log.debug(f"✔ Usando cache em memória para {cnpj}")
            return cached

        # 🔍 2. Tenta Supabase
        if dados_banco := self._buscar_supabase(cnpj):
            return dados_banco

        # 🔍 3. Consulta na ReceitaWS
        rng = random.Random(int(cnpj[-6:]))

        for attempt in range(1, max_retries + 1):
            conn = None
            try:
                with API_RECEITA_GLOBAL:
                    # atraso fixo + leve variação aleatória
                    time.sleep(10.0 + rng.uniform(0.0, 2.0))

                    conn = http.client.HTTPSConnection(self.HOST, timeout=timeout)
                    headers = {
                        "User-Agent": "Sicredi-Automacoes/1.0",
                        "Accept": "application/json",
                        "Connection": "close",
                    }
                    conn.request("GET", f"/v1/cnpj/{cnpj}", headers=headers)
                    resp = conn.getresponse()
                    status = resp.status
                    body = resp.read()
                    headers_list = resp.getheaders()

                    if status == 200:
                        try:
                            dados = json.loads(body.decode("utf-8", errors="replace"))
                            self.set_cached(cnpj, dados)
                            self._salvar_supabase(cnpj, dados)
                            log.info(f"✔ Receita consultada e salva: {cnpj}")
                            return dados
                        except Exception:
                            log.error("⚠️ 200 recebido, mas JSON inválido — retry.")
                            status = 502

                    if status == 429:
                        ra = self._parse_retry_after(headers_list)
                        wait_s = max(21.0, ra) if ra else 21.0
                        if attempt < max_retries:
                            log.warning(f"⚠️ 429. Aguardando {wait_s:.1f}s (tentativa {attempt}/{max_retries})…")
                            time.sleep(wait_s)
                            continue
                        break

                    if 500 <= status < 600:
                        if attempt < max_retries:
                            log.warning(f"⚠️ {status}. Backoff 5s (tentativa {attempt}/{max_retries})…")
                            time.sleep(5.0)
                            continue
                        break

                    if status in (400, 401, 403, 404):
                        log.error(f"⚠️ HTTP {status}. Sem retry.")
                        break

                    log.error(f"⚠️ HTTP {status} inesperado. Encerrando.")
                    break

            except Exception as e:
                if attempt < max_retries:
                    log.error(f"❌ {type(e).__name__}: {e}. Backoff 5s (tentativa {attempt}/{max_retries})…")
                    time.sleep(5.0)
                    continue
                else:
                    log.error(f"❌ Exceção final: {e}")
                    break
            finally:
                if conn:
                    try:
                        conn.close()
                    except Exception:
                        pass

        log.error(f"❌ Falha após todas as tentativas para {cnpj}")
        return None
