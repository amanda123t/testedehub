

import requests

from datetime import datetime
from dateutil.relativedelta import relativedelta

API_KEY = "8838d0a31aaea29e8c6ced30434b849a"  # <-- sua chave aqui

HEADERS = {
    "chave-api-dados": API_KEY,
    "Accept": "application/json",
}

BASE = "https://api.portaldatransparencia.gov.br/api-de-dados"


def get(url, params):
    try:
        resp = requests.get(url, headers=HEADERS, params=params, timeout=20)

        if resp.status_code == 200:
            try:
                return resp.json()
            except:
                return None

        if resp.status_code == 400:
            # parâmetro obrigatório faltando → tratar como "nenhum benefício"
            print(f"⚠ HTTP 400 na URL {url} com parâmetros {params} → retornando None")
            return None
        print(f"⚠ HTTP {resp.status_code} na URL {url} com parâmetros {params} → retornando None")
        return None
    except:
        return None

# ==========================================================
# BENEFÍCIOS
# ==========================================================
def consultar_beneficios(cpf):
    cpf = cpf.replace(".", "").replace("-", "").strip()

    beneficios = {
        "auxilio_emergencial": False,
        "bpc": False,
        "seguro_defeso": False,
        "garantia_safra": False,
        "peti": False,
    }

    # Auxílio Emergencial
    ae = get(
        f"{BASE}/auxilio-emergencial-por-cpf-ou-nis",
        {
            "codigoBeneficiario": cpf,
            "pagina": 1,
        }
    )
    if isinstance(ae, list) and len(ae) > 0:
        beneficios["auxilio_emergencial"] = True

    # BPC
    bpc = get(
        f"{BASE}/bpc-por-cpf-ou-nis",
        {
            "codigo": cpf,
            "pagina": 1,
        }
    )
    if isinstance(bpc, list) and len(bpc) > 0:
        beneficios["bpc"] = True

    # Seguro Defeso
    sd = get(
        f"{BASE}/seguro-defeso-codigo",
        {
            "codigo": cpf,
            "pagina": 1,
        }
    )
    if isinstance(sd, list) and len(sd) > 0:
        beneficios["seguro_defeso"] = True

    # Garantia Safra
    gs = get(
        f"{BASE}/safra-codigo-por-cpf-ou-nis",
        {
            "codigo": cpf,
            "pagina": 1,
        }
    )
    if isinstance(gs, list) and len(gs) > 0:
        beneficios["garantia_safra"] = True

    return beneficios
# ==========================================================
# REMUNERAÇÃO
# ==========================================================
def consultar_remuneracao_servidor(cpf, meses=3):
    cpf = cpf.replace(".", "").replace("-", "").strip()
    url = f"{BASE}/servidores/remuneracao"

    hoje = datetime.now()
    resultados = []

    for i in range(meses):
        ano_mes = (hoje - relativedelta(months=i)).strftime("%Y%m")

        dados = get(url, {
            "cpf": cpf,
            "mesAno": ano_mes,
            "pagina": 1
        })

        if not isinstance(dados, list) or len(dados) == 0:
            continue

        for item in dados:
            det = item.get("servidor", {})
            remuneracoes = item.get("remuneracoesDTO", [])

            # Se não tem remuneração (mês futuro), pula
            if len(remuneracoes) == 0:
                continue

            r = remuneracoes[0]  # sempre o conjunto do mês

            # ==========================
            # BRUTO TOTAL
            # ==========================  
            total_bruto = 0
            for rub in r.get("rubricas", []):
                valor = rub.get("valor", 0)
                if valor > 0:   # só somamos valores positivos
                    total_bruto += valor

            # ==========================
            # LÍQUIDO TOTAL
            # ==========================
            liquido_str = r.get("valorTotalRemuneracaoAposDeducoes")
            if isinstance(liquido_str, str):
                liquido = float(liquido_str.replace(".", "").replace(",", "."))
            else:
                liquido = None

            resultados.append({
                "mesAno": ano_mes,
                "valor_bruto": round(total_bruto, 2),
                "valor_liquido": liquido,
                "situacao": det.get("situacao"),
                "orgao_lotacao": det.get("orgaoServidorLotacao", {}).get("nome"),
                "orgao_codigo": det.get("orgaoServidorLotacao", {}).get("codigo"),
                "estado_exercicio": det.get("estadoExercicio", {}).get("sigla"),
                "tipo_servidor": det.get("tipoServidor"),
                "cargo": det.get("funcao", {}).get("descricaoFuncaoCargo"),
            })

    if not resultados:
        return {
            "ultimo_salario": None,
            "media": None,
            "meses": []
        }

    # ordena do mais recente para o mais antigo
    resultados.sort(key=lambda x: x["mesAno"], reverse=True)

    # calcula média do líquido
    liquidos = [r["valor_liquido"] for r in resultados if r["valor_liquido"]]
    media = sum(liquidos) / len(liquidos) if liquidos else None

    return {
        "ultimo_salario": resultados[0],
        "media_liquido": media,
        "meses": resultados
    }

# ==========================================================
# CONSULTA PRINCIPAL
# ==========================================================
def consultar_pessoa_federal(cpf):
    print(f"\n🔎 Consultando CPF {cpf}…")

    dados = get(f"{BASE}/pessoa-fisica", {"cpf": cpf})

    if not dados:
        return {
            "cpf": cpf,
            "nome": None,
            "is_servidor": None,
            "is_servidor_inativo": None,
            "is_pensionista" : None,
            "sancoes": {
                "sancionadoCEIS": None,
                "sancionadoCNEP": None,
                "sancionadoCEAF": None,
                "sancionadoCEPIM": None,
            },
            "raw": None,
        }

    sancoes = {
        "sancionadoCEIS": dados.get("sancionadoCEIS"),
        "sancionadoCNEP": dados.get("sancionadoCNEP"),
        "sancionadoCEAF": dados.get("sancionadoCEAF"),
        "sancionadoCEPIM": None,
    }

    beneficios = consultar_beneficios(cpf)

    remuneracao = consultar_remuneracao_servidor(cpf)

    return {
        "cpf": cpf,
        "nome": dados.get("nome"),
        "is_servidor": dados.get("servidor"),
        "is_servidor_inativo": dados.get("servidorInativo"),
        "is_pensionista" : dados.get("pensionistaOuRepresentanteLegal"),
        "beneficios": beneficios,
        "sancoes": sancoes,
        "remuneracao": remuneracao,     # ← ADICIONADO AQUI
        "raw": dados,
    }


