import requests,json


def calculator_irpf(salary: float, dependents: int = 0, others_deductions: float = 0, rule: str = "benefical") -> dict:
    url = "https://bff.idinheiro.com.br/api/calculator/result/irrf/"

    payload = {
        "value": salary,
        "numDependents": dependents,
        "otherDiscounts": others_deductions,
        "calcRule": rule
    }

    response = requests.post(url, json=payload, timeout=15)
    response.raise_for_status()

    dados = response.json()
    return dados