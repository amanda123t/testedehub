import requests
url = 'https://www.4devs.com.br/ferramentas_online.php'

def acessar_ferramentas(header_params: dict):
    response = requests.post(url, data=header_params)
    print("Status Code:", response.status_code)
    return response.text

def gerar_rg(pontuacao="S"):
    return acessar_ferramentas({
        "acao": "gerar_rg",
        "pontuacao": pontuacao,
    })

def gerar_cnh():
    return acessar_ferramentas({
        "acao": "gerar_cnh",
    })

def gerar_certidao(tipo_certidao= 'indiferente', pontuacao="N"):
    return acessar_ferramentas({
        "acao": "gerador_certidao",
        "tipo_certidao": tipo_certidao,
        "pontuacao": pontuacao,
    })

def gerar_cpf(pontuacao="S", estado = None):
    return acessar_ferramentas({
        "acao": "gerar_cpf",
        "pontuacao": pontuacao,
        "cpf_estado": estado,
    })

def gerar_cnpj(pontuacao="S"):
    return acessar_ferramentas({
        "acao": "gerar_cnpj",
        "pontuacao": pontuacao,
    })

def gerar_cep(estado: str = None, cidade: str = None, pontuacao="S"): #HTML
    return acessar_ferramentas({
        "acao": "gerar_cep",
        "estado": estado,
        "cidade": cidade,
        "pontuacao": pontuacao,
    })

def gerar_conta_bancaria(banco: str = None, estado: str = None):
    return acessar_ferramentas({
        "acao": "gerar_conta_bancaria",
        "banco": banco,
        "estado": estado,
    })

def gerar_pis(pontuacao="S"):
    return acessar_ferramentas({
        "acao": "gerar_pis",
        "pontuacao": pontuacao,
    })

def gerar_renavam():
    return acessar_ferramentas({
        "acao": "gerar_renavam",
    })


def gerar_placa_veiculos(pontuacao="S", estado: str = None):
    return acessar_ferramentas({
        "acao": "gerar_placa",
        "pontuacao": pontuacao,
        "estado": estado, 
    })

def validar_cpf(cpf: str):
    return acessar_ferramentas({
        "acao": "validar_cpf",
        "txt_cpf": cpf,
    })

def validar_cnpj(cnpj: str):
    return acessar_ferramentas({
        "acao": "validar_cnpj",
        "txt_cnpj": cnpj,
    })

def validar_cnh(cnh: str):
    return acessar_ferramentas({
        "acao": "validar_cnh",
        "txt_cnh": cnh,
    })

def validar_conta_bancaria(banco: str, agencia: str, conta: str):
    return acessar_ferramentas({
        "acao": "validar_conta_bancaria",
        "banco": banco,
        "agencia": agencia,
        "conta": conta,
    })

def validar_pis(pis: str):
    return acessar_ferramentas({
        "acao": "validar_pis",
        "txt_pis": pis,
    })

def validar_renavam(renavam: str):
    return acessar_ferramentas({
        "acao": "validar_renavam",
        "txt_renavam": renavam,
    })

def validar_rg(rg: str):
    return acessar_ferramentas({
        "acao": "validar_rg",
        "txt_rg": rg,
    })

def validar_titulo_eleitor(titulo: str):
    return acessar_ferramentas({
        "acao": "validar_titulo_eleitor",
        "txt_titulo_eleitor": titulo,
    })

def validar_certidoes(numero_certidao:str):
    return acessar_ferramentas({
        "acao": "validar_certidao",
        "txt_certidao": numero_certidao,
    })

def filtrar_lista_banco(nome_banco: str):
    return acessar_ferramentas({
        "acao": "filtrar_lista_banco",
        "txt_filtrar_banco": nome_banco,
    })

def informacoes_caracter(caracter: str):
    return acessar_ferramentas({
        "acao": "char_informacoes",
        "txt_caracter": caracter,
    })