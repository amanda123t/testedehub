import requests
import re
from difflib import SequenceMatcher
from unidecode import unidecode

BASE_FIPE = "https://parallelum.com.br/fipe/api/v1"

TIPOS_FIPE = ["carros", "motos", "caminhoes"]


# ===============================
# Helpers
# ===============================

def _norm(t: str):
    return unidecode(t).lower().strip()


def _similar(a: str, b: str):
    return SequenceMatcher(None, a, b).ratio()


def _extrair_cilindrada(modelo: str):
    m = re.search(r"(\d{2,4})", modelo)
    return m.group(1) if m else None


def _get(url):
    r = requests.get(url, timeout=15)
    r.raise_for_status()
    return r.json()


# ===============================
# Passo 1 — Encontrar marca
# ===============================

def _encontrar_marca(tipo: str, marca_usuario: str):
    marca_user_norm = _norm(marca_usuario)
    marcas = _get(f"{BASE_FIPE}/{tipo}/marcas")

    melhor = None
    melhor_score = 0

    for m in marcas:
        score = _similar(marca_user_norm, _norm(m["nome"]))
        if score > melhor_score:
            melhor_score = score
            melhor = m

    if melhor_score < 0.50:
        raise ValueError("Marca não encontrada")

    return melhor["codigo"], melhor["nome"], melhor_score


# ===============================
# Passo 2 — Encontrar modelo
# ===============================

def _encontrar_modelo(tipo: str, codigo_marca: str, modelo_usuario: str):
    modelo_user_norm = _norm(modelo_usuario)
    cilindrada = _extrair_cilindrada(modelo_user_norm)

    modelos = _get(
        f"{BASE_FIPE}/{tipo}/marcas/{codigo_marca}/modelos"
    )["modelos"]

    melhor = None
    melhor_score = 0

    for m in modelos:
        nome_norm = _norm(m["nome"])
        score = _similar(modelo_user_norm, nome_norm)

        if cilindrada and cilindrada in nome_norm:
            score += 0.15

        for p in modelo_user_norm.split():
            if p in nome_norm:
                score += 0.05

        if score > melhor_score:
            melhor_score = score
            melhor = m

    if melhor_score < 0.50:
        raise ValueError("Modelo não encontrado")

    return melhor["codigo"], melhor["nome"], melhor_score


# ===============================
# Passo 3 — Encontrar ano
# ===============================

def _encontrar_ano(tipo: str, codigo_marca: str, codigo_modelo: str, ano_usuario: int):
    anos = _get(
        f"{BASE_FIPE}/{tipo}/marcas/{codigo_marca}/modelos/{codigo_modelo}/anos"
    )

    ano_usuario = str(ano_usuario)

    for item in anos:
        if item["codigo"].startswith(ano_usuario):
            return item["codigo"], item["nome"]

    for item in anos:
        if ano_usuario in item["nome"]:
            return item["codigo"], item["nome"]

    if anos:
        anos_numericos = [(a, int(a["codigo"][:4])) for a in anos]
        mais_proximo = min(
            anos_numericos,
            key=lambda x: abs(x[1] - int(ano_usuario))
        )[0]
        return mais_proximo["codigo"], mais_proximo["nome"]

    raise ValueError("Ano não encontrado")


# ===============================
# Função interna por tipo
# ===============================

def _consultar_por_tipo(tipo: str, marca: str, modelo: str, ano: int):
    cod_marca, marca_found, score_marca = _encontrar_marca(tipo, marca)
    cod_modelo, modelo_found, score_modelo = _encontrar_modelo(tipo, cod_marca, modelo)
    cod_ano, ano_nome = _encontrar_ano(tipo, cod_marca, cod_modelo, ano)

    dados = _get(
        f"{BASE_FIPE}/{tipo}/marcas/{cod_marca}/modelos/{cod_modelo}/anos/{cod_ano}"
    )

    return {
        "entrada": {
            "marca": marca,
            "modelo": modelo,
            "ano": ano
        },
        "match": {
            "marca_encontrada": marca_found,
            "score_marca": round(score_marca, 3),
            "modelo_encontrado": modelo_found,
            "score_modelo": round(score_modelo, 3),
            "ano_codigo": cod_ano,
            "ano_nome": ano_nome,
            "tipo_fipe": tipo  # opcional, mas MUITO útil
        },
        "fipe": dados
    }



# ===============================
# Função principal com fallback
# ===============================

def consultar_fipe(marca: str, modelo: str, ano: int, tipo: str = "carros"):
    ordem = [tipo] + [t for t in TIPOS_FIPE if t != tipo]

    for t in ordem:
        try:
            return _consultar_por_tipo(t, marca, modelo, ano)
        except Exception:
            continue

    return None

