import requests


# NAO FUNCIONA CORRETAMENTE - API RECEITAWS TEM LIMITES MUITO RESTRITOS

def consultar_simples(cnpj):
    url = f"https://www.receitaws.com.br/v1/cnpj/{cnpj}"
    response = requests.get(url)
    print(f"Response: {response}")
    data = response.json()

    return {
        "cnpj": cnpj,
        "nome": data.get("nome"),
        "opcao_pelo_simples": data.get("opcao_pelo_simples"),
        "data_opcao_simples": data.get("data_opcao_simples"),
        "data_exclusao_simples": data.get("data_exclusao_simples"),
        "opcao_pelo_mei": data.get("opcao_pelo_mei")
    }