import requests

def consultar_dap(cpf: str):
    url = "https://smap14.mda.gov.br/extratodap/PesquisarDAP/CarregarExtratoDAP"

    payload = {
        "cpf": cpf,
        "numeroControleExterno": ""
    }

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    resp = requests.post(url, json=payload, headers=headers)

    if resp.status_code != 200:
        raise Exception(f"Erro HTTP {resp.status_code}: {resp.text}")

    return resp.json()


# === EXEMPLO ===
dados = consultar_dap("06712127106")
print(dados)
