import os
import time
import random
import requests
from bs4 import BeautifulSoup
from threading import Semaphore
from typing import Optional, Dict
from app.utils.logger import LoggerManager

log = LoggerManager(__name__)

# ================================================================
# SEMÁFORO GLOBAL
# ================================================================
API_PLACA_GLOBAL = Semaphore(int(os.getenv("API_PLACA_TRAVA", "2")))

# ================================================================
# CACHE EM MEMÓRIA
# ================================================================
_CACHE_PLACA: Dict[str, dict] = {}

def get_cached(key: str) -> Optional[dict]:
    return _CACHE_PLACA.get(key)

def set_cached(key: str, value: dict):
    _CACHE_PLACA[key] = value

# ================================================================
# FUNÇÃO GENÉRICA COM RETRY (SEM SUPABASE)
# ================================================================
def fetch_retry(
    method: str,
    url: str,
    *,
    params=None,
    json_body=None,
    headers=None,
    max_retries=6,
    timeout=12.0,
    chave_cache: str = None,
):
    """Executa GET/POST com retry e cache somente em memória."""

    rng = random.Random(int(str(hash(chave_cache))[-6:].replace("-", "1"))) if chave_cache else random.Random()

    for attempt in range(1, max_retries + 1):
        try:
            with API_PLACA_GLOBAL:
                time.sleep(0.3 + rng.uniform(0, 0.3))

                if method == "GET":
                    resp = requests.get(url, params=params, headers=headers, timeout=timeout)
                else:
                    resp = requests.post(url, json=json_body, headers=headers, timeout=timeout)

                status = resp.status_code

                # Sucesso
                if status == 200:
                    return resp  # Retorna a resposta original

                # 5xx → retry
                if 500 <= status < 600:
                    log.warning(f"⚠ {status} — retry em 3s (tentativa {attempt})")
                    time.sleep(3)
                    continue

                # 429 → rate limited
                if status == 429:
                    wait_s = float(resp.headers.get("Retry-After", 2))
                    log.warning(f"⚠ 429 — aguardando {wait_s}s")
                    time.sleep(wait_s)
                    continue

                # 4xx → erro permanente
                if status in (400, 401, 403, 404):
                    log.error(f"❌ HTTP {status} sem retry.")
                    return resp

                log.error(f"⚠ Erro inesperado HTTP {status}")
                return resp

        except Exception as e:
            if attempt < max_retries:
                log.error(f"⚠ Exceção {type(e).__name__}: {e} — retry 3s")
                time.sleep(3)
                continue
            else:
                log.error(f"❌ Exceção final: {e}")
                return None


# ================================================================
# ANYCAR (POST + GET)
# ================================================================
def consultar_placa_anycar(placa: str) -> dict:
    placa = placa.upper().replace("-", "")
    chave = f"anycar:{placa}"
    # 🔥 SE JÁ TEM CACHE, ACABOU
    cache = get_cached(chave)
    if isinstance(cache, dict):
        log.debug(f"✔ Anycar cache HIT direto para {placa}")
        return cache

    url = "https://api-v2.anycar.com.br/site/test-drive"

    # --- FIRST STEP: POST to get ID ---
    resp_post = fetch_retry(
        method="POST",
        url=url,
        json_body={"placa": placa},
        headers={"User-Agent": "Mozilla/5.0"},
        chave_cache=None,  # Apenas GET final é cacheável
    )

    if not resp_post:
        return {"erro": "Falha ao gerar ID Anycar"}

    try:
        resp_json = resp_post.json()
    except Exception:
        return {"erro": "Anycar POST não retornou JSON válido"}

    id_consulta = resp_json.get("id")
    if not id_consulta:
        return {"erro": "ID não retornado pela Anycar", "resposta": resp_json}

    # --- SECOND STEP: GET vehicle data ---
    resp_get = fetch_retry(
        method="GET",
        url=f"{url}/{id_consulta}",
        chave_cache=chave,
    )

    if not resp_get:
        return {"erro": "Falha no GET da Anycar", "placa": placa}

    try:
        dados = resp_get.json()
    except Exception:
        return {"erro": "JSON inválido no GET Anycar", "placa": placa}


    # Normalização padrão
    if isinstance(dados, dict) and "data" in dados:
        dados_final = dados["data"]
        for item_excluir in ['logo', 'status', 'encontrado']:
            if item_excluir in dados_final:
                dados_final.pop(item_excluir)
    else:
        dados_final = dados

    set_cached(chave, dados_final)
    return dados_final


# ================================================================
# ÔNIBUS BRASIL
# ================================================================
def consultar_placa_onibusbrasil(placa: str) -> dict:
    placa = placa.upper().replace("-", "")
    chave = f"onibus:{placa}"

    url = f"https://onibusbrasil.com/placas/1/{placa}"

    resp = fetch_retry(
        method="GET",
        url=url,
        chave_cache=chave,
    )

    if not resp:
        return {"erro": "Falha ao acessar Ônibus Brasil", "placa": placa}

    if resp.status_code != 200:
        return {"erro": f"Status {resp.status_code}", "placa": placa}

    soup = BeautifulSoup(resp.text, "html.parser")
    dados = {}

    # Título
    titulo = soup.find("h1", class_="text-center")
    if titulo:
        dados["placa"] = titulo.get_text(strip=True).replace("Placa ", "")

    # Informações cadastrais
    info_block = soup.find("h2", text="Informações Cadastrais do Veículo")
    if info_block:
        parent = info_block.find_parent("div")
        for strong in parent.find_all("strong"):
            label = strong.get_text(strip=True).replace(":", "")
            valor = strong.next_sibling.strip() if strong.next_sibling else None
            if valor:
                dados[label.lower()] = valor

    set_cached(chave, dados)
    return dados
