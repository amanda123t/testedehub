import os
from typing import List
import zipfile
from pathlib import Path
import fitz  # PyMuPDF
from shutil import rmtree
from app.utils.logger import LoggerManager
import hashlib

log = LoggerManager(__name__)  # logger do módulo (task)

EXTENSOES_SUPORTADAS = {".pdf",".png",".jpg",".jpeg",".jfif",".tif",".tiff",".bmp",".webp"}
IGNORED_NAMES = {"__MACOSX", ".DS_Store", "Thumbs.db"}
ARCHIVE_EXTS = {'.zip', '.rar', '.7z', '.tar', '.gz', '.bz2'}

def gerar_hash_arquivo(file_path: str) -> str:
    """
    Gera uma hash única e estável considerando:
      - bytes brutos do arquivo,
      - número de páginas,
      - bounding boxes das imagens,
      - metadados principais.
    """
    file_path = Path(file_path)
    hash_md5 = hashlib.md5()

    try:
        # 🔹 Base: bytes brutos (garante unicidade mesmo em PDFs-imagem)
        with open(file_path, "rb") as f:
            hash_md5.update(f.read())

        if file_path.suffix.lower() == ".pdf":
            doc = fitz.open(file_path)
            hash_md5.update(str(doc.page_count).encode())

            # 🔹 Acrescenta bounding boxes das imagens
            for page in doc:
                for img in page.get_images(full=True):
                    xref = img[0]
                    info = doc.extract_image(xref)
                    bbox = str(img[1:5])  # (x, y, w, h)
                    size = len(info["image"])
                    hash_md5.update(f"{bbox}-{size}".encode())

            # 🔹 Metadados (creation date, producer, etc.)
            meta = doc.metadata or {}
            meta_str = f"{meta.get('producer','')}-{meta.get('creationDate','')}-{meta.get('modDate','')}"
            hash_md5.update(meta_str.encode())

        return hash_md5.hexdigest()

    except Exception as e:
        print(f"Erro ao gerar hash: {e}")
        return None

def possui_arquivos(caminho: str | Path) -> bool:
    """
    Verifica se o caminho local contém arquivos válidos:
        - Se for PDF solto → True
        - Se for pasta e tiver ao menos 1 arquivo → True
        - Se for ZIP e tiver ao menos 1 arquivo dentro → True
        - Se for pasta ou ZIP e estiver vazio → False
    """
    caminho = Path(caminho)

    try:
        # 1) PDF solto
        if caminho.is_file() and caminho.suffix.lower() == ".pdf":
            return True

        # 2) Pasta
        if caminho.is_dir():
            for _, _, files in os.walk(caminho):
                if any(f not in IGNORED_NAMES for f in files):
                    return True
            return False

        # 3) ZIP
        if caminho.is_file() and caminho.suffix.lower() == ".zip":
            try:
                with zipfile.ZipFile(caminho, 'r') as zf:
                    for member in zf.infolist():
                        if not member.is_dir():
                            return True
                return False
            except zipfile.BadZipFile:
                return False

        # 4) Outros casos (não pdf/pasta/zip)
        return False

    except Exception as e:
        log.error(f"⚠ Erro ao verificar arquivos em {caminho}: {e}")
        return False

def listar_arquivos_validos(caminho_base: str) -> List[str]:
    arquivos: List[str] = []
    for raiz, _dirs, nomes in os.walk(caminho_base):
        for nome in nomes:
            if os.path.splitext(nome)[1].lower() in EXTENSOES_SUPORTADAS:
                arquivos.append(os.path.join(raiz, nome))
    return arquivos

def is_zip(path: str | Path) -> bool:
    return str(path).lower().endswith(".zip") and os.path.isfile(path)

def eh_pdf(path: str) -> bool:
    return Path(path).suffix.lower() == ".pdf"

def _safe_extract_zip(
    zf: zipfile.ZipFile,
    dest_dir: str | Path,
    *,
    max_total_bytes: int = 1_000_000_000,   # 1GB
    max_files: int = 20_000
) -> None:
    """
    Extrai um ZIP com proteção contra Zip Slip e zip-bomb.
    """
    dest_dir = Path(dest_dir).resolve()

    total_bytes = 0
    count_files = 0

    for member in zf.infolist():
        # ignora “lixo” comum
        name = member.filename
        if not name or any(part in IGNORED_NAMES for part in Path(name).parts):
            continue

        out_path = (dest_dir / name).resolve()

        # Zip Slip
        if not str(out_path).startswith(str(dest_dir)):
            raise RuntimeError(f"Zip Slip detectado: {name}")

        # Limites de segurança
        if not member.is_dir():
            total_bytes += member.file_size
            count_files += 1
            if total_bytes > max_total_bytes:
                raise RuntimeError("Zip muito grande (limite de bytes atingido).")
            if count_files > max_files:
                raise RuntimeError("Zip com arquivos demais (limite atingido).")

        # Extrai
        if member.is_dir():
            out_path.mkdir(parents=True, exist_ok=True)
        else:
            out_path.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(member) as src, open(out_path, "wb") as dst:
                dst.write(src.read())

def extract_archives_recursive(base_dir: str | Path,
                            max_depth: int = 5,
                            delete_archives: bool = True) -> list[str]:
    """ 
    Extrai .zip recursivamente dentro de `base_dir`.
    """
    base_dir = Path(base_dir)
    extracted_dirs: list[str] = []
    depth = 0

    while depth < max_depth:
        depth += 1
        found_any = False
        for root, _, files in os.walk(base_dir):
            for f in files:
                if f in IGNORED_NAMES:
                    continue
                file_path = Path(root) / f
                if not is_zip(file_path):
                    continue
                try:
                    target_dir = Path(root) / Path(f).stem
                    target_dir.mkdir(parents=True, exist_ok=True)
                    with zipfile.ZipFile(file_path, 'r') as zf:
                        _safe_extract_zip(zf, target_dir)
                    extracted_dirs.append(str(target_dir))
                    found_any = True
                    if delete_archives:
                        try:
                            os.remove(file_path)
                        except Exception:
                            pass
                except (zipfile.BadZipFile, RuntimeError) as e:
                    log.info(f"⚠ ZIP ignorado ({file_path}): {e}")
                except Exception as e:
                    log.error(f"⚠ Falha ao extrair '{file_path}': {e}")

        if not found_any:
            break

    if depth >= max_depth:
        log.error(f"⚠ Parando por max_depth={max_depth}. Pode haver zips muito aninhados.")
    return extracted_dirs

def contar_paginas(path: str) -> int:
    try:
        with fitz.open(path) as doc:
            # funciona para PDF e imagens multipágina (ex.: TIFF)
            return doc.page_count  # ou len(doc)
    except Exception:
        # se não der para abrir com fitz (ou for imagem simples), use 1
        return 1

def excluir_arquivo(arquivo):
    if os.path.exists(arquivo):
        os.remove(arquivo)
        log.info(f"🗑️ Arquivo {arquivo} foi excluído para reiniciar do zero.")

def excluir_pasta(local_proc: Path, out_dir: Path) -> None:
    """
    Remove com segurança a pasta local do processo (se existir),
    garantindo que está dentro de out_dir.
    """
    try:
        lp = Path(local_proc).resolve()
        od = Path(out_dir).resolve()
        # só apaga se lp estiver DENTRO de out_dir
        if od in lp.parents and lp.exists():
            log.info(f"🧹 Removendo pasta local antiga: {lp}")
            rmtree(lp, ignore_errors=True)
    except Exception as e:
        log.error(f"⚠ Não foi possível remover {local_proc}: {e}")

def has_archives(base_dir: str | Path) -> bool:
    base = Path(base_dir)
    for p in base.iterdir():
        if p.is_file() and p.suffix.lower() in ARCHIVE_EXTS:
            return True
    return False
