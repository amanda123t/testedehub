
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from time import sleep
import os
from pathlib import Path

class Navegador():
    def __init__(self, output_path: str = None, headless = True):
        options = Options()
        if headless:
            options.add_argument("--headless=new")
            options.add_argument("--window-size=1920,1080")
        else:
            options.add_argument("--start-maximized")

        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--disable-notifications")
        options.add_argument("--disable-infobars")
        options.add_argument("--disable-popup-blocking")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.page_load_strategy = "eager"

        # 1) caminho absoluto e pasta criada
        if not output_path:
            output_path = 'output'
        out_abs = str(Path(output_path).resolve())   # <- ABSOLUTO
        os.makedirs(out_abs, exist_ok=True)

        self.output_path = out_abs

        # 2) prefs + forçar download de PDF (sem viewer)
        download_prefs = {
            "download.default_directory": out_abs,
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "safebrowsing.enabled": True,
            "profile.managed_default_content_settings.images": 2,
            "plugins.always_open_pdf_externally": True,  # <- força baixar PDF
        }
        options.add_experimental_option("prefs", download_prefs)

        serviço = Service(ChromeDriverManager().install())
        self.erros = []
        self.navegador = webdriver.Chrome(service=serviço, options=options)

        # 3) CDP: garante que TUDO que for download vá para out_abs
        try:
            # Selenium 4 mantém execute_cdp_cmd para Page.setDownloadBehavior
            self.navegador.execute_cdp_cmd(
                "Page.setDownloadBehavior",
                {"behavior": "allow", "downloadPath": out_abs}
            )
        except Exception as e:
            print(f"⚠️ Falha ao aplicar Page.setDownloadBehavior: {e}")

    def limpar(self, xpath, time = 3):
        campo = WebDriverWait(self.navegador, time).until(
            EC.presence_of_element_located((By.XPATH, xpath))
        )
        try:
            campo.clear()
            return True
        except Exception:
            return False
        
    def escrever(self, xpath_campo, texto, time= 10):
        campo = WebDriverWait(self.navegador, time).until(EC.presence_of_element_located((By.XPATH, xpath_campo)))
        campo.send_keys(texto)

    def clicar(self,xpath,time=5):
        try:
            # Esperar até que o campo  esteja disponível
            campo = WebDriverWait(self.navegador, time).until(
                EC.element_to_be_clickable((By.XPATH, xpath))
            )
            #clicar
            campo.click()
            return True
        except Exception:
            return False
    
    def selecionar_arquivo_css(self, css_campo, arquivo_local, time = 10):
        # espera o input aparecer no DOM
        file_input = WebDriverWait(self.navegador, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, css_campo))
        )
        # se estiver invisível/oculto (display:none), torna visível para permitir o send_keys
        try:
            self.navegador.execute_script(
                "arguments[0].style.display='block';"
                "arguments[0].style.visibility='visible';"
                "arguments[0].removeAttribute('hidden');", 
                file_input
            )
        except Exception:
            pass
        sleep(0.1)

        # caminho absoluto e no formato esperado pelo Chrome
        caminho = str(Path(arquivo_local).resolve())
        # envia o arquivo (isso 'anexa' no formulário)
        file_input.send_keys(caminho)
        print(f"📎 Arquivo enviado para o input: {caminho}")


    def aguardar_campo(self, xpath, time=5):
        # Resolver o aviso se aparecer após clicar no processo
        try:
            WebDriverWait(self.navegador, time).until(EC.element_to_be_clickable((By.XPATH, xpath)))
            print("Campo detectado.")
            return True
        except Exception:
            print("Campo não encontrado.")
            return False

    def rolar_ate_elemento(self, xpath, time = 20):
        checkbox = WebDriverWait(self.navegador, time).until(
                EC.presence_of_element_located((By.XPATH, xpath))
            )

        # 🔄 Rola até o elemento
        self.navegador.execute_script("arguments[0].scrollIntoView({block: 'center'});", checkbox)
        sleep(0.5)

    def tirar_print_tela(self, nome_arquivo = 'print_de_tela.png', downloads_path= None):
        if not downloads_path:
            if self.output_path:
                downloads_path = self.output_path
            else:
                downloads_path = "output"
                os.makedirs(downloads_path, exist_ok=True)
                self.output_path = downloads_path
        caminho_completo = f"{downloads_path}/{nome_arquivo}"
        self.navegador.save_screenshot(caminho_completo)
        print(f"Print da tela salvo em: {caminho_completo}")

    def fechar_aba(self):
        guias_atuais = self.navegador.window_handles

        try:
            # Tenta fechar a aba atual se a sessão ainda estiver ativa
            if self.navegador.session_id:
                if len(guias_atuais) > 1:
                    try:
                        self.navegador.close()
                        print("✅ Aba atual fechada com sucesso.")
                    except Exception as e:
                        print(f"⚠️ Erro ao tentar fechar a aba atual: {e}")
                else:
                    print("⚠️ Nenhuma aba para fechar.")
            else:
                print("⚠️ Sessão do navegador já encerrada. Não é possível fechar a aba.")

            # Tenta voltar para a aba principal se ela ainda existir
            if self.navegador.session_id:
                if guias_atuais:
                    try:
                        self.navegador.switch_to.window(guias_atuais[0])
                        print("✅ Retornou para a aba principal com sucesso.")
                    except Exception as e:
                        print(f"⚠️ Erro ao alternar para a aba principal: {e}")
                else:
                    print("⚠️ Nenhuma aba restante para alternar.")
            else:
                print("⚠️ Sessão do navegador já encerrada. Não foi possível retornar.")
        except Exception as e:
            print(f"❌ Erro inesperado durante o fechamento ou alternância de aba: {e}")

    def alterar_zoom(self, zoom):
        self.navegador.execute_script(f"document.body.style.zoom='{zoom}'")
        sleep(0.5)
        print(f'Zoom alterado para {zoom}')
    
    def subir_inicio_pagina(self):
        sleep(0.5)
        self.navegador.execute_script("window.scrollTo(0, 0);") 
        sleep(0.5)

    def descer_fim_pagina(self):
        sleep(0.5)
        self.navegador.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        sleep(0.5)

    def fechar_navegador(self):
        self.navegador.quit()
        sleep(0.5)
        print("Navegador fechado com sucesso!")

    def capturar_dado(self, xpaths, chave):
        """
        Tenta capturar o dado usando uma lista de XPaths.
        :param xpaths: Lista de XPaths para tentar.
        :param chave: Nome do campo para log de erros.
        :return: Texto do elemento encontrado ou None se todos falharem.
        """
        for xpath in xpaths:
            try:
                elemento = self.navegador.find_element(By.XPATH, xpath)
                texto = elemento.text.strip()
                if texto:
                    print(f"Dado capturado para {chave}: {texto}")
                    return texto
            except Exception as e:
                print(f"Erro ao capturar {chave} com XPath {xpath}")
                continue  # Continua tentando os próximos XPaths

        self.erros.append(f"Erro ao capturar {chave}.")
        return None
    
    def retornar_guia_principal(self):
        guias_atuais = self.navegador.window_handles
        try:
            self.navegador.switch_to.window(guias_atuais[0])
            sleep(0.5)
            print("✅ Retornou para a aba principal com sucesso.")
        except Exception as e:
            print(f"⚠️ Erro ao alternar para a aba principal: {e}")

    def alterar_ultima_guia_aberta(self):
        guias_atuais = self.navegador.window_handles
        if len(guias_atuais) > 1:
            self.navegador.switch_to.window(guias_atuais[1])  # Última aba aberta
            sleep(0.5)
            print("Alterado para ultima guia aberta com sucesso!")


