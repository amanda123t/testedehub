from playwright.sync_api import sync_playwright, TimeoutError
from pathlib import Path
import os
from time import sleep


class Navegador:
    def __init__(self, output_path: str = None, headless=True):
        # Caminho de saída
        if not output_path:
            output_path = "output"

        out_abs = str(Path(output_path).resolve())
        os.makedirs(out_abs, exist_ok=True)
        self.output_path = out_abs

        # Playwright
        self._pw = sync_playwright().start()
        self.browser = self._pw.chromium.launch(headless=headless)
        self.navegador = self.browser.new_page(accept_downloads=True)

        # lista de erros (compatível)
        self.erros = []


    # =====================================================================
    #  FUNÇÕES PRINCIPAIS (MESMOS NOMES QUE NO SELENIUM)
    # =====================================================================

    def limpar(self, xpath, time=3):
        """Limpa campo usando Playwright."""
        timeout = time * 1000
        try:
            campo = self.navegador.locator(xpath)
            campo.wait_for(timeout=timeout)
            campo.fill("")  # esvazia
            return True
        except TimeoutError:
            return False


    def escrever(self, xpath_campo, texto, time=10):
        """Escreve texto em um campo."""
        timeout = time * 1000
        campo = self.navegador.locator(xpath_campo)
        campo.wait_for(timeout=timeout)
        campo.fill(texto)


    def clicar(self, xpath, time=5):
        """Clica em elemento aguardando até o timeout."""
        timeout = time * 1000
        try:
            self.navegador.click(xpath, timeout=timeout)
            return True
        except TimeoutError:
            return False


    def selecionar_arquivo_css(self, css_campo, arquivo_local, time=10):
        """Seleciona arquivo sem hacks; Playwright aceita direto."""
        timeout = time * 1000
        try:
            self.navegador.set_input_files(css_campo, arquivo_local, timeout=timeout)
            print(f"📎 Arquivo enviado para input: {arquivo_local}")
        except TimeoutError:
            print("❌ Timeout ao enviar arquivo.")
            raise


    def aguardar_campo(self, xpath, time=5):
        """Espera um elemento existir e estar pronto para clique."""
        timeout = time * 1000
        try:
            self.navegador.locator(xpath).wait_for(timeout=timeout)
            print("Campo detectado.")
            return True
        except TimeoutError:
            print("Campo não encontrado.")
            return False


    def rolar_ate_elemento(self, xpath, time=20):
        """Scroll até elemento."""
        timeout = time * 1000
        try:
            elemento = self.navegador.locator(xpath)
            elemento.wait_for(timeout=timeout)
            elemento.scroll_into_view_if_needed()
            sleep(0.3)
        except TimeoutError:
            print("❌ Timeout ao rolar até elemento.")


    def tirar_print_tela(self, nome_arquivo="print_de_tela.png", downloads_path=None):
        """Screenshot da tela."""
        if not downloads_path:
            downloads_path = self.output_path

        caminho = os.path.join(downloads_path, nome_arquivo)
        self.navegador.screenshot(path=caminho)
        print(f"🖼️ Print salvo em: {caminho}")


    # =====================================================================
    # ABA / JANELA — comportamentos equivalentes ao Selenium
    # =====================================================================

    def fechar_aba(self):
        """Fecha apenas a aba atual."""
        try:
            self.navegador.close()
            print("Aba fechada.")
        except Exception as e:
            print("Erro ao fechar aba:", e)


    def retornar_guia_principal(self):
        """No Playwright, usa sempre a mesma page, então mantém compatibilidade."""
        print("Playwright usa aba única; retornar_guia_principal é no-op.")


    def alterar_ultima_guia_aberta(self):
        """Compatibilidade com Selenium; Playwright não precisa disso."""
        print("Playwright não usa múltiplas abas automaticamente.")


    # =====================================================================
    # ZOOM, SCROLL, FECHAR NAVEGADOR
    # =====================================================================

    def alterar_zoom(self, zoom):
        self.navegador.evaluate(f"document.body.style.zoom='{zoom}'")
        print(f"Zoom alterado para {zoom}")


    def subir_inicio_pagina(self):
        self.navegador.evaluate("window.scrollTo(0,0)")
        sleep(0.2)


    def descer_fim_pagina(self):
        self.navegador.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        sleep(0.2)


    def fechar_navegador(self):
        self.browser.close()
        self._pw.stop()
        print("Navegador fechado com sucesso!")


    # =====================================================================
    # CAPTURAR DADO — compatível com sua lógica
    # =====================================================================

    def capturar_dado(self, xpaths, chave):
        """Tenta capturar texto usando lista de XPaths."""
        for xpath in xpaths:
            try:
                elemento = self.navegador.locator(xpath)
                texto = elemento.inner_text(timeout=2000).strip()
                if texto:
                    print(f"Dado capturado para {chave}: {texto}")
                    return texto
            except:
                continue

        self.erros.append(f"Erro ao capturar {chave}.")
        return None
