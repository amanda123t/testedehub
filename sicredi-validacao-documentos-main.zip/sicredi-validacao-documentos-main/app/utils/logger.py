import logging
import os
import sys
from datetime import datetime

class LoggerManager:
    """
    Logger padronizado e simples para todo o projeto.

    Variáveis de ambiente:
        LOG_DETAIL=true|false (default: false)
            - true  => console em DEBUG (logs detalhados)
            - false => console em INFO  (logs simples) e SILENCIA libs no console
        LOG_SAVE=true|false (default: false)
            - true  => salva em LOG_DIR/app.log (sempre sobrescrevendo) e SEMPRE completo (DEBUG)
            - false => não salva em arquivo
        LOG_DIR=./logs (default)
            - pasta onde o app.log será salvo quando LOG_SAVE=true
    """
    _configured = False

    def __init__(self, name: str = "app"):
        if not LoggerManager._configured:
            self._setup_root_logger()
            LoggerManager._configured = True
        self.logger = logging.getLogger(name)

    # ---------- uso direto ----------
    def info(self, msg: str, *args, **kwargs):
        self.logger.info(msg, *args, **kwargs)

    def debug(self, msg: str, *args, **kwargs):
        self.logger.debug(msg, *args, **kwargs)

    def warning(self, msg: str, *args, **kwargs):
        self.logger.warning(msg, *args, **kwargs)

    def error(self, msg: str, *args, **kwargs):
        # por padrão, inclui traceback se houver exceção ativa
        if "exc_info" not in kwargs:
            kwargs["exc_info"] = True
        self.logger.error(msg, *args, **kwargs)

    def critical(self, msg: str, *args, **kwargs):
        if "exc_info" not in kwargs:
            kwargs["exc_info"] = True
        self.logger.critical(msg, *args, **kwargs)

    @classmethod
    def get_logger(cls, name: str = "app"):
        return cls(name).logger

    # ---------- setup interno ----------
    @staticmethod
    def _parse_bool(value: str, default: bool = False) -> bool:
        if value is None:
            return default
        return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}

    def _setup_root_logger(self):
        log_detail = self._parse_bool(os.getenv("LOG_DETAIL"), default=False)
        log_save   = self._parse_bool(os.getenv("LOG_SAVE"),   default=False)
        log_dir    = os.getenv("LOG_DIR", "./logs")

        # root aceita tudo; os handlers filtram
        root = logging.getLogger()
        root.setLevel(logging.DEBUG)

        # remove handlers pré-existentes (evita duplicar saídas quando recarrega)
        for h in list(root.handlers):
            root.removeHandler(h)

        # formatos: ambos com %(name)s para mostrar o módulo/origem
        fmt_console = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"
        fmt_file    = "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"
        datefmt     = "%Y-%m-%d %H:%M:%S"

        # filtro para silenciar libs barulhentas no CONSOLE quando não-detalhado
        class _SilenceNoisyLibs(logging.Filter):
            NOISY = (
                "urllib3", "hpack", "httpcore", "azure", "azure.core",
                "msal", "requests", "openai", "botocore", "s3transfer",
                "filelock", "Kestra"
            )
            def filter(self, record: logging.LogRecord) -> bool:
                # se detalhado, deixa tudo
                if log_detail:
                    return True
                # em modo simples, só deixa WARNING+ dessas libs
                name = record.name or ""
                if any(name == lib or name.startswith(lib + ".") for lib in self.NOISY):
                    return record.levelno >= logging.WARNING
                return True

        silence_filter = _SilenceNoisyLibs()

        # 1) Console handler
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.DEBUG if log_detail else logging.INFO)
        ch.setFormatter(logging.Formatter(fmt_console, datefmt=datefmt))
        ch.addFilter(silence_filter)
        root.addHandler(ch)

        # 2) File handler (opcional)
        if log_save:
            os.makedirs(log_dir, exist_ok=True)
            log_path = os.path.join(log_dir, "app.log")
            fh = logging.FileHandler(log_path, mode="w", encoding="utf-8", delay=False)
            fh.setLevel(logging.DEBUG)
            fh.setFormatter(logging.Formatter(fmt_file, datefmt=datefmt))
            fh.addFilter(silence_filter)   # <<=== aplicar o mesmo filtro aqui!
            root.addHandler(fh)

            root.info(f"🟢 Logger inicializado | detalhe={log_detail} | salvar={log_save} | arquivo={log_path}")
        else:
            root.info(f"🟢 Logger inicializado | detalhe={log_detail} | salvar={log_save} | sem arquivo")

        # Encaminha warnings do módulo 'warnings' para o logging (útil pra rastrear deprecations)
        logging.captureWarnings(True)
