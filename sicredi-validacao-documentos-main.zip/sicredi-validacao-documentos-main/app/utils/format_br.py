# app/validators/mixins/formatacao.py
from __future__ import annotations
import re
from datetime import datetime, date
from app.utils.helpers import normalize  # você já usa esse helper

"""
Funções de formatação de texto, valores e datas (pt-BR).
"""
# --- FORMATAÇÕES CPF / CNPJ ---
def digits(s: str | None) -> str:
    return re.sub(r"\D", "", s or "")

def formatar_cnpj(cnpj: str | None) -> str:
    '''
    Formata um CNPJ para o padrão 00.000.000/0000-00.
    Retorna "SEM CNPJ" se não tiver 14 dígitos válidos.
    '''
    numeros = re.sub(r"\D", "", cnpj or "")
    if len(numeros) == 14:
        return f"{numeros[0:2]}.{numeros[2:5]}.{numeros[5:8]}/{numeros[8:12]}-{numeros[12:14]}"
    return "SEM CNPJ"


# --- FORMATAÇÕES VALORES R$ ---

def converter_valor_para_float(valor) -> float | None:
    """
    Converte strings pt-BR/en-US para float de modo robusto.
    Exemplos suportados:
        "1.302,00" -> 1302.00
        "3,610.60" -> 3610.60
        "2473,33"  -> 2473.33
        "5158.00"  -> 5158.00
    Retorna None se não conseguir converter.
    """
    if valor is None:
        return None
    s = str(valor).strip()
    if not s:
        return None

    # remove símbolos de moeda e espaços
    s = re.sub(r"[^\d.,\-]", "", s)

    # caso tenha os dois separadores, decide pelo ÚLTIMO como decimal
    if "," in s and "." in s:
        last_comma = s.rfind(",")
        last_dot   = s.rfind(".")
        if last_comma > last_dot:
            # vírgula é decimal; ponto é milhar
            s = s.replace(".", "")
            s = s.replace(",", ".")
        else:
            # ponto é decimal; vírgula é milhar
            s = s.replace(",", "")
            # ponto já é decimal
    elif "," in s:
        # só vírgula presente -> decimal se 1-2 dígitos no fim
        partes = s.rsplit(",", 1)
        if len(partes[-1]) in (1, 2):
            s = partes[0].replace(",", "") + "." + partes[1]
        else:
            # tudo vírgula de milhar
            s = s.replace(",", "")
    elif "." in s:
        # só ponto presente -> decimal se 1-2 dígitos no fim
        partes = s.rsplit(".", 1)
        if len(partes[-1]) in (1, 2):
            s = partes[0].replace(".", "") + "." + partes[1]
        else:
            s = s.replace(".", "")

    try:
        return float(s)
    except Exception:
        return None

def formatar_moeda_br(valor: float | None) -> str:
    """Formata 1234.5 -> 'R$ 1.234,50'."""
    if valor is None:
        return "0,00"
    txt = f"{valor:,.2f}"
    # primeiro vírgulas por placeholder
    return "R$ " + txt.replace(",", "§").replace(".", ",").replace("§", ".")

def formatar_valor(valor: float) -> str:
    return f"{valor:,.2f}".replace(",", "v").replace(".", ",").replace("v", ".")

# --- FORMATAÇÕES DATAS XX/XX/XXXX ---

def formatar_data_br(texto: str | None) -> datetime | None:
    s = (texto or '').strip()
    if not s:
        return None

    # 1) DD/MM/AAAA [HH:MM[:SS]]
    m = re.fullmatch(r'\s*(\d{1,2})/(\d{1,2})/(\d{2,4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?\s*', s)
    if m:
        dd, mm, aa, hh, mi, ss = m.groups()
        dd, mm, aa = int(dd), int(mm), int(aa)
        if aa < 100: aa += 2000
        hh, mi, ss = int(hh or 0), int(mi or 0), int(ss or 0)
        try:
            return datetime(aa, mm, dd, hh, mi, ss)
        except ValueError:
            return None

    # normaliza para tratar nomes/abreviações de mês sem acento/caixa
    s_norm = normalize(s)

    # 2) MM/AAAA ou MM/AA (aceita "/" ou "-")
    m = re.fullmatch(r'\s*(\d{1,2})\s*[/\-]\s*(\d{2,4})\s*', s_norm)
    if m:
        mm, aa = map(int, m.groups())
        if 1 <= mm <= 12:
            if aa < 100: aa += 2000
            try:
                return datetime(aa, mm, 1)
            except ValueError:
                return None

    # 3) AJUSTADO: mês por extenso com espaço, "/" OU "-" + ano (2 a 4 dígitos)
    #    Exemplos: "marco 2022", "agosto-2025", "fevereiro/24"
    m = re.fullmatch(r'\s*([a-z]+)\s*[/\-\s]+\s*(\d{2,4})\s*', s_norm)
    if m:
        nome, aa = m.groups()
        meses = {
            'janeiro':1,'fevereiro':2,'marco':3,'abril':4,'maio':5,'junho':6,
            'julho':7,'agosto':8,'setembro':9,'outubro':10,'novembro':11,'dezembro':12
        }
        if nome in meses:
            aa = int(aa)
            if aa < 100: aa += 2000
            try:
                return datetime(int(aa), meses[nome], 1)
            except ValueError:
                return None

    # 4) Abreviações: "ago/24" | "ago-2024" | "jan/2025"
    m = re.fullmatch(r'\s*([a-z]{2,4})\s*[/\-]\s*(\d{2,4})\s*', s_norm)
    if m:
        abrev, aa = m.groups()
        abr = {'jan':1,'fev':2,'mar':3,'abr':4,'mai':5,'jun':6,'jul':7,'ago':8,'set':9,'out':10,'nov':11,'dez':12}
        if abrev in abr:
            aa = int(aa)
            if aa < 100: aa += 2000
            try:
                return datetime(aa, abr[abrev], 1)
            except ValueError:
                return None

    return None

def formatar_data_texto(dt: datetime | None) -> str:
    '''
    Converte um objeto datetime em texto no formato DD/MM/AAAA.
    Retorna string vazia se dt for None.
    '''
    return dt.strftime("%d/%m/%Y") if dt else ""

def obter_ano_mes_atual() -> tuple[int, int]:
    '''
    Retorna o ano e mês atuais com base na data do dia.
    '''
    hoje = datetime.today()
    return hoje.year, hoje.month

def extrair_mes_ano(d: date) -> str:
    '''
    Recebe date/datetime e retorna "MM/AAAA".
    Ex.: datetime(2025, 5, 5) -> "05/2025"
    '''
    return f"{d.month:02d}/{d.year}"

def mes_anterior(data: datetime) -> datetime:
    """
    Retorna a data correspondente ao mês anterior,
    sempre com o dia fixado em 1.

    Args:
        data (datetime): Data base.

    Returns:
        datetime: Data ajustada para o primeiro dia do mês anterior.
    """
    ano, mes = data.year, data.month - 1
    if mes == 0:  # Caso janeiro -> volta para dezembro do ano anterior
        mes, ano = 12, ano - 1
    return data.replace(year=ano, month=mes, day=1)  

def formatar_anos(anos: list[str]) -> str:
    """
    Formata anos em PT-BR:
    []                        -> ""
    ["2023"]                  -> "2023"
    ["2023","2024"]           -> "2023 e 2024"
    ["2022","2023","2024"]    -> "2022, 2023 e 2024"
    """
    if not anos:
        return ""
    anos = [str(a).strip() for a in anos if a is not None and str(a).strip()]
    if not anos:
        return ""
    if len(anos) == 1:
        return anos[0]
    if len(anos) == 2:
        return f"{anos[0]} e {anos[1]}"
    return " e ".join([", ".join(anos[:-1]), anos[-1]])
    
def calcular_meses_entre(ano1: int, mes1: int, ano2: int, mes2: int) -> int:
    '''
    Calcula a diferença em meses entre duas competências.
    Exemplo:
        (2025, 8) e (2025, 6) -> 2
    '''
    return (ano1 - ano2) * 12 + (mes1 - mes2)