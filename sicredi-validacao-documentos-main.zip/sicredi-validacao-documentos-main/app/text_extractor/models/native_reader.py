from __future__ import annotations
from typing import List, Optional
import fitz
from app.text_extractor.base.base_extractor import BaseExtractor
from app.text_extractor.base.template_result import TemplateResult

#GRATUITO

class PDFTextExtractor(BaseExtractor):
    """
    Extrai texto nativo de PDFs (sem OCR).
    Usa o método get_text() do PyMuPDF.
    """

    def extract(self, pdf_path: str, page_indices: Optional[List[int]] = None) -> List[str]:
        pages: List[str] = []
        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices if page_indices else list(range(doc.page_count))
                for i in idxs:
                    try:
                        text = (doc.load_page(i).get_text() or "").strip()
                        pages.append(self._clean_text_post(text))
                    except Exception as e:
                        self.log.error(f"Erro ao extrair texto da página {i+1}: {e}")
                        pages.append("")
        except Exception as e:
            self.log.error(f"Erro ao abrir PDF '{pdf_path}': {e}")
        return TemplateResult(
            pages=pages,
            methods=["pdf_text"] * len(pages),
            qualities=[self.score_text_quality(p) for p in pages],
            errors=[None] * len(pages),
            text="\n".join(pages),
            meta={"total_pages": len(pages), "ocr_count": 0, "pdf_text_count": len(pages)}
        )

    def extract_with_blocks(self, pdf_path: str, page_indices: Optional[List[int]] = None) -> TemplateResult:
        """
        Extrai texto nativo de PDFs tabulares com base em coordenadas (x, y).
        Agrupa blocos horizontais (linhas) e funde blocos verticais (colunas quebradas).
        Ideal para tabelas IRPF, holerites e demonstrativos.
        """
        pages: List[str] = []
        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))
                for i in idxs:
                    try:
                        self.log.debug(f"Extraindo texto tabular da página {i+1} de '{pdf_path}'")
                        page = doc.load_page(i)
                        blocks = page.get_text("blocks")
                        blocks = sorted(blocks, key=lambda b: (b[1], b[0]))  # ordena topo→baixo, esq→dir

                        # === etapa 1: fundir verticalmente cabeçalhos na mesma coluna ===
                        fused = []
                        tol_y = 10  # tolerância vertical p/ fundir blocos empilhados
                        last_x, last_y, buf = None, None, []
                        for (x0, y0, x1, y1, text, *_rest) in blocks:
                            text = text.strip()
                            if not text:
                                continue
                            if last_x is not None and abs(x0 - last_x) < 15 and (0 < y0 - last_y < tol_y):
                                # está quase na mesma coluna e logo abaixo → junta verticalmente
                                buf[-1] = (x0, y0, x1, y1, buf[-1][4] + " " + text)
                            else:
                                buf.append((x0, y0, x1, y1, text))
                            last_x, last_y = x0, y0
                        fused = buf

                        # === etapa 2: agrupar horizontalmente (linhas) ===
                        linhas, linha_atual, cur_y = [], [], None
                        tol_y_line = 10
                        for (x0, y0, x1, y1, text) in fused:
                            if cur_y is None or abs(y0 - cur_y) < tol_y_line:
                                linha_atual.append((x0, text))
                            else:
                                linha_atual.sort(key=lambda b: b[0])
                                linhas.append([t for _, t in linha_atual])
                                linha_atual = [(x0, text)]
                            cur_y = y0
                        if linha_atual:
                            linha_atual.sort(key=lambda b: b[0])
                            linhas.append([t for _, t in linha_atual])

                        # === etapa 3: gerar saída ===
                        linhas_formatadas = [" | ".join(l) for l in linhas]
                        text_page = "\n".join(linhas_formatadas)
                        pages.append(self._clean_text_post(text_page))
                        self.log.debug(f"Página {i+1} extraída com {len(linhas)} linhas.")
                        print(f"Página {i+1} extraída com {len(linhas)} linhas.")
                    except Exception as e:
                        self.log.error(f"Erro ao extrair texto por blocks da página {i+1}: {e}")
                        print(f"Erro ao extrair texto por blocks da página {i+1}: {e}")
                        pages.append("")

        except Exception as e:
            self.log.error(f"Erro ao abrir PDF '{pdf_path}' com blocks: {e}")

        return TemplateResult(
            pages=pages,
            methods=["pdf_blocks_tabular_v2"] * len(pages),
            qualities=[self.score_text_quality(p) for p in pages],
            errors=[None] * len(pages),
            text="\n".join(pages),
            meta={"total_pages": len(pages), "method": "blocks_tabular_v2"},
        )

