from __future__ import annotations
from typing import List, Optional
from io import BytesIO
import time, random, fitz, os
from azure.core.credentials import AzureKeyCredential
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.exceptions import ServiceRequestError, HttpResponseError
from ssl import SSLError
from threading import Semaphore
from app.text_extractor.base.base_extractor import BaseExtractor
from app.text_extractor.base.template_result import TemplateResult
import hashlib

AZURE_SEMAPHORE = Semaphore(int(os.getenv("MAX_AZURE_TRAVA", "8")))
PAGE_CACHE = {}  # cache global simples de páginas processadas

class AzureOCRExtractor(BaseExtractor):
    """
    Extrai texto de PDFs ou imagens usando o OCR do Azure Form Recognizer.
    """

    def __init__(self):
        super().__init__()
        endpoint = os.getenv("AZURE_ENDPOINT", "")
        key = os.getenv("AZURE_KEY", "")
        self.client = DocumentAnalysisClient(endpoint, AzureKeyCredential(key))

    def _hash_page(self, page: fitz.Page, dpi: int = 150) -> str:
        """Calcula hash estável da imagem rasterizada de uma página PDF."""
        mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        return hashlib.sha256(pix.samples).hexdigest()
        
    def _analyze_png_with_retry(self, png_bytes: bytes, max_attempts: int = 3):
        attempt = 1
        while True:
            try:
                with AZURE_SEMAPHORE:
                    poller = self.client.begin_analyze_document("prebuilt-read", document=BytesIO(png_bytes))
                    # Segundo modelo da azure disponível: prebuilt-layout | 
                    # CUIDADO !!!!! 
                    # Modelo prebuilt-layout custa 10 a 15x mais caro do que o read, só trocar se tiver certeza.
                    # CUIDADO !!!!! 
                    # poller = self.client.begin_analyze_document('prebuilt-layout', document=BytesIO(png_bytes))
                    return poller.result()

            except HttpResponseError as e:
                msg = str(getattr(e, "message", e))
                inner_code = getattr(getattr(e, "error", None), "code", "")
                # 🚫 Se for erro de dimensão inválida -> não retry, apenas propaga
                if "InvalidContentDimensions" in msg or "InvalidContentDimensions" in inner_code:
                    self.log.error(f"[skip retry] Erro de dimensão inválida, tentando próximo DPI...")
                    raise e  # <-- deixa o loop de DPI lidar com isso

                # Erros temporários continuam com retry
                if attempt >= max_attempts:
                    raise
                retry_after = getattr(getattr(e, "response", None), "headers", {}).get("Retry-After", None)
                sleep_s = float(retry_after) if retry_after else min(6.0, 1.5 * (2 ** (attempt - 1))) * (1 + 0.2 * random.random())
                self.log.error(f"[retry] tentativa {attempt}/{max_attempts} falhou: {msg}. Tentando novamente em {sleep_s:.1f}s")
                time.sleep(sleep_s)
                attempt += 1

            except (ServiceRequestError, SSLError, ConnectionError, TimeoutError) as e:
                if attempt >= max_attempts:
                    raise
                sleep_s = min(6.0, 1.5 * (2 ** (attempt - 1))) * (1 + 0.2 * random.random())
                self.log.error(f"[retry] tentativa {attempt}/{max_attempts} falhou (rede): {e}. Tentando novamente em {sleep_s:.1f}s")
                time.sleep(sleep_s)
                attempt += 1

    def extract(self, pdf_path: str, page_indices: Optional[List[int]] = None) -> List[str]:
        dpi_trials = [300, 240, 200, 150]
        pages: List[str] = []
        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices if page_indices else list(range(doc.page_count))
                for idx in idxs:
                    text = ""
                    for dpi in dpi_trials:
                        try:
                            page = doc.load_page(idx)
                            page_hash = self._hash_page(page)
                    
                            # Verifica se já existe no cache
                            if page_hash in PAGE_CACHE:
                                self.log.debug(f"♻️ Página {idx+1} reaproveitada do cache (hash={page_hash[:8]})")
                                texto_final = PAGE_CACHE[page_hash]
                                pages.append(texto_final)
                                continue
                            mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)
                            pix = page.get_pixmap(matrix=mat, alpha=False)
                            with BytesIO() as buf:
                                pix.pil_save(buf, format="png")
                                result = self._analyze_png_with_retry(buf.getvalue())
                            if result and result.pages and result.pages[0].lines:
                                text = "\n".join(l.content for l in result.pages[0].lines)
                                PAGE_CACHE[page_hash] = text
                            break
                        except Exception as e:
                            continue
                    pages.append(self._clean_text_post(text) if text else "")
        except Exception as e:
            self.log.error(f"Erro no OCR Azure para '{pdf_path}': {e}")
        return TemplateResult(
            pages=pages,
            methods=["ocr"] * len(pages),
            qualities=[self.score_text_quality(p) for p in pages],
            errors=[None] * len(pages),
            text="\n".join(pages),
            meta={"total_pages": len(pages), "ocr_count": len(pages), "pdf_text_count": 0}
        )
    
    def extract_with_blocks(self, pdf_path: str, page_indices: Optional[List[int]] = None) -> TemplateResult:
        pages = []
        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))
                for idx in idxs:
                    page = doc.load_page(idx)
                    page_hash = self._hash_page(page)
                    
                    # Verifica se já existe no cache
                    if page_hash in PAGE_CACHE:
                        self.log.debug(f"♻️ Página {idx+1} reaproveitada do cache (hash={page_hash[:8]})")
                        texto_final = PAGE_CACHE[page_hash]
                        pages.append(texto_final)
                        continue
                    
                    # Se não está no cache → roda OCR normalmente
                    mat = fitz.Matrix(3, 3)
                    pix = page.get_pixmap(matrix=mat, alpha=False)
                    with BytesIO() as buf:
                        pix.pil_save(buf, format="png")
                        result = self._analyze_png_with_retry(buf.getvalue())

                    # Reorganiza blocos normalmente...
                    lines = []
                    for line in result.pages[0].lines:
                        y = sum(p.y for p in line.polygon) / 4
                        x = sum(p.x for p in line.polygon) / 4
                        lines.append((x, y, line.content.strip()))

                    lines.sort(key=lambda l: (l[1], l[0]))

                    tol_y = 10
                    grupos, atual_y, grupo_atual = [], None, []
                    for x, y, texto in lines:
                        if atual_y is None or abs(y - atual_y) < tol_y:
                            grupo_atual.append((x, texto))
                        else:
                            grupo_atual.sort(key=lambda b: b[0])
                            grupos.append(" | ".join(t for _, t in grupo_atual))
                            grupo_atual = [(x, texto)]
                        atual_y = y
                    if grupo_atual:
                        grupo_atual.sort(key=lambda b: b[0])
                        grupos.append(" | ".join(t for _, t in grupo_atual))

                    texto_final = self._clean_text_post("\n".join(grupos))
                    PAGE_CACHE[page_hash] = texto_final  # salva no cache local
                    pages.append(texto_final)

        except Exception as e:
            self.log.error(f"Erro OCR with blocks: {e}")
            pages.append("")

        return TemplateResult(
            pages=pages,
            methods=["ocr_blocks_tabular"] * len(pages),
            qualities=[self.score_text_quality(p) for p in pages],
            errors=[None] * len(pages),
            text="\n".join(pages),
            meta={"total_pages": len(pages), "method": "ocr_blocks_tabular"},
        )
