from __future__ import annotations
from typing import List, Optional
from io import BytesIO
import time, random, fitz, os, hashlib
from threading import Semaphore

from google.cloud import documentai_v1 as documentai
from google.api_core.exceptions import GoogleAPIError, DeadlineExceeded, RetryError

from app.text_extractor.base.base_extractor import BaseExtractor
from app.text_extractor.base.template_result import TemplateResult

# Semáforo como os outros OCRs
DOC_AI_SEMAPHORE = Semaphore(int(os.getenv("MAX_DOC_AI_TRAVA", "4")))
PAGE_CACHE = {}  # cache global igual ao do Azure e Vision


class DocumentAIOCRExtractor(BaseExtractor):
    """
    Extrai texto de PDFs usando Google Cloud Document AI (Document OCR).
    Muito mais forte que Vision, Azure e Tesseract.
    """

    def __init__(self):
        super().__init__()
        # ⚠️ Coloque seu processor ID aqui
        # Exemplo: "projects/750807605258/locations/us/processors/3c80efa76b66f..."
        self.processor_name = os.getenv("GOOGLE_DOC_AI_PROCESSOR", "").strip()

        if not self.processor_name:
            raise ValueError("Variável GOOGLE_DOC_AI_PROCESSOR não configurada!")

        self.client = documentai.DocumentProcessorServiceClient()

    # ============================================================
    # 🔑 HASH DA PÁGINA
    # ============================================================
    def _hash_page(self, page: fitz.Page, dpi: int = 300) -> str:
        mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        return hashlib.sha256(pix.samples).hexdigest()

    # ============================================================
    # 🔄 RETRY DO DOCUMENT AI
    # ============================================================
    def _ocr_with_retry(self, png_bytes: bytes, max_attempts: int = 3):
        attempt = 1
        while True:
            try:
                with DOC_AI_SEMAPHORE:
                    raw_doc = documentai.RawDocument(
                        content=png_bytes,
                        mime_type="image/png"
                    )

                    request = documentai.ProcessRequest(
                        name=self.processor_name,
                        raw_document=raw_doc,
                    )

                    result = self.client.process_document(request=request)
                    return result.document

            except (GoogleAPIError, DeadlineExceeded, RetryError) as e:
                if attempt >= max_attempts:
                    raise

                wait = min(5.0, (2 ** attempt) + random.uniform(0, 1))
                self.log.error(f"[DOC-AI RETRY] {attempt}/{max_attempts} falhou: {e}. Aguardando {wait:.1f}s...")
                time.sleep(wait)
                attempt += 1

    # ============================================================
    # 📄 EXTRACT — texto linear
    # ============================================================
    def extract(self, pdf_path: str, page_indices: Optional[List[int]] = None) -> TemplateResult:
        pages: List[str] = []

        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))

                for idx in idxs:
                    page = doc.load_page(idx)
                    page_hash = self._hash_page(page)

                    # Cache
                    if page_hash in PAGE_CACHE:
                        pages.append(PAGE_CACHE[page_hash])
                        continue

                    # Rasterização
                    mat = fitz.Matrix(300 / 72.0, 300 / 72.0)
                    pix = page.get_pixmap(matrix=mat, alpha=False)

                    with BytesIO() as buf:
                        pix.pil_save(buf, format="png")
                        png_data = buf.getvalue()

                    # OCR Document AI
                    document = self._ocr_with_retry(png_data)

                    # Pega texto reconstruído
                    text = document.text or ""

                    text = self._clean_text_post(text)
                    PAGE_CACHE[page_hash] = text
                    pages.append(text)

        except Exception as e:
            self.log.error(f"Erro Document AI OCR para '{pdf_path}': {e}")

        return TemplateResult(
            pages=pages,
            methods=["ocr_google_doc_ai"] * len(pages),
            qualities=[self.score_text_quality(p) for p in pages],
            errors=[None] * len(pages),
            text="\n".join(pages),
            meta={"total_pages": len(pages)},
        )

    # ============================================================
    # 📊 EXTRACT WITH BLOCKS — tokens + coordenação
    # ============================================================
    def extract_with_blocks(self, pdf_path: str, page_indices: Optional[List[int]] = None) -> TemplateResult:
        pages = []

        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))

                for idx in idxs:
                    page = doc.load_page(idx)
                    page_hash = self._hash_page(page)

                    if page_hash in PAGE_CACHE:
                        pages.append(PAGE_CACHE[page_hash])
                        continue

                    # Rasterização
                    mat = fitz.Matrix(300 / 72.0, 300 / 72.0)
                    pix = page.get_pixmap(matrix=mat, alpha=False)

                    with BytesIO() as buf:
                        pix.pil_save(buf, format="png")
                        png_data = buf.getvalue()

                    # OCR DocumentAI
                    document = self._ocr_with_retry(png_data)

                    # ================================
                    # 💎 EXTRAÇÃO ÓTIMA USANDO TOKENS
                    # ================================
                    tokens_with_pos = []

                    full_text = document.text or ""

                    for page_obj in document.pages:
                        if not page_obj.tokens:
                            continue

                        for token in page_obj.tokens:
                            # Posição (bounding box)
                            verts = token.layout.bounding_poly.vertices
                            x = verts[0].x
                            y = verts[0].y

                            # Recorta texto usando anchor offset
                            tok_text = ""
                            if token.layout.text_anchor.text_segments:
                                seg = token.layout.text_anchor.text_segments[0]
                                tok_text = full_text[seg.start_index:seg.end_index]

                            tok_text = tok_text.strip()
                            if tok_text:
                                tokens_with_pos.append((x, y, tok_text))

                    # ================================
                    # Ordenar tokens corretamente
                    # ================================
                    tokens_with_pos.sort(key=lambda t: (t[1], t[0]))  # y depois x

                    # ================================
                    # Agrupar tokens na mesma linha
                    # ================================
                    grouped = []
                    current = []
                    last_y = None
                    tol = 10  # tolerância vertical

                    for x, y, tok in tokens_with_pos:
                        if last_y is None or abs(y - last_y) < tol:
                            current.append((x, tok))
                        else:
                            current.sort(key=lambda c: c[0])
                            grouped.append(" ".join(t for _, t in current))
                            current = [(x, tok)]

                        last_y = y

                    if current:
                        current.sort(key=lambda c: c[0])
                        grouped.append(" ".join(t for _, t in current))

                    # ================================
                    # Resultado limpo
                    # ================================
                    final = self._clean_text_post("\n".join(grouped))

                    PAGE_CACHE[page_hash] = final
                    pages.append(final)

        except Exception as e:
            self.log.error(f"Erro Document AI extract_with_blocks: {e}")
            pages.append("")

        return TemplateResult(
            pages=pages,
            methods=["ocr_google_doc_ai_blocks"] * len(pages),
            qualities=[self.score_text_quality(p) for p in pages],
            errors=[None] * len(pages),
            text="\n".join(pages),
            meta={"total_pages": len(pages)},
        )
