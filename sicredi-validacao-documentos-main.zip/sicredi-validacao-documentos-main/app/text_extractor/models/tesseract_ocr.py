from __future__ import annotations
from typing import List, Optional
from io import BytesIO
import os
import time
import random
import hashlib
from threading import Semaphore

import fitz
import pytesseract
from PIL import Image

from app.text_extractor.base.base_extractor import BaseExtractor
from app.text_extractor.base.template_result import TemplateResult


TESSERACT_SEMAPHORE = Semaphore(int(os.getenv("MAX_TESSERACT_TRAVA", "4")))
PAGE_CACHE = {}
#GRATUITO

class TesseractOCRExtractor(BaseExtractor):
    """
    Extrator OCR usando Tesseract no mesmo padrão dos demais (EasyOCR, Vision, DocumentIA).
    Usa: Semáforo, retry, cache de páginas, extract e extract_with_blocks.
    """

    def __init__(self):
        super().__init__()

        # Configuração opcional do caminho padrão (Windows)
        tess_cmd = os.getenv("TESSERACT_CMD", r"C:/Program Files/Tesseract-OCR/tesseract.exe")
        pytesseract.pytesseract.tesseract_cmd = tess_cmd

        tessdata = os.getenv("TESSDATA_PREFIX", r"C:/Program Files/Tesseract-OCR/tessdata")
        os.environ["TESSDATA_PREFIX"] = tessdata

        self.lang = os.getenv("TESSERACT_LANG", "por+eng")
        self.dpi = int(os.getenv("TESSERACT_DPI", "300"))

    # ============================================================
    # 🔑 HASH DA PÁGINA
    # ============================================================
    def _hash_page(self, page: fitz.Page, dpi: int = 300) -> str:
        mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        return hashlib.sha256(pix.samples).hexdigest()

    # ============================================================
    # 🔁 OCR com Retry
    # ============================================================
    def _ocr_with_retry(self, img: Image.Image, max_attempts: int = 3):
        attempt = 1

        while True:
            try:
                with TESSERACT_SEMAPHORE:
                    text = pytesseract.image_to_string(img, lang=self.lang)
                    return text

            except Exception as e:
                if attempt >= max_attempts:
                    raise

                wait = min(5.0, (2 ** attempt) + random.uniform(0, 1))
                self.log.error(f"[TESSERACT RETRY] tentativa {attempt}/{max_attempts}: {e}. Esperando {wait:.1f}s…")
                time.sleep(wait)
                attempt += 1

    # ============================================================
    # 📄 extract — saída padrão
    # ============================================================
    def extract(
        self,
        pdf_path: str,
        page_indices: Optional[List[int]] = None
    ) -> TemplateResult:

        pages_text = []

        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))

                for idx in idxs:
                    page = doc.load_page(idx)
                    page_hash = self._hash_page(page, dpi=self.dpi)

                    # Cache global
                    if page_hash in PAGE_CACHE:
                        pages_text.append(PAGE_CACHE[page_hash])
                        continue

                    # Rasterização
                    mat = fitz.Matrix(self.dpi / 72.0, self.dpi / 72.0)
                    pix = page.get_pixmap(matrix=mat, alpha=False)

                    mode = "RGB" if pix.n > 1 else "L"
                    img = Image.frombytes(mode, (pix.width, pix.height), pix.samples)

                    # OCR Tesseract
                    text = self._ocr_with_retry(img)

                    text = self._clean_text_post(text)

                    PAGE_CACHE[page_hash] = text
                    pages_text.append(text)

        except Exception as e:
            self.log.error(f"Erro no Tesseract OCR para '{pdf_path}': {e}")
            pages_text.append("")

        return TemplateResult(
            pages=pages_text,
            methods=["ocr_tesseract"] * len(pages_text),
            qualities=[self.score_text_quality(p) for p in pages_text],
            errors=[None] * len(pages_text),
            text="\n".join(pages_text),
            meta={"total_pages": len(pages_text)}
        )

    # ============================================================
    # 🧩 extract_with_blocks — versão pseudo-estruturada
    # ============================================================
    def extract_with_blocks(
        self,
        pdf_path: str,
        page_indices: Optional[List[int]] = None
    ) -> TemplateResult:

        pages_text = []

        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))

                for idx in idxs:

                    page = doc.load_page(idx)
                    page_hash = self._hash_page(page, dpi=self.dpi)

                    # Cache global
                    if page_hash in PAGE_CACHE:
                        pages_text.append(PAGE_CACHE[page_hash])
                        continue

                    # Rasterização
                    mat = fitz.Matrix(self.dpi / 72.0, self.dpi / 72.0)
                    pix = page.get_pixmap(matrix=mat, alpha=False)

                    mode = "RGB" if pix.n > 1 else "L"
                    img = Image.frombytes(mode, (pix.width, pix.height), pix.samples)

                    # OCR normal (Tesseract não dá blocos estruturados nativamente)
                    text = self._ocr_with_retry(img)

                    # Aqui tentamos "forçar" um agrupamento por linhas
                    lines = text.splitlines()
                    cleaned_lines = [self._clean_text_post(line) for line in lines]
                    final_text = "\n".join(cleaned_lines)

                    PAGE_CACHE[page_hash] = final_text
                    pages_text.append(final_text)

        except Exception as e:
            self.log.error(f"Erro no Tesseract extract_with_blocks: {e}")
            pages_text.append("")

        return TemplateResult(
            pages=pages_text,
            methods=["ocr_tesseract_blocks"] * len(pages_text),
            qualities=[self.score_text_quality(p) for p in pages_text],
            errors=[None] * len(pages_text),
            text="\n".join(pages_text),
            meta={"total_pages": len(pages_text)}
        )
