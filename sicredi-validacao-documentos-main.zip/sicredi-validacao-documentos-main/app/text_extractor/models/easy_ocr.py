from __future__ import annotations
from typing import List, Optional
from io import BytesIO
import time, random, fitz, os, hashlib
from threading import Semaphore
import easyocr

from app.text_extractor.base.base_extractor import BaseExtractor
from app.text_extractor.base.template_result import TemplateResult

EASYOCR_SEMAPHORE = Semaphore(int(os.getenv("MAX_EASYOCR_TRAVA", "6")))
PAGE_CACHE = {}  # cache global para páginas OCRizadas

#GRATUITO
class EasyOCRExtractor(BaseExtractor):
    """
    Extrai texto usando EasyOCR (offline, gratuito).
    Interface idêntica aos extratores do Google/Azure.
    """

    def __init__(self):
        super().__init__()
        self.reader = easyocr.Reader(['pt', 'en'], gpu=False)

    # ============================================================
    # 🔑 HASH PROCESSADO (para cache)
    # ============================================================
    def _hash_page(self, page: fitz.Page, dpi: int = 300) -> str:
        mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        return hashlib.sha256(pix.samples).hexdigest()

    # ============================================================
    # 🔁 EXECUÇÃO EASY OCR COM RETRY
    # ============================================================
    def _ocr_with_retry(self, png_bytes: bytes, max_attempts: int = 3):
        attempt = 1
        while True:
            try:
                with EASYOCR_SEMAPHORE:
                    result = self.reader.readtext(png_bytes, detail=1)
                    return result

            except Exception as e:
                if attempt >= max_attempts:
                    raise
                wait = min(4.0, (2 ** attempt) + random.uniform(0, 1))
                self.log.error(f"[EASY OCR RETRY] {attempt}/{max_attempts}: {e}. Aguardando {wait:.1f}s...")
                time.sleep(wait)
                attempt += 1

    # ============================================================
    # 📄 EXTRACT — versão simples (mesmo padrão do Azure e Google)
    # ============================================================
    def extract(self, pdf_path: str, page_indices: Optional[List[int]] = None) -> TemplateResult:
        pages_text: List[str] = []

        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))

                for idx in idxs:
                    page = doc.load_page(idx)
                    page_hash = self._hash_page(page)

                    # cache
                    if page_hash in PAGE_CACHE:
                        pages_text.append(PAGE_CACHE[page_hash])
                        continue

                    # Render para PNG
                    mat = fitz.Matrix(300 / 72.0, 300 / 72.0)
                    pix = page.get_pixmap(matrix=mat, alpha=False)

                    with BytesIO() as buf:
                        pix.pil_save(buf, format="png")
                        png_data = buf.getvalue()

                    # OCR
                    result = self._ocr_with_retry(png_data)

                    # EasyOCR devolve lista: [(bbox, text, conf), ...]
                    lines = [item[1] for item in result]
                    text = "\n".join(lines)

                    text = self._clean_text_post(text)

                    PAGE_CACHE[page_hash] = text
                    pages_text.append(text)

        except Exception as e:
            self.log.error(f"Erro no EasyOCR para '{pdf_path}': {e}")
            pages_text.append("")

        return TemplateResult(
            pages=pages_text,
            methods=["ocr_easyocr"] * len(pages_text),
            qualities=[self.score_text_quality(p) for p in pages_text],
            errors=[None] * len(pages_text),
            text="\n".join(pages_text),
            meta={"total_pages": len(pages_text)},
        )

    # ============================================================
    # 🧩 EXTRACT_WITH_BLOCKS — agrupamento baseado em bbox
    # ============================================================
    def extract_with_blocks(self, pdf_path: str, page_indices: Optional[List[int]] = None) -> TemplateResult:
        pages_text: List[str] = []

        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))

                for idx in idxs:
                    page = doc.load_page(idx)
                    page_hash = self._hash_page(page)

                    # Cache
                    if page_hash in PAGE_CACHE:
                        pages_text.append(PAGE_CACHE[page_hash])
                        continue

                    # Raster
                    mat = fitz.Matrix(300 / 72.0, 300 / 72.0)
                    pix = page.get_pixmap(matrix=mat, alpha=False)

                    with BytesIO() as buf:
                        pix.pil_save(buf, format="png")
                        png_data = buf.getvalue()

                    result = self._ocr_with_retry(png_data)

                    # result = [(bbox, text, conf)]
                    # cada bbox = [ [x1,y1], [x2,y2], [x3,y3], [x4,y4] ]

                    tokens = []
                    heights = []

                    for bbox, text, conf in result:
                        if not text.strip():
                            continue

                        xs = [p[0] for p in bbox]
                        ys = [p[1] for p in bbox]
                        x_center = sum(xs) / 4
                        y_center = sum(ys) / 4
                        height = max(ys) - min(ys)

                        tokens.append((x_center, y_center, text))
                        heights.append(height)

                    if not tokens:
                        pages_text.append("")
                        continue

                    # Tolerância vertical dinâmica
                    heights_sorted = sorted(heights)
                    mid = len(heights_sorted) // 2
                    median_h = (
                        heights_sorted[mid]
                        if len(heights_sorted) % 2 == 1
                        else (heights_sorted[mid - 1] + heights_sorted[mid]) / 2
                    )
                    tol_y = max(12, median_h * 1.5)

                    # Agrupamento em linhas
                    tokens.sort(key=lambda t: (t[1], t[0]))

                    grouped = []
                    current = []
                    last_y = None

                    for x, y, tok in tokens:
                        if last_y is None or abs(y - last_y) < tol_y:
                            current.append((x, tok))
                        else:
                            current.sort(key=lambda c: c[0])
                            grouped.append(" ".join(t for _, t in current))
                            current = [(x, tok)]
                        last_y = y

                    if current:
                        current.sort(key=lambda c: c[0])
                        grouped.append(" ".join(t for _, t in current))

                    final = self._clean_text_post("\n".join(grouped))

                    PAGE_CACHE[page_hash] = final
                    pages_text.append(final)

        except Exception as e:
            self.log.error(f"Erro no EasyOCR extract_with_blocks: {e}")
            pages_text.append("")

        return TemplateResult(
            pages=pages_text,
            methods=["ocr_easyocr_blocks"] * len(pages_text),
            qualities=[self.score_text_quality(p) for p in pages_text],
            errors=[None] * len(pages_text),
            text="\n".join(pages_text),
            meta={"total_pages": len(pages_text)},
        )
