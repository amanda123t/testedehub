from __future__ import annotations
from typing import List, Optional
from io import BytesIO
import time, random, fitz, os, hashlib
from threading import Semaphore
from google.cloud import vision
from google.api_core.exceptions import GoogleAPIError, RetryError, DeadlineExceeded

from app.text_extractor.base.base_extractor import BaseExtractor
from app.text_extractor.base.template_result import TemplateResult

GOOGLE_SEMAPHORE = Semaphore(int(os.getenv("MAX_GOOGLE_TRAVA", "8")))
PAGE_CACHE = {}  # cache global de páginas OCRizadas


class GoogleOCRExtractor(BaseExtractor):
    """
    Extrai texto de PDFs usando Google Cloud Vision OCR.
    Usa PDF → PNG via fitz (nenhum pacote externo necessário).
    Mantém interface e comportamento idênticos ao AzureOCRExtractor.
    """

    def __init__(self):
        super().__init__()
        self.client = vision.ImageAnnotatorClient()

    # ============================================================
    # 🔑 HASH DA PÁGINA (PNG gerado por PyMuPDF)
    # ============================================================
    def _hash_page(self, page: fitz.Page, dpi: int = 300) -> str:
        mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        return hashlib.sha256(pix.samples).hexdigest()

    # ============================================================
    # 🔁 ENVIA PNG AO GOOGLE COM RETRY
    # ============================================================
    def _ocr_with_retry(self, png_bytes: bytes, max_attempts: int = 3):
        attempt = 1
        while True:
            try:
                with GOOGLE_SEMAPHORE:
                    image = vision.Image(content=png_bytes)
                    response = self.client.text_detection(image=image)

                    if response.error.message:
                        raise GoogleAPIError(response.error.message)

                    return response

            except (GoogleAPIError, RetryError, DeadlineExceeded) as e:
                if attempt >= max_attempts:
                    raise
                wait = min(5.0, (2 ** attempt) + random.uniform(0, 1))
                self.log.error(f"[GOOGLE RETRY] tentativa {attempt}/{max_attempts} falhou: {e}. Esperando {wait:.1f}s...")
                time.sleep(wait)
                attempt += 1

    # ============================================================
    # 📄 EXTRACT — texto normal (mesma estrutura do Azure)
    # ============================================================
    def extract(self, pdf_path: str, page_indices: Optional[List[int]] = None) -> TemplateResult:
        pages: List[str] = []

        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))

                for idx in idxs:
                    text = ""
                    page = doc.load_page(idx)

                    # Hash único da página (PNG)
                    page_hash = self._hash_page(page)

                    # Cache
                    if page_hash in PAGE_CACHE:
                        pages.append(PAGE_CACHE[page_hash])
                        continue

                    # Rasterização com FITZ (300 DPI)
                    mat = fitz.Matrix(300 / 72.0, 300 / 72.0)
                    pix = page.get_pixmap(matrix=mat, alpha=False)

                    with BytesIO() as buf:
                        pix.pil_save(buf, format="png")
                        png_data = buf.getvalue()

                    # OCR Google
                    result = self._ocr_with_retry(png_data)

                    if result.text_annotations:
                        text = result.text_annotations[0].description or ""

                    # Limpeza
                    text = self._clean_text_post(text)

                    PAGE_CACHE[page_hash] = text
                    pages.append(text)

        except Exception as e:
            self.log.error(f"Erro no Google OCR para '{pdf_path}': {e}")

        return TemplateResult(
            pages=pages,
            methods=["ocr_google"] * len(pages),
            qualities=[self.score_text_quality(p) for p in pages],
            errors=[None] * len(pages),
            text="\n".join(pages),
            meta={"total_pages": len(pages), "ocr_count": len(pages)},
        )

    # ============================================================
    # 📊 EXTRACT_WITH_BLOCKS — versão melhorada usando full_text_annotation
    # ============================================================
    def extract_with_blocks(self, pdf_path: str, page_indices: Optional[List[int]] = None) -> TemplateResult:
        pages = []

        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))

                for idx in idxs:
                    page = doc.load_page(idx)
                    page_hash = self._hash_page(page)

                    # cache
                    if page_hash in PAGE_CACHE:
                        pages.append(PAGE_CACHE[page_hash])
                        continue

                    # Raster
                    mat = fitz.Matrix(300 / 72.0, 300 / 72.0)
                    pix = page.get_pixmap(matrix=mat, alpha=False)

                    with BytesIO() as buf:
                        pix.pil_save(buf, format="png")
                        png_data = buf.getvalue()

                    result = self._ocr_with_retry(png_data)

                    # =====================================================
                    # 🔍 FULL TEXT ANNOTATION (MUITO MELHOR QUE text_annotations)
                    # =====================================================
                    tokens_with_pos = []
                    heights = []

                    full = result.full_text_annotation
                    if full and full.pages:
                        for page_obj in full.pages:
                            for block in page_obj.blocks:
                                for para in block.paragraphs:
                                    for word in para.words:
                                        # monta o texto do word
                                        w_text = "".join(sym.text for sym in word.symbols).strip()
                                        if not w_text:
                                            continue

                                        # bounding box
                                        verts = word.bounding_box.vertices
                                        xs = [v.x for v in verts]
                                        ys = [v.y for v in verts]

                                        x_center = sum(xs) / len(xs)
                                        y_center = sum(ys) / len(ys)
                                        height = (max(ys) - min(ys)) if ys else 0

                                        tokens_with_pos.append((x_center, y_center, w_text))
                                        if height > 0:
                                            heights.append(height)

                    # ===== CASE: fallback se não houver tokens =====
                    if not tokens_with_pos:
                        lines = []
                        if result.text_annotations:
                            for ann in result.text_annotations[1:]:
                                xs = [v.x for v in ann.bounding_poly.vertices]
                                ys = [v.y for v in ann.bounding_poly.vertices]
                                x = sum(xs) / 4
                                y = sum(ys) / 4
                                lines.append((x, y, ann.description))

                        lines.sort(key=lambda l: (l[1], l[0]))

                        grouped = []
                        current = []
                        current_y = None
                        tol = 10

                        for x, y, t in lines:
                            if current_y is None or abs(y - current_y) < tol:
                                current.append((x, t))
                            else:
                                current.sort(key=lambda c: c[0])
                                grouped.append(" ".join(t for _, t in current))
                                current = [(x, t)]
                            current_y = y

                        if current:
                            current.sort(key=lambda c: c[0])
                            grouped.append(" ".join(t for _, t in current))

                        final = self._clean_text_post("\n".join(grouped))
                        PAGE_CACHE[page_hash] = final
                        pages.append(final)
                        continue

                    # =====================================================
                    # 📏 Tolerância vertical dinâmica
                    # =====================================================
                    if heights:
                        heights_sorted = sorted(heights)
                        mid = len(heights_sorted) // 2
                        median_h = (
                            heights_sorted[mid]
                            if len(heights_sorted) % 2 == 1
                            else (heights_sorted[mid - 1] + heights_sorted[mid]) / 2
                        )
                    else:
                        median_h = 18.0

                    tol_y = max(10.0, median_h * 1.55)  # tolerância vertical adaptativa

                    # =====================================================
                    # 📚 Ordenar tokens + agrupar em linhas
                    # =====================================================
                    tokens_with_pos.sort(key=lambda t: (t[1], t[0]))  # sort by y then x

                    grouped = []
                    current = []
                    last_y = None

                    for x, y, tok in tokens_with_pos:
                        if last_y is None or abs(y - last_y) < tol_y:
                            current.append((x, tok))
                        else:
                            current.sort(key=lambda c: c[0])
                            grouped.append(" ".join(t for _, t in current))
                            current = [(x, tok)]
                        last_y = y

                    if current:
                        current.sort(key=lambda c: c[0])
                        grouped.append(" ".join(t for _, t in current))

                    final = self._clean_text_post("\n".join(grouped))
                    PAGE_CACHE[page_hash] = final
                    pages.append(final)

        except Exception as e:
            self.log.error(f"Erro no extract_with_blocks Google: {e}")
            pages.append("")

        return TemplateResult(
            pages=pages,
            methods=["ocr_google_blocks"] * len(pages),
            qualities=[self.score_text_quality(p) for p in pages],
            errors=[None] * len(pages),
            text="\n".join(pages),
            meta={"total_pages": len(pages)},
        )
