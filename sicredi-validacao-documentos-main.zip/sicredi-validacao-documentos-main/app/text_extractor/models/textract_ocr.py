from __future__ import annotations
from typing import List, Optional
from io import BytesIO
import time, random, fitz, os, hashlib
import boto3
from botocore.exceptions import ClientError, EndpointConnectionError
from threading import Semaphore

from app.text_extractor.base.base_extractor import BaseExtractor
from app.text_extractor.base.template_result import TemplateResult

# Semáforo para limitar paralelismo (igual Azure)
TEXTRACT_SEMAPHORE = Semaphore(int(os.getenv("MAX_TEXTRACT_TRAVA", "5")))

# Cache por página (hex hash → texto extraído)
TEXTRACT_PAGE_CACHE = {}

class TextractOCRExtractor(BaseExtractor):
    """
    Extrator OCR usando Amazon Textract (DetectDocumentText).
    Segue exatamente o padrão da AzureOCRExtractor: semáforo, retry, cache, DPI fallback.
    """

    def __init__(self):
        super().__init__()
        self.client = boto3.client(
            "textract",
            region_name=os.getenv("AWS_REGION", "us-east-1")
        )

    # -------------------------------
    # Hash da página
    # -------------------------------
    def _hash_page(self, page: fitz.Page, dpi: int = 150) -> str:
        mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)
        pix = page.get_pixmap(matrix=mat, alpha=False)
        return hashlib.sha256(pix.samples).hexdigest()

    # -------------------------------
    # Chamadas Textract com retry
    # -------------------------------
    def _detect_with_retry(self, png_bytes: bytes, max_attempts: int = 3):
        attempt = 1
        while attempt <= max_attempts:
            try:
                with TEXTRACT_SEMAPHORE:
                    response = self.client.detect_document_text(
                        Document={"Bytes": png_bytes}
                    )
                    return response

            except (EndpointConnectionError, ClientError) as e:
                msg = str(e)

                if attempt == max_attempts:
                    raise e

                sleep_s = min(6.0, 1.5 * (2 ** (attempt - 1))) * (1 + random.random() * 0.2)
                self.log.error(
                    f"[Textract Retry] tentativa {attempt}/{max_attempts} falhou: {msg}. "
                    f"Tentando novamente em {sleep_s:.1f}s"
                )
                time.sleep(sleep_s)
                attempt += 1

    # -------------------------------
    # MÉTODO extract (modo simples)
    # -------------------------------
    def extract(self, pdf_path: str, page_indices: Optional[List[int]] = None):
        dpi_trials = [300, 240, 200, 150]
        pages: List[str] = []

        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))

                for idx in idxs:
                    page = doc.load_page(idx)
                    text_final = ""

                    # Tenta múltiplos DPI
                    for dpi in dpi_trials:
                        try:
                            # Hash + cache
                            page_hash = self._hash_page(page, dpi)
                            if page_hash in TEXTRACT_PAGE_CACHE:
                                self.log.debug(f"♻️ Página {idx+1} reaproveitada do cache Textract")
                                text_final = TEXTRACT_PAGE_CACHE[page_hash]
                                break

                            # Rasterização
                            mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)
                            pix = page.get_pixmap(matrix=mat, alpha=False)

                            with BytesIO() as buf:
                                pix.pil_save(buf, format="png")
                                response = self._detect_with_retry(buf.getvalue())

                            # Leitura de linhas detectadas
                            lines = []
                            for block in response.get("Blocks", []):
                                if block.get("BlockType") == "LINE":
                                    lines.append(block.get("Text", "").strip())

                            text_final = "\n".join(lines)

                            # Salva no cache
                            TEXTRACT_PAGE_CACHE[page_hash] = text_final

                            break  # DPI OK → para tentativas
                        except Exception as e:
                            self.log.warning(f"[Textract] Falha no DPI {dpi}: {e}")
                            continue

                    pages.append(self._clean_text_post(text_final))

        except Exception as e:
            self.log.error(f"Erro TextractOCRExtractor para '{pdf_path}': {e}")
            pages.append("")

        return TemplateResult(
            pages=pages,
            methods=["textract"] * len(pages),
            qualities=[self.score_text_quality(p) for p in pages],
            errors=[None] * len(pages),
            text="\n".join(pages),
            meta={"total_pages": len(pages), "ocr_count": len(pages)}
        )

    # -------------------------------
    # MÉTODO extract_with_blocks (modo tabular)
    # -------------------------------
    def extract_with_blocks(self, pdf_path: str, page_indices: Optional[List[int]] = None):
        pages = []

        try:
            with fitz.open(pdf_path) as doc:
                idxs = page_indices or list(range(doc.page_count))

                for idx in idxs:
                    page = doc.load_page(idx)

                    page_hash = self._hash_page(page)
                    if page_hash in TEXTRACT_PAGE_CACHE:
                        texto_final = TEXTRACT_PAGE_CACHE[page_hash]
                        pages.append(texto_final)
                        continue

                    # rasterizar
                    mat = fitz.Matrix(3, 3)
                    pix = page.get_pixmap(matrix=mat, alpha=False)

                    with BytesIO() as buf:
                        pix.pil_save(buf, format="png")
                        response = self._detect_with_retry(buf.getvalue())

                    # Extrair blocos com coordenadas
                    linhas = []
                    for block in response.get("Blocks", []):
                        if block.get("BlockType") == "LINE":
                            text = block.get("Text", "").strip()
                            geom = block.get("Geometry", {})
                            bbox = geom.get("BoundingBox", {})
                            top = bbox.get("Top", 0)
                            left = bbox.get("Left", 0)
                            linhas.append((left, top, text))

                    # Ordenar por Top, depois Left
                    linhas.sort(key=lambda x: (x[1], x[0]))

                    texto_final = "\n".join([t for _, _, t in linhas])
                    texto_final = self._clean_text_post(texto_final)

                    TEXTRACT_PAGE_CACHE[page_hash] = texto_final
                    pages.append(texto_final)

        except Exception as e:
            self.log.error(f"[Textract Blocks] Erro no OCR: {e}")
            pages.append("")

        return TemplateResult(
            pages=pages,
            methods=["textract_blocks"] * len(pages),
            qualities=[self.score_text_quality(p) for p in pages],
            errors=[None] * len(pages),
            text="\n".join(pages),
            meta={"total_pages": len(pages), "method": "textract_blocks"}
        )
