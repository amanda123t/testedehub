from __future__ import annotations
import os, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional, Tuple, List
from app.text_extractor.models.native_reader import PDFTextExtractor
from app.text_extractor.models.azure_ocr_reader import AzureOCRExtractor
from .base.template_result import TemplateResult
from app.utils.logger import LoggerManager
import atexit, os
import fitz

_POOL_OCR = ThreadPoolExecutor(max_workers=int(os.getenv("MAX_OCR_POR_PROCESS", "8")))
atexit.register(lambda: _POOL_OCR.shutdown(wait=False))

class PDFTextManager:
    """
    Classe principal que orquestra os extratores de texto:
    - PDFTextExtractor (nativo)
    - AzureOCRExtractor (OCR Azure)
    - EasyOCRExtractor (futuro)
    """
    def __init__(self):
        self.log = LoggerManager(__name__)
        self.pdf_text = PDFTextExtractor()
        self.azure_ocr = AzureOCRExtractor()
        self.qtde_caracteres_por_pagina = 300
        self.qualidade = 0.5

    def texto_por_pagina_threaded(
        self,
        caminho_arquivo: str,
        qtde_paginas: Optional[int] = None,
        modo: str = "AUTO",
        quality_threshold: float = 0.5,
        min_chars_per_page: Optional[int] = None,
        pages_indices: Optional[List[int]] = None, 
    ) -> TemplateResult:
        """
        Extrai o texto de cada página com threads e fallback automático (texto nativo → OCR).
        Pode receber pages_indices para processar páginas específicas.
        """
        t0 = time.perf_counter()
        min_chars = min_chars_per_page or self.qtde_caracteres_por_pagina
        quality = quality_threshold or self.qualidade

        with fitz.open(caminho_arquivo) as doc:
            total_paginas = doc.page_count

        # Definir páginas a processar
        if pages_indices:
            indices = sorted(set([i for i in pages_indices if 0 <= i < total_paginas]))
        else:
            n_pages = qtde_paginas or total_paginas
            indices = list(range(n_pages))

        pages = {}
        methods = {}
        qualities = {}
        errors = {}
        ocr_count = pdf_count = 0

        def _extrair(idx: int):
            try:
                if modo == "PDF_TEXT":
                    res = self.pdf_text.extract_with_blocks(caminho_arquivo, [idx])
                    #res = self.pdf_text.extract_with_blocks(caminho_arquivo, [idx])
                    texto = (res.pages[0] if res and res.pages else "")
                    metodo = "pdf_text"
                elif modo == "AZURE_OCR":
                    res = self.azure_ocr.extract_with_blocks(caminho_arquivo, [idx])
                    texto = (res.pages[0] if res and res.pages else "")
                    metodo = "ocr"
                else:
                    res = self.pdf_text.extract_with_blocks(caminho_arquivo, [idx])
                    #res = self.pdf_text.extract_with_blocks(caminho_arquivo, [idx])
                    texto = (res.pages[0] if res and res.pages else "")
                    q = self.pdf_text.score_text_quality(texto, expected_min_chars=min_chars)
                    if q < quality or not texto:
                        res = self.azure_ocr.extract_with_blocks(caminho_arquivo, [idx])
                        texto = (res.pages[0] if res and res.pages else "")
                        metodo = "ocr"
                    else:
                        metodo = "pdf_text"
                q = self.pdf_text.score_text_quality(texto, expected_min_chars=min_chars)
                return idx, texto, metodo, q, None
            except Exception as e:
                self.log.error(f"Erro ao extrair o texto da página {idx}: {e}")
                return idx, "", "error", 0.0, str(e)

        futuros = [_POOL_OCR.submit(_extrair, i) for i in indices]

        for f in as_completed(futuros):
            idx, texto, metodo, q, err = f.result()
            pages[idx] = texto
            methods[idx] = metodo
            qualities[idx] = q
            errors[idx] = err
            if metodo == "ocr": ocr_count += 1
            if metodo == "pdf_text": pdf_count += 1

        # Ordenar páginas conforme ordem original
        ordered_indices = sorted(pages.keys())
        ordered_pages = [pages[i] for i in ordered_indices]

        return TemplateResult(
            pages=ordered_pages,
            methods=[methods[i] for i in ordered_indices],
            qualities=[qualities[i] for i in ordered_indices],
            errors=[errors[i] for i in ordered_indices],
            text="\n".join(ordered_pages),
            meta={
                "total_pages": len(ordered_pages),
                "ocr_count": ocr_count,
                "pdf_text_count": pdf_count,
                "time_s": round(time.perf_counter() - t0, 3)
            }
        )
