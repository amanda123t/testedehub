from __future__ import annotations
import re, unicodedata
from abc import ABC
from typing import Optional
from app.utils.logger import LoggerManager

class BaseExtractor(ABC):
    """
    Classe base para todos os extratores de texto.
    Fornece métodos utilitários compartilhados, como limpeza e cálculo de qualidade.
    """

    def __init__(self):
        self.log = LoggerManager(__name__)
        self.qtde_caracteres_por_pagina = 300

    def _clean_text_post(self, text: str) -> str:
        """
        Limpa e normaliza o texto extraído, removendo caracteres invisíveis e espaços desnecessários.
        """
        if not text:
            return ""
        text = unicodedata.normalize("NFKC", text)
        text = text.replace("\u00ad", "")
        text = re.sub(r"[\u200b-\u200f\u202a-\u202e]", "", text)
        text = re.sub(r"[ \t]{2,}", " ", text)
        return text.strip()

    def score_text_quality(self, text: str, expected_min_chars: int = 0) -> float:
        """
        Retorna um score (0..1) da qualidade do texto com base em heurísticas simples.
        """
        if not text:
            return 0.0
        bruto = text
        t = unicodedata.normalize("NFKC", text).replace("\u00ad", "")
        t = re.sub(r"[\u200b-\u200f\u202a-\u202e]", "", t)
        t = re.sub(r"[ \t]{2,}", " ", t)
        n = max(1, len(t))
        ruins = re.findall(r"[^\w\s\.,;:%/\-()$€R\$ºª°&+]", t)
        porc_ruins = min(1.0, len(ruins) / n)
        combining = sum(1 for ch in unicodedata.normalize("NFD", bruto) if unicodedata.combining(ch))
        porc_comb = min(1.0, combining / max(1, len(bruto)))
        dens_punct = min(1.0, len(re.findall(r"[^\w\s]", t)) / n)
        tokens = re.findall(r"\b\w+\b", t)
        tt = max(1, len(tokens))
        one_char = sum(1 for w in tokens if len(w) == 1 and not w.isdigit())
        porc_one = min(1.0, one_char / tt)
        STOP_PT = {"de","da","do","em","para","por","com","ao","a","o","os","as","e","ou",
                   "que","um","uma","no","na","nos","nas","se","não","dos","das","sua","seu",
                   "este","esta","essa","isso","isto","ele","ela","eles","elas","nosso","nossa"}
        hits_stop = sum(1 for w in tokens[:min(2000, tt)] if w.lower() in STOP_PT)
        porc_stop = min(1.0, hits_stop / max(1, min(400, tt)))
        comp_rel = 1.0 if expected_min_chars <= 0 else min(1.0, len(t) / expected_min_chars)
        score = 0.42 * porc_stop + 0.23 * comp_rel + 0.35 * (1.0 - min(1.0, 0.7 * porc_ruins + 0.6 * porc_comb + 0.5 * dens_punct + 0.4 * porc_one))
        return round(max(0.0, min(1.0, score)), 3)
