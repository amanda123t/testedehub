# app/modules/file_reader/template_result.py
from dataclasses import dataclass
from typing import List, Dict, Any, Optional

@dataclass
class TemplateResult:
    pages: List[str]
    methods: List[str]          # "pdf_text" | "ocr" | "error"
    qualities: List[float]
    errors: List[Optional[str]]
    text: str
    meta: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pages": self.pages,
            "methods": self.methods,
            "qualities": self.qualities,
            "errors": self.errors,
            "text": self.text,
            "meta": self.meta,
        }

    def merge(self, other: "TemplateResult") -> "TemplateResult":
        """Combina resultados (útil para juntar OCR e texto nativo)."""
        return TemplateResult(
            pages=self.pages + other.pages,
            methods=self.methods + other.methods,
            qualities=self.qualities + other.qualities,
            errors=self.errors + other.errors,
            text=self.text + "\n" + other.text,
            meta={**self.meta, **other.meta}
        )

    def summary(self) -> str:
        """Resumo rápido para logs e debug."""
        return (
            f"{len(self.pages)} páginas | "
            f"OCR={self.meta.get('ocr_count', 0)} | "
            f"PDF={self.meta.get('pdf_text_count', 0)} | "
            f"Tempo={self.meta.get('time_s', '?')}s"
        )
