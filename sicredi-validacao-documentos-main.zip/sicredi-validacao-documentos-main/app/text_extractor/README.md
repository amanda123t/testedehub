📁 Estrutura geral do módulo de texto

O diretório de OCR segue uma arquitetura padronizada:

app/modules/text/
    base_extractor.py       # classe base com interface comum
    template_result.py      # dataclass TemplateResult (saída unificada)
    pdf_text_extractor.py   # get_text / get_text_with_blocks (PyMuPDF)
    tesseract_extractor.py  # Tesseract OCR
    easyocr_extractor.py    # EasyOCR
    vision_ocr_extractor.py # Google Cloud Vision OCR
    azure_ocr_extractor.py  # Azure Read / Layout
    document_ai_ocr_extractor.py  # Google Document AI (Document OCR)
    ...


A ideia é que todos os extratores tenham a mesma “cara” e sejam intercambiáveis.

🧱 BaseExtractor e TemplateResult

Todos os extratores herdam de BaseExtractor, que define a interface padrão:

extract(pdf_path: str, page_indices: Optional[List[int]] = None) -> TemplateResult

Retorna o texto “normal”, página a página, já limpo.

extract_with_blocks(pdf_path: str, page_indices: Optional[List[int]] = None) -> TemplateResult

Versão “mais rica”, usando informações de layout quando o motor suporta
(blocos, linhas, colunas, reconstrução de ordem, etc.).

A classe TemplateResult padroniza a saída de todos os motores:

pages: List[str] – texto de cada página.

methods: List[str] – rótulo do método usado (ex.: "pdf_text", "ocr_doc_ai"…).

qualities: List[float] – score heurístico de qualidade do texto.

errors: List[Optional[str]] – erros por página (se existirem).

text: str – texto concatenado de todas as páginas.

meta: Dict[str, Any] – metadados (ex.: total_pages, ocr_count, etc.).

Isso permite que o restante do pipeline (classificação, extração de dados, validação) não precise saber qual OCR foi usado.

🔄 Concorrência: Semáforos por serviço

Cada extrator que chama um serviço externo usa um Semaphore dedicado para limitar o paralelismo:

GOOGLE_SEMAPHORE em GoogleOCRExtractor / Vision OCR

DOC_AI_SEMAPHORE em DocumentAIOCRExtractor

EASYOCR_SEMAPHORE em EasyOCRExtractor

AZURE_SEMAPHORE (ou equivalente) no extrator Azure

etc.

O valor é configurável via .env, por exemplo:

MAX_GOOGLE_TRAVA=8
MAX_DOC_AI_TRAVA=4
MAX_EASYOCR_TRAVA=6
MAX_AZURE_TRAVA=8


Isso evita:

estouro de limite de QPS dos provedores;

sobrecarga da máquina local;

timeouts em cascata.

🧠 Cache por página (hash de imagem)

Para não OCRizar a mesma página várias vezes:

Cada página do PDF é renderizada em PNG (via PyMuPDF / fitz, normalmente a 300 DPI).
PyMuPDF
+1

Calculamos um hash SHA-256 dos bytes da imagem.

Guardamos o resultado do OCR em um dicionário global PAGE_CACHE[hash].

Assim, se:

o mesmo PDF for processado de novo; ou

páginas idênticas aparecerem em arquivos diferentes (ex.: capa padrão, instruções etc.)

…o texto já vem do cache, sem custo adicional de OCR.

♻️ Retry com backoff exponencial

Todos os extratores externos implementam um método de retry, por exemplo:

def _ocr_with_retry(self, png_bytes: bytes, max_attempts: int = 3):
    attempt = 1
    while True:
        try:
            with SEMAPHORE:
                # chamada real ao serviço externo
                ...
                return result

        except AlgumErroDeAPI as e:
            if attempt >= max_attempts:
                raise
            wait = min(5.0, (2 ** attempt) + random.uniform(0, 1))
            self.log.error(f"[RETRY] tentativa {attempt}/{max_attempts} falhou: {e}. Esperando {wait:.1f}s...")
            time.sleep(wait)
            attempt += 1


Limita tentativas.

Usa backoff exponencial com jitter.

Loga a causa do erro.

Isso torna o módulo resiliente a instabilidades temporárias de rede/API.

📄 Paginação flexível (página isolada ou documento inteiro)

Todos os extratores aceitam um parâmetro opcional page_indices: List[int]:

Se None → processa todas as páginas do PDF.

Se for uma lista (ex.: [0], [2, 3]) → processa somente essas páginas.

Isso permite:

reprocessar apenas páginas “problemáticas”;

fazer pipelines híbridos (ex.: get_text no documento todo, OCR só em 1–2 páginas escaneadas).


🔐 Configuração via .env

Exemplo de variáveis usadas no módulo de texto (ajustar ao que já existe no teu projeto):

# ---------- SELEÇÃO DE MOTORES / PIPELINE ----------
TEXT_EXTRACTOR_PRIMARY=document_ai_ocr      # ou azure_read, azure_layout, vision_ocr, easyocr, tesseract
TEXT_EXTRACTOR_FALLBACK=vision_ocr
TEXT_EXTRACTOR_FALLBACK2=easyocr

# ---------- GOOGLE VISION & DOCUMENT AI ----------
GOOGLE_APPLICATION_CREDENTIALS=/caminho/service-account.json
GOOGLE_DOC_AI_PROCESSOR=projects/XXX/locations/us/processors/YYY   # usado no DocumentAIOCRExtractor

MAX_GOOGLE_TRAVA=8        # Vision OCR
MAX_DOC_AI_TRAVA=4        # Document AI OCR

# ---------- AZURE DOCUMENT INTELLIGENCE ----------
AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=https://seu-endpoint.cognitiveservices.azure.com/
AZURE_DOCUMENT_INTELLIGENCE_KEY=chave_aqui

MAX_AZURE_TRAVA=8

# ---------- EASYOCR / OPEN SOURCE ----------
MAX_EASYOCR_TRAVA=6

# (opcional) Tesseract
TESSERACT_CMD=/usr/bin/tesseract
MAX_TESSERACT_TRAVA=4


Na aplicação, a escolha do extrator pode ser feita por uma factory simples, baseada nessas variáveis.

🔗 Links oficiais para consulta de preços (atualizar se necessário)

Azure AI Document Intelligence (Read + Prebuilt/Layout):
https://azure.microsoft.com/pricing/details/ai-document-intelligence/
 
itmagination.com
+1

Google Cloud Vision OCR – Pricing:
https://cloud.google.com/vision/pricing
 
Google Cloud Documentation
+1

Google Document AI – Pricing (Enterprise Document OCR Processor):
https://cloud.google.com/document-ai/pricing
 
Google Cloud Documentation
+1

PyMuPDF (get_text / extração nativa de PDF):
https://pymupdf.readthedocs.io
 
PyMuPDF
+2
PyMuPDF
+2

Tesseract OCR (open source, Apache 2.0):
https://github.com/tesseract-ocr/tesseract
 
GitHub
+1

EasyOCR (open source, Apache 2.0):
https://github.com/JaidedAI/EasyOCR
 
GitHub
+1