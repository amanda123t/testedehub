from pydantic import BaseModel, Field
from typing import List, Dict, Optional

class Receita(BaseModel):
    name: str = Field(
        description="Full name of the person or company name associated with the document.",
        example="João da Silva",
        alias="Nome:"
    )

    document: str = Field(
        description="The CNPJ or CPF. " \
        "The CNPJ(Cadastro Nacional da Pessoa Jurídica) is the registration number of a company or entity with the Brazilian Federal Revenue Service." \
        "The CPF(Cadastro Pessoa Física) – 11 dígitos no formato 123.456.789-10.", 
        examples=["01.000.025/0001-00", "897.847.879-54"],
        alias="CPF/CNPJ:"
    )
    
    extraction_date: Optional[str] = Field(
        description="Date and time when the document was extracted, in the format DD/MM/YYYY HH:MM:SS.",
        example="25/02/2025 14:30:00",
        alias="Data de Extração:"
    )
    
    situation: str = Field(
        description="Income status of the person or company.",
        example=["Ativa", "Inativa", "Regular", "Pendente de Regularização"],
        alias="Situacao:"
    )

