from pydantic import BaseModel, Field

class SelfDeclaration(BaseModel):
    name: str = Field(
        description="Full name of the person registered on the account.",
        example="João da Silva",
        alias="Nome:"
    )
    
    cpf: str = Field(
        description="""CPF (Cadastro de Pessoas Físicas) is the taxpayer identification number for individuals in Brazil. It should have 11 digits in the format 123.456.789-10.  Example: 123.456.789-10.
It should not be confused with CNPJ, which is for legal entities (businesses).
CNPJ has 14 digits and follows the format 05.928.773/0001-56.""",
        alias="CPF:"
    )
    
    occupation: str = Field(
        description="Occupation or job title", 
        example="Analista Financeiro",
        alias="Cargo:"
        )
    
    since_when_occupation: str = Field(
        description="Date the employee started the occupation. Respond in the format DD/MM/YYYY",
        example="15/06/2020",
        alias="Data de inicío:"
    )
    
    emission_date: str = Field(
        description="Emission date, in the format 25/02/2025",
        example="25/02/2025",
        alias="Data de Emissão:"     
    )   
    
    average_monthly_income: str = Field(
        description="Average monthly income in Brazilian Real (BRL)",
        example="5000,75",
        alias="Renda Mensal Média:"
    )