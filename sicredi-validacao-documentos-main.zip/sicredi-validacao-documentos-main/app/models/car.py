from pydantic import BaseModel, Field
from typing import Dict
class CAR(BaseModel):
    car_registration: str = Field(
        description="CAR registration code, including UF prefix.",
        example="MG-3101607-EC7C.23D3.1604.4478.8C9C.D354.E7D4.D58E",
        alias="Registro no CAR:"
    )

    rural_property_name: str = Field(
        description="Name of the rural property.",
        example="Fazenda Boa Esperança",
        alias="Nome do Imóvel Rural:"
    )

    municipality: str = Field(
        description="Municipality where the property is located.",
        example="Patos de Minas",
        alias="Município:"
    )

    uf: str = Field(
        description="State (UF).",
        example="MG",
        alias="UF:"
    )

    total_area: str = Field(
        description="Total area of the rural property in CAR.",
        example="52,30 ha",
        alias="Área Total do Imóvel Rural:"
    )

    protocol_code: str = Field(
        description="Protocol code from CAR.",
        example="1234567890",
        alias="Código do Protocolo:"
    )

    consolidated_area: str = Field(
        description="Consolidated area from the CAR certificate.",
        example="22,10 ha",
        alias="Área Consolidada:"
    )

    registry_numbers: list = Field(
        description="List of registry (matrícula) numbers.",
        example=["123456 55 2021 1 00012 999 333", "987654 22 2011 1 00002 111 333"],
        alias="Números das Matrículas:"
    )

    owners: Dict[str, Dict[str, str]] = Field(
        description="Owners of the property with their CPFs.",
        example={
            "Proprietario 1": {"Nome": "José Almeida", "CPF": "111.111.111-11"},
            "Proprietario 2": {"Nome": "Cláudia Martins", "CPF": "222.222.222-22"}
        },
        alias="Proprietários:"
    )
