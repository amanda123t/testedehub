from typing import Dict, List, Optional
from pydantic import BaseModel, Field


class Contract(BaseModel):
    title: str = Field(
        description="Title that summarizes the purpose of the contract amendment. Usually found at the beginning of the document.",
        examples=["ALTERAÇÃO CONTRATUAL Nº 1 DA SOCIEDADE LTDA"],
        alias="Título",
    )
    cnpj: str = Field(
        description="CNPJ (Cadastro Nacional da Pessoa Jurídica): the company’s tax ID in Brazil. Format: 12.345.678/0001-90.",
        examples=["12.345.678/0001-90"],
        alias="CNPJ",
    )
    legal_name: str = Field(
        description="The company’s registered legal name. Corresponds to 'Razão Social'.",
        examples=["SOCIEDADE LTDA"],
        alias="Razão Social",
    )
    trade_name: str = Field(
        description="The trade name used by the company in public dealings. Corresponds to 'Nome Fantasia'.",
        examples=["SOCIEDADE"],
        alias="Nome Fantasia",
    )
    address: str = Field(
        description="Full address of the company. Corresponds to the field labeled 'Endereço'.",
        examples=["Rua dos Bobos, 0"],
        alias="Endereço",
    )
    footer: str = Field(
        description="Footer information containing registration number and amendment date. Usually located at the bottom of the document.",
        alias="Rodapé",
    )
    partners: List[Dict[str, str]] = Field(
        description="List of company partners. Return name, CPF (Cadastro de Pessoa Física), and share capital for each partner.",
        examples=[
            {"NOME": "John Doe", "CPF": "123.456.789-00", "Capital": "R$ 100,00"}
        ],
        alias="Sócios",
    )
    representation: str = Field(
        description="Company representation details, including managing partners, administrators, or owners. Corresponds to 'Representação'.",
        alias="Representação",
    )
    joint_debtors: List[str] = Field(
        description="List of joint debtors, including managing partners, administrators, owners, and partners holding 50% or more of the capital. Corresponds to 'Devedores Solidários'.",
        alias="Devedores Solidários",
    )
    company_type: str = Field(
        description="Type of company headquarters: either 'Matriz' (main office) or 'Filial' (branch).",
        alias="Tipo de Empresa",
    )
    company_size: str = Field(
        description="Company size (porte): MEI, Microempresa, Empresa de Pequeno Porte, Média Empresa, or Grande Empresa.",
        alias="Porte",
    )
    subgroup: str = Field(
        description="Subgroup classification of the company, if applicable.",
        alias="Subgrupo",
    )
    capital_composition: Dict[str, str] = Field(
        description="Capital composition by partner. Return as a mapping of partner name to percentage ownership. Corresponds to 'Composição de Capital'.",
        examples=[{"John Doe": "50%", "Jane Smith": "50%"}],
        alias="Composição de Capital",
    )
    new_member: Optional[List[str]] = Field(
        description="List of new members joining the company. Corresponds to 'Sócio Ingressante'.",
        alias="Sócio Ingressante",
    )
    member_out: Optional[List[str]] = Field(
        description="List of members who have left the company. Corresponds to 'Sócio que Saiu'.",
        alias="Sócio que Saiu",
    )
    cnae: str = Field(
        description="CNAE (Classificação Nacional de Atividades Econômicas) code that identifies the company's main business activity. Format: numeric. Leave blank if not available.",
        examples=["62.01-5/01"],
        alias="CNAE",
    )
    updates: Dict[str, str] = Field(
        description="Contractual updates. Return a mapping where keys are clauses and values are the updated content. Corresponds to 'Atualizações'.",
        examples={"Cláusula Segunda": "Objeto social alterado para incluir consultoria em TI"},
        alias="Atualizações",
    )
