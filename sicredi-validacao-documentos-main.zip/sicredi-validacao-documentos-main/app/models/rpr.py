from pydantic import BaseModel, Field
from typing import List


class RuralProperties(BaseModel):
    registration_number: str = Field(
        description="Property registration number. You can find under 'Matrícula' in the document.",
        example=["R.3/4.561 CIB/NIRF:2.055.742-6"],
        alias="Matrícula",
    )
    description_car: str = Field(
        description="Description of the rural property. You can find under 'Descrição' in the document.",
        example=["Don Alvaro - Própria CAR: "],
        alias="Descrição",
    )
    locality: str = Field(
        description="Locality of the rural property. You can find under 'Localidade' in the document.",
        example=["HERVAL/ RS"],
        alias="Localidade",
    )
    total_area: str = Field(
        description="Total area of the rural property. You can find under 'Área Total' in the document.",
        example=["100.98 ha"],
        alias="Área Total",
    )
    cultivated_area: str = Field(
        description="Cultivated area of the rural property. You can find under 'Área Explorada' in the document.",
        example=["50.00 ha"],
        alias="Área Explorada",
    )
    property_status: str = Field(
        description="Status of the rural property. You can find under 'Situação do imóvel' in the document.",
        example=["Própio 100%"],
        alias="Situação do imóvel",
    )
    assessment: str = Field(
        description="Assessment of the rural property. You can find under 'Avaliação' in the document.",
        example=["Vencto: 21/05/2024 Valor Avaliação: R$ 100.000,00"],
        alias="Avaliação",
    )

class Livestock(BaseModel):
    species: str = Field(
        description="Species of the livestock. You can find under 'Espécie' in the document.",
        examples=["Bovinos Carne"],
        alias="Espécie",
    )
    description: str = Field(
        description="Description of the livestock. You can find under 'Descrição' in the document.",
        examples=["Macho"],
        alias="Descrição",
    )
    age: str = Field(
        description="Age in months of the livestock. You can find under 'Idade' in the document.",
        examples=["0-12"],
        alias="Idade",
    )
    breed: str = Field(
        description="Breed of the livestock. You can find under 'Raça' in the document.",
        examples=["SRD"],
        alias="Raça",
    )
    quantity: str = Field(
        description="Quantity of the livestock. You can find under 'Quantidade' in the document.",
        examples=["10"],
        alias="Quantidade",
    )
    unit_value: str = Field(
        description="Unit value of the livestock. You can find under 'Valor Unit.' in the document.",
        examples=["R$ 1.000,00"],
        alias="Valor Unitário",
    )
    total_value: str = Field(
        description="Total value of the livestock. You can find under 'Valor Total' in the document.",
        examples=["R$ 10.000,00"],
        alias="Valor Total",
    )

class MachinesEquipments(BaseModel):
    name_description: str = Field(
        description="Name or description of the machine or equipment.",
        examples=["Trator John Deere 5075E"],
        alias="Nome/Descrição",
    )
    type: str = Field(
        description="Type of the machine or equipment.",
        examples=["Máquinas e Equipamentos"],
        alias="Tipo",
    )
    brand: str = Field(
        description="Brand of the machine or equipment.",
        examples=["Renault"],
        alias="Marca",
    )
    year: str = Field(
        description="Year of manufacture of the machine or equipment.",
        examples=["2020"],
        alias="Ano",
    )
    assesment_value: str = Field(
        description="Assessment value of the machine or equipment.",
        examples=["R$ 50.000,00"],
        alias="Valor da Avaliação",
    )
    garantee: str = Field(
        description="Guarantee associated with the machine or equipment. Can be 'Sim' or 'Não'.",
        examples=["Sim"],
        alias="Garantia",
    )
    
class UrbanProperties(BaseModel):
    registration_number: str = Field(
        description="Property registration number. You can find under 'Matrícula' in the document.",
        example=["R.3/4.561 CIB/NIRF:2.055.742-6"],
        alias="Matrícula",
    )
    description: str = Field(
        description="Description of the urban property. You can find under 'Descrição' in the document.",
        example=["Casa na cidade"],
        alias="Descrição",
    )
    locality: str = Field(
        description="Locality of the urban property. You can find under 'Localidade' in the document.",
        example=["HERVAL/ RS"],
        alias="Localidade",
    )
    property_status: str = Field(
        description="Status of the urban property. You can find under 'Situação do imóvel' in the document.",
        example=["Próprio 100%"],
        alias="Situação do imóvel",
    )    
    assessment: str = Field(
        description="Assessment of the urban property. You can find under 'Avaliação' in the document.",
        alias="Avaliação",
    )
    
class Income(BaseModel):
    type: str = Field(
        description="Type of income.",    
        examples=["Renda Prevista", "Renda Obtida", "Receita Obtida"],
        alias="Tipo de Receita",
    )
    culture_activity: str = Field(
        description="Culture or activity associated with the income.",
        examples=["Soja", "Milho", "Bovinos para corte"],
        alias="Cultura/Atividade",
    )
    season: str = Field(
        description="Season associated with the income.",
        examples=["2023/2024", "2022/2023"],    
        alias="Safra",
    )
    year: str = Field(
        description="Year associated with the income.",
        examples=["2023", "2024"],
        alias="Ano",
    )
    quantity: str = Field(
        description="Quantity associated with the income. You can find under 'Quantidade Área/Animal' in the document.",
        examples=["120", "100"],
        alias="Quantidade Área/Animal",
    )
    unit_production: str = Field(
        description="Unit of production associated with the income. You can find under 'Produção Unitária' in the document.",
        examples=["300"],
        alias="Produção Unitária",
    )
    unit_value: str = Field(
        description="Unit value associated with the income. You can find under 'Valor Unitário' in the document.",  
        examples=["R$ 100,00", "R$ 150,00"],
        alias="Valor Unitário",
    )
    total_gross_revenue: str = Field(
        description="Total gross revenue associated with the income. You can find under 'Receita Bruta Total' in the document.",
        examples=["R$ 12.000,00", "R$ 15.000,00"],
        alias="Receita Bruta Total",
    )
    estimated_projected_cost: str = Field(
        description="Estimated or projected cost associated with the income. You can find under 'Custo - Estimado/Projetado' in the document.",
        examples=["R$ 8.000,00", "R$ 10.000,00"],
        alias="Custo Estimado/Projetado",
    )
    local_revenue: str = Field(
        description="Local revenue associated with the income. You can find under 'Receita Local' in the document.",    
        examples=["R$ 10.000,00", "R$ 12.000,00"],
        alias="Receita Local",
    )

class Expenses(BaseModel):
    year: str = Field(
        description="Year associated with the expenses.",
        examples=["2023", "2024"],
        alias="Ano",
    )
    type: str = Field(
        description="Type of expenses.",
        examples=["Custo de Produção", "Despesas Gerais"],
        alias="Tipo de Despesa",
    )
    value: str = Field(
        description="Value of the expenses.",   
        examples=["R$ 5.000,00", "R$ 3.000,00"],
        alias="Valor",
    ) 
    
class RPR(BaseModel):
    name: str = Field(
        description="Producer's Name.",
        example=["João da Silva"],
        alias="Nome",
    )
    data: str = Field(
        description="Report Issuance Date. Format: DD/MM/YYYY",
        example=["01/01/2023"],
        alias="Data de emissão",
    )
    cpf: str = Field(
        description="CPF number of the producer. Format: XXX.XXX.XXX-XX",
        example=["123.456.789-00"],
        alias="CPF",
    )
    rural_properties: List[RuralProperties] = Field(
        description="List of rural properties associated with the producer.",
        example=[
            {
                "Matrícula": "R.3/4.561 CIB/NIRF:2.055.742-6",
                "Descrição": "Don Alvaro - Própria CAR: ",
                "Localidade": "HERVAL/ RS",
                "Área Total": "100.98 ha",
                "Área Explorada": "50.00 ha",
                "Situação do imóvel": "Própio 100%",
                "Avaliação": "Vencto: 21/05/2024 Valor Avaliação: R$ 100.000,00"
            }
        ],
        alias="Imóveis Rurais",
    )
    livestock: List[Livestock] = Field(
        description="List of livestock associated with the producer.",
        example=[
            {
                "Espécie": "Bovinos Carne",
                "Descrição": "Macho",
                "Idade": "0-12",
                "Raça": "SRD",
                "Quantidade": "10",
                "Valor Unitário": "R$ 1.000,00",
                "Valor Total": "R$ 10.000,00"
            }
        ],
        alias="SEMOVENTES",
    )
    machines_equipments: List[MachinesEquipments] = Field(
        description="List of machines and equipment associated with the producer.",
        example=[
            {
                "Nome/Descrição": "Trator John Deere 5075E",
                "Tipo": "Máquinas e Equipamentos",
                "Marca": "Renault",
                "Ano": "2020",
                "Valor da Avaliação": "R$ 50.000,00",
                "Garantia": "Sim"
            }
        ],
        alias="MÁQUINAS E EQUIPAMENTOS",
    )
    urban_properties: List[UrbanProperties] = Field(
        description="List of urban properties associated with the producer.",
        example=[
            {
                "Matrícula": "R.3/4.561 CIB/NIRF:2.055.742-6",
                "Descrição": "Casa na cidade",
                "Localidade": "HERVAL/ RS",
                "Situação do imóvel": "Próprio 100%",
                "Avaliação": "R$ 150.000,00"
            }
        ],
        alias="IMÓVEIS URBANOS",
    )
    estimated_revenues: List[Income] = Field(
        description="List of estimated revenues associated with the producer.",
        example=[
            {
                "Tipo de Receita": "Renda Prevista",
                "Cultura/Atividade": "Soja",
                "Safra": "2023/2024",
                "Ano": "2023",
                "Quantidade Área/Animal": "120",
                "Produção Unitária": "300",
                "Valor Unitário": "R$ 100,00",
                "Receita Bruta Total": "R$ 12.000,00",
                "Custo Estimado/Projetado": "R$ 8.000,00",
                "Receita Local": "R$ 10.000,00"
            }
        ],
        alias="Rendas Previstas",
    )
    effective_income: str = Field(
        description="Effective income of the producer. You can find under 'Renda Efetiva' in the document.",
        example=["R$ 20.000,00"],
        alias="Rendas Efetivas",
    ) 
    expenses: List[Expenses] = Field(
        description="List of expenses associated with the producer.",
        example=[
            {
                "Ano": "2023",
                "Tipo de Despesa": "Custo de Produção",
                "Valor": "R$ 5.000,00"
            }
        ],
        alias="Despesas",
    )
    