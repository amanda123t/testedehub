from pydantic import BaseModel, Field


class Gleba(BaseModel):
    area: str = Field(
        description="Area of the gleba (parcel).",
        example="12,5 ha",
        alias="Área da Gleba:"
    )

    description: str = Field(
        description="Description of the gleba.",
        example="Área de pastagem situada ao norte da sede.",
        alias="Descrição:"
    )


class MunicipalityArea(BaseModel):
    municipality: str = Field(
        description="Municipality name.",
        example="Carazinho",
        alias="Município:"
    )

    uf: str = Field(
        description="State (UF).",
        example="RS",
        alias="UF:"
    )

    area: str = Field(
        description="Area in the municipality.",
        example="32,10 ha",
        alias="Área (ha):"
    )

    percentage: str = Field(
        description="Percentage of total area located in this municipality.",
        example="61%",
        alias="% Área:"
    )

class Croqui(BaseModel):
    cooperative: str = Field(
        description="Cooperative responsible for the croqui.",
        example="Sicredi Alto Uruguai RS/SC/MG",
        alias="Cooperativa:"
    )

    sketch_date: str = Field(
        description="Date of the croqui document.",
        example="14/07/2024",
        alias="Data do Croqui:"
    )

    sketch_code: str = Field(
        description="Sketch/Croqui identification code.",
        example="CRQ-2024-000123",
        alias="Código do Croqui:"
    )

    member_name: str = Field(
        description="Name of the associated member.",
        example="João Batista de Souza",
        alias="Nome:"
    )

    activity: str = Field(
        description="Crop, culture or activity being financed.",
        example="Suinocultura",
        alias="Cultura / Atividade:"
    )

    financed_total: str = Field(
        description="Total animals or financed area.",
        example="350 animais",
        alias="Total de Animais / Área Financiada:"
    )

    access_route: str = Field(
        description="Access route guidance.",
        example="Entrada pela BR-386, km 230, virar à esquerda na linha São Pedro.",
        alias="Roteiro de Acesso:"
    )

    glebas_count: int = Field(
        description="Number of glebas (parcels).",
        example=3,
        alias="Número de Glebas:"
    )

    total_area: str = Field(
        description="Total area of the property.",
        example="52,20 ha",
        alias="Área Total:"
    )

    net_area: str = Field(
        description="Net usable area.",
        example="47,00 ha",
        alias="Área Líquida:"
    )

    glebas: list[Gleba] = Field(
        description="List of glebas (parcels).",
        alias="Glebas:"
    )

    municipalities: list[MunicipalityArea] = Field(
        description="List of municipalities involved in the area.",
        alias="Municípios:"
    )
