from pydantic import BaseModel, Field

class PresumedBilling(BaseModel):
    company: str = Field(
        description="Razão social ou nome da empresa",
        example="Tomografia Vilhena Ltda",
        alias="Nome:"
    )
    cnpj: str = Field(
        description="CNPJ da empresa",
        example="11.185.259/0001-70",
        alias="CNPJ:"
    )
    city: str = Field(
        description="Cidade da empresa",
        example="Primavera do Leste",
        alias="Cidade:"
    )
    uf: str = Field(
        description="UF do estado da empresa",
        example=["RS", "PA", "RJ", "RO"],
        alias="UF:"
    )
    presumed_billing: str = Field(
        description="Valor do faturamento presumido anual, formatado como R$00.000,00",
        example="R$ 579.000,00",
        alias="Faturamento Presumido Anual"
    )
    date: str = Field(
        description="Data de emissão do documento, no formato dd/mm/aaaa hh:mm",
        examples= "11/05/2024 16:49",
        alias= "Data de emissão:"
        )
