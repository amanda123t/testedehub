from typing import List, Optional
from pydantic import BaseModel, Field


class Representative(BaseModel):
    name: str = Field(description="Name of the representative", alias="Nome")
    role: Optional[str] = Field(description="Role of the representative", alias="Cargo")

class Minute(BaseModel):
    cnpj: Optional[str] = Field(
        description="The CNPJ (Cadastro Nacional da Pessoa Jurídica) is the registration number of a company or entity with the Brazilian Federal Revenue Service.",
        examples="12.345.678/0001-90",
        alias="CNPJ",
    )
    # razão social
    legal_name: str = Field(
        description="The legal name of the company",
        examples="SOCIEDADE LTDA",
        alias="Nome:",
    )
    # nome fantasia
    trade_name: str = Field(
        description="The trade name a company uses to identify itself to the public",
        examples="SOCIEDADE",
        alias="Nome Fantasia",
    )
    address: str = Field(
        description="The address of the company",
        examples="Rua dos Bobos, 0",
        alias="Endereço",
    )
    meeting_date: str = Field(
        description="The date of the meeting. Return the format dd/mm/yyyy",
        alias="Data da Reunião",
    )
    # Representantes com cargos
    representatives: List[Representative] = Field(
        description="List of representatives with their roles", 
        examples=[
            {"Nome": "Augusto Lauro sw Oliveira Júnior", "Cargo": "Presidenter"},
            {"Nome": "Luciano Adures de Oliveira", "Cargo": "Vice-Presidente"}
        ],
        alias="Representantes"
    )
    # Ano do mandato
    mandate_year: str = Field(
        description="The year of the mandate", alias="Ano do Mandato"
    )
    # Data de início e data de fim
    start_end_date: str = Field(
        description="Start and end date of the mandate. Return the format dd/mm/yyyy - dd/mm/yyyy",
        alias="Data de Início e Fim",
    )
    # registro/autenticação em cartório
    notorial_registration: str = Field(
        description="The notorial name", alias="Registro/Autenticação em Cartório"
    )
    