from pydantic import BaseModel, Field
from typing import Optional

class CNH(BaseModel):
    name: str = Field(
        description="Full name.",
        alias="Nome:"
    )

    identity: str = Field(
        description="Identity document, issuing authority, and state.",
        alias="Identidade:"
    )

    informations_birth: Optional[str] = Field(
        description=(
            "Return this field ONLY if the document contains the explicit field "
            "'Data, local e UF de nascimento'.\n\n"
            "This value must come EXACTLY from that field and must NOT be inferred "
            "from any other place in the document.\n\n"
            "⚠️ Forbidden sources: 'Local', 'Local do documento', 'Data de emissão', "
            "document footer, header, or any other unrelated text.\n\n"
            "If the field does NOT exist, return an EMPTY STRING ('')."
        ),
        alias="Data, local e UF de nascimento:"
    )

    birth_date: Optional[str] = Field(
        description=(
            "Return this field whenever the document explicitly contains the field "
            "'Data de nascimento:'.\n\n"
            "⚠️ This field must ALWAYS be extracted if present — even if the field "
            "'Data, local e UF de nascimento' also exists.\n\n"
            "If the field does NOT exist in the document, return an EMPTY STRING ('')."
        ),
        alias="Data de nascimento:"
    )

    cpf: str = Field(
        description="CPF with format xxx.xxx.xxx-xx.",
        alias="CPF:"
    )

    parents: str = Field(
        description="Parents' names ('filiação').",
        alias="Filiação:"
    )

    cnh: str = Field(
        description="CNH number ('Nº Registro'), 11 digits.",
        alias="CNH:"
    )

    expiration_date: str = Field(
        description="Expiration date (Validade).",
        alias="Validade:"
    )

    nationality: Optional[str] = Field(
        description="Nationality.",
        alias="Nacionalidade"
    )

    place_document: Optional[str] = Field(
        description=(
            "Place of DOCUMENT emission. "
            "⚠️ MUST NEVER be used as birthplace under any circumstance."
        ),
        alias="Local do documento"
    )

    emition_date: Optional[str] = Field(
        description="Document emission date.",
        alias="Data de emissão"
    )
