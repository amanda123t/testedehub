from pydantic import BaseModel, Field
from typing import Dict, List, Optional

class IR_Receipt(BaseModel):
    header: str = Field(
        description="It indicates that the document is related to the Imposto de Renda de Pessoa Física (IRPF), "
        "and that the declaration will be made in the current year, based on the income earned in the previous year. "
        "It also mentions that the Ministério da Fazenda and the Receita Federal are the authorities responsible for managing and overseeing the process.",
        example=[
            "NOME: Beltrana de Souza; CPF: 987.654.321.01; DECLARAÇÃO DE AJUSTE ANUAL; IMPOSTO SOBRE A RENDA - PESSOA FÍSICA EXERCÍCIO 2025; ANO-CALENDÁRIO 2024",
            "NOME: Fulano da Silva; CPF: 123.456.789-10; DECLARAÇÃO DE AJUSTE ANUAL; IMPOSTO SOBRE A RENDA - PESSOA FÍSICA EXERCÍCIO 2024; ANO-CALENDÁRIO 2023",
        ],
        alias="Cabeçalho",
    )
    title: Optional[str] = Field(
        description=(
            "Type of declaration. It must be exactly one of the following, based on what "
            "appears **literally** in the document text:\n"
            "- 'DECLARAÇÃO ORIGINAL'\n"
            "- 'DECLARAÇÃO RETIFICADORA N° X'\n\n"
            "If the text does not contain either of these phrases, leave this field as null. "
            "Do not assume or infer the type — only extract what is explicitly written. "
            "The title usually appears near the top, close to 'RECIBO DE ENTREGA DA DECLARAÇÃO DE AJUSTE ANUAL', "
            "even if there are other words like 'OPÇÃO PELO DESCONTO SIMPLIFICADO' between them."
            "Never return an amended declaration without the number. If it does not have the number next to it, return it blank."
        ),
        examples=[
            "DECLARAÇÃO ORIGINAL",
            "DECLARAÇÃO RETIFICADORA No 1",
            "DECLARAÇÃO RETIFICADORA No 2",
            "DECLARAÇÃO RETIFICADORA No 3",
        ],
        alias="Título",
    )
    calendar_year: str = Field(
        description=(
            "Calendar year shown immediately after the token 'ANO-CALENDÁRIO' in the header. "
            "Extract this exact 4-digit year from the header text only. "
            "Ignore any other years mentioned elsewhere (including patrimonial dates like 31/12/20XX). "
            "Example: if the header says 'EXERCÍCIO 2024; ANO-CALENDÁRIO 2023', then calendar_year is 2023. "
            "The calendar_year must be exactly one year less than exercise_year."
        ),
        examples=['2022', '2023', '2024'],
        alias="Ano-Calendário",
    )


    name: str = Field(
        description="Taxpayer's full name",
        alias="Nome"
    )
    cpf: str = Field(
        description="""CPF (Cadastro de Pessoas Físicas) is the taxpayer identification number for individuals in Brazil. It should have 11 digits in the format 123.456.789-10.  Example: 123.456.789-10.
        It should not be confused with CNPJ, which is for legal entities (businesses).
        CNPJ has 14 digits and follows the format 05.928.773/0001-56.""",
        examples=['879.945.124-48', '123.456.789-10', '496.548.749-66'],
        alias="CPF",
    )
    total_taxable_income: str = Field(
        description="TOTAL TAXABLE INCOME.",
        alias="Total rendimentos tributaveis"
    )
    tax_due : str = Field(
        description="tax due, you can find as 'IMPOSTO DEVIDO'.",
        alias="Imposto devido"
    )
    tax_refunded : str = Field(
        description="tax to be refunded, you can find as 'IMPOSTO A RESTITUIR'.",
        alias="Imposto a restituir"
    )
    tax: str = Field(
        description="balance of tax to be paid, you can find as 'SALDO DO IMPOSTO A PAGAR'.",
        alias="Saldo do imposto a pagar"
    )
    tax_capital: str = Field(
        description="balance of tax to be paid - capital gain, you can find as 'SALDO DO IMPOSTO A PAGAR - GANHO DE CAPITAL'.",
        alias="Saldo do imposto a pagar - ganho de capital"
    )




