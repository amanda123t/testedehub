from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from pydantic import BaseModel, Field

class Recibo_PGDAS(BaseModel):
    company: str = Field(
        description="Registered company name. Corresponds to the field labeled 'Empresa'.",
        alias="Nome",
    )
    cnpj: str = Field(
        description="Main corporate tax ID (CNPJ). Format: 12.345.678/0001-90. Corresponds to 'CNPJ Matriz'.",
        examples=["12.345.678/0001-90"],
        alias="CNPJ Matriz",
    )
    branches_cnpj: Optional[List[str]] = Field(
        description="List of branch CNPJs. Format: 12.345.678/0001-90. Corresponds to 'CNPJ Filiais'.",
        examples=["12.345.678/0001-90", "98.765.432/0001-01"],
        alias="CNPJ Filiais",
    )
    opening_date: str = Field(
        description="Company’s official opening date. Format: dd/mm/yyyy. Corresponds to 'Data de Abertura'.",
        examples=["01/01/2000"],
        alias="Data de Abertura",
    )
    period: str = Field(
        description="Covered reporting period. Format: mm/yyyy. Corresponds to 'Período de apuração'.",
        alias="Período de Apuracao",
    )
    number: str = Field(
        description="Election Number",
        examples= '19361531202509001',
        alias="Numero da Apuracao"
    )
    optant_simples: str = Field(
        description="Opting for the simplified national tax regime, yes or no.",
        examples= ['Sim', 'Não'],
        alias="Optante pelo simples"
    )
    gross_revenue: str = Field(
        description="Total gross revenue. Format: R$0.000,00. Corresponds to the field labeled 'Receita Bruta Total'.",
        alias="Receita Bruta Total",
    )
    datetime: str = Field(
        description="Date and time of submission. Format: dd/mm/yyyy HH:MM:SS. Corresponds to 'Data e Horário da Transmissão da Declaração'.",
        alias="Data e Horário",
    )
    