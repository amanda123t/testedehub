from pydantic import BaseModel, Field
from typing import Optional, Dict

class WorkContract(BaseModel):
    establishment_info: str = Field(
        description="Establishment name, CNPJ and address (usually appears together).",
        example="EMPRESA ABC LTDA - CNPJ 11.222.333/0001-44 - Rua X, 123",
        alias="Estabelecimento - CNPJ - Endereço:"
    )

    position: str = Field(
        description="Position or job title.",
        example="Auxiliar Administrativo",
        alias="Cargo:"
    )

    cbo: str = Field(
        description="CBO (Brazilian Occupation Code).",
        example="4110-10",
        alias="CBO:"
    )

    contract_type: str = Field(
        description="Type of employment contract.",
        example="Contrato Prazo Indeterminado",
        alias="Tipo de Contrato:"
    )

    salary: str = Field(
        description="Contractual salary.",
        example="R$ 2.500,00",
        alias="Salário Contratual:"
    )

    work_relation: str = Field(
        description="Type of work relation.",
        example="Empregado",
        alias="Relação de Trabalho:"
    )

class WorkCard(BaseModel):
    civil_name: str = Field(
        description="Worker's civil name.",
        example="João da Silva",
        alias="Nome:"
    )

    cpf: str = Field(
        description="Worker's CPF.",
        example="123.456.789-00",
        alias="CPF:"
    )

    sex: Optional[str] = Field(
        description="Biological sex of the worker.",
        example="Masculino",
        alias="Sexo:"
    )

    birth_date: Optional[str] = Field(
        description="Worker's birth date in DD/MM/YYYY format.",
        example="15/08/1990",
        alias="Data de Nascimento:"
    )

    work_contracts: Dict[str, WorkContract] = Field(
        description=(
            "Work contracts indexed by date. "
            "Each key is the contract reference date (DD/MM/YYYY), "
            "and each value is a WorkContract object."
        ),
        example={
            "01/02/2020": {
                "Estabelecimento - CNPJ - Endereço:": "EMPRESA ABC LTDA - CNPJ 11.222.333/0001-44 - Rua Teste, 123",
                "Cargo:": "Auxiliar Administrativo",
                "CBO:": "4110-10",
                "Tipo de Contrato:": "Indeterminado",
                "Salário Contratual:": "R$ 2.500,00",
                "Relação de Trabalho:": "Empregado"
            }
        },
        alias="Contratos de Trabalho:"
    )
