from pydantic import BaseModel, Field
from typing import List, Dict, Optional

class Address(BaseModel):
    type: str = Field(
        description="Type of address (e.g., AVENIDA, RUA, FAZENDA).",
        example=["AVENIDA", "RUA", "RODOVIA"],
        alias="Tipo:"
    )
    street: str = Field(
        description="Street, avenue, or other public place name.",
        example="ANTONIO FERREIRA SOBRINHO",
        alias="Logradouro:"
    )
    number: str = Field(
        description="Address number.",
        example=["3117", "LOTE 10","SN", "0"],
        alias="Número:"
    )
    complement: Optional[str] = Field(
        description="address complement.",
        example="Lote 5 quadra 2",
        alias="Complemento:"
    )
    neighborhood: str = Field(
        description="Neighborhood name.",
        example="CENTRO",
        alias="Bairro:"
    )
    state: str = Field(
        description="State abbreviation (UF) of the address.",
        example="MT",
        alias="UF:"
    )
    cep: str = Field(
        description="address zip code, return in format xx.xxx-xxx",
        example="93.224-170",
        alias="CEP:"
    )

class Certificado_MEI(BaseModel):
    civil_name: str = Field(
        description="civil name.",
        alias="Nome Civil:"
    )
    cpf: str = Field(
        description="The CPF(Cadastro Pessoa Física) with eleven digits in format xxx.xxx.xxx-xx.",
        alias="CPF"
    )

    document: str = Field(
        description="The CNPJ(Cadastro Nacional da Pessoa Jurídica) is the registration number of a company or entity with the Brazilian Federal Revenue Service.",
        examples="01.000.025/0001-00",
        alias="CNPJ:"
    )

    opening_date: str = Field(
        description="company opening date, return in format dd/mm/aaaa",
        examples={"11/08/2021", "01/03/2024"},
        alias="Data de abertura:"
    )

    name: str = Field(
        description="Full name of the company name associated with the document.",
        example={"Mercado de alimentos LTDA"},
        alias="Nome:"
    )
    share_capital: str = Field(
        description="Declared share capital of the company.",
        example="344.122,00",
        alias="Capital social:"
    )
        
    trade_name: str = Field(
        description="company trade name",
        example="Mercadinho",
        alias="Nome Fantasia:"
    )  
    situation: str = Field(
        description="Income status of the person or company. You can find as 'Situação cadastral vigente'",
        example=["Ativa", "Inativa", "Regular", "Pendente de Regularização"],
        alias="Situacao cadastral vigente:"
    )

    address: Address = Field(
        description="Main address of the company.",
        alias="Endereço:"
    )
    method_operation: str = Field(
        description="method of operation.",
        alias="Forma de Atuação:"
    )
    main_occupation: str = Field(
        description="main occupation.",
        alias="Ocupação principal:"
    )
    main_activity: str = Field(
        description="code and description of the main economic activity, you can find as 'Atividade Principal (CNAE)'.",
        example=["C5487789 - Comercio varejista de bebidas", "5611201 - Restaurantes e similares"],
        alias="CNAE:"
    )
    current_situation: str = Field(
        description="current situation.",
        examples="Enquadrado na condição de MEI",
        alias="Situação Atual:"
    )
    extraction_date: Optional[str] = Field(
        description="Date and time when the document was extracted, in the format DD/MM/YYYY.",
        example="25/02/2025",
        alias="Data de Extração:"
    )

