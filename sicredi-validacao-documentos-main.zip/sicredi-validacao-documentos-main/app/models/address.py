from pydantic import BaseModel, Field

class Address(BaseModel):
    name: str = Field(
        description="Full name of the person registered on the account.",
        example="João da Silva",
        alias="Nome:"
    )
    
    information: str = Field(
        description="This is a formatted address, including the street name, number, neighborhood or region, and postal code",
        example="RUA ITAJUBA, 10 - 0020513399000 - CPA I - QD 03 - 78058000",
        alias="Informações:"	
    )
    
    agency: str = Field(
        description="Indicates the service region or neighborhood, sometimes including a bank branch reference (e.g., AG: 4). Can be the name of the Company too",
        example=["PARQUE GEORGIA COXIPÓ DA PONTE (AG: 4)", "Vivo"],
        alias="Agência:"
    )
    
    reference_period: str = Field(
        description="Month and year to which the data or information refer. Convert to the format mm/yyyy.",
        alias="Período de Referência:"
    )