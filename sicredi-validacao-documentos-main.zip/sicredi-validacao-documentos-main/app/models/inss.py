from pydantic import BaseModel, Field
from typing import List

class INSS(BaseModel):
    
    name: str = Field(
        description="Full name of the individual associated with the document.",
        example="João da Silva",
        alias="Nome:"
    )
    
    title: str = Field(
        description="INSS benefit statement.",
        example="Demonstrativo de Crédito de Benefícios",
        alias="Título:"
    )
    
    payer: str = Field(
        description="Entity responsible for the payment.",
        example="Instituto Nacional do Seguro Social",
        alias="Fonte Pagadora:"
    )
    
    competence: str = Field(
        description="Reference month and year of the payment, formatted as MM/YYYY.",
        example="09/2023",
        alias="Competência:"
    )
    
    payment: str = Field(
        description="Total amount received, labeled as 'Valor Total Renda Mensal' in the document.",
        example="4033.36",
        alias="Valor:"
    )

    nb: str = Field(
        description="NB is the acronym for INSS Benefit Number. It is a 10-digit code that identifies each social security benefit.",
        examples="1099655258",
        alias = "NUMERO DO NB:"
    )
    
class INSSList(BaseModel):
    receipt: List[INSS] = Field(
        description="List of receipts. There are one or more receipts in the context, bring all of them.",
        alias="Recibos:"
        )