from pydantic import BaseModel, Field


class FipeTable(BaseModel):
    reference_month: str = Field(
        description="Reference month of the FIPE table.",
        example="Outubro/2024",
        alias="Mês de Referência:"
    )

    fipe_code: str = Field(
        description="FIPE code that identifies the vehicle model.",
        example="001267",
        alias="Código FIPE:"
    )

    brand: str = Field(
        description="Vehicle brand.",
        example="Toyota",
        alias="Marca:"
    )

    model: str = Field(
        description="Vehicle model.",
        example="Corolla XEi 2.0",
        alias="Modelo:"
    )

    model_year: str = Field(
        description="Model year of the vehicle.",
        example="2021",
        alias="Ano Modelo:"
    )

    consultation_date: str = Field(
        description="Date of the FIPE consultation.",
        example="10/10/2024",
        alias="Data da Consulta:"
    )

    average_price: str = Field(
        description="Average market price of the vehicle per FIPE.",
        example="R$ 98.500,00",
        alias="Preço Médio:"
    )
