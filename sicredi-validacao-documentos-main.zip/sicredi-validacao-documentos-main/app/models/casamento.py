from pydantic import BaseModel, Field
from typing import Optional, Dict


class Casamento(BaseModel):
    spouses: Dict[str, Dict[str, str]] = Field(
        description="Full names and CPFs of both spouses before the marriage. Dictionary with person identifiers as keys.",
        example={
            "Conjuge 1": {"Nome": "JOÃO DA SILVA", "CPF": "111.111.111-11"},
            "Conjuge 2": {"Nome": "MARIA DA ROSA", "CPF": "222.222.222-22"}
        },
        alias="Nomes:"
    )

    adopted_names: Optional[str] = Field(
        description="Names adopted after the marriage. Often appears as unified new names.",
        example="JOÃO DA SILVA E MARIA DA ROSA",
        alias="Nomes que passaram a utilizar:"
    )

    marriage_date: str = Field(
        description="Marriage date in DD/MM/YYYY format.",
        example="12/05/2012",
        alias="Data do Casamento:"
    )

    registration_number: str = Field(
        description="Official certificate registry number (matrícula), longer than 20 characters. Pay attention to OCR line breaks.",
        example="123456 01 55 2020 1 00012 789 321",
        min_length=20,
        alias="Número da Matrícula:"
    )

    marriage_regime: str = Field(
        description="Marriage property regime.",
        example="Comunhão Parcial de Bens",
        alias="Regime de Casamento:"
    )

    remarks: Optional[str] = Field(
        description="Averbações or additional remarks related to the marriage.",
        example="Consta averbação de divórcio em 2020.",
        alias="Averbações / Observações:"
    )

    registry_office: str = Field(
        description="Name of the notary office (cartório).",
        example="Cartório do Registro Civil de Porto Alegre",
        alias="Nome do Cartório:"
    )
    selo_autenticidade: Optional[Dict[str, str]] = Field(
        default=None,
        description="Authentication seal of the court of justice, when informed in the document",
        example={
            "selo": "101691 55 2024 00004436 94",
            "orgao": "TJRS",
            "tipo": "Selo Digital"
        },
        alias="Selo de Autenticidade:"
    )
