from pydantic import BaseModel, Field


class CpfReceitaFederal(BaseModel):
    name: str = Field(
        description="Full registered name of the individual according to Receita Federal.",
        example="JOÃO DA SILVA",
        alias="Nome:"
    )

    cpf: str = Field(
        description="CPF number of the individual.",
        example="123.456.789-10",
        alias="CPF:"
    )

    birth_date: str = Field(
        description="Date of birth in DD/MM/YYYY format.",
        example="15/08/1990",
        alias="Data de Nascimento:"
    )

    registration_status: str = Field(
        description="Current CPF registration status (e.g., Regular, Suspenso, Cancelado).",
        example="REGULAR",
        alias="Situação Cadastral:"
    )

    registration_date: str = Field(
        description="Date when the CPF was originally registered (DD/MM/YYYY).",
        example="10/05/2005",
        alias="Data da Inscrição:"
    )

    verification_digit: str = Field(
        description="Verification digit extracted from the CPF record.",
        example="10",
        alias="Dígito Verificador:"
    )

    emission_datetime: str = Field(
        description="Date and time when the certificate was issued, in DD/MM/YY HH:MM:SS format.",
        example="12/11/24 14:35:21",
        alias="Data e Hora da Emissão:"
    )
