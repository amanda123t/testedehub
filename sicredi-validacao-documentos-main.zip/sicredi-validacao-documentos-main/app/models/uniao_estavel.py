from pydantic import BaseModel, Field
from typing import Optional, Dict


class StableUnion(BaseModel):
    document_date: str = Field(
        description="Date when the certificate/document was issued.",
        example="18/04/2023",
        alias="Data do Documento:"
    )

    registry_office: str = Field(
        description="Name of the registry office or notary.",
        example="Cartório do Registro Civil de Belo Horizonte",
        alias="Nome do Cartório:"
    )

    partners: Dict[str, Dict[str, str]] = Field(
        description="Names and CPFs of both partners in the stable union.",
        example={
            'Parceiro_1': {'Nome': 'Carlos Souza', 'CPF': '111.111.111-11'},
            'Parceiro_2': {'Nome': 'Fernanda Lima', 'CPF': '222.222.222-22'}
        },
        alias="Nomes dos Parceiros:"
    )

    union_date: str = Field(
        description="Date when the stable union began.",
        example="20/03/2020",
        alias="Data da União:"
    )

    regime: Optional[str] = Field(
        description="Property regime used in the stable union.",
        example="Comunhão Parcial",
        alias="Regime:"
    )
