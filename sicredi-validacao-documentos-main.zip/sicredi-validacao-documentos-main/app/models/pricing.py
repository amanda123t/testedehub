from pydantic import BaseModel, Field

class Pricing(BaseModel):
    date: str = Field(
        description="document creation date, you can find as 'Gerada em:'.",
        example="25/03/2025",
        alias="Data de Criação:"
    )
    
    name: str = Field(
        description="Full name of the person associated with the document, return only the name, whithout CPF or CNPJ, you can find as 'Para:'.",
        example="João da Silva",
        alias="Nome:"
    )

    requested_amount: str = Field(
        description="Amount stated on the document, using two decimal places and with R$ at the beginning, you can find as 'Valor Solicitado'.",
        example="R$ 30.500,00",
        alias="Valor Solicitado:"
    )
    
    installments: str = Field(
        description="Number of installments due, from 1 to 100, you can find as 'Qtd. de Parcelas:'",
        example="48",
        alias="Parcelas:"
    )
    
    periodicity: str = Field(
        description="Payment frequency (monthly, quarterly, half-yearly or annual) can be found as 'Periodicidade:'.",
        example=["Mensal", "Trimestral", "Semestral", "Anual"],
        alias="Periodicidade:"
    )

    date_payment: str = Field(
        description="date of first payment due,you can find as '1º Vencimento:'.",
        example="25/04/2025",
        alias="Data do 1° vencimento:"
    )

    insurance: str = Field(
        description="Does it finance the loan insurance together with the value of the proposal, yes or no, you can find as 'Financia Prestamista:'.",
        example=["Sim", "Não"],
        alias="Financia Prestamista:"
    )

    simulation: str = Field(
        description="Document simulation number, with 12 digits, you can find as 'Simulação'.",
        example="860802113996",
        alias="Simulação:"
    )
    
    product: str = Field(
        description="name of the credit line, along with the product code which has 3 numbers and 1 letter, you can find as 'Produto'.",
        example="017C - CONSTRUÇÃO E REFORMA PESSOAL",
        alias="Produto:"
    )

    rate: str = Field(
        description= r"credit interest rate, in percentage, you can find as 'Taxa de Juros (% a.m.)'.",
        example="3.69%",
        alias="Taxa de Juros:"
    )

    indexer: str = Field(
        description= "credit indexer, it can 'Pré-fixado' or 'Pós-fixado' only, you can find as 'Indexador'.",
        example=["Pré-fixado", "Pós-fixado"],
        alias="Indexador:"
    ) 

    amortization_method: str = Field(
        description= "Type of credit amortization, it can be 'PRICE', 'SAC' or 'SPV' only, you can find as 'Método de Amortização'.",
        example=["PRICE", "SPV", "SAC"],
        alias="Método de Amortização:"
    ) 

    operation_value: str = Field(
        description="total value of the operation, it is always greater than the requested value and it always using two decimal places and with R$ at the beginning, you can find as 'Valor Operação'.",
        example="R$ 31.519,00",
        alias="Valor Total Operação:"
    )
