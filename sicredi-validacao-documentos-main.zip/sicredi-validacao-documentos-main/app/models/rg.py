from pydantic import BaseModel, Field
from typing import Optional

class RG(BaseModel):
    name: str = Field(
        description="Full name. Never return the name written in the signature field, as it may contain grammatical errors.",
        alias="Nome:"
    )
    cpf: Optional[str] = Field(
        description="CPF number with 11 digits. Always return only digits (no dots, no dashes).",
        example="12345678901",
        alias="CPF:"
    )

    identity: str = Field(
        description="General Registry (RG) document number. Always return only digits, without dots or dashes.",
        example="55448455",
        alias="Registro Geral:"
    )

    parents: Optional[str] = Field(
        description="Parents names (filiação).",
        alias="Filiação:"
    )

    birth_date: Optional[str] = Field(
        description="Date of birth (dd/mm/yyyy).",
        alias="Data de Nascimento:"
    )
    expedition_date: Optional[str] = Field(
        description="Expedition date (dd/mm/yyyy).",
        alias="Data de Expedição:"
    )

    # CAMPO EXPLÍCITO DO DOCUMENTO
    issuing_agency: Optional[str] = Field(
        description="Órgão expedidor (ex.: SSP, IGP, DETRAN). Use apenas se o campo existir explicitamente no documento.",
        alias="Órgão Expedidor:"
    )

    # CAMPO IMPLÍCITO DO CABEÇALHO
    emitting_institution: Optional[str] = Field(
        description=(
            "Instituição emissora responsável pela emissão do documento, "
            "derivada do cabeçalho (ex.: Secretaria da Segurança Pública, "
            "Instituto Geral de Perícias, Departamento de Identificação). "
            "Use especialmente quando o órgão expedidor não estiver explícito."
        ),
        alias="Órgão Emissor:"
    )

    naturality: Optional[str] = Field(
        description="City and State of birth (naturalidade).",
        alias="Naturalidade:"
    )
    civil_registry: Optional[str] = Field(
        description="Registro civil, livro, folha, termo ou 'doc. origem'.",
        alias="Registro Civil:"
    )
