from pydantic import BaseModel, Field
from typing import Optional, List


class Representative(BaseModel):
    name: str = Field(
        description="Representative full name.",
        alias="Nome"
    )
    cpf: Optional[str] = Field(
        description="Representative CPF, 11 digits.",
        alias="CPF"
    )


class Attorney(BaseModel):
    name: str = Field(
        description="Attorney full name.",
        alias="Nome"
    )
    cpf: Optional[str] = Field(
        description="Attorney CPF, 11 digits.",
        alias="CPF"
    )
    tipo_assinatura: Optional[str] = Field(
        description=(
            "Signature type. Return only 'conjunto' or 'isoladamente' "
            "when the document explicitly defines how the attorneys must sign together or individually. "
            "If not present, return null."
        ),
        alias="Tipo de Assinatura:"
    )
    powers: Optional[str] = Field(
        description="Description of the granted powers, especially regarding banking operations or financial institutions.",
        alias="Poderes:"
    )


class Procuracao(BaseModel):
    power_of_attorney_date: Optional[str] = Field(
        description="Date of the power of attorney document. Format dd/mm/yyyy.",
        alias="Data da Procuração:"
    )
    issue_date: Optional[str] = Field(
        description="Issue date of the power of attorney, if available.",
        alias="Data de Emissão:"
    )
    grantor: str = Field(
        description="Grantor of the power of attorney (individual or company).",
        alias="Outorgante:"
    )

    representatives: Optional[List[Representative]] = Field(
        description="List of representatives (only when the grantor is a company). Return name and CPF.",
        alias="Representantes:"
    )

    attorneys: List[Attorney] = Field(
        description="List of attorneys granted powers. Return name and CPF.",
        alias="Procuradores:"
    )

    term: Optional[str] = Field(
        description=(
            "Validity term of the document. May be a date (e.g. 'até dd/mm/aaaa'), "
            "a duration ('prazo de 2 anos'), 'indeterminado', or empty if not provided."
        ),
        alias="Prazo:"
    )
