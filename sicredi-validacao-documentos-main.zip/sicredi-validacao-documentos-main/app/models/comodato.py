from pydantic import BaseModel, Field
from typing import List, Optional, Dict


class Person(BaseModel):
    name: str = Field(
        description="Full name of the person.",
        example="JOÃO DA SILVA",
        alias="Nome:"
    )
    cpf: Optional[str] = Field(
        description="CPF of the person in xxx.xxx.xxx-xx format.",
        example="123.456.789-10",
        alias="CPF:"
    )


class PropertyItem(BaseModel):
    registration_number: Optional[str] = Field(
        description="Property registration number (matrícula), if provided.",
        example="12345 678 0001 9",
        alias="Número da Matrícula:"
    )

    description: str = Field(
        description="Description of the property as written in the contract.",
        example="Área rural situada na Linha São João, contendo benfeitorias.",
        alias="Descrição do Imóvel:"
    )

    city: str = Field(
        description="City where the property is located.",
        example="Erechim",
        alias="Município do Imóvel:"
    )

    total_area: str = Field(
        description="Total area of the property (in hectares or another unit).",
        example="12,5 ha",
        alias="Área Total do Imóvel:"
    )

    ceded_area: Optional[str] = Field(
        description="Area allowed to be explored by the lessee/beneficiary.",
        example="7,0 ha",
        alias="Área Cedida ao Arrendatário:"
    )

class Comodato(BaseModel):
    names: Dict[str, List[Person]] = Field(
        description=(
            "Grouped parties of the contract. Must contain 'Comodante' and 'Comodatário'."
        ),
        example={
            "Comodante": [{"Nome": "PAULO", "CPF": "123.456.789-10"}],
            "Comodatário": [{"Nome": "LUCAS", "CPF": "987.654.321-00"}]
        },
        alias="Nomes:"
    )

    registry_office: Optional[str] = Field(
        description="Name of the notary office where the contract was registered, if available.",
        example="Tabelionato de Notas de Lagoa Vermelha",
        alias="Nome do Cartório:"
    )

    properties: List[PropertyItem] = Field(
        description="List of all properties included in the contract, each one with its own details.",
        alias="Imóveis:"
    )

    contract_term_years: Optional[str] = Field(
        description="Contract term expressed in years, if stated (e.g. '3 anos').",
        example="3 anos",
        alias="Prazo (Anos):"
    )

    contract_term_date: Optional[str] = Field(
        description="Contract term expressed in dates (DD/MM/YY or DD/MM/YYYY), if present.",
        example="01/03/2024 a 01/03/2027",
        alias="Prazo (Data):"
    )

    authorized_banks: Optional[List[str]] = Field(
        description="List of banks authorized for financing according to the contract, if specified.",
        example=["Sicredi", "Banco do Brasil"],
        alias="Bancos Autorizados:"
    )
