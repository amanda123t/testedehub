from pydantic import BaseModel, Field
from typing import Optional


class Midas(BaseModel):
    user: str = Field(
        description=(
            "User code (8 to 10 digits) associated with the MIDAS declaration. "
            "Kept as string to preserve leading zeros."
        ),
        example="0123456789",
        alias="Usuário:"
    )

    print_datetime: str = Field(
        description="Print timestamp in DD/MM/YY HH:MM:SS format.",
        example="12/11/24 14:35:21",
        alias="Data/Hora de Impressão:"
    )

    cpf: str = Field(
        description="CPF of the declarant in xxx.xxx.xxx-xx format.",
        example="123.456.789-10",
        alias="CPF:"
    )

    delivery_datetime: str = Field(
        description="Delivery timestamp in DD/MM/YY HH:MM:SS format.",
        example="12/11/24 14:36:10",
        alias="Data/Hora da Entrega:"
    )

    delivery_method: str = Field(
        description="Delivery method used for the declaration (e.g., M-IRPF, Internet, Certificado Digital).",
        example="M-IRPF",
        alias="Meio de Entrega:"
    )

    model: str = Field(
        description="Declaration model (e.g., Modelo Completo, Modelo Simplificado).",
        example="Modelo Completo",
        alias="Modelo:"
    )

    document_type: str = Field(
        description="Type of submitted document (Original, Retificado).",
        example="Original",
        alias="Tipo de Documento:"
    )

    status: str = Field(
        description="Current status of the declaration (e.g., Finalizada, Processada, Recebida).",
        example="Finalizada",
        alias="Situação:"
    )

    delivered_with_certificate: Optional[str] = Field(
        description="Indicates whether the declaration was delivered with a digital certificate.",
        example="Sim",
        alias="Entregue com Certificado:"
    )
