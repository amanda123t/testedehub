from pydantic import BaseModel, Field
from typing import List, Optional


class PessoaMatricula(BaseModel):
    Nome: str = Field(
        description="Full name explicitly listed as owner, buyer, seller, donor, heir, or party in the registry act.",
        alias="Nome"
    )
    CPF: Optional[str] = Field(
        description="CPF of the person, if present.",
        alias="CPF"
    )
    Estado_Civil: Optional[str] = Field(
        description="Civil status exactly as listed (e.g., solteiro, casado, divorciado, viúvo, separado judicialmente, união estável).",
        alias="Estado Civil"
    )
    Regime_de_Bens: Optional[str] = Field(
        description="Marital property regime ONLY if the person is married (e.g., Comunhão Parcial, Comunhão Universal, Separação Total).",
        alias="Regime de Bens"
    )
    Conjuge: Optional[str] = Field(
        description="Spouse name if explicitly mentioned as an independent person. NOT a qualification-only mention.",
        alias="Cônjuge"
    )
    Percentual: Optional[str] = Field(
        description="Ownership percentage exactly as stated in the document.",
        alias="Percentual"
    )


class AtoMatricula(BaseModel):
    Tipo: str = Field(
        description="Type of the registry act that changes ownership (e.g., Compra e Venda, Doação, Inventário e Partilha).",
        alias="Tipo"
    )
    Registro: str = Field(
        description="Registry act identifier (e.g., R-5/23012).",
        alias="Registro"
    )
    Data: Optional[str] = Field(
        description="Date of the registry act or protocol.",
        alias="Data"
    )
    Valor_do_Imovel: Optional[str] = Field(
        description="Value stated for the transaction (purchase, sale, donation, succession, etc.).",
        alias="Valor do Imóvel"
    )


class PropertyRegistration(BaseModel):
    Dados_da_Matricula: dict = Field(
        description=(
            "General registration data: number, office, jurisdiction, the FULL initial property "
            "description (from 'IMÓVEL:' until before boundaries), and the property address. "
            "If no explicit address appears in the IMÓVEL block, infer the street/road from boundaries. "
            "If not inferable, return empty string."
        ),
        alias="Dados da Matrícula"
    )
    Matricula_Anterior: Optional[str] = Field(
        description="Previous registration number if explicitly cited.",
        alias="Matrícula Anterior"
    )

    Proprietarios_Abertura: List[PessoaMatricula] = Field(
        default_factory=list,
        description="ONLY the explicit owners in the opening act or first ownership block.",
        alias="Primeiros Proprietarios:"
    )

    Ato_Mais_Recente: Optional[AtoMatricula] = Field(
        description="Latest act that changes ownership (Compra e Venda, Doação, Inventário, etc.).",
        alias="Ato mais recente:"
    )

    Transmitentes: List[PessoaMatricula] = Field(
        default_factory=list,
        description="People who transferred the property in the most recent ownership-changing act.",
        alias="Transmitentes:"
    )

    Adquirentes: List[PessoaMatricula] = Field(
        default_factory=list,
        description="People who acquired the property in the most recent act.",
        alias="Adquirentes:"
    )
