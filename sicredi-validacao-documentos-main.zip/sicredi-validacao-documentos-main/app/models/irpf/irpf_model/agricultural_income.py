from typing import List, Dict, Optional
from pydantic import BaseModel, Field


# ======= 1️⃣ DADOS DOS IMÓVEIS EXPLORADOS =======

class RuralProperty(BaseModel):
    code: Optional[str] = Field(
        description="Código do imóvel rural (CÓDIGO).",
        alias="Código",
    )
    participation: Optional[str] = Field(
        description="Percentual de participação do contribuinte na atividade (PARTICIPAÇÃO %).",
        alias="Participação (%)",
    )
    condition: Optional[str] = Field(
        description="Condição de exploração ou tipo de posse (CONDIÇÃO).",
        alias="Condição",
    )
    name_location: Optional[str] = Field(
        description="Nome e localização do imóvel explorado (NOME E LOCALIZAÇÃO ou ATIVIDADE).",
        alias="Nome e Localização",
    )
    area: Optional[str] = Field(
        description="Área total do imóvel rural em hectares (ÁREA ha).",
        alias="Área (ha)",
    )
    cib_nirf: Optional[str] = Field(
        description="Número CIB/NIRF do imóvel (pode estar em branco).",
        alias="CIB/NIRF",
    )


# ======= 2️⃣ RECEITAS E DESPESAS =======

class RuralMonthRecord(BaseModel):
    receita_bruta: Optional[float] = Field(
        description="Valor da receita bruta mensal.",
        alias="Receita Bruta",
    )
    despesas: Optional[float] = Field(
        description="Valor das despesas de custeio ou investimento mensais.",
        alias="Despesas de Custeio/Investimento",
    )


# ======= 3️⃣ APURAÇÃO DO RESULTADO =======

class RuralResult(BaseModel):
    receita_bruta_total: Optional[float] = Field(
        description="Receita bruta total anual.",
        alias="Receita bruta total",
    )
    despesa_total: Optional[float] = Field(
        description="Despesa total de custeio e investimento.",
        alias="Despesa de custeio e investimento total",
    )
    resultado: Optional[float] = Field(
        description="Resultado final (lucro ou prejuízo).",
        alias="Resultado",
    )
    limite_20_percent: Optional[float] = Field(
        description="Limite de 20% sobre a receita bruta total.",
        alias="Limite de 20% sobre a receita bruta total",
    )
    resultado_tributavel: Optional[float] = Field(
        description="Resultado tributável (após compensações).",
        alias="Resultado Tributável",
    )
    saldo_prejuizo_compensar: Optional[float] = Field(
        description="Saldo de prejuízo(s) a compensar.",
        alias="Saldo de prejuízo(s) a compensar",
    )


# ======= 4️⃣ BLOCO COMPLETO DA ATIVIDADE RURAL =======

class RuralActivity(BaseModel):
    property_data: Optional[List[RuralProperty]] = Field(
        description="Lista de imóveis rurais explorados, com código, participação, condição, localização e área.",
        alias="DADOS E IDENTIFICAÇÃO DO IMÓVEL EXPLORADO",
    )
    revenues_and_expenses: Optional[Dict[str, RuralMonthRecord]] = Field(
        description="Registro mês a mês das receitas e despesas de custeio/investimento.",
        alias="RECEITAS E DESPESAS",
    )
    result_summary: Optional[RuralResult] = Field(
        description="Resumo da apuração final da atividade rural (totais anuais e resultados).",
        alias="APURAÇÃO DO RESULTADO",
    )

# ======= 6️⃣ CLASSE PRINCIPAL (IRPFAgricultural) =======

class IRPFAgricultural(BaseModel):
    rural: Optional[RuralActivity] = Field(
        description="Contains all data related to rural/agricultural income and expenses.",
        alias="DEMONSTRATIVO DE ATIVIDADE RURAL",
    )
