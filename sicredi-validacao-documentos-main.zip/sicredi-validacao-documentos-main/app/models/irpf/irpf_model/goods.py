from typing import Optional, List, Dict
from pydantic import BaseModel, Field

class Address(BaseModel):
    type: Optional[str] = Field(
        alias="Tipo",
        description="Type of address (street type such as RUA, AVENIDA, FAZENDA)."
    )

    street: Optional[str] = Field(
        alias="Logradouro",
        description="Street, avenue, or other public location name."
    )

    number: Optional[str] = Field(
        alias="Número",
        description="Address number, lot or S/N value."
    )

    complement: Optional[str] = Field(
        alias="Complemento",
        description="Address complement such as block, apartment, or additional details."
    )

    neighborhood: Optional[str] = Field(
        alias="Bairro",
        description="Name of the neighborhood."
    )

    city: Optional[str] = Field(
        alias="Município",
        description="City or municipality of the address."
    )

    state: Optional[str] = Field(
        alias="UF",
        description="State of the address (Brazilian UF code)."
    )

    cep: Optional[str] = Field(
        alias="CEP",
        description="Postal code in format 00.000-000."
    )

class IRPFBem(BaseModel):
    tipo: str = Field(
        alias="Tipo",
        description="Asset type such as imóvel, veículo, participação, conta, investimento, outros."
    )

    descricao: str = Field(
        alias="Descrição",
        description="Exact textual description of the asset."
    )

    valor: float = Field(
        alias="Valor",
        description="Current declared value for the asset (latest fiscal year)."
    )

    # endereço completo reconstruído pelo sistema
    endereco: Optional[Dict[str, Address]] = Field(
        alias="Endereço",
        description="Structured address information for the asset, when applicable."
    )
    nome_fazenda: Optional[str] = Field(
        alias="Nome da Fazenda",
        description="Nome da fazenda, sítio, chácara ou propriedade rural, quando aplicável."
    )

    area_total_m2: Optional[float] = Field(
        alias="Área Total",
        examples=["xx m2", "xx HA"],
        description="Total area of ​​the property in square meters or hectares, when available."    
    )

    inscricao_municipal: Optional[str] = Field(
        alias="Inscrição Municipal",
        description="Municipal IPTU registration number for properties."
    )

    data_aquisicao: Optional[str] = Field(
        alias="Data de Aquisição",
        description="Acquisition date in dd/mm/yyyy format."
    )

    matricula: Optional[str] = Field(
        alias="Matrícula",
        description="Property registry number, when available."
    )

    registrado_cartorio: Optional[str] = Field(
        alias="Registrado no Cartório",
        description="Indicates whether the property is officially registered (Sim/Não)."
    )

    nome_cartorio: Optional[str] = Field(
        alias="Nome do Cartório",
        description="Name of the registry office if registered."
    )

    propriedade_percentual: Optional[float] = Field(
        alias="Propriedade (%)",
        description="Ownership percentage for the asset."
    )
    

    # veículos
    marca: Optional[str] = Field(
        alias="Marca",
        description="vehicle make."
    )
    model: Optional[str] = Field(
        alias="Modelo",
        description="vehicle model."
    )

    # veículos
        # veículos
    renavam: Optional[str] = Field(
        alias="RENAVAM",
        description="RENAVAM number for vehicles."
    )

    placa: Optional[str] = Field(
        alias="Placa",
        description="Vehicle license plate, when present."
    )

    ano_fabricacao: Optional[int] = Field(
        alias="Ano de Fabricação",
        description="Vehicle manufacturing year, if explicitly stated."
    )

    ano_modelo: Optional[int] = Field(
        alias="Ano Modelo",
        description="Vehicle model year (used for FIPE reference), if explicitly stated."
    )

    # contas e investimentos
    banco: Optional[str] = Field(
        alias="Banco",
        description="Bank or financial institution name."
    )

    numero_conta: Optional[str] = Field(
        alias="Número da Conta",
        description="Bank or investment account number."
    )

    cnpj_instituicao: Optional[str] = Field(
        alias="cnpj_instituicao",
        description="CNPJ of the financial institution."
    )

    pertence_a: Optional[str] = Field(
        alias="Pertence a",
        description="Indicates to whom the asset belongs (titular or dependent)."
    )

    # participações
    cnpj_empresa: Optional[str] = Field(
        alias="CNPJ da Empresa",
        description="CNPJ of the company related to the corporate participation."
    )

    observacoes: Optional[str] = Field(
        alias="Observações",
        description="Additional unstructured information about the asset."
    )


class DeclaracaoBens(BaseModel):
    bens: list[IRPFBem] = Field(
        alias="DECLARAÇÃO DE BENS E DIREITOS",
        description="List of all extracted assets from the IRPF declaration."
    )