from typing import List, Optional
from pydantic import BaseModel, Field


class Details(BaseModel):
    month: Optional[str] = Field(
        description="Reference month in Portuguese and the value under 'Total'",
        example="FEV",
        alias="Mês"
    )
    work: Optional[str] = Field(
        description="Amount from unpaid work; It is the value from the column 'TRABALHO NÃO ASSALARIADO'.",
        example="1586.00",
        alias="Trabalho não assalariado",
    )
    rent: Optional[str] = Field(
        description="Amount of rent received. It is the value from the column 'ALUGUÉIS'",
        example="2500.00",
        alias="Aluguel",
    )
    others: Optional[str] = Field(
        description="Amount from other sources. It is the value from the column 'OUTROS'",
        example="1200.00",
        alias="Outros",
    )
    exterior: Optional[str] = Field(
        description="Amount received from foreign sources. It is the value from the column 'EXTERIOR'",
        example="5000.00",
        alias="Exterior",
    )


class IndividualForeignEarnings(BaseModel):
    individual_foreign_earnings: Optional[List[Details]] = Field(
        description="List of taxable earnings received from individuals and abroad by the taxpayer. You can find as 'RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA FÍSICA E DO EXTERIOR PELO TITULAR'. Responde with the value under 'Rendimentos'; ignore the values from 'DEDUÇÔES' ('PREVIDÊNCIA OFICIAL', 'QUANTIDADE DEDEPENDENTES', 'PENSÃO ALIMENTÍCIA', 'LIVRO CAIXA DARF PAGO CÓD. 0190'). Include each month and also the row where 'Mês' is 'Total', which represents the total amount for the year.",
        examples={
            "RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA FÍSICA E DO EXTERIOR PELO TITULAR": [
                {
                    "Mês": "JAN",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "2.000,00",
                    "Exterior": "0,00",
                },
                {
                    "Mês": "FEV",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "2.000,00",
                    "Exterior": "0,00",
                },
                {
                    "Mês": "MAR",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "2.000,00",
                    "Exterior": "0,00",
                },
                {
                    "Mês": "ABR",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "2.000,00",
                    "Exterior": "0,00",
                },
                {
                    "Mês": "MAI",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "2.000,00",
                    "Exterior": "0,00",
                },
                {
                    "Mês": "JUN",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "2.000,00",
                    "Exterior": "0,00",
                },
                {
                    "Mês": "JUL",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "2.000,00",
                    "Exterior": "0,00",
                },
                {
                    "Mês": "AGO",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "3.000,00",
                    "Exterior": "0,00",
                },
                {
                    "Mês": "SET",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "3.000,00",
                    "Exterior": "0,00",
                },
                {
                    "Mês": "OUT",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "3.000,00",
                    "Exterior": "0,00",
                },
                {
                    "Mês": "NOV",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "3.000,00",
                    "Exterior": "0,00",
                },
                {
                    "Mês": "DEZ",
                    "Trabalho não assalariado": "1.000,00",
                    "Aluguel": "2.500,00",
                    "Outros": "3.000,00",
                    "Exterior": "29.000,00",
                },
                {
                    "Mês": "Total",
                    "Trabalho não assalariado": "10.000,00",
                    "Aluguel": "30.000,00",
                    "Outros": "29.000,00",
                    "Exterior": "29.000,00",
                },
            ]
        },
        alias="RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA FÍSICA E DO EXTERIOR PELO TITULAR",
    )
