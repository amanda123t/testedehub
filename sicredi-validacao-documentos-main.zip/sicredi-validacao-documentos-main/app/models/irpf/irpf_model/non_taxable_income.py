from typing import List, Optional
from pydantic import BaseModel, Field

class SubItem(BaseModel):
    beneficiario: str = Field(alias="Beneficiário")
    cpf: str = Field(description="CPF in format xxx.xxx.xxx-xx. Never return CNPJ here",alias="CPF")
    cnpj: str = Field(description="CNPJ in format xx.xxx.xxx/xxxx-xx. Never return CPF here", alias="CNPJ")
    fonte_pagadora: str = Field(alias="Fonte Pagadora")
    valor: str = Field(alias="Valor")
    description_item: str = Field(description= "Description of item.", alias="Descrição")
    

class Details(BaseModel):
    item: str = Field(description="Income category code", alias="Item")
    description: str = Field(
        description="Description of the non-taxable income", alias="Descrição"
    )
    amount: str = Field(
        description="Total value of this category (value from the headline line).",
        alias="Valor",
    )
    subitems: Optional[List[SubItem]] = Field(
        default=None,
        description="List of subitems composing the total value",
        alias="Subitens",
    )

class NonTaxableIncome(BaseModel):
    non_taxable_income: Optional[List[Details]] = Field(
        description="List of non-taxable income. You can find as 'RENDIMENTOS ISENTOS E NÃO TRIBUTÁVEIS'.",
        example=[
            {
                "Item": "09",
                "Descrição": "Lucros e dividendos recebidos",
                "Valor": "1.234,00",
                "Subitens": []
            },
            {
                "Item": "15",
                "Descrição": "Parcela não tributável correspondente à atividade rural",
                "Valor": "24.751,74",
                "Subitens": []
            },
            {
                "Item": "99",
                "Descrição": "Outros",
                "Valor": "442.833,76",
                "Subitens": []
            },
            {
                "Item": "13",
                "Descrição": "Rendimento de sócio ou titular de ME/EPP optante pelo Simples Nacional",
                "Valor": "50.000,76",
                "Subitens": [
                    {
                        "Beneficiário": "Titular",
                        "CPF": "000.000.000-00",
                        "CNPJ": "11.111.111/1111-11",
                        "Fonte Pagadora": "EMPRESA XYZ LTDA",
                        "Valor": "50.000,76"
                    }
                ]
            },
        ],
        alias="RENDIMENTOS ISENTOS E NÃO TRIBUTÁVEIS",
    )
