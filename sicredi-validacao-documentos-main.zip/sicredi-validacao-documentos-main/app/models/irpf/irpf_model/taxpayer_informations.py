from datetime import date
from pydantic import BaseModel, Field

class IRPF(BaseModel):
    header: str = Field(
        description="Header containing taxpayer's name, CPF, fiscal year (the year after the word 'EXERCÍCIO'), and calendar year.",
        example=[
            "NOME: Beltrana de Souza; CPF: 987.654.321.01; DECLARAÇÃO DE AJUSTE ANUAL; IMPOSTO SOBRE A RENDA - PESSOA FÍSICA EXERCÍCIO 2025; ANO-CALENDÁRIO 2024",
            "NOME: Fulano da Silva; CPF: 123.456.789-10; DECLARAÇÃO DE AJUSTE ANUAL; IMPOSTO SOBRE A RENDA - PESSOA FÍSICA EXERCÍCIO 2024; ANO-CALENDÁRIO 2023",
        ],
        alias="Cabeçalho",
    )
    name: str = Field(description="Taxpayer's full name", alias="Nome")
    cpf: str = Field(
        description="""CPF (Cadastro de Pessoas Físicas) is the taxpayer identification number for individuals in Brazil. It should have 11 digits in the format 123.456.789-10.  Example: 123.456.789-10.
It should not be confused with CNPJ, which is for legal entities (businesses).
CNPJ has 14 digits and follows the format 05.928.773/0001-56.""",
        examples=['879.945.124-48', '123.456.789-10', '496.548.749-66'],
        alias="CPF",
    )
    exercise_year: int = Field(
        description=(
            "Fiscal exercise year shown immediately after the token 'EXERCÍCIO' in the header. "
            "Extract this exact 4-digit year from the header text only. "
            "Ignore any other years mentioned in tables or auxiliary sections (e.g., 'Informações Adicionais', "
            "'Malha(s)', 'Evolução Patrimonial', or dates like 31/12/20XX). "
            "The exercise year must be exactly one year greater than the calendar_year."
        ),
        examples=[2023, 2024, 2025],
        alias="Exercício",
    )

    calendar_year: int = Field(
        description=(
            "Calendar year shown immediately after the token 'ANO-CALENDÁRIO' in the header. "
            "Extract this exact 4-digit year from the header text only. "
            "Ignore any other years mentioned elsewhere (including patrimonial dates like 31/12/20XX). "
            "Example: if the header says 'EXERCÍCIO 2024; ANO-CALENDÁRIO 2023', then calendar_year is 2023. "
            "The calendar_year must be exactly one year less than exercise_year."
        ),
        examples=[2022, 2023, 2024],
        alias="Ano-Calendario",
    )

    birthday: date = Field(
        description="Taxpayer's birth date (format: DD/MM/YYYY)", alias="Data de Nascimento"
    )
    voter_id: str = Field(
        description="12-digit voter ID",
        example="001234567890",
        alias="Título de Eleitor",
    )
    address: str = Field(
        description="Formatted address: 'Street, Number, Complement, Neighborhood, City - State, ZIP Code, Country'",
        alias="Endereço",
    )
    type_declaration: str = Field(
        description="type of declaration, 'Declaração Retificadora' or 'Declaração original'", 
        examples=['Declaração Retificadora', 'Declaração Original'],
        alias="Tipo"
    )
    occupation: str = Field(
        description="Occupation or job title of the taxpayer", alias="Ocupacao"
    )
    receipt: str = Field(
        description="Receipt number of the last tax return submitted",
        alias="Número do Recibo Anterior",
    )
