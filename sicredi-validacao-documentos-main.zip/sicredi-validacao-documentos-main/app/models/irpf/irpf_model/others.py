from typing import List, Dict, Optional
from pydantic import BaseModel, Field

# ======= 5️⃣ RESUMO DO IRPF (já feito antes) =======

class IRPFSummary(BaseModel):
    received_from_legal_entity_holder: Optional[str] = Field(
        description="Total taxable income received from legal entities by the main taxpayer.",
        alias="Recebidos de Pessoa Jurídica pelo Titular",
    )
    received_from_legal_entity_dependents: Optional[str] = Field(
        description="Total taxable income received from legal entities by dependents.",
        alias="Recebidos de Pessoa Jurídica pelos Dependentes",
    )
    received_from_physical_or_foreign_holder: Optional[str] = Field(
        description="Total taxable income received from individuals or abroad by the main taxpayer.",
        alias="Recebidos de Pessoa Física/Exterior pelo Titular",
    )
    received_from_physical_or_foreign_dependents: Optional[str] = Field(
        description="Total taxable income received from individuals or abroad by dependents.",
        alias="Recebidos de Pessoa Física/Exterior pelos Dependentes",
    )
    total_taxable_income: Optional[str] = Field(
        description="Sum of all taxable income from the section.",
        alias="Total de Rendimentos Tributáveis",
    )
    balance_due_tax: Optional[str] = Field(
        description="Remaining income tax amount due or payable.",
        alias="Saldo Imposto a Pagar",
    )


# ======= 6️⃣ CLASSE PRINCIPAL (IRPFOthers) =======

class IRPFOthers(BaseModel):

    summary: Optional[IRPFSummary] = Field(
        description=(
            "Resumo section of the IRPF, containing totals of taxable income and remaining tax balance. "
            "This includes fields like 'Recebidos de Pessoa Jurídica', 'Recebidos de Pessoa Física/Exterior', "
            "'Total de Rendimentos Tributáveis' and 'Saldo Imposto a Pagar'."
        ),
        alias="Resumo",
        example={
            "Resumo": {
                "Recebidos de Pessoa Jurídica pelo Titular": "R$ 50.000,00",
                "Recebidos de Pessoa Jurídica pelos Dependentes": "R$ 0,00",
                "Recebidos de Pessoa Física/Exterior pelo Titular": "R$ 0,00",
                "Recebidos de Pessoa Física/Exterior pelos Dependentes": "R$ 0,00",
                "Total de Rendimentos Tributáveis": "R$ 50.000,00",
                "Saldo Imposto a Pagar": "R$ 0,00"
            }
        },
    )

