from typing import List, Optional
from pydantic import BaseModel, Field


class Details(BaseModel):
    payer_name: str = Field(
        description="Name of the paying entity", alias="Fonte Pagadora"
    )
    cnpj: str = Field(
        description="CNPJ of the paying entity", alias="CNPJ"
    )
    earnings: str = Field(
        description="Taxable earnings amount. It's the value from 'Rend. Recebidos de Pes. Jurídica'",
        alias="Rend. Recebidos de Pes. Jurídica",
    )
    contr_previd: str = Field(
        description="It refers to the amount that the taxpayer paid to INSS (National Institute of Social Security) or another official pension system.",
        alias="Contribuição Previdenciária Oficial",
    )
    collected: str = Field(
        description="This tax is collected by the payer (company, bank, government, etc.) and forwarded to the Federal Revenue Service. You can find as 'Imposto Retido na Fonte'",
        alias="Imposto Retido na Fonte",
    )
    thirteenth_salary: str = Field(
        description="'13º SALÁRIO' or similar variations. PAY ATTENTION: Do not mistake it for the value of 'IRRF SOBRE 13° Salário'.",
        alias="13º Salário",
    )
    irpf_13: str = Field(
        description="Refers to the Withholding Income Tax (IRRF) applied to the value of the taxpayer's 13th salary. It's the value from 'IRRF SOBRE 13° Salário'.",
        alias="IRPF sobre 13º Salário",
    )


class Earnings(BaseModel):
    earnings: Optional[List[Details]] = Field(
        description="List of taxable earnings received from legal entities. You can find as 'RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA JURÍDICA PELO TITULAR'",
        example={
            "RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA JURÍDICA PELO TITULAR": [
                {
                    "Fonte Pagadora": "COOPERATIVA DE CREDITO, POUPANCA E INVESTIMENTO INTERESTADOS",
                    "Rend. Recebidos de Pes. Jurídica": "2,83",
                    "Contribuição Previdenciária Oficial": "0,00",
                    "Imposto Retido na Fonte": "0,00",
                    "13º Salário": "0,00",
                    "IRPF sobre 13º Salário": "0,00",
                },
                {
                    "Fonte Pagadora": "DAYANE SANTOS SOARES DE OLIVEIRA",
                    "Rend. Recebidos de Pes. Jurídica": "51.850,02",
                    "Contribuição Previdenciária Oficial": "0,00",
                    "Imposto Retido na Fonte": "0,00",
                    "13º Salário": "0,00",
                    "IRPF sobre 13º Salário": "0,00",
                },
            ]
        },
        alias="RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA JURÍDICA PELO TITULAR",
    )
