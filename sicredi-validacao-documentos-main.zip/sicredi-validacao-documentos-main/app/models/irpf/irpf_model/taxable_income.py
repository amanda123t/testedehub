from typing import List, Optional
from pydantic import BaseModel, Field

class SubItem(BaseModel):
    beneficiario: str = Field(alias="Beneficiário")
    cpf: str = Field(description="CPF in format xxx.xxx.xxx-xx. Never return CNPJ here",alias="CPF")
    cnpj: str = Field(description="CNPJ in format xx.xxx.xxx/xxxx-xx. Never return CPF here", alias="CNPJ")
    fonte_pagadora: str = Field(alias="Fonte Pagadora")
    valor: str = Field(alias="Valor")
    description_item: str = Field(description= "Description of item.", alias="Descrição")
    
class Details(BaseModel):
    item: str = Field(
        description="Taxable income category code", alias="Item"
    )
    description: str = Field(
        description="Description of the taxable income",
        alias="Descrição"
    )
    amount: str = Field(
        description="Amount received in this category",
        alias="Valor"
    )
    subitems: Optional[List[SubItem]] = Field(default=None, alias="Subitens")


class TaxableIncome(BaseModel):
    taxable_income: Optional[List[Details]] = Field(
        description="List of taxable income. Found under 'RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA/DEFINITIVA'",
        alias="RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA/DEFINITIVA",
    )
