from pydantic import BaseModel, Field
from typing import List, Dict, Optional

class Address(BaseModel):
    type: str = Field(
        description="Type of address (e.g., AVENIDA, RUA, FAZENDA).",
        example=["AVENIDA", "RUA", "RODOVIA"],
        alias="Tipo:"
    )
    street: str = Field(
        description="Street, avenue, or other public place name.",
        example="ANTONIO FERREIRA SOBRINHO",
        alias="Logradouro:"
    )
    number: str = Field(
        description="Address number.",
        example=["3117", "LOTE 10","SN", "0"],
        alias="Número:"
    )
    complement: Optional[str] = Field(
        description="address complement.",
        example="Lote 5 quadra 2",
        alias="Complemento:"
    )
    neighborhood: str = Field(
        description="Neighborhood name.",
        example="CENTRO",
        alias="Bairro:"
    )
    state: str = Field(
        description="State abbreviation (UF) of the address.",
        example="MT",
        alias="UF:"
    )
    cep: str = Field(
        description="address zip code, return in format xx.xxx-xxx",
        example="93.224-170",
        alias="CEP:"
    )

class CartaoCNPJ(BaseModel):
    document: str = Field(
        description="The CNPJ(Cadastro Nacional da Pessoa Jurídica) is the registration number of a company or entity with the Brazilian Federal Revenue Service.",
        examples="01.000.025/0001-00",
        alias="CNPJ:"
    )

    Type: str = Field(
        description="Company is Head Office or Branch",
        examples={"Matriz", "Filial"},
        alias="Tipo:"
    )

    opening_date: str = Field(
        description="company opening date, return in format dd/mm/aaaa",
        examples={"11/08/2021", "01/03/2024"},
        alias="Data de abertura:"
    )

    name: str = Field(
        description="Full name of the company name associated with the document.",
        example={"Mercado de alimentos LTDA"},
        alias="Nome:"
    )
        
    trade_name: str = Field(
        description="company trade name",
        example="Mercadinho",
        alias="Nome Fantasia:"
    )  

    company_size: str = Field(
        description="company size",
        example=["ME", "EPP", "DEMAIS", "MICRO EMPRESA"],
        alias="Porte:"
    )  
       
    main_activity: str = Field(
        description="code and description of the main economic activity",
        example=["C5487789 - Comercio varejista de bebidas", "5611201 - Restaurantes e similares"],
        alias="CNAE:"
    ) 
    
    legal_nature: str = Field(
        description="code and description of the legal nature.",
        example=["206-2 - Sociedade Empresária Limitada", "213-5 - Empresário(Individual)"],
        alias="Natureza Juridica:"
    )

    address: Address = Field(
        description="Main address of the company.",
        alias="Endereço:"
    )

    company_email: str = Field(
        description="company email address.",
        example="restauranteltda@gmail.com",
        alias="Email:"
    )

    company_phone_number: str = Field(
        description="company phone number.",
        example="(11) 99877-5487",
        alias="Telefone:"
    )

    situation: str = Field(
        description="Income status of the person or company.",
        example=["Ativa", "Inativa", "Regular", "Pendente de Regularização"],
        alias="Situacao:"
    )

    extraction_date: Optional[str] = Field(
        description="Date and time when the document was extracted, in the format DD/MM/YYYY HH:MM:SS.",
        example="25/02/2025 14:30:00",
        alias="Data de Extração:"
    )

