from pydantic import BaseModel, Field
from typing import List, Optional

class Address(BaseModel):
    type: str = Field(
        description="Type of address (e.g., AVENIDA, RUA, FAZENDA).",
        example="AVENIDA",
        alias="Tipo:"
    )
    street: str = Field(
        description="Street, avenue, or other public place name.",
        example="ANTONIO FERREIRA SOBRINHO",
        alias="Logradouro:"
    )
    number: str = Field(
        description="Address number.",
        example="3117",
        alias="Número:"
    )
    neighborhood: str = Field(
        description="Neighborhood name.",
        example="CENTRO",
        alias="Bairro:"
    )
    state: str = Field(
        description="State abbreviation (UF) of the address.",
        example="MT",
        alias="UF:"
    )
    receive_correspondence: str = Field(
        description="Whether the associate receives correspondence: 'SIM' or 'NÃO'.",
        examples=["SIM", "NÃO"],
        alias="Recebe correspondência?:"
    )
    proven: str = Field(
        description="Whether the address has been proven: 'SIM' or 'NÃO'.",
        examples=["SIM", "NÃO"],
        alias="Comprovado?:"
    )

class Partner(BaseModel):
    name: str = Field(
        description="Full name of the partner or shareholder.",
        example="SOPHIA WAGNER RUSSI",
        alias="Nome Sócio:"
    )
    cpf_cnpj: str = Field(
        description="CPF or CNPJ of the partner.",
        example="035.591.911-73",
        alias="cpf/cnpj:"
    )

class Registration_Pj(BaseModel):
    company_name: str = Field(
        description="Company’s legal name, usually found after 'Dados pessoais'.",
        example="JJ COMERCIO E TRANSPORTES LTDA",
        alias="Nome:"
    )
    cnpj: str = Field(
        description="Company’s CNPJ identifier.",
        example="55.379.813/0001-26",
        alias="CNPJ:"
    )
    cnae: str = Field(
        description="Company’s main CNAE (economic activity code).",
        example="J6010100 - ATIVIDADES DE RADIO",
        alias="CNAE:"
    )
    headquarters: str = Field(
        description="Indicates if the company is the main branch: 'Sim' or 'Não'.",
        example="Sim",
        alias="Matriz:"
    )
    legal_nature: str = Field(
        description="Legal nature of the business.",
        example=["SOCIEDADE EMPRESARIA LIMITADA", "EMPRESÁRIO INDIVÍDUAL"],
        alias="Natureza Jurídica:"
    )
    renovation_date: str = Field(
        description="Date of the last registration update (e.g., 'Data da Última Renovação Cadastral').",
        example="10/04/2025",
        alias="Data de Renovação:"
    )
    share_capital: str = Field(
        description="Declared share capital of the company.",
        example="344.122,00",
        alias="Capital social:"
    )
    partners: Optional[List[Partner]] = Field(
        description="List of partners or shareholders with their names and CPF/CNPJ.",
        alias="Cotistas:"
    )
    address: Address = Field(
        description="Main address of the company.",
        alias="Endereço:"
    )
    invoicing_year: List[str] = Field(
        description="Years for which the company reported revenue.",
        examples=['2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025'],
        alias='Ano:'
    )
    invoicing_value: List[str] = Field(
        description="Total revenue for each respective year.",
        examples=["234.422,94"],
        alias="Valor:"
    )
