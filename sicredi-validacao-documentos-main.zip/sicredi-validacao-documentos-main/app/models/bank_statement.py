from pydantic import BaseModel, Field
from typing import Dict, List, Optional


class BankStatement(BaseModel):
    account_holder: str = Field(
        description="Name of the account_holder, generally is the first line in the bank statements", 
        alias="Nome"
    )

    period: str = Field(
        description="document period mm/yyyy to mm/yyyy if informed",
        examples= '03/2024 a 02/2025',
        alias= "Periodo",
    )

    transactions: List[Dict[str, str]] = Field(
        description="List of all financial movements extracted from the tables.",
        examples=[
            {"Data": "01 NOV 2024", "Descrição": "Compra no débito Mercado da Vila", "Valor": "- 10,00"}, 
        ],
        alias="Transações"
        
    )





