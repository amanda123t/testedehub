from pydantic import BaseModel, Field
from typing import List, Dict, Optional

class Item(BaseModel):
    description: str = Field(description="Description of the item.", alias="Nome")
    amount: str = Field(
        description="Valor associated with the item.",
        example="R$ 1.000,00",
        alias="Valor:",
    )

class ProLabore(BaseModel):
    name: str = Field(
        description="Full name of the person associated with the document.",
        example="João da Silva",
        alias="Nome:"
    )
    employer: str = Field(
        description="Institution where the employee is working.",
        example="Empresa XYZ Ltda",
        alias="Empresa:"
    )
    cnpj: str = Field(
        description="The CNPJ (Cadastro Nacional da Pessoa Jurídica) is the registration number of a company or entity with the Brazilian Federal Revenue Service.",
        example="12.345.678/0001-90",
        alias="CNPJ:"
    )
    reference_month: str = Field(
        description="The reference month of the document. Respond in the format MM/YYYY",
        example="02/2025",
        alias="Mês de Referência:"
    )
    emission_date: str = Field(
        description="Emission date, in the format 25/02/2025",
        example="25/02/2025",
        alias="Data de Emissão:"     
    )   
    occupation: str = Field(
        description="Occupation or job title of the employee.",
        example="Diretor Financeiro:",
        alias= "Cargo:"
    )
    cbo: Optional[str] = Field(
        description="Brazilian Classification of Occupations (CBO) code (6 digits)",
        example="252205",
        alias="CBO:",
    )
    pro_labore: str = Field(
        description="Net income of the employee. Convert the value to the Brazilian currency format R$ 00.000,00. you can find as 'Pro labore', 'prolabore', etc.",
        example="12.000,00",
        alias="Pró-Labore:"
    )
    base_salary: str = Field(
        description="Net salary received, after all discounts.",
        example="5.000,00",
        alias="Salário Líquido:"
    )
    salary_minimum: Optional[str] = Field(
        description="Number of minimum wages.",
        example="01 salario minimo regionais que corresponde a R$ 1.320,00",
        alias="Salários mínimos:"
        )
    deductions: List[Item] = Field(
        description="Amounts deducted from the employee's salary.",
        alias="Descontos:",
        default_factory=list,
    )
    counter_data: Dict = Field(
        description="Counter's name, CRC (CONSELHO REGIONAL CONTABILIDADE) and the CPF or CNPJ",
        examples=["{'Nome': 'JULIO DA SILVA', 'CRC': 'MT-123456', 'CPF': '456.123.145-87', 'CNPJ': ''}",
                  "{'Nome': 'ESCRITORIO DE CONTABILIDADE LTDA', 'CRC': 'SP-123456', 'CPF': '', 'CNPJ': '12.3456.789/0001-12'}",
                  "{'Nome': 'JULIO DA SILVA', 'CRC': 'RO-123456/O0', 'CPF': '', 'CNPJ': ''}"
                  ],
        alias= "Contador:"
        )