from pydantic import BaseModel, Field
from typing import List, Dict, Optional

class BensModel(BaseModel):
    imoveis_urbanos: Optional[str] = Field(
        description="Full description of declared urban properties.",
        alias="Imóveis urbanos"
    )
    imoveis_rurais: Optional[str] = Field(
        description="Full description of declared rural properties.",
        alias="Imóveis rurais"
    )
    imoveis_terceiros: Optional[str] = Field(
        description="Full description of third-party rural properties.",
        alias="Imóveis rurais de terceiros"
    )
    veiculos: Optional[str] = Field(
        description="Full description of declared vehicles.",
        alias="Veículos"
    )
    maquinas: Optional[str] = Field(
        description="Full description of declared machinery.",
        alias="Máquinas"
    )
    rebanhos: Optional[str] = Field(
        description="Description of declared livestock herds.",
        alias="Rebanhos"
    )
    semoventes: Optional[str] = Field(
        description="Description of declared movable livestock.",
        alias="Semoventes"
    )
    outros: Optional[str] = Field(
        description="Description of other assets not covered by the previous categories.",
        alias="Outros"
    )

class Address(BaseModel):
    tipo: str = Field(
        description="Type of address (e.g., AVENIDA, RUA, FAZENDA).",
        example=["AVENIDA", "RUA", "FAZENDA"],
        alias="Tipo:"
    )
    logradouro: str = Field(
        description="Name of the street, avenue, or road.",
        example="ANTONIO FERREIRA SOBRINHO",
        alias="Logradouro:"
    )
    numero: str = Field(
        description="Street number of the address.",
        example="3117",
        alias="Número:"
    )
    bairro: str = Field(
        description="Neighborhood of the address.",
        example="CENTRO",
        alias="Bairro:"
    )
    uf: str = Field(
        description="State (UF) where the address is located.",
        example=["MT", "RS", "SP", "MG"],
        alias="UF:"
    )
    receive_correspondence: str = Field(
        description="Indicates whether the associate receives correspondence ('SIM' or 'NÃO').",
        examples=["SIM", "NÃO"],
        alias="Recebe correspondência?:"
    )
    proven: str = Field(
        description="Indicates whether the address was verified ('SIM' or 'NÃO').",
        examples=["SIM", "NÃO"],
        alias="Comprovado?:"
    )

class Identification(BaseModel):
    document_type: str = Field(
        description="Type of document used for identification (e.g., RG, CNH).",
        examples=['CARTEIRA DE IDENTIDADE', 'CNH', 'CARTEIRA NACIONAL DE HABILITACAO', 'CARTEIRA DE IDENTIDADE'],
        alias="Tipo de Documento:"
    )
    document_number: str = Field(
        description="Document number (ID, driver’s license, etc).",
        examples="2114177335",
        alias="N° do documento:"
    )
    emission_date: Optional[str] = Field(
        description="Issuance date of the identification document.",
        examples="23/05/2002",
        alias="Data de emissão:"
    )
    issuing_body: Optional[str] = Field(
        description="Authority that issued the identification document.",
        examples=['SSP', 'DETRAN', 'SJS'],
        alias="Orgão emissor:"
    )
    uf: str = Field(
        description="State (UF) where the document was issued.",
        example=["MT", "RS", "SP", "MG"],
        alias="UF:"
    )

class Registration_Pf(BaseModel):
    name: str = Field(
        description="Full name of the associate, typically found after 'Dados pessoais'.",
        example="POLIANA RIBEIRO CARVALHO",
        alias="Nome:"
    )
    cpf: str = Field(
        description="CPF number of the associate.",
        example="867.825.800-40",
        alias="CPF:"
    )
    identification: List[Identification] = Field(
        description="Identification details (e.g., ID card or driver's license).",
        alias="Identificação:"
    )
    renovation_date: str = Field(
        description="Date of the last registration update.",
        example="10/04/2025",
        alias="Data de Renovação:"
    )
    occupation: str = Field(
        description="Occupation of the associate.",
        example=["Produtor agropecuário", "Policial militar", "Servidor Público"],
        alias="Ocupacao:"
    )
    cbo: str = Field(
        description="CBO (Brazilian Occupation Code) of the associate.",
        example="141010",
        alias="CBO:"
    )
    category: str = Field(
        description="Employment category of the associate.",
        examples=["Empregado", "Autônomo", "Aposentado"],
        alias="Categoria da Ocupacao:"
    )
    employer: Optional[str] = Field(
        description="Name or corporate name of the employer, if applicable.",
        examples="EMPRESA DE TRANSPORTES LTDA",
        alias="Empregador:"
    )
    employer_cnpj: Optional[str] = Field(
        description="CNPJ or CPF of the employer if the name is provided.",
        examples="00.000.000/0001-01",
        alias="CNPJ do Empregador:"
    )
    endereco: Address = Field(
        description="Main address of the associate or their employer.",
        alias="Endereço:"
    )
    income_type: str = Field(
        description="Type of income: 'Efetiva' (actual) or 'Prevista' (expected).",
        examples=['Efetiva', 'Prevista'],
        alias="Tipo da renda:"
    )
    income_description: str = Field(
        description="Description of the declared income (e.g., salary, retirement).",
        examples=['SALÁRIO LÍQUIDO', 'RENDIMENTO LÍQUIDO DO CONJUGÊ', 'APOSENTADORIA/PENSÕES', 'LOCAÇÕES E ARRENDAMENTOS', 'RENDAS AGROPECUÁRIAS', 'PRÓ-LABORE/PARTICIPAÇÕES SOCIETÁRIAS', 'OUTROS'],
        alias='Campo:'
    )
    income: str = Field(
        description="Income amount, located right after the description.",
        example="15.000,00",
        alias="Valor:"
    )
    periodicity: str = Field(
        description="Income frequency (e.g., monthly, quarterly).",
        example=["Mensal", "Trimestral", "Semestral", "Anual"],
        alias="Periodicidade:"
    )
    goods: Optional[BensModel] = Field(
        description="Declared assets grouped by type.",
        alias="Bens:"
    )
