from pydantic import BaseModel, Field
from typing import List, Dict, Optional

from typing import Any, List, Dict, Optional
from pydantic import BaseModel, Field

class Consulta_Optantes(BaseModel):
    company: str = Field(
        description="Name of the company",
        examples="COMERCIO DE LANCHES LTDA",
        alias= "Nome"
        )
    cnpj: str = Field(
        description="The CNPJ (Cadastro Nacional da Pessoa Jurídica) is the registration number of a company or entity with the Brazilian Federal Revenue Service.", 
        examples="12.345.678/0001-90",
        alias="CNPJ"
        )

    datetime: str = Field(
        description="Date and time of the report. You can find as 'Data e Horário da Transmissão da Declaração'. Return the format dd/mm/yyyy HH:MM:SS",
        examples= "29/07/2024 15:47:54",
        alias="Data da consulta"
        )
    situation_simples: str = Field(
        description= "situation under the simplified national tax regime",
        examples= "NÃO optante pelo Simples Nacional",
        alias="Situacao no Simples Nacional"
    )
    situation_simei: str = Field(
        description= "situation in simei",
        examples= "NÃO enquadrado no SIMEI",
        alias="Situacao no SIMEI"
    )