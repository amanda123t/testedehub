from pydantic import BaseModel, Field
from typing import Optional


class SelfDeclarationAddress(BaseModel):
    member_name: str = Field(
        description="Full name of the member who issued the declaration.",
        example="JOÃO DA SILVA",
        alias="Nome:"
    )

    cpf: str = Field(
        description="CPF of the member in xxx.xxx.xxx-xx format.",
        example="123.456.789-10",
        alias="CPF:"
    )

    declared_address: str = Field(
        description="Address declared by the member, exactly as reported in the document.",
        example="Rua das Flores, 123 - Centro - Porto Alegre/RS",
        alias="Endereço Declarado:"
    )

    issue_date: Optional[str] = Field(
        description="Document issuance date in DD/MM/YYYY format, if provided.",
        example="12/11/2024",
        alias="Data de Emissão:"
    )
