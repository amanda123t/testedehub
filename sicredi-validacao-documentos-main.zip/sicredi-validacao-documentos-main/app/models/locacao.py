from pydantic import BaseModel, Field
from typing import List, Optional, Dict


class Person(BaseModel):
    name: str = Field(
        description="Full name of the individual.",
        example="JOÃO DA SILVA",
        alias="Nome:"
    )
    cpf: Optional[str] = Field(
        description="CPF in xxx.xxx.xxx-xx format.",
        example="123.456.789-10",
        alias="CPF:"
    )


class RentalProperty(BaseModel):
    property_type: Optional[str] = Field(
        description="Type of rented asset (e.g., 'Imóvel', 'Veículo', 'Máquina agrícola').",
        example="Imóvel",
        alias="Tipo do Bem:"
    )

    registration_number: Optional[str] = Field(
        description="Property registry/matrícula number, if provided.",
        example="123456 789 0001 9",
        alias="Número da Matrícula:"
    )

    description: str = Field(
        description="Detailed description of the rented property.",
        example="Casa residencial localizada na Rua Central, nº 100.",
        alias="Descrição do Imóvel:"
    )

    municipality: str = Field(
        description="Municipality where the asset/property is located.",
        example="Porto Alegre",
        alias="Município:"
    )

    address: Optional[str] = Field(
        description="Address of the property, if provided.",
        example="Rua Central, 100 - Centro - Porto Alegre/RS",
        alias="Endereço do Imóvel:"
    )


class Locacao(BaseModel):
    names: Dict[str, List[Person]] = Field(
        description=(
            "Dictionary grouping all parties of the contract. "
            "Must contain 'Locador' and 'Locatário', each with a list of Person objects."
        ),
        example={
            "Locador": [{"Nome": "JOÃO", "CPF": "123.456.789-10"}],
            "Locatário": [{"Nome": "MARIA", "CPF": "987.654.321-00"}]
        },
        alias="Nomes:"
    )

    lease_term_years: Optional[str] = Field(
        description=(
            "Lease term expressed in years (e.g., '1 ano', '3 anos'). "
            "If only the duration in years is present, only this field is filled."
        ),
        example="3 anos",
        alias="Prazo (Anos):"
    )

    lease_term_date: Optional[str] = Field(
        description=(
            "Lease term expressed as start–end dates "
            "(e.g., '01/02/2024 a 01/02/2025'). "
            "Returned if the document specifies dates like 'até XX/XX/XXXX'."
        ),
        example="01/02/2024 a 01/02/2025",
        alias="Prazo (Data):"
    )

    rent_value: Optional[str] = Field(
        description="Rent value in BRL as written in the document.",
        example="R$ 1.500,00",
        alias="Valor da Locação:"
    )

    properties: List[RentalProperty] = Field(
        description="List of all rented properties/assets associated with the contract.",
        alias="Imóveis:"
    )

    issue_date: Optional[str] = Field(
        description="Date when the contract was issued (DD/MM/YYYY).",
        example="10/03/2024",
        alias="Data de Emissão:"
    )

    registry_office: Optional[str] = Field(
        description="Name of the notary office where the contract was registered, if applicable.",
        example="2º Tabelionato de Notas de Caxias do Sul",
        alias="Nome do Cartório:"
    )
