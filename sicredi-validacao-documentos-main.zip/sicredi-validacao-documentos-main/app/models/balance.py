from pydantic import BaseModel, Field
from typing import Dict, List, Optional

class AtivoItem(BaseModel):
    name: str = Field(
        alias="Nome",
        description=(
            "Item do bloco do Ativo no balanço patrimonial. "
            "Inclua todos os itens que NÃO pertencem ao passivo E patrimônio líquido, mesmo se houver repetições, nomes semelhantes ou for um valor muito baixo como 1 centavo, não deixe NADA DE FORA, inclusive TITULOS como 'CIRCULANTE' e 'NÃO CIRCULANTE'. "
            "Mantenha os nomes exatamente como aparecem no documento."
            "NÃO EXCLUA NENHUM ITEM, mesmo que pareça redundante ou estejam duplicados."
        ),
        example=["Caixa", "Bancos", "Contas a Receber", "Clientes", "(-) Adiantamentos"]
    )
    value: str = Field(
        alias="Valor",
        description=(
            "Valor bruto do item exatamente como no documento, incluindo sufixos como '-', 'D', 'C', 'CR' ou 'DB' se tiverem presentes no documento. Não realizar cálculos ou conversões."
        ),
        example= ["10.000,00D", "10.000,00-", "-10.000,00", "10.000,00C"]
    )

class PassivoOuPLItem(BaseModel):
    name: str = Field(
        alias="Nome",
        description=(
            "Item do bloco do Passivo E Patrimônio Líquido no balanço patrimonial "
            "Inclua todos os itens que NÃO pertencem ao ativo. "
            "Retorne todos os nomes como estão no documento, sem omissões ou agrupamentos, inclusive titulos como 'PASSIVO CIRCULANTE', 'PASSIVO NAO CIRCULANTE', 'OBRIGACOES A CURTO PRAZO', 'PATRIMONIO LIQUIDO', etc."
            "NÃO EXCLUA NENHUM ITEM, mesmo que pareça redundante ou estejam duplicados."
            "Não deixe NENHUM campo do patrimônio líquido de fora."

        ),
        example=["Fornecedores", "Salários a Pagar", "Impostos a Recolher", "(-) Adiantamentos"]
    )
    value: str = Field(
        alias="Valor",
        description=(
            "Valor bruto do item exatamente como no documento, incluindo sufixos como '-', 'D', 'C', 'CR' ou 'DB' se tiverem presentes no documento. Não realizar cálculos ou conversões."
        ),
        example= ["80.000,00C", "80.000,00-", "-80.000,00", "80.000,00D"]
    )

class Partner(BaseModel):
    Nome: str = Field(description="Nome do sócio/administrador/representante")
    CPF: Optional[str] = Field(
        description='CPF no formato ###.###.###-##. Se não houver, retorne ""',
        default=""
    )
    
class Balance(BaseModel):
    reference_date: str = Field(alias="Data de Referência:", description="Data de encerramento do balanço patrimonial.")

    total_assets: str = Field(alias="Ativo Total:", description="Valor total do Ativo.")
    total_liabilities: str = Field(alias="Passivo Total:", description="Valor total do Passivo.")
    total_equity: str = Field(alias="Patrimônio Líquido:", description="Valor total do Patrimônio Líquido.")

    componentes_do_ativo: List[AtivoItem] = Field(
        alias="Componentes do Ativo:",
        description=(
            "✅ Lista de TODOS os itens que pertencem ao Ativo total, inclusive titulos como 'ATIVO CIRCULANTE' e 'NÃO CIRCULANTE'. "
            "Inclua tudo que estiver no ativo circulante e no ativo não circulante. "
            "Não inclua nenhum item do PASSIVO ou PATRIMONIO aqui, apenas oque compoem o ATIVO TOTAL"
            "Não omita ou agrupe títulos similares. Preserve nomes originais."
            "NÃO EXCLUA NENHUM ITEM, mesmo que pareça redundante ou estejam duplicados."
        )
    )

    componentes_do_passivo_e_pl: List[PassivoOuPLItem] = Field(
        alias="Componentes do Passivo e Patrimônio Líquido:",
        description=(
            "✅ Lista de TODOS os itens que pertencem ao Passivo circulante, não circulante E ao Patrimônio Líquido, inclusive títulos como 'PASSIVO CIRCULANTE', 'PASSIVO NAO CIRCULANTE', 'PATRIMONIO LIQUIDO', ETC. "
            "Preserve os campos como 'PATRIMÔNIO LÍQUIDO', mesmo que seja o mesmo valor do total do patrimônio líquido. "
            "Não inclua nenhum item do ativo aqui. Retorne os nomes conforme estão no documento."
            "NÃO EXCLUA NENHUM ITEM, mesmo que pareça redundante ou estejam duplicados."
            "Não deixe NENHUM campo do patrimônio líquido de fora."
        )
    )
    #counter_data: Dict = Field(
    #    description="Counter's name, CRC (CONSELHO REGIONAL CONTABILIDADE) and the signature",
    #    alias= "Contador:"
    #    )
    #partner_data: Dict = Field(
    #    description="Partner's name and CPF (Cadastro de Pessoa Física)",
    #    alias= "Sócios:"
    #    )
    

class BalanceSheetList(BaseModel):
    company_name: str = Field(alias="Nome:", description="Razão social completa da empresa.")
    cnpj: str = Field(alias="CNPJ:", description="Número de CNPJ da empresa.")
    balances: Dict[str, Balance] = Field(
        description="Balanços patrimoniais separados por ano. Verifique se há informações de mais de um ano, retorno todos os anos e as informações completas.",
        alias="Balanços"
        )
    counter_data: Optional[dict] = Field(
        description="Counter's name, CRC (CONSELHO REGIONAL CONTABILIDADE) and the signature",
        alias= "Contador:"
        )
    
    partner_data: List[Partner] = Field(
        description="Name and CPF (Cadastro de Pessoa Física) of the company's partner/administrator/representative",
        alias= "Sócios:"
        )

