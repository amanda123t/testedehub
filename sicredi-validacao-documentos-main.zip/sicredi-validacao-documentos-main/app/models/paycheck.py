from pydantic import BaseModel, Field
from typing import Optional, List

class Item(BaseModel):
    description: str = Field(description="Description of the item.", alias="Nome")
    reference: Optional[str] = Field(
        description="Reference associated with the item, can be in date format, percentage, hours worked, overtime, percentages, etc.",        
        example=["200", "1.402", "09/2025", "02/2025", "220,00", "240", "50","27,50",'12,5', "25%", "4.52"],
        alias="Referência:"
    )
    amount: str = Field(
        description="Valor associated with the item.",
        example=["R$ 1.000,00", "1.000,00", "546,87", "897,31"],
        alias="Valor:",
    )

class Paycheck(BaseModel):
    name: str = Field(description="Name of the employee", alias="Nome:")
    cpf: str = Field(
        description=(
        "CPF (Individual Taxpayer Registry) – 11 digits in the format 123.456.789-10. Not to be confused with CNPJ (14 digits, 05.928.773/0001-56)."        ),
        alias="CPF:",
    )
    department: Optional[str] = Field(
        description="Department the employee works in",
        example="Financeiro",
        alias="Departamento:",
    )
    institution: str = Field(
        description="Institution where the employee is working",
        example="Banco do Brasil",
        alias="Instituição:",
    )
    cnpj: Optional[str] = Field(
        description=( "CNPJ in the format xx.xxx.xxx/xxxx-xx."),
        examples=["12.345.678/0001-90", "08.845.360/0001-45"],
        alias="CNPJ:",
    )
    occupation: Optional[str] = Field(
        description="Occupation or job title",
        example="Analista Financeiro",
        alias="Cargo:",
    )
    cbo: Optional[str] = Field(
        description="Brazilian Classification of Occupations (CBO) code (6 digits)",
        example="252205",
        alias="CBO:",
    )
    reference_month: str = Field(
        description="The reference month of the payslip. Respond in the format MM/YYYY",
        example="02/2024",
        alias="Mês de Referência:",
    )
    since_when_occupation: Optional[str] = Field(
        description="Date the employee started the occupation. Respond in the format DD/MM/YYYY. You can find as 'Admissão' or 'data de admissão'",
        example="15/06/2020",
        alias="Desde Quando na Função:",
    )

    base_salary: Optional[str] = Field(
        description="Fixed salary without bonuses",
        example="R$ 4.500,00",
        alias="Salário Base:",
    )
    total_salary: str = Field(
        description="Total salary, sum of all items received.",
        example="20.000,00",
        alias="Salário Total:"
    )
    total_deductions: str = Field(
        description="Total discounts, sum of all discounted items.",
        example="2.000,00",
        alias="Desconto total:"
    )
    net_salary: str = Field(
        description="Net salary after deductions",
        example="R$ 5.000,75",
        alias="Salário Líquido:",
    )
    # NOVAS LISTAS – categorias específicas
    overtime: Optional[List[Item]] = Field(
        description=(
            "Items related to overtime (p. ex.: H.E 50%, H.E 100%, Hora Extra, Extra, DSR s/ Hora Extra, etc.)."
        ),
        alias="Horas Extras:",
        default_factory=list,
    )
    bonuses: Optional[List[Item]] = Field(
        description=(
            "Items related to bonuses (p. ex.: Grat. xxxx, Gratificação xxxx, Grat. Edu, função gratificada). ATTENTION: 'Gratificação Natalina' does NOT go here."
        ),
        examples=[
            "FUNÇÃO GRATIFICADA", 
            "GRATIFICAÇÃO", 
            "GRATIFICAÇÕES", 
            "GRAT. FUNÇÃO", 
            "GRAT. EDUCAÇÃO",
            "GRAT. EDU",
            "GRATIFICAÇÃO DE FUNÇÃO"
        ],
        alias="Gratificações:",
        default_factory=list,
    )
    commissions: Optional[List[Item]] = Field(
        description=(
            "Items related to commissions (p. ex.: Comiss. sobre vendas, comissões, comissão)."
        ),
        examples=[
            "FUNÇÃO COMISSIONADA", 
            "COMISSÃO", 
            "COMISSÕES"
        ],
        alias="Comissões:",
        default_factory=list,
    )

    # Itens restantes de salário que não se enquadram nas 3 categorias acima
    salary: List[Item] = Field(
        description=("Other salary items that are not HE, are not bonuses and are not commissions."),
        alias="Itens de Salario",
        examples=[
            "PRO LABORE",
            "SALARIO NORMAL",
            "SALARIO",
            "SUBSIDIOS",
            "FUNÇAO CONFIANÇA",
            "INSALUBRIDADE",
            "ADICIONAL DE PERICULOSIDADE",
            "AJUDA DE CUSTO",
            "AUXILIO ALIMENTAÇÃO",
            "AUXILIO CRECHE",
            "AUXILIO TRANSPORTE",
            "AUXILIO SAUDE",
            "INDENIZAÇÃO", 
            "ATESTADOS", 
            "FALTAS", 
            "ADICIONAL DE FUNÇÃO",
            "ADICIONAL NOTURNO",
            "FUNÇÃO CONFIANÇA"
        ],
        default_factory=list,
    )

    deductions: List[Item] = Field(
        description="Amounts deducted from the employee's salary.",
        alias="Descontos:",
        default_factory=list,
    )

class PaycheckList(BaseModel):
    paychecks: List[Paycheck] = Field(
        description="List of paycheck. There are one or more paychecks in the context, bring all of them.",
        alias="Holerites"
    )
