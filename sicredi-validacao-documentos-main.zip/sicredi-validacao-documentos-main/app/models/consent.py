from pydantic import BaseModel, Field
from typing import Dict


class User(BaseModel):
    name: str = Field(
        description="Full name of the person associated with the document.",
        example="João da Silva",
        alias="Nome:"
    )
    
    cpf: str = Field(
        description="""CPF (Cadastro de Pessoas Físicas) is the taxpayer identification number for individuals in Brazil. It should have 11 digits in the format 123.456.789-10.  Example: 123.456.789-10.
It should not be confused with CNPJ, which is for legal entities (businesses).
CNPJ has 14 digits and follows the format 05.928.773/0001-56.""",
        alias="CPF:"
    )

class Property(BaseModel):
    address: str = Field(
        description="Address of the property. You can find as 'Endereço Completo'.",
        example="Rua das Flores, 123",
        alias="Endereço:"
    )
    
    information: str = Field(
        description="Information about the property. You can find as 'Número da matrícula e Cartório de Registro'.",
        example="Casa com 3 quartos, 2 banheiros e 1 vaga de garagem.",
        alias="Informações:"
    )
    
class Contract(BaseModel):
    typoe: str = Field(
        description="Type of contratct.",
        examples=["Arrendamento", "Anuência", "Comodato"],
        alias="Tipo de contrato:"
    )
    area: str = Field(
        description="Total area of the property. You can find as 'Área total do IMÓVEL'",
        example="149,9 ha",
        alias="Área:"
    )
    explored_area: str = Field(
        description="Area of the property that can being explored by the user. You can find as 'Área total que pode ser explorada pelo USUÁRIO'",
        example="100 ha",
        alias="Área explorada:"
    )
    start_end_date: str = Field(
        description="Start and end date of the contract. You can find as 'VigÇencia da relação contatual e desta Carta de AnuÇencia'.",
        example="01/01/2021 à 01/01/2026",
        alias="Vigiência:"
    )
    

class Consent(BaseModel):
    anu: User = Field(
        description="Property owner's personal information.",
        alias="Anuente:"
    )
    
    user: User = Field(
        description="The user's personal information.",
        alias="Usuário:"
    )
    property: Property = Field(
        description="Property information.",
        alias="Imóvel:"
    )
    
    contract: Contract = Field(
        description="Contract information.",   
        alias="Contrato:"
    )