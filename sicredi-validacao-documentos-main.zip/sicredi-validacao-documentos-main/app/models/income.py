from pydantic import BaseModel, Field
from typing import List, Dict, Optional

class Income(BaseModel):
    name: Optional[str] = Field(
        description=(
            "Return the name exactly as written in the document. "
            "Names containing an underscore '_' MUST be ignored entirely. "
            "If a name contains '_', do NOT rewrite, clean, or modify it — simply discard it. "
            "If all names in the document contain '_', return an empty string. "
            "Only return a name that appears in the document AND does not contain '_'."
        ),
        alias="Nome:"
    )
    
    extraction_date: Optional[str] = Field(
        description="Date and time when the document was extracted, in the format DD/MM/YYYY HH:MM:SS.",
        example="25/02/2025 14:30:00",
        alias="Data de Extração:"
    )
    
    system: str = Field(
        description="System from which the presumed income document was downloaded.",
        example="Bureau",
        alias="Sistema (Fonte):"
    )
    risk: str = Field(
        description="Associate risk, you can find as 'Faixa de Risco padrão:'.",
        example=["BAIXISSIMO", "BAIXO", "MÉDIO 1", "MÉDIO 2", "ALTO", "ALTISSIMO", "DEFAUT"],
        alias="Faixa de risco:"
    )
    
    value: str = Field(
        description="Amount stated on the presumed income document, using two decimal places.",
        example="12345.67",
        alias="Valor:"
    )

