from pydantic import BaseModel, Field
from typing import List, Dict, Optional

from typing import Any, List, Dict, Optional
from pydantic import BaseModel, Field

class Simples(BaseModel):
    company: str = Field(
        description="Name of the company",
        examples="COMERCIO DE LANCHES LTDA",
        alias= "Nome"
        )
    cnpj: str = Field(
        description="The CNPJ (Cadastro Nacional da Pessoa Jurídica) is the registration number of a company or entity with the Brazilian Federal Revenue Service.", 
        examples="12.345.678/0001-90",
        alias="CNPJ"
        )
    period: str = Field(
        description="Covered period. Return the format 'dd/mm/yyyy - dd/mm/yyyy'",
        examples="01/01/2023 a 31/12/2023",
        alias="Período"
        ) 
    summary: Optional[List[str]] = Field(
        description="Summary of the period. Return the PA (Período Abrangido - Covered Period) values",
        examples="01/2023 , 02/2023, 03/2023, 04/2023",
        alias="Meses:"
        )
    gross_revenue: str = Field(
        description="Gross revenue. You can find as 'Receita Bruta Total'. Return the format R$0.000,00",
        examples= "R$ 65.430,00",
        alias= "Faturamento total:"
        )
    datetime: str = Field(
        description="Date and time of the report. You can find as 'Data e Horário da Transmissão da Declaração'. Return the format dd/mm/yyyy HH:MM:SS",
        examples= "29/07/2024 15:47:54",
        alias="Data de Emissão"
        )