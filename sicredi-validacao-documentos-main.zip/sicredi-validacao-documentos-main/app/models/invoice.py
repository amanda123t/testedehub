from pydantic import BaseModel, Field
from typing import Dict, List, Optional

class Partner(BaseModel):
    Nome: str = Field(description="Nome do sócio/administrador/representante")
    CPF: Optional[str] = Field(
        description='CPF no formato ###.###.###-##. Se não houver, retorne ""',
        default=""
    )

class Invoice(BaseModel):
    company: str = Field(
        description="Name of the company",
        alias= "Nome:"
        )
    cnpj: Optional[str] = Field(
        description="The CNPJ (Cadastro Nacional da Pessoa Jurídica) is the registration number of a company or entity with the Brazilian Federal Revenue Service. Return in format xx.xxx.xxx/xxxx-xx", 
        alias= "CNPJ:"
        )
    title: str = Field(
        description="The document title appears at the beginning.",
        examples= [
            "DEMONSTRAÇÃO DE FATURAMENTO",
            "DESMONTRAÇÃO DE SERVIÇOS PRESTADOS",
            "DEMONSTRATIVO DE VENDAS",
            "DESMONTRAÇÃO DO FATURAMENTO DOS ULTIMOS 12 MESES",
            "RELAÇÃO DE FATURAMENTO",
            "PREVISÃO DE FATURAMENTO",
            "RELAÇÃO DE DESPESAS",
            "RELAÇÃO DE VENDAS",
            "RELATÓRIO DE FATURAMENTO"
        ],
        alias= "Título:"
    )
    
    period: str = Field(
        description="document period mm/yyyy to mm/yyyy if informed",
        examples= '03/2024 a 02/2025',
        alias= "Periodo:",
        )
    months: Dict[str, str | dict] = Field(
        description="Reported months. Respond with the month as a key and the amount as the value an the total too. Format thr value as R$0.000,00, If the value for any month is zero, return R$ 0.00.",
        alias= "Meses:"
        )
    total_revenue: str | Dict[str, str] = Field(
        description="total revenue if informed",
        examples=["R$ 0,00", "À vista: R$ 0,00 À prazo: R$ 0,00"],
        alias= "Faturamento total:",
        )
    date: Optional[str] = Field(
        description="The issue date. Return the format dd/mm/yyyy",
        examples= "11/05/2024",
        alias= "Data de emissão:"
        )
    counter_data: Optional[dict] = Field(
        description="Counter's name, CRC (CONSELHO REGIONAL CONTABILIDADE) and the signature",
        alias= "Contador:"
        )
    
    partner_data: List[Partner] = Field(
        description="Name and CPF (Cadastro de Pessoa Física) of the company's partner/administrator/representative",
        alias= "Sócios:"
        )
    

    

