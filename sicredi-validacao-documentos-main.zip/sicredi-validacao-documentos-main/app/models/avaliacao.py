from pydantic import BaseModel, Field

class Appraiser(BaseModel):
    name: str = Field(
        description="Appraiser full name.",
        example="Carlos Pereira",
        alias="Nome do Avaliador:"
    )

    cpf: str = Field(
        description="Appraiser CPF.",
        example="123.456.789-10",
        alias="CPF do Avaliador:"
    )

    registration_number: str = Field(
        description="Appraiser professional registration number.",
        example="CRECI 12345",
        alias="Número do Registro:"
    )

    registration_type: str = Field(
        description="Type of registry: CRECI, CREA, CFTA, etc.",
        example="CREA",
        alias="Tipo de Registro:"
    )

class Avaliacao(BaseModel):
    appraisal_date: str = Field(
        description="Date of the appraisal in DD/MM/YYYY.",
        example="22/04/2024",
        alias="Data da Avaliação:"
    )

    appraiser: Appraiser = Field(
        description="Appraiser identification block.",
        alias="Identificação do Avaliador:"
    )

    property_identification: str = Field(
        description="Property identification text extracted from the report.",
        example="Imóvel localizado na Rua X, nº 123, Bairro Centro",
        alias="Identificação do Imóvel:"
    )

    total_appraisal_value: str = Field(
        description="Total appraised value of the property.",
        example="R$ 350.000,00",
        alias="Valor Total da Avaliação:"
    )

    forced_sale_value: str = Field(
        description="Forced sale / liquidation value (if applicable).",
        example="R$ 230.000,00",
        alias="Valor de Liquidação / Venda Forçada:"
    )

    registry_number: str = Field(
        description="Property registry (matrícula) number.",
        example="123456 55 2020 1 00012 543 987",
        alias="Número da Matrícula do Imóvel:"
    )

    owners: dict = Field(
        description="Owners (interested parties) with name and CPF.",
        example={
            "Proprietario_1": {"Nome": "João da Silva", "CPF": "111.111.111-11"},
            "Proprietario_2": {"Nome": "Maria Souza", "CPF": "222.222.222-22"}
        },
        alias="Proprietários:"
    )
