from pydantic import BaseModel, Field
from typing import Optional, Dict


class Obito(BaseModel):
    name: str = Field(
        description="Full name of the deceased.",
        example="José da Silva",
        alias="Nome:"
    )

    cpf: Optional[str] = Field(
        description="CPF of the deceased (may not always be present).",
        example="123.456.789-10",
        alias="CPF:"
    )

    registration_number: str = Field(
        description="Official certificate registry number (matrícula), longer than 20 characters.",
        example="123456 55 2021 1 00012 345 678",
        min_length=20,
        alias="Número da Matrícula:"
    )

    death_date: str = Field(
        description="Date of death in DD/MM/YYYY format.",
        example="03/08/2021",
        alias="Data do Falecimento:"
    )

    death_cause: str = Field(
        description="Cause of death as described in the certificate.",
        example="Parada cardiorrespiratória",
        alias="Causa da Morte:"
    )

    registry_office: str = Field(
        description="Name of the notary office (cartório).",
        example="Cartório de Registro Civil de Campinas",
        alias="Nome do Cartório:"
    )
    selo_autenticidade: Optional[Dict[str, str]] = Field(
        default=None,
        description="Authentication seal of the court of justice, when informed in the document",
        example={
            "selo": "101691 55 2024 00004436 94",
            "orgao": "TJRS",
            "tipo": "Selo Digital"
        },
        alias="Selo de Autenticidade:"
    )