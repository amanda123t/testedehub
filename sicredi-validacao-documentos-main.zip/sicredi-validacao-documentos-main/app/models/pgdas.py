from pydantic import BaseModel, Field
from typing import Any, List, Dict, Optional
from pydantic import BaseModel, Field

class TotalReceitasBrutas(BaseModel):
    internal: str = Field(
        description="Gross revenue from the domestic market. Format: R$0.000,00. Corresponds to the field labeled 'Mercado Interno'.",
        alias="Mercado Interno",
    )
    external: str = Field(
        description="Gross revenue from the foreign market. Format: R$0.000,00. Corresponds to the field labeled 'Mercado Externo'.",
        alias="Mercado Externo",
    )
    total: str = Field(
        description="Total gross revenue. Format: R$0.000,00. Corresponds to the field labeled 'Total'.",
        alias="Total",
    )


class ReceitasBrutasAnteriores(BaseModel):
    month: str = Field(
        description="Month reference from the previous year. Format: MM/YYYY. Corresponds to the field labeled 'Mês'.",
        alias="Mês",
    )
    internal: str = Field(
        description="Domestic gross revenue for the given month in the previous year. Format: R$0.000,00. Corresponds to 'Mercado Interno'.",
        alias="Mercado Interno",
    )
    external: str = Field(
        description="Foreign gross revenue for the given month in the previous year. Format: R$0.000,00. Corresponds to 'Mercado Externo'.",
        alias="Mercado Externo",
    )


class PGDAS(BaseModel):
    company: str = Field(
        description="Registered company name. Corresponds to the field labeled 'Empresa'.",
        alias="Nome",
    )
    cnpj: str = Field(
        description="Main corporate tax ID (CNPJ). Format: 12.345.678/0001-90. Corresponds to 'CNPJ Matriz'.",
        examples=["12.345.678/0001-90"],
        alias="CNPJ Matriz",
    )
    branches_cnpj: Optional[List[str]] = Field(
        description="List of branch CNPJs. Format: 12.345.678/0001-90. Corresponds to 'CNPJ Filiais'.",
        examples=["12.345.678/0001-90", "98.765.432/0001-01"],
        alias="CNPJ Filiais",
    )
    opening_date: str = Field(
        description="Company’s official opening date. Format: dd/mm/yyyy. Corresponds to 'Data de Abertura'.",
        examples=["01/01/2000"],
        alias="Data de Abertura",
    )
    period: str = Field(
        description="Covered reporting period. Format: dd/mm/yyyy - dd/mm/yyyy. Corresponds to 'Período Abrangido'.",
        alias="Período Abrangido",
    )
    summary: Optional[List[str]] = Field(
        description="Summary of the covered period. Each entry contains a month/year and value. Derived from '2. Resumo da Declaração'.",
        examples=[
            'MAIO/2024: R$0,00', 'JUNHO/2024: R$0,00', 'JULHO/2024: R$0,00',
            'AGOSTO/2024: R$0,00', 'SETEMBRO/2024: R$0,00', 'OUTUBRO/2024: R$0,00',
            'NOVEMBRO/2024: R$0,00', 'DEZEMBRO/2024: R$0,00', 'JANEIRO/2025: R$0,00',
            'FEVEREIRO/2025: R$0,00', 'MARÇO/2025: R$0,00', 'ABRIL/2025: R$69.952,13'
        ],
        alias="Resumo do Período Abrangido",
    )
    gross_revenue: str = Field(
        description="Total gross revenue. Format: R$0.000,00. Corresponds to the field labeled 'Receita Bruta Total'.",
        alias="Receita Bruta Total",
    )
    datetime: str = Field(
        description="Date and time of submission. Format: dd/mm/yyyy HH:MM:SS. Corresponds to 'Data e Horário da Transmissão da Declaração'.",
        alias="Data e Horário",
    )
    discriminativo_receitas: Optional[Dict[Any, Dict[str, TotalReceitasBrutas]]] = Field(
        description="Breakdown of gross revenue. Includes values from: 'Receita Bruta do PA', 'Receita bruta acumulada no ano-calendário corrente', and 'Receita bruta acumulada no ano-calendário anterior'. Derived from '2.1 Discriminativo de Receitas'.",
        examples={
            "Receita Bruta do PA": {
                "Mercado Interno": "R$0.000,00",
                "Mercado Externo": "R$0.000,00",
                "Total": "R$0.000,00"
            },
            "Receita bruta acumulada no ano-calendário corrente": {
                "Mercado Interno": "R$0.000,00",
                "Mercado Externo": "R$0.000,00",
                "Total": "R$0.000,00"
            },
            "Receita bruta acumulada no ano-calendário anterior": {
                "Mercado Interno": "R$0.000,00",
                "Mercado Externo": "R$0.000,00",
                "Total": "R$0.000,00"
            }
        },
        alias="Discriminativo de Receitas",
    )
    last_year: Optional[List[ReceitasBrutasAnteriores]] = Field(
        description="Historical gross revenue by month from the previous calendar year. Format: R$0.000,00. Derived from section '2.2) Receitas Brutas Anteriores (R$)'.",
        alias="Total de Receitas Brutas Anteriores",
    )