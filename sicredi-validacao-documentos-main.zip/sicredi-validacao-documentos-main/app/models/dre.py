from pydantic import BaseModel, Field
from typing import Dict, List, Optional

class TotaisTitulo(BaseModel):
    # Preencha SOMENTE quando reconhecer com segurança
    Deducoes: Optional[float] = Field(description="Total Deductions, may appear as 'deduções', 'devoluções', 'abatimentos', 'abatimentos e devoluções', etc.")
    ImpostosSobreVenda: Optional[float] = Field(description="Sales and service taxes.")
    custo: Optional[float] = Field(description="Cost of goods, products and services sold, you can find as 'CUSTO DOS PRODUTOS VENDIDOS' OR 'CUSTO MERCADORIAS VENDIDAS'.")
    DespesasOperacionais:  Optional[float] = Field(description="Operating Expenses.")
    DespesasComVendas:  Optional[float] = Field(description="Sales Expenses.")
    DespesasAdministrativas:  Optional[float] = Field(description="Administrative expenses.")
    DespesasComPessoal:  Optional[float] = Field(description="Personnel expenses.")
    UtilidadesServicos:  Optional[float] = Field(description="Utilities and Services.")
    EncargosSociais:  Optional[float] = Field(description="Social charges.")
    DespesasGerais:  Optional[float] = Field(description="General Expenses.")
    DespesasTributarias:  Optional[float] = Field(description="Despesas Tributárias.")
    DespesasFinanceiras:  Optional[float] = Field(description="Financial Expenses.")
    DespesasTributarias:  Optional[float] = Field(description="Tax Expenses.")
    ReceitasFinanceiras:  Optional[float] = Field(description="Financial Revenues.")
    DespesasNaoOperacionais:  Optional[float] = Field(description="Non-Operating Expenses.")
    ReceitasNaoOperacionais:  Optional[float] = Field(description="Non-Operating Revenues.")
    OutrasDespesasOperacionais:  Optional[float] = Field(description="Other Operating Expenses.")
    OutrasReceitasOperacionais:  Optional[float] = Field(description="Other Operating Revenues.")
    ImpostosSobreLucro:  Optional[float] = Field(description="Income taxes (IRPJ/CSLL).")  # IRPJ/CSLL consolidado
    Provisoes:  Optional[float] = Field(description="Provisions.")


class DREANO(BaseModel):
    company_name: str = Field(alias="Nome:", description="Full company name.")
    cnpj: str = Field(alias="CNPJ:", description="Company's CNPJ number, in format xx.xxx.xxx/xxxx-xx.")
    reference_date: str = Field(alias="Data de Referência:", description="DRE closing date.")

    renda_operacional_bruta: float = Field(
        alias="Renda Operacional Bruta:", default=None,
        description="The float, exactly as in the document, is the FIRST value titled 'Receita Operacional', 'Receita Operacional Bruta', 'Receita Bruta', etc. in the document. It always appears before Gross Profit. *PROHIBITED* Returning a value that is not in the document."
    )
    lucro_liquido: float = Field(
        alias="Lucro Líquido do Exercício:", default=None,
        description="The float, exactly as in the document, Net Profit for the Year."
    )

    totais_por_titulo: list[TotaisTitulo] = Field(
        alias="Totais por Título", default=None,
        description="totals by title, fill in whenever they are present in the document."
    )

class DRE(BaseModel):
    balances: Dict[str, DREANO] = Field(
        description="Separate income statements by year. Check if there is information from more than one year; return all years and provide complete information.",
        alias="DREs"
        )