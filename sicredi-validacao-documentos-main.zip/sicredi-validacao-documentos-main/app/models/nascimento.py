from pydantic import BaseModel, Field
from typing import Optional, Dict, List


class Nascimento(BaseModel):
    name: str = Field(
        description="Full name of the newborn.",
        example="Ana Beatriz Silva",
        alias="Nome:"
    )

    cpf: Optional[str] = Field(
        description="CPF of the newborn, if available.",
        example="111.222.333-44",
        alias="CPF:"
    )

    registration_number: str = Field(
        description="Official certificate registry number (matrícula), longer than 20 characters.",
        example="123456 01 55 2023 1 00012 222 999",
        min_length=20,
        alias="Número da Matrícula:"
    )

    birth_date: str = Field(
        description="Date of birth in DD/MM/YYYY format.",
        example="15/09/2023",
        alias="Data do Nascimento:"
    )

    naturality: str = Field(
        description="City and state of origin.",
        example="Porto Alegre - RS",
        alias="Naturalidade:"
    )

    birth_place: str = Field(
        description="Place of birth (hospital, city, or location).",
        example="Hospital Moinhos de Vento",
        alias="Local do Nascimento:"
    )

    sex: str = Field(
        description="Biological sex.",
        example="Feminino",
        alias="Sexo:"
    )

    parents: Dict[str, str] = Field(
        description="Parents of the newborn. Dictionary mapping parental roles to names.",
        example={"Mãe": "Maria da Silva", "Pai": "João Pereira"},
        alias="Filiação:"
    )

    grandparents: Optional[List[str]] = Field(
        description="Grandparents on both sides. Optional field.",
        example=["José da Silva", "Ana Pereira"],
        alias="Avós:"
    )

    twins: Optional[bool] = Field(
        description="Indicates whether the birth was part of a twin set.",
        example=True,
        alias="Gêmeos:"
    )

    twins_data: Optional[List[Dict[str, str]]] = Field(
        description="List containing name and registry of twin siblings.",
        example=[{"Nome": "Beatriz Silva", "Matrícula": "123456 55 ..."}],
        alias="Nome e Matrícula dos Gêmeos:"
    )

    registry_office: str = Field(
        description="Name of the notary office (cartório).",
        example="Cartório de Registro Civil de Curitiba",
        alias="Nome do Cartório:"
    )
    selo_autenticidade: Optional[Dict[str, str]] = Field(
        default=None,
        description="Authentication seal of the court of justice, when informed in the document",
        example={
            "selo": "101691 55 2024 00004436 94",
            "orgao": "TJRS",
            "tipo": "Selo Digital"
        },
        alias="Selo de Autenticidade:"
    )
