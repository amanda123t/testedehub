from pydantic import BaseModel, Field


class Nota_Fiscal(BaseModel):
    issuer: str = Field(
        description="Name of the company or entity that issued the invoice. This is usually the first name that appears in the document, before the recipient.",
        example=["COMERCIO DE BEBIDAS LTDA", "MARIA DE SOUZA", "JONAS MANOEL PINTO"],
        alias="Emissor:"
    )

    recipient: str = Field(
        description="Name of the invoice recipient.",
        example="JOAO SILVA DOS SANTOS",
        alias="Destinatário:"
    )

    issue_date: str = Field(
        description="Date when the invoice was issued. Format should be dd/mm/yyyy.",
        example="10/09/2024",
        alias="DataEmissao:"
    )

    invoice_number: str = Field(
        description="Unique number identifying the invoice.",
        example="000000123",
        alias="NumeroNota:"
    )

    direction: str = Field(
        description="Indicates whether the note is an entry (0) or exit (1).",
        example=["0","1"],
        alias="Entrada/Saida:"
    )

    products: str = Field(
        description="List of products or services mentioned in the invoice. Names must be corrected if OCR has introduced errors (e.g., 'Bo,ino' should be 'Bovino'), appears after 'DADOS DO PRODUTOS / SERVIÇOS'",
        example= ["Bovino Femea, 13 a 24", "Café", "bezerros"],
        alias="Produtos:"
    )

    total_value: str = Field(
        description="Total monetary value in BRL (Brazilian Reais), including taxes and additional charges. Format should be xx.xxx,xx.",
        example="2.000,00",
        alias="ValorTotal:"
    )


'''

from pydantic import BaseModel, Field
from typing import List


class Products(BaseModel):
    description: str = Field(
        description="Product/Service Description",
        example=["Produto Exemplo 1"],
        alias="Descrição"
    )
    total_value: str = Field(
        description="Total value of the product/service, labeled as 'Valor Total' in the document.",
        example=["100.00"],
        alias="Valor total"
    )

class Nota_Fiscal(BaseModel):
    issuer: str = Field(
        description="Name of the issuer of the invoice issuer document.",
        example=["Empresa Exemplo LTDA"],
        alias="Emitente"
    )
    in_out: str = Field(
        description="Indicates whether the document is an entry or exit. It's 0 to 'Entrada' and 1 to 'Saída'.",
        example=["Entrada"],
        alias="Entrada/Saída"
    )
    invoice_number: str = Field(
        description="Invoice number, which is the unique identifier of the document.",
        example=["000263990"],
        alias="Número da Nota Fiscal"
    )
    type: str = Field(
        description="Type of the document.",
        example=["Compra para industrialização"],
        alias="Natureza da operação"
    )
    recipient: str = Field(
        description="Name of the recipient of the invoice document.",
        example=["Cliente Exemplo LTDA"],
        alias="Destinatário"
    )
    recipient_cpf: str = Field(
        description="CPF of the recipient of the invoice document.",
        example=["123.456.789-09"],
        alias="CPF do destinatário"
    )
    issue_date: str = Field(
        description="Date of issue of the invoice document, formatted as DD/MM/YYYY.",
        example=["01/10/2023"],
        alias="Data de emissão"
    )
    in_out_date: str = Field(
        description="Date of entry or exit of the invoice document, formatted as DD/MM/YYYY.",
        example=["01/10/2023"],
        alias="Data de entrada/saída"
    )
    exit_hour: str = Field(
        description="Hour of exit of the invoice document, formatted as HH:MM:SS.",
        example=["10:00:15"],
        alias="Hora de saída"
    )
    products_total_value: str = Field(
        description="Total value of the products in the invoice document, labeled as 'Valor Total dos Produtos' in the document.",
        example=["1000.00"],
        alias="Valor total dos produtos"
    )
    invoice_total_value: str = Field(
        description="Total value of the invoice document, labeled as 'Valor Total da Nota Fiscal' in the document.",
        example=["1100.00"],
        alias="Valor total da nota"
    )
    description: List[Products] = Field(
        description="List of products/services in the invoice document.",
        example=[{"description": "Produto Exemplo 1", "total_value": "100.00"}],
        alias="Descrição dos produtos"
    )
'''