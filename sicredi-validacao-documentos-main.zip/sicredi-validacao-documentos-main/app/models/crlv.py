from pydantic import BaseModel, Field
from typing import Dict, Optional

class Crlv(BaseModel):
    renavam: str = Field(
        description="Vehicle Registration Information (Renavam is the unique vehicle registry identifier in Brazil).",
        example="12345678901",
        alias="Renavam:"
    )
    license_plate: str = Field(
        description=(
            "Brazilian vehicle license plate (PLACA DO VEÍCULO).\n\n"
            "Accepted formats:\n"
            "- ABC-1234\n"
            "- ABC1D23 (Mercosul)\n\n"
            "IMPORTANT:\n"
            "- The license plate may appear in the document WITHOUT the label 'PLACA'\n"
            "- It may be incorrectly associated with other labels such as 'ANO FABRICAÇÃO'\n"
            "- If a value matches the official license plate format anywhere in the document, extract it\n"
            "- Prefer values that match the official pattern over nearby semantic labels\n"
            "- Do NOT extract values like '5P', '05P', 'O5P'\n"
            "- If no valid plate exists, return null"
        ),
        example=["ABC1234", "RRJ5C35"],
        alias="Placa:"
    )
    year: str = Field(
        description="Year of Manufacture/Model (Format: YYYY/YYYY).",
        example="2020/2021",
        alias="Ano de Fabricação:"
    )
    informations: Dict[str, str] = Field(
        description="Vehicle details including Make, Model, and Version.",
        example={"Marca": "Toyota", "Modelo": "Corolla", "Versão": "XEi 2.0 Flex"},
        alias="Informações:"
    )
    chassis: str = Field(
        description="Unique vehicle chassis identification number.",
        example="9BWZZZ377VT004251",
        alias="Chassis:"
    )
    color: str = Field(
        description="Vehicle color as registered in the system.",
        example="Preto",
        alias="Cor:"
    )
    remarks: str = Field(
        description="Additional vehicle information, such as financing status.",
        example="Financiado",
        alias="Observação:"
    )
    power_horsepower: str = Field(
        description="Engine power in horsepower (HP) and Engine displacement.",
        example="150CV/1000",
        alias="Potência/ Cilindrada:"
    )
    seats: str = Field(
        description="Number of seats (seating capacity of the vehicle). You can find as 'Lotação'. The format is 'O5P'.",
        example="O5P",
        alias="Lotação:"
    )
    owner: str = Field(
        description="Name of the registered vehicle owner.",
        example="João da Silva",
        alias="Proprietário:"
    )
    uf: str = Field(
        description="Brazilian state (UF) where the vehicle is registered.",
        example="SP",
        alias="UF:"
    )
    
    fuel: str = Field(
        description="Fuel Type",
        example="Gasolina",
        alias="Combustível:"
    )