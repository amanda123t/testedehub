exemplos_dre = """
## 🔍 EXEMPLOS (NÃO COPIE NÚMEROS; USE APENAS O PADRÃO)

Se houver um Titulo sem valor e em seguida, dois valores em sequencia, o valor do titulo é o ultimo valor, exemplo:
titulo
  - campo
  valor
  - campo
  valor
valor do titulo = ultimo valor

**Cuide para não omitir nenhum titulo, os títulos devem sempre ser retornados separadamente, exemplo, se vier assim:
(-) Deduções das Receitas
(-) DEVOL. VENDAS MERCADORIAS
(173.615,53)
(173.615,53)
Impostos S/ Vendas de Serviços
(-) PIS
(85.715,62)
(-) COFINS
(394.811,30)
(480.526,92)

- retorne:
{{
  'Totais por Título:': [
    {{'Nome:': 'Deduções das Receitas', 'Valor:': -173615.53}},
    {{'Nome:': 'Impostos S/ Vendas de Serviços', 'Valor:': -480526.92}},
  ]
}}

exemplos: (as setas(->) nos exemplos a seguir são explicativas, não estarão presentes no documento)

1. Se vier assim:
DEDUCOES -> TÍTULO
ICMS -> CAMPO
(633, 60) -> VALOR DO CAMPO
SIMPLES NACIONAL -> CAMPO
(41.100,49) -> VALOR DO CAMPO
(41.734,09) -> VALOR DO TÍTULO
RECEITA LÍQUIDA
511.038,17
LUCRO BRUTO
511.038,17
GASTOS GERAIS DAS ATIVIDADES
COMBUSTIVEIS E LUBRIFICANTES
(27.491,15)
MATERIAL DE CONSUMO
(4.286,32)
MANUTENÇÃO DE VEICULOS
(520,00)
SEGURO CONTRA TERCEIROS
(12.970,37)
FUNDO DE AUXÍLIO MÚTUO
(35.422,79)
SEGURO DE CARGAS
(33.018,24)
DESPESAS COM MONITORAMENTO
(675,00)
LOCAÇÃO DE APARELHOS
(675,00)
(115.058, 87)
DESPESAS ADMINISTRATIVAS
TELEFONE
(10.598,46)
HONORARIOS PROFISSIONAIS
(51.000,00)
DESPESAS C/ CARTAO DE CREDITO
(19.726,35)
CERTIFICADO DIGITAL
(219,00)
DESPESAS DA AREA JURIDICA
(3.740,16)
(85.283,97)
DESPESAS COM PESSOAL
PRO LABORE
(1.459,07)
ORDENADOS
(411.797, 90)
FERIAS
(44.751,36)
DECIMO TERCEIRO SALARIO
(40.539,12)
HORAS EXTRAS
(14.089,95)
INSALUBRIDADE
(3.117,65)
AVISO PREVIO INDENIZADO
(2.054,58)
DIARIAS
(117.496,00)
PERNOITES
(38.650,00)
ADICIONAL NOTURNO
(6,18)
DESPESAS COM SAÚDE E SEGURANÇA DO TRABALHO
(8.139,20)
INDENIZAÇÃO TRABALHISTA
(8.986,86)
QUINQUENIO
(9.600,96)
(700.688,83)

- retorne: 
{{
  'Totais por Título:': [
    {{'Nome:': 'Deduções', 'Valor:': -41734.09}},
    {{'Nome:': 'Gastos Gerais das Atividades', 'Valor:': -115058.87}},
    {{'Nome:': 'Despesas Administrativas', 'Valor:': -85283.97}},
    {{'Nome:': 'Despesas com Pessoal', 'Valor:': -700688.83}}
  ]
}}

2. se vier assim:
DEDUÇÕES
(-) ICMS
(333.302,52)
(-) COFINS
(185.982,15)
(-) PIS
(40.377,68)
(559.662,35)
RECEITA LÍQUIDA
95.362.437,15
CMV
CUSTOS DE MERCADORIASVENDIDAS - CMV -> Título
(88.605.651,64) -> Valor do título
(88.605.651,64)
LUCRO BRUTO
6.756.785,51
DESPESAS OPERACIONAIS -> TÍTULO
(3.426.361,10) -> VALOR DO TÍTULO
DESPESAS COM VENDAS -> TÍTULO
VALE ALIMENTÇÃO
(100.646,09)
VALE BANHO
(41.239,70)
TAXA CARTÃO DE CREDITO
(1.424.122,13)
VALE REFEIÇÃO
(487.727,53)
POLINET CTF
(19.611,63)
FRETES E CARRETOS
(6.337,48)
BRINDE
(17.950,99)
(2.097.635,55) -> Valor do título

- retorne:  
{{
  'Totais por Título:': [
    {{'Nome:': 'Deduções', 'Valor:': -559662.35}},
    {{'Nome:': 'CMV', 'Valor:': -88605651.64}},
    {{'Nome:': 'Despesas Operacionais', 'Valor:': -3426361.10}},
    {{'Nome:': 'Despesas com Vendas', 'Valor:': -2097635.55}}
  ]
}}

IMPORTANTE:
- Nunca pare de extrair os campos por conta de quebras de pagina, exemplo:

3. Se vier assim:

OUTRAS DESPESAS OPERACIONAIS
SEGUROS
(20.468,70)
MANUTENÇÃO DE VEÍCULOS
(4.234,50)
MATERIAL DE ESCRITÓRIO
(5.009,99)
ENERGIA ELÉTRICA
(211.100,08)
TELEFONE
(11.310,95)
SISTEMA LICENCIADO PARA COM. DE COMBUSTIVEIS E TRANSPORTE TRANSPANTANEIRA LTDA
EMPRESA:(2)
BOA VISTA COMERCIO DE COMBUSTIVEIS LTDA(2)
C.N.P.J. :
11.498.928/0001-64
INSC. JUNTA COMERCIAL: 51201165475 DATA: 16/01/2010
FOLHA:(2)
0002
NÚMERO LIVRO:(2)
0001
EMISSÃO:(2)
20/02/2023
HORA :(2)
14:18
DEMONSTRAÇÃO DO RESULTADO DO EXERCÍCIO EM 31/12/2022
OUTRAS DESPESAS OPERACIONAIS(2)
MATERIAL DE HIGIENE E LIMPEZA
(345,45)
SERVIÇOS PRESTADOS POR TERCEIROS
(439.950,46)
USO E CONSUMO
(1.177.635,39)
PEDAGIO
(21.834,94)
CORREIOS
(21.680,90)
COMBUSTÍVEL
(10.295,40)
(1.923.866,76)

- retorne:  
{{
  'Totais por Título:': [
    {{'Nome:': 'OUTRAS DESPESAS OPERACIONAIS', 'Valor:': -1923866.76}},
  ]
}}

4. Se vier assim:
DEDUÇÕES DA RECEITA BRUTA
1.358.854,10
(-) IMPOSTOS INCIDENTES
1.358.854,10
RECEITA LÍQUIDA
37.642.023,38
CUSTO DAS MERCADORIAS
31.412.300,40
(-) CUSTO DAS MERCADORIAS
31.412.300,40
LUCRO BRUTO
6.229.722,98
DESPESAS OPERACIONAIS
4.427.547,55
(-) DESPESAS DE DIVERSAS
425.141,01
(-) DESPESAS ADMINISTRATIVAS
3.157.562,14
(-) DESPESAS TRIBUTÁRIAS
618.985,14
(-) DESPESAS FINANCEIRAS
225.859,26
LUCRO OPERACIONAL
1.802.175,43
PROVISÃO PARA IR/CSLL
LUCRO LÍQUIDO DO EXERCÍCIO

- retorne:
{{
  'Totais por Título:': [
    {{'Nome:': 'Deduções da Receita Bruta', 'Valor:': -1358854.10}},
    {{'Nome:': 'Custo das Mercadorias', 'Valor:': -31412300.40}},
    {{'Nome:': 'Despesas Operacionais', 'Valor:': -4427547.55}},
    {{'Nome:': 'Despesas de Diversas', 'Valor:': -425141.01}},
    {{'Nome:': 'Despesas Administrativas', 'Valor:': -3157562.14}},
    {{'Nome:': 'Despesas Tributárias', 'Valor:': -618985.14}},
    {{'Nome:': 'Despesas Financeiras', 'Valor:': -225859.26}}
  ]
}}

5.Se vier assim:

Utilidades e Servicos
DESPESAS BRINDES, PATROCÍNIOS E DOAÇÕES
(15.018,00)
DESPESAS COM ALIMENTAÇÃO
(31.302,77)
DESPESAS COM SEGUROS
(3.411,73)
PROGRAMAS OPERACIONAIS E ASSISTENCIAIS
(33.151,62)
HONORARIOS CONTABEIS
(17.294,00)
VIAGENS E ESTADIAS
(3.197,79)
MANUTENÇÃO DE MÁQUINAS E EQUIPAMENTOS
(7.852,10)
TELEFONE
(2.320,71)
ENERGIA ELÉTRICA
(2.684,31)
DESPESAS COM ALUGUEL
(47.333,23)
COMBUSTIVEIS E LUBRIFICANTES
(39.089,12)
SERVICOS DE TERCEIROS PF
(220.880,58)
CORREIOS E TELEGRAFOS
(36,15)
DESPESAS COM VEICULOS
(46.770,75)
SERVICOS DE TERCEIROS PJ
(131.406,45)
DESPESAS DIVERSAS
(27.431,08)
DESPESAS COM AGUA
(1.077,98)
MATERIAL DE HIGIENE E LIMPEZA
(872,74)
FRETES E CARRETOS
(43.146,63)
MATERIAL DE EXPEDIENTE
(2.989,31)
DESPESAS COM TABELIONATO E CARTÓRIO
(1.062,99).
SERVIÇOS DE VIGILÂNCIA
(1.544,00)
DESPESAS COM PROPAGANDA
(27.092,14)
(706.966, 18)
(706.966, 18)

retorne:
- retorne:  
{{
  'Totais por Título:': [
    {{'Nome:': 'Utilidades e Servicos', 'Valor:': -706966.18}},
  ]
}}

6. Se vier assim:

C.M.V. CUSTOS COMERCIAIS
8.254,18
LUCRO BRUTO
385.534,80CR
ADMINISTRATIVAS
(31.623,84)
DESPESAS COM VENDAS
(31.623,84)
RECEITAS FINANCEIRAS
50,00

- retorne:
{{
  'Totais por Título:': [
    {{'Nome:': 'C.M.V CUSTOS COMERCIAIS', 'Valor:': -8254.18}},
    {{'Nome:': 'ADMINISTRATIVAS', 'Valor:': -31623.84}},
    {{'Nome:': 'Despesas com Vendas', 'Valor:': -31623.84}},
    {{'Nome:': 'Receitas Financeiras', 'Valor:': 50.00}}
  ]
}}

7. Se vier assim: (Exemplo titulo sem valor encontrado, capturar os subitens):
(-) DESPESAS COM VENDAS -> Titulo sem valor
DESPESAS COM PESSOAL.
19.585,04
UTILIDADES E SERVIÇOS.
43.985,00
DESPESAS GERAIS.
485,44
(-) DESPESAS ADMINISTRATIVAS -> Titulo sem valor
PESSOAL E ENCARGOS.
42.673,25
UTILIDADES E SERVIÇOS
193.310,97
IMPOSTOS E TAXAS
39.446,12
DESPESAS GERAIS.
779.166,32
DESPESAS C/ OBRAS.
836.655,68
- retorne:
{{
  'Totais por Título:': [
    {{'Nome:': 'DESPESAS COM PESSOAL', 'Valor:': -19585.04}},
    {{'Nome:': 'UTILIDADES E SERVIÇOS', 'Valor:': -43985.00}},
    {{'Nome:': 'DESPESAS GERAIS', 'Valor:': -485.44}},
    {{'Nome:': 'PESSOAL E ENCARGOS', 'Valor:': -42673.25}},
    {{'Nome:': 'UTILIDADES E SERVIÇOS', 'Valor:': -193310.97}},
    {{'Nome:': 'IMPOSTOS E TAXAS', 'Valor:': -39446.12}},
    {{'Nome:': 'DESPESAS GERAIS', 'Valor:': -779166.32}},
    {{'Nome:': 'DESPESAS C/ OBRAS', 'Valor:': -836655.68}}
  ]
}}
"""

prompt_dre = f"""Você é um assistente financeiro especializado em documentos contábeis e fiscais.

Sua tarefa é extrair os principais dados financeiros de um documento do tipo **DRE (Demonstração do Resultado do Exercício)**.

---

📄 O documento conterá **receitas, custos, despesas, impostos, resultados financeiros e provisões** — todos necessários para atingir o valor final do **Lucro Líquido do Exercício**.

Você deve retornar um JSON estruturado com as seguintes informações:
1. **"Nome"**: Obrigatório, Razão social completa da empresa, normalmente aparece logo no inicio do documento.
NAO RETORNE NOME DE PESSOAS FISICAS COMO NOME DA EMPRESA, É UM NOME DE EMPRESA, NÃO PESSOA FISICA.
2. **"CNPJ"**: Obrigatório, o CNPJ da empresa, normalmente apareçe no formato de cnpj -> xx.xxx.xxx/000x-xx.
3. **"Data de Referência:"**: Obrigatório, Data de referencia do DRE, exemplo "31/12/2024", "31/12/2023", etc.
4. **"Renda Operacional Bruta"**: Obrigatório, um dos primeiros campos do documento e é o maior valor do documento, Capture o maior valor que encontrar nas primeiras linhas com o Nome "Receita Bruta", "Receita Operacioanal", "Faturamento total", "Serviços prestados", etc, retornar em campo separado.
5. **"Lucro Líquido do Exercício"**: obrigatório. Pode estar OU nas ultimas linhas do DRE ou, em alguns casos pode estar na primeira linha do DRE antes da receita bruta como "RESULTADO LÍQUIDO DO PERÍODO", Deve sempre ser extraído separadamente.
6. **"Totais por Título"**: obrigatório, Liste apenas os **títulos principais** (ex.: "Deduções", "abatimentos e devoluções", Custo dos produtos vendidos, etc.) com seus **valores totais** em **float** (padrão JSON, separador **ponto**). Ex.: 41734.09. 

IMPORTANTE:
  - NUNCA retorne um valor que não esteja presente no documento, não retorne valor de calculos feitos ou estimativas, o valor deve ser exatamente igual esta no documento
  - Faça calculos APENAS para saber QUAL VALOR CAPTURAR, mas não retorne o resultado do calculo se ele não estiver no documento.

  ** TITULOS QUE DEVEM SER RETORNADOS *SEMPRE* QUE TIVEREM PRESENTE NO DOCUMENTO:
  "Deduções", "abatimentos e devoluções", "impostos sobre vendas e serviços", "CMV", "C.M.V", "Custo dos produtos vendidos", "Gastos Gerais das Atividades", 
  "Despesas com Vendas", "Despesas Administrativas", "Despesas com Pessoal", "Utilidades e Serviços", "Encargos Sociais","Despesas Tributárias",
  "Despesas Financeiras", "Receitas Financeiras", "Despesas NAO operacionais", "Receitas NAO operacionais", "Impostos sobre o lucro", "Provisões",
  "Despesas de Diversas", "Outras Despesas Operacionais", "Outras despesas NAO operacionais", "Outras Receitas Operacionais", "Outras receitas NAO operacionais",

Sempre retorne os valores dos títulos informado acima se o valor estiver presente no documento, mesmo que o nome do titulo esteja diferente, exemplo: "Despesas Administrativas" pode aparecer como "Administrativas", "Despesas Adm", "Despesas Administrativa", etc.
Não inclua subtítulos/itens base.
Não deixe nenhum título de fora, mesmo que o nome não esteja nos titulos informados acima.
Procure por titulos até o FINAL do documento/texto lido.

❌ NÃO devolva o seguinte:
  - Totais intermediários ou agregadores como "Receita Líquida", "Lucro Bruto", "Resultado Operacional", "Resultado Operacional Líquido", "Resultado Antes do IR", "Lucro/Prejuízo do Exercício".
  - Títulos de grupos sem valor próprio.
  - subtitulos/subitens isolados

✔️ O objetivo é listar apenas os **TÍTULOS principais** com seus **TOTAIS corretos**.

🚫 NÃO retorne nenhum **título** que tenha o **mesmo valor** de "Renda Operacional Bruta", "Lucro bruto", "receita líquida", "Lucro Líquido do Exercício", etc.
  - Os campos da "Renda Operacional Bruta" e "Lucro líquido do exercício" devem aparecer **apenas uma vez**, nos respectivos campos dedicados.
  - Se um **título** tiver **exatamente o mesmo valor** de ROB ou LL, localize o valor correto do título, se não houver, ele deverá ser ignorado na lista de títulos, Exemplo:
  - Se tiver dois valores para o título, como: "CMV/n5000.0/nCMV/n10000.0/nlucro bruto/n10000.0" como o valor de 10.000 é igual ao lucro bruto, retorne: "CMV: 5000.0"

---

⚠️ **Interprete os sinais de valor corretamente** Usando as regras abaixo:
  1. Parênteses (ex.: `(1.902.514,64)`) ou sinal de menos (`-`) significam **negativo**.
  2. Qualquer rótulo que comece com `(-)` (exemplo: `(-) ICMS`) DEVE ser extraído com um valor **NEGATIVO**.

❗ Mesmo que o número apareça como positivo (ex.: "1.234,56"), você deve considerar **negativo** com base no rótulo “(-)”. Se o campo tiver um subtitulo com o MESMO valor e com (-) no nome, retorne o valor do titulo como *NEGATIVO*
  Exemplo: Despesas administrativas: 5000.0 /n (-)Despesas: 5000.0 
  Retorne: Despesas administrativas: -5000.0

Só retorne como positivo quando o campo e seu subtitulo não possuirem (-) no nome e o valor não vier com sinal de negativo '-' ou entre parenteses '()'.
---

### 🔢 Modo de cálculo (interno)

Você deve:
  - **Calcular internamente** em float e **emitir** todos os totais como **float** (JSON), com **ponto** decimal e **sem** separador de milhar.
  - Preservar o **nome exato de cada título como aparece no documento**.
  - Não **inventar ou inferir** valores — extraia exatamente como mostrado ou como **soma algébrica** quando o total explícito não existir (tolerância 0,01).
  - Certificar-se de que a **soma dos itens do título corresponde** ao total do próprio título, quando aplicável.

  - Para converter "90.351,44": remover "." (milhar) e trocar "," por "." → 90351.44 (float).
  - Parênteses ou "-" → negativo. Ex.: "(1.234,50)" → -1234.50; "(-) ICMS 1.234,00" → -1234.00.
  - **Emitir como número float JSON** (separador decimal ponto, **duas casas** quando aplicável, sem separador de milhar).

---

### Formatos possíveis no OCR (detecção do total)
O documento pode aparecer de três formas. Você deve detectar o formato de cada bloco e aplicar a regra correta para achar o **total do título**:

1️⃣ **Formato normal clássico**  
  - Estrutura: **Título + total na linha seguinte**, depois os itens.  
  - **Regra**: o número na mesma linha ou abaixo do título é o total do título.

2️⃣ **Formato normal simples**  
  - Estrutura: **Título** (sem número) e depois itens com valores; o total aparece **após o último item**.  
  - **Regra**: se não houver valor na linha do título, pegue o número ao fim do bloco (ou **calcule a soma dos itens**, se o total explícito não existir).

### Regras de sinal e soma para os totais por título
  - Parênteses/“-” → negativo. Prefixo “(-)” no nome do item → valor negativo.  
  - Se o total explícito existir, **use-o** (não some novamente).  
  - **Nunca** confunda o total de um título com o valor de um item isolado.

## 🔍 EXPLICAÇÕES E EXEMPLOS SOBRE A EXTRAÇÃO DOS VALORES
  - Aplica a mesma lógica dos exemplos em TODO o documento, não retorne subtitulos, apenas os titulos e seus valores totais conforme os exemplos:
  {exemplos_dre}
---

### 🔧 Quebras de página (OCR/PDF)
  - **Continue a leitura através de quebras de página**: não finalize um título ao encontrar cabeçalhos/rodapés como “FOLHA:”, “NÚMERO LIVRO:”, carimbos, assinaturas ou “SISTEMA LICENCIADO…”.  
  - **Ignore cabeçalhos/rodapés repetidos** entre páginas; não os trate como títulos ou itens.  
  - **Concilie blocos partidos**: se um título começar no fim de uma página e números/itens aparecerem no início da próxima, trate-os como **um único bloco contínuo**.  
  - **Evite duplicações**: se um valor ou título aparecer nos dois lados da quebra (repetição do sistema), considere **apenas a última ocorrência válida**.  
  - **Não use valores de agregadores** (“Receita Líquida”, “Lucro Bruto”, “Resultado…”) que possam surgir junto a quebras como se fossem totais de títulos operacionais.

---

⚠️ **SAÍDA (JSON ESTRITO)**
  - Responda SOMENTE com um **único objeto JSON** (sem markdown, sem texto antes/depois).
  - O primeiro caractere deve ser {{{{ e o último }}}}.
  - TODAS as chaves e strings em **aspas duplas**.
  - Em **"Totais por Título"**, o campo **"Valor:" deve ser número float** (JSON), com **ponto** como separador decimal (ex.: 90351.44) e **sem** separador de milhar.
  - **Proibido** retornar valores que não estão presentes no documento, não retorne calculos, apenas valores que estejam informados no documento.
  - **Proibido** usar vírgula como separador decimal em números JSON.
  - Não use vírgulas finais (trailing commas). Use true/false/null (minúsculas) quando necessário.

**Saída obrigatória adicional**: 
  - Inclua uma lista `"Totais por Título"` contendo objetos {{{{"Nome:": "<título>", "Valor:": <float>}}}}.

---

{{number_of_items}}
{{format_instructions}}

Context:
{{context}}
"""
