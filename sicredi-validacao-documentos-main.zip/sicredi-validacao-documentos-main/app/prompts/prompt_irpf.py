

prompt_irpf_pj = """
Você deve extrair, em formato JSON, os dados da tabela 
'RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA JURÍDICA PELO TITULAR'.

Cada fonte pagadora possui:

• 1 NOME DA FONTE PAGADORA  
• 1 CNPJ DA FONTE PAGADORA (sempre ligado ao nome, nunca é uma coluna)  
• EXATAMENTE cinco valores numéricos, SEMPRE nesta ordem fixa e obrigatória:

1️⃣ **Rend. Recebidos de Pes. Jurídica** — é o **primeiro número** após o nome da fonte.  
2️⃣ **Contribuição Previdenciária Oficial** — é o **segundo número**.  
3️⃣ **Imposto Retido na Fonte** — é o **terceiro número**.  
4️⃣ **13º Salário** — é o **quarto número**.  
5️⃣ **IRPF sobre 13º Salário** — é o **quinto e último número**.

⚠️ O CNPJ NÃO é uma coluna.  
Ele sempre pertence ao nome imediatamente acima, mesmo se vier:
- em outra linha  
- ao final da linha  
- após uma quebra do OCR  
- separado por ":"  

🧠 **Regras para leitura dos valores:**
- Sempre identifique os valores **na ordem em que aparecem após o nome**.  
- Nunca use o cabeçalho do OCR para determinar a ordem das colunas, pois ele pode vir quebrado.  
- A ordem REAL das colunas é sempre determinada pelos valores numéricos.  
- Ignore completamente linhas com “TOTAL”.  
- Se o OCR quebrar a linha com “|”, conte os valores na ordem:  
  valor1 → rendimentos  
  valor2 → previdência  
  valor3 → imposto  
  valor4 → 13º salário  
  valor5 → IRRF sobre 13º  

🧩 **EXEMPLO (OCR com colunas separadas por '|'):**

Entrada:
Nome | valor1 | valor2 | valor3 | valor4 | valor5
CNPJ/CPF: 00.000.000/0000-00

Interpretação correta:
NOME DA FONTE PAGADORA        = Nome  
REND. RECEBIDOS               = valor1  
CONTR. PREVID. OFICIAL        = valor2  
IMPOSTO RETIDO NA FONTE       = valor3  
13º SALÁRIO                   = valor4  
IRRF SOBRE 13º SALÁRIO        = valor5  
CNPJ DA FONTE PAGADORA        = 00.000.000/0000-00  

🧩 **Outro exemplo (OCR quebrado em várias linhas):**

RUTNEY CESAR DE RESENDE
16.852,00
1.263,90
0,00
1.306,10
0,00
CNPJ/CPF: 11.109.398/0001-15

Interpretação correta é exatamente a mesma.

⚠️ **Nunca inverta as colunas dos valores.**  
O 13º salário é SEMPRE o 4º número.  
O IRRF sobre 13º é SEMPRE o 5º número.  
O imposto normal é SEMPRE o 3º número.  

Se algum valor não existir, retorne "0,00".

Saída esperada:
{{
    "RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA JURÍDICA PELO TITULAR": [
        {{
            "Fonte Pagadora": "",
            "CNPJ": "",
            "Rend. Recebidos de Pes. Jurídica": "",
            "Contribuição Previdenciária Oficial": "",
            "Imposto Retido na Fonte": "",
            "13º Salário": "",
            "IRPF sobre 13º Salário": ""
        }}
    ]
}}

{format_instructions}

🧠 Context: (a partir daqui é apenas o texto do documento, sem instruções)
{context}
"""


prompt_irpf_pf = """Você deve extrair, em formato JSON, os dados da tabela
'RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA FÍSICA E DO EXTERIOR PELO TITULAR'.

O texto vem do OCR em formato tabular com separadores de barra vertical “|”, 
seguindo esta estrutura exata:

NIT/PIS/PASEP: | <número>
RENDIMENTOS
TRABALHO NÃO | ALUGUÉIS, INCLUSIVE | OUTROS | EXTERIOR
ASSALARIADO | POR TEMPORADA
JAN | 0,00  | 0,00 | 0,00 | 0,00
FEV | 0,00  | 0,00 | 0,00 | 0,00
...
DEZ | 0,00  | 0,00 | 0,00 | 0,00
TOTAL | 0,00  | 0,00 | 0,00 | 0,00

Cada linha representa um mês (JAN a DEZ) e uma linha final "TOTAL".
A tabela contém **cinco colunas fixas**, nesta ordem obrigatória:

1️⃣ **Mês** — abreviação de três letras em português (JAN, FEV, MAR, ..., DEZ, TOTAL).  
2️⃣ **Trabalho não assalariado** — primeiro valor após o nome do mês.  
3️⃣ **Aluguel** — segundo valor numérico.  
4️⃣ **Outros** — terceiro valor numérico.  
5️⃣ **Exterior** — quarto valor numérico.  

⚠️ **O texto pode conter barras verticais “|” entre as colunas.**
Sempre respeite a ordem das colunas e ignore quebras de linha ou palavras divididas.

🧩 **Regras e validações obrigatórias:**
- Se um valor estiver ausente, ilegível ou em branco, retorne `"0,00"`.  
- Os valores devem permanecer em formato string no padrão brasileiro (“1.234,56”).  
- Sempre inclua **todas as 12 linhas de meses + a linha TOTAL**.  
- A linha "TOTAL" deve conter a soma de cada coluna.  
- Ignore cabeçalhos, legendas e observações (“Valores em Reais”, “NIT/PIS/PASEP”, etc.).  
- Nunca remova ou reordenar colunas.  

🧾 **Saída esperada (apenas o modelo de saida, retorne com os valores do documento):**

{{
    "RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA FÍSICA E DO EXTERIOR PELO TITULAR": [
        {{
            "Mês": "JAN",
            "Trabalho não assalariado": "0,00",
            "Aluguel": "0,00",
            "Outros": "0,00",
            "Exterior": "0,00"
        }},
        ...
        {{
            "Mês": "TOTAL",
            "Trabalho não assalariado": "0,00",
            "Aluguel": "0,00",
            "Outros": "0,00",
            "Exterior": "0,00"
        }}
    ]
}}

{format_instructions}

🧠 Context: ( a partir daqui é o texto do documento, não terá instruções ou regras, apenas o texto)
{context}
"""

prompt_irpf_summary = """Você deve extrair, em formato JSON, as informações do 'Resumo' do Imposto de Renda.

Se um valor não estiver presente, retorne "R$ 0,00" ou lista vazia conforme o tipo.

---

Campos obrigatórios (use os nomes exatos abaixo):

1️⃣ **Recebidos de Pessoa Jurídica pelo Titular**  
2️⃣ **Recebidos de Pessoa Jurídica pelos Dependentes**  
3️⃣ **Recebidos de Pessoa Física/Exterior pelo Titular**  
4️⃣ **Recebidos de Pessoa Física/Exterior pelos Dependentes**  
5️⃣ **Total de Rendimentos Tributáveis**  
6️⃣ **Saldo Imposto a Pagar**

Mesmo que algum campo não apareça no texto, retorne com valor "R$ 0,00".
---

### 🔄 SAÍDA ESPERADA:
{{
  "Resumo": {{
    "Recebidos de Pessoa Jurídica pelo Titular": "",
    "Recebidos de Pessoa Jurídica pelos Dependentes": "",
    "Recebidos de Pessoa Física/Exterior pelo Titular": "",
    "Recebidos de Pessoa Física/Exterior pelos Dependentes": "",
    "Total de Rendimentos Tributáveis": "",
    "Saldo Imposto a Pagar": ""
  }},
}}

{format_instructions}

🧠 Context: ( a partir daqui é o texto do documento, não terá instruções ou regras, apenas o texto)
{context}
"""

prompt_irpf_agricultural = """Você deve extrair, em formato JSON, as informações do 'DEMONSTRATIVO DE ATIVIDADE RURAL' do Imposto de Renda.

Se um valor não estiver presente, retorne "R$ 0,00" ou lista vazia conforme o tipo.

### DEMONSTRATIVO DE ATIVIDADE RURAL

Contém informações sobre a renda agropecuária (atividade rural).

#### A. DADOS E IDENTIFICAÇÃO DO IMÓVEL EXPLORADO  
Cada imóvel deve conter os seguintes campos (use sempre os nomes em português):  
- Código  
- Participação (%)  
- Condição  
- Nome e Localização  
- Área (ha)  
- CIB/NIRF

Se algum campo estiver ausente, retorne com valor vazio "".

#### B. RECEITAS E DESPESAS  
Deve listar cada mês (Janeiro, Fevereiro, ..., Dezembro) com os respectivos valores:  
- Receita Bruta  
- Despesas de Custeio/Investimento

#### C. APURAÇÃO DO RESULTADO  
Campos fixos (mesmo que vazios ou zero):  
- Receita bruta total  
- Despesa de custeio e investimento total  
- Resultado  
- Limite de 20% sobre a receita bruta total  
- Resultado Tributável  
- Saldo de prejuízo(s) a compensar

---

### 🔄 SAÍDA ESPERADA:
{{
  "DEMONSTRATIVO DE ATIVIDADE RURAL": {{
    "DADOS E IDENTIFICAÇÃO DO IMÓVEL EXPLORADO": [
      {{
        "Código": "",
        "Participação (%)": "",
        "Condição": "",
        "Nome e Localização": "",
        "Área (ha)": "",
        "CIB/NIRF": ""
      }}
    ],
    "RECEITAS E DESPESAS": {{
      "Janeiro": {{
        "Receita Bruta": 0.0,
        "Despesas de Custeio/Investimento": 0.0
      }}
    }},
    "APURAÇÃO DO RESULTADO": {{
      "Receita bruta total": 0.0,
      "Despesa de custeio e investimento total": 0.0,
      "Resultado": 0.0,
      "Limite de 20% sobre a receita bruta total": 0.0,
      "Resultado Tributável": 0.0,
      "Saldo de prejuízo(s) a compensar": 0.0
    }}
  }}
}}

{format_instructions}

🧠 Context: ( a partir daqui é o texto do documento, não terá instruções ou regras, apenas o texto)
{context}
"""

prompt_rendimentos_isentos = """
Você deve extrair, em formato JSON, os dados da tabela:

'RENDIMENTOS ISENTOS E NÃO TRIBUTÁVEIS'

A saída deve seguir exatamente esta estrutura:

{{
  "RENDIMENTOS ISENTOS E NÃO TRIBUTÁVEIS": [
    {{
      "Item": "",
      "Descrição": "",
      "Valor": "",
      "Subitens": [
        {{
          "Beneficiário": "",
          "CPF": "",
          "CNPJ": "",
          "Fonte Pagadora": "",
          "Descrição": "",
          "Valor": ""
        }}
      ]
    }}
  ]
}}

---

### ✔ REGRAS OBRIGATÓRIAS

1️⃣ **Somente retorne itens cujo número esteja dentro desta lista:**

01, 02, 03, 04, 05, 06, 07, 08, 09, 10,
11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
31, 32, 34, 99

Se encontrar números fora dessa lista, ignore.

---

2️⃣ O item verdadeiro é sempre a linha:

<item>. <descrição> ... <valor_total>

A descrição pode estar dividida, una tudo em uma única string.

---

3️⃣ **SUBITENS (OBRIGATÓRIO)**

Após a linha do item, existe um bloco contendo:

Beneficiário | CPF | CNPJ da Fonte Pagadora | Nome da Fonte Pagadora | Valor

Essas linhas representam os subitens que compõem o valor total.

Você deve extrair CADA SUBITEM e retornar:

- "Beneficiário" -> Sempre "Titular" ou "Dependente" nunca outro nome.
- "CPF"          -> No formato xxx.xxx.xxx-xx
- "CNPJ"         -> No formato xx.xxx.xxx/xxxx-xx
- "Fonte Pagadora"-> Nome da empresa
- "Valor"         -> Valor em R$

Retorne esses subitens dentro de uma lista chamada **"Subitens"** dentro do item principal.

Se não houver subitens, retorne "Subitens": [].

---

4️⃣ NÃO RETORNAR:

- Cabeçalhos como “Beneficiário / CPF / ...”
- Valores isolados que não sejam subitens
- Itens fora da lista permitida
- Linhas avulsas sem relação com um item

---

{format_instructions}

🧠 A partir daqui é somente o texto do documento.  
Aplique todas as regras acima:

{context}
"""

prompt_rendimentos_tributados = """
Você deve extrair, em formato JSON, os dados da tabela:

'RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA/DEFINITIVA'

A saída deve seguir exatamente esta estrutura:

{{
  "RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA/DEFINITIVA": [
    {{
      "Item": "",
      "Descrição": "",
      "Valor": "",
      "Subitens": [
        {{
          "Beneficiário": "",
          "CPF": "",
          "CNPJ": "",
          "Fonte Pagadora": "",
          "Descrição": "",
          "Valor": ""
        }}
      ]
    }}
  ]
}}

---

### ✔ REGRAS OBRIGATÓRIAS

1️⃣ **Somente retorne itens cujo número esteja dentro desta lista:**

01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 12, 13, 14, 15, 16

Qualquer outro número → ignore.

---

2️⃣ O item válido é sempre a linha no formato:

<item>. <descrição> ... <valor_total>

A descrição pode vir dividida em múltiplas linhas → una tudo em uma única string.

O valor total é SEMPRE o valor da linha do item (não dos subitens).
não ignore nenhum item dos rendimentos tributáveis, mesmo que não encontre subtitulos.
---

3️⃣ **SUBITENS (OBRIGATÓRIO SE EXISTIREM)**

Logo abaixo do item, existe um bloco contendo:

Beneficiário | CPF | CNPJ da Fonte Pagadora | Nome da Fonte Pagadora | Descrição | Valor

Cada linha representa um subitem que compõe o valor total.

Você deve extrair:

- "Beneficiário" -> Sempre "Titular" ou "Dependente" nunca outro nome.
- "CPF"          -> No formato xxx.xxx.xxx-xx
- "CNPJ"         -> No formato xx.xxx.xxx/xxxx-xx
- "Fonte Pagadora"-> Nome da empresa
- "Valor"         -> Valor em R$

Retorne dentro de uma lista chamada **"Subitens"**.

Se não houver subitens, retorne "Subitens": [].

IMPORTANTE:
O item 01 - 13° Salário NUNCA tem subtítulos.
- O nome e descrição podem vir na mesma linha, exemplo:
NOME EMPRESA | DESCRIÇÃO
Nunca retorne o Nome + descrição juntos, retorne cada informação no seu campo.

---

4️⃣ NÃO RETORNAR:

- Cabeçalhos ("Beneficiário / CPF / ...")  
- Linhas não relacionadas a um item válido  
- Valores avulsos fora da linha do item  
- Itens fora da lista permitida  

---

{format_instructions}

🧠 A partir daqui é somente o texto do documento.  
Siga todas as regras acima:

{context}
"""

prompt_bens = """
Você deve extrair TODOS os bens listados na seção “Bens e Direitos” do IRPF e retornar uma LISTA de objetos em JSON.

NÃO invente dados.  
NÃO resuma.  
NÃO explique.  
Somente extraia o que aparece no texto.

============================================================
🔒 REGRAS GERAIS (OBRIGATÓRIAS)
============================================================

1) **RETORNAR SOMENTE O VALOR ATUAL DO BEM**  
- Ignore completamente o valor anterior.  
- Nunca compare valores, nunca escolha o maior.  
- Use SEMPRE o valor da **última coluna**, que corresponde a **31/12 do ano mais recente**.  

**Exemplo REAL:**  
{{200.000,00 | 0,00}}  
→ Interprete como: ANO ANTERIOR | ANO ATUAL  
→ Valor correto a extrair: **0,00**

2) Cada bem é um objeto independente na lista.

3) Campos obrigatórios para todos os bens:
- "descricao" → discriminação completa (sem cortar texto)  
- "valor" → valor atual (somente número, sem “R$”, sem pontos)

4) Classifique “tipo” exatamente com um dos valores:
- "imóvel", "veículo", "participação", "conta", "investimento", "outros"

5) Retorne TODOS os bens, mesmo que o valor atual esteja zerado.
============================================================
🏠 IMÓVEIS — SE EXISTIREM
============================================================
Extrair opcionalmente:
- endereco (dict: tipo, logradouro, numero, complemento, bairro, municipio, cep, uf)
- area_total
- inscricao_municipal
- data_aquisicao
- matricula
- registrado_cartorio
- nome_cartorio

🚗 VEÍCULOS — SE EXISTIREM
============================================================

Extrair SOMENTE se estiver explícito no texto:
- marca
- modelo
- renavam  
- placa  
- ano de fabricação  
- ano modelo  

⚠️ Regras importantes:
- Não inferir anos.
- Não copiar anos de outros campos.
- Se aparecer dois anos no formato “AAAA/BBBB”:
  - O MENOR ano é sempre o **Ano de Fabricação**
  - O MAIOR ano é sempre o **Ano Modelo**
- Mesmo que a ordem no texto esteja invertida, aplicar essa regra.
- Se aparecer apenas um ano isolado, NÃO preencher ambos.

============================================================
🏢 PARTICIPAÇÕES — SE EXISTIREM
============================================================
- cnpj_empresa  
- pertence_a

============================================================
🏦 CONTAS / INVESTIMENTOS — SE EXISTIREM
============================================================
- banco  
- numero_conta  
- cnpj_instituicao  
- pertence_a

============================================================
📦 OUTROS BENS
============================================================
Se não houver nada estruturado, retornar apenas:
- descricao  
- valor

============================================================
📌 FORMATO DE SAÍDA (OBRIGATÓRIO)
============================================================

Retornar sempre no formato:

{{
  "DECLARAÇÃO DE BENS E DIREITOS": [
      {{ IRPFBem }},
      {{ IRPFBem }},
      ...
  ]
}}

{format_instructions}

============================================================
🧠 CONTEXTO DO DOCUMENTO
============================================================

{context}
"""

prompt_irpf_receipt = """
Você é um extrator especializado em **Recibos de Entrega da Declaração de Ajuste Anual do Imposto de Renda Pessoa Física (IRPF)**.

Leia TODO o texto do documento OCR e retorne **apenas** um JSON com os seguintes campos obrigatórios:

1) **"Cabeçalho"** — Texto completo que aparece no topo do recibo, contendo as expressões:
   - “DECLARAÇÃO DE AJUSTE ANUAL”  
   - “IMPOSTO SOBRE A RENDA - PESSOA FÍSICA”  
   - “EXERCÍCIO XXXX” e “ANO-CALENDÁRIO YYYY”.
   - Copie o trecho completo, mantendo a pontuação e separadores.
   
2) **"Título"** — Tipo de declaração:
   - Pode ser **"DECLARAÇÃO ORIGINAL"** ou **"DECLARAÇÃO RETIFICADORA N° X"** (com número).
   - Aceite também variações de símbolo, como:
       - “DECLARAÇÃO RETIFICADORA No 1”
       - “DECLARAÇÃO RETIFICADORA N. 1”
       - “DECLARAÇÃO RETIFICADORA Número 1”
       - “DECLARAÇÃO RETIFICADORA Nº 1”
   - ⚠️ **Nunca** retorne apenas “DECLARAÇÃO RETIFICADORA” sem número.  
     Se o número da retificadora não estiver visível, retorne o campo **vazio**.
   - Exemplo de aceitos:
       - “DECLARAÇÃO ORIGINAL”
       - “DECLARAÇÃO RETIFICADORA No 1”
       - “DECLARAÇÃO RETIFICADORA Nº 3”
   - Exemplos **inválidos**:
       - “DECLARAÇÃO RETIFICADORA” (sem número) → deve retornar vazio.
    ⚠️ A expressão "DECLARAÇÃO RETIFICADORA" pode conter símbolos diferentes para o número ("N°", "No", "N.", "Número") — todos devem ser tratados como equivalentes.


3) **"Ano-Calendário"** — Ano de referência da declaração, extraído **exclusivamente** do trecho “ANO-CALENDÁRIO YYYY”.  
   - Retorne apenas o ano (4 dígitos).  
   - Exemplo: “ANO-CALENDÁRIO 2024” → `"Ano-Calendário": "2024"`  
   - Ignore outras datas como “31/12/2024” ou anos do exercício.
   
4) **"Nome"** — Nome completo do contribuinte.  
   - Deve ser copiado exatamente como aparece no recibo, geralmente após “NOME:”.
   - Ignore letras truncadas, mas mantenha acentuação se legível.

5)  **"CPF"** — CPF do contribuinte no formato 000.000.000-00.  
   - Sempre vem após “CPF:”.
   - Se vier com espaços ou hífens fora do padrão, normalize.

6) **"Total rendimentos tributaveis:"** — Valor literal do campo “TOTAL RENDIMENTOS TRIBUTÁVEIS”.  
   - Retorne no formato padrão BR (“0,00”, “1.234,56”).  
   - Se não houver valor, retorne “0,00”

7)  **"Imposto devido:"** — Valor literal do campo “IMPOSTO DEVIDO”.  
   - Mesmo formato, padrão BR. 

8) **"Imposto a restituir:"** — Valor literal do campo “IMPOSTO A RESTITUIR”.  
   - Mesmo formato, padrão BR.  
   - Se não houver, “0,00”.

9)  **"Saldo do imposto a pagar:"** — Valor literal do campo “SALDO DO IMPOSTO A PAGAR”.  
   - Sempre no padrão “R$ x.xxx,xx” ou apenas “x.xxx,xx”.
   - Se não houver, “0,00”.

10) **"Saldo do imposto a pagar - ganho de capital:"** — Valor literal do campo correspondente a “SALDO DO IMPOSTO A PAGAR - GANHO DE CAPITAL”.  
   - Mesmo formato.  
   - Se não houver, “0,00”.

---

🧩 **Regras e observações adicionais:**

- Nunca traduza ou reordene os campos; use **os nomes originais em português** conforme listados acima.
- Não invente valores: se o campo não aparecer, devolva “0,00”.
- O JSON deve ter **exatamente** os campos abaixo, nesta estrutura e com as chaves **idênticas**:

{{
  "Cabeçalho": "",
  "Título": "",
  "Ano-Calendário": "",
  "Nome": "",
  "CPF": "",
  "Total rendimentos tributaveis:": "",
  "Imposto devido:": "",
  "Imposto a restituir:": "",
  "Saldo do imposto a pagar:": "",
  "Saldo do imposto a pagar - ganho de capital:": ""
}}
---

🧠 Context: ( a partir daqui é o texto do documento, não terá instruções ou regras, apenas o texto)
{context}
"""
