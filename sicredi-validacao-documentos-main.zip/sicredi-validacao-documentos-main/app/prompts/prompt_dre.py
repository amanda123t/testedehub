exemplos_dre = """
## 🔍 EXEMPLOS DE EXTRAÇÃO

1️⃣ Título com valor no final do bloco:
---------------------------------------
DEDUÇÕES
ICMS
(633,60)
PIS
(41.100,49)
(41.734,09)   <- total do título
RECEITA LÍQUIDA
511.038,17

Retorne:
{{
  "Totais por Título": [
    {{"Nome:": "Deduções", "Valor:": -41734.09}}
  ]
}}

---

2️⃣ Título atravessando quebra de página (não corte o bloco):
-------------------------------------------------------------
OUTRAS DESPESAS OPERACIONAIS
SEGUROS
(20.468,70)
MANUTENÇÃO DE VEÍCULOS
(4.234,50)
[QUEBRA DE PÁGINA: cabeçalho, carimbos, etc.]
MATERIAL DE ESCRITÓRIO
(5.009,99)
ENERGIA ELÉTRICA
(211.100,08)
240.813,27   <- total depois da quebra (mesmo bloco)

Retorne:
{{
  "Totais por Título": [
    {{"Nome:": "Outras Despesas Operacionais", "Valor:": 240813.27}}
  ]
}}

---

3️⃣ Título sem total explícito (usar subtítulos DO MESMO BLOCO):
----------------------------------------------------------------
DESPESAS ADMINISTRATIVAS   <- sem total
PESSOAL E ENCARGOS
42.673,25
UTILIDADES E SERVIÇOS
193.310,97
IMPOSTOS E TAXAS
39.446,12

Retorne:
{{
  "Totais por Título": [
    {{"Nome:": "Pessoal e Encargos", "Valor:": -42673.25}},
    {{"Nome:": "Utilidades e Serviços", "Valor:": -193310.97}},
    {{"Nome:": "Impostos e Taxas", "Valor:": -39446.12}}
  ]
}}


4- Titulo com dois anos no documento:
----------------------------------------------------------------
Receita Operacional -> Titulo da ROB(Renda Operacional Bruta)
VENDAS DE MERCADORIAS GRU - Subtitulo
819.394,64 -> Valor de 2024
392.885,45 -> Valor de 2023
VENDAS DE MERCADORIAS MATRIZ - Subtitulo
6.593.627,63 -> Valor de 2024
3.055.368,20 -> Valor de 2023
0,00 
VENDAS DE MERCADORIAS POA -> Subtitulo
4.482.039,58 -> Valor de 2024
11.895.061,85 -> Valor TOTAL DE 2024
2.242.432,00 -> Valor de 2023
5.690.685,65 -> Valor TOTAL de 2023
(-) Deduções das Receitas
(705.943,60) -> Valor de 2024
(272.963,06) -> Valor de 2023

(-) Custo das Mercadorias Vendidas -> Titulo do CMV
ESTOQUE INICIAL DE MERCADORIAS
(513.632,82) -> Valor de 2024
(534.392,48) -> Valor de 2023
COMPRA DE MERCADORIAS EMPORIO
0,00 -> Valor de 2024
(20.781,09) -> Valor de 2023
COMPRA DE MERCADORIA GUARULHOS
(65.981,78) -> Valor de 2024
(52.992,91) -> Valor de 2023
COMPRA DE MERCADORIA PORTO ALEGRE
....(demais campos)
MULTA RESCISÓRIA FGTS
(24.741,05) -> Valor de 2024
(8.820,85) -> Valor de 2023
MULTA RESCISÓRIA FGTS GRU
(739,76) -> Valor de 2024
0,00 -> Valor de 2023
MULTA RESCISÓRIA FGTS POA
(1.246,65) -> Valor de 2024
(8.272.101,05) -> Valor TOTAL DE 2024
0,00 -> Valor de 2023
(4.506.379,37) -> Valor TOTAL de 2023

Retorne:
{{
  DREs: {{
    "2024": {{
      "Renda Operacional Bruta": 11895061.85,
      "Totais por Título": [
        {{"Nome:": "Deduções das Receitas", "Valor:": -705943.60}},
        {{"Nome:": "(-) Custo das Mercadorias Vendidas", "Valor:": -8272101.05}},
      ] }},
    "2023": {{
      "Renda Operacional Bruta": 5690685.65,
      "Totais por Título": [
        {{"Nome:": "Deduções das Receitas", "Valor:": -272963.06}},
        {{"Nome:": "(-) Custo das Mercadorias Vendidas", "Valor:": -4506379.37}},
      ] }}
  }}
}}
"""

prompt_dre = f"""
Você é um assistente financeiro especializado em **DRE (Demonstração do Resultado do Exercício)**.

Extraia um JSON estruturado com:
- "Nome": Razão social completa da empresa, aparece no inicio do documento.
- "CNPJ": no formato xx.xxx.xxx/000x-xx.
- "Data de Referência": ex. "31/12/2024".
- "Renda Operacional Bruta": É o PRIMEIRO valor entitulado como "Receita Operacional", "Receita Operacional Bruta", "Receita Bruta", etc. do documento. *PROIBIDO* Retornar um valor que não esteja no documento.
- "Lucro Líquido do Exercício": valor final do DRE.
- "Totais por Título": lista de títulos principais com seus totais.

📌 TÍTULOS OBRIGATÓRIOS (se existirem no documento, devem ser retornados SEPARADAMENTE):
- "Deduções", "Devoluções e Abatimentos", "Abatimentos" → use apenas os itens correspondentes (ex.: Devoluções de Vendas).
- "Impostos sobre Vendas e Serviços" → use apenas impostos/tributos incidentes sobre vendas (ICMS, PIS, COFINS, IRPJ/CSLL sobre vendas, etc.).
- "Custo de Mercadorias Vendidas" (ou CPV/CMV/CSV),
- "Despesas Operacionais", "Despesas NÃO operacionais", "Despesas com Vendas", "Despesas Administrativas",
- "Despesas com Pessoal", "Despesas Gerais", "Despesas Tributárias",
- "Despesas Financeiras", "Receitas Financeiras",
- "Outras Despesas Operacionais", "Outras Receitas Operacionais",
- "Outras Receitas", "Outras Despesas",
- "Receitas Operacionais", "Receitas NÃO operacionais",
- "Encargos Sociais", "Impostos sobre o Lucro", "Provisões".

NUNCA retorne como título: "Receita Líquida", "Lucro Bruto", "Resultado Operacional" ou variações de ROB/LL.
NUNCA retorne um campo com o mesmo valor de "Receita Líquida", "Lucro Bruto", "Resultado Operacional" ou variações de ROB/LL. Se houver dois valores possíveis para um campo, utilize o valor DIFERENTE do ROB, Lucro, etc.
Se houver mais de um titulo com o mesmo nome, mas com valores diferentes, retorne todos. Exemplo, Custo dos produtos: 7.000 e Custo de mercadorias: 5.000, retorne ambos.
Sempre retorne os títulos referente a receitas, exemplo, "Receitas Financeiras", "Receitas NÃO operacionais", "Outras receitas operacionais", etc.

📌 Normalização de números (pt-BR → JSON):
- Se o token tiver PONTO e VÍRGULA (ex.: "19.585,04"), trate PONTO como milhar e VÍRGULA como decimal:
  "19.585,04" → "19585.04", "43.985,00" → "43985.00", "1.314.911,74" → "1314911.74".
- Se houver espaços no meio do número (ex.: "1. 314.911,74"), remova-os antes da conversão.
- Se houver apenas vírgula (ex.: "9,85"), troque vírgula por ponto: "9.85".
- Se houver apenas ponto (ex.: "1234.56"), mantenha como decimal.
- Nunca remova dígitos — apenas remova separadores de milhar e troque a vírgula decimal por ponto.

📌 Sinal sem suposição (REGRA FORTE):
- **Somente** considere **negativo** quando houver evidência explícita:
  - número com parênteses, ex.: "(123,45)"
  - número com prefixo "-", ex.: "-123,45"
  - rótulo do título/linha com "(-)" (ex.: "(-) ICMS").
- Se o **total do TÍTULO** estiver **sem sinal** e o título **não** tiver "(-)", **retorne POSITIVO** (não deduza pelo sentido do nome).
Exemplos rápidos:
- Título "Despesas com Pessoal" com total "123,45" (sem parênteses/ "-"/"(-)") → **+123.45**
- Título com total "(123,45)" → **-123.45**
- Título com "(-)" no nome → total do título **negativo**.

📌 Regras de valor:
- NUNCA retorne valores de cálculos ou valores que não estejam no documento.
- É PROIBIDO retornar valores aproximados, ajustados ou arredondados que não correspondam EXATAMENTE ao número do documento.
- Sempre float JSON, ponto decimal, sem separador de milhar.
- PROIBIDO somar itens de blocos diferentes.
- PROIBIDO usar o mesmo número (mesma ocorrência) em dois títulos.
- **Verificação interna obrigatória**: para cada valor em "Totais por Título", confirme mentalmente que o número:
  (a) aparece explicitamente no bloco do título; OU
  (b) é a soma EXATA dos itens imediatamente abaixo do título no mesmo bloco, por ano.
  Se não for possível garantir (diferença absoluta > 0,01), NÃO retorne esse total.

📌 **Renda Operacional Bruta (ROB)**:
  - *NUNCA* retorne um valor de ROB que não esteja no documento.
  - pegue SOMENTE das linhas com os rótulos "Receita Operacional", "Receita Operacional Bruta" ou "Receita Bruta". NUNCA confundir com “Resultado Operacional Líquido” (ignorá-lo para fins de ROB).
  - Se houver apenas um valor explícito de "Receita Operacional Bruta", use-o diretamente.
  - Se houver subtítulos dentro de "Receita Operacional" (ex.: vendas por filial/unidade) e **um número total no fim do bloco**, este número final é o ROB de cada ano (não use os subtítulos).
  - Nos casos de dois anos, o **primeiro valor do total corresponde ao ano mais recente** e o **segundo valor ao ano anterior**.
  - Nunca confunda com "Resultado Operacional Líquido".

REGRAS ESPECIAIS:
- **Deduções**: Se for informado 'Deduções', 'Devoluções', 'Abatimentos', etc e possuir subtitulos (ex.: "DEVOLUÇÕES DE VENDAS", "COFINS SOBRE VENDAS", "ICMS SOBRE VENDAS", "PIS SOBRE VENDAS"), o valor em "Totais por Título" para "Deduções" deve ser EXATAMENTE a soma desses itens do MESMO BLOCO para cada ano. É PROIBIDO inventar um total diferente do somatório dos itens quando o total explícito não existir.
- **CMV/CPV/CSV**: priorize total explícito no próprio bloco “(-) Custo…”. Se não houver total explícito, calcule EXCLUSIVAMENTE a soma dos itens do MESMO BLOCO (ex.: Estoque Inicial, Compras, Devoluções de compras, Fretes sobre compras, Estoque Final etc.), respeitando os sinais exatamente como estão no documento. PROIBIDO inventar totais arredondados ou “estimados”.
- Se ficar na duvida se um campo deve ser retornado, retorne. Só omita o campo se tiver certeza absoluta que ele não é um título e não deve ser retornado.
🚫 NÃO retorne nenhum **título** que tenha o **mesmo valor** de "Renda Operacional Bruta", "Lucro bruto", "receita líquida", "Lucro Líquido do Exercício", etc.
- Os campos da "Renda Operacional Bruta" e "Lucro líquido do exercício" devem aparecer **apenas uma vez**, nos respectivos campos dedicados.
- Se um **título** tiver **exatamente o mesmo valor** de ROB ou LL, localize o valor correto do título, se não houver, ele deverá ser ignorado na lista de títulos, Exemplo:
- Se tiver dois valores para o título, como: "CMV/n5000.0/nCMV/n10000.0/nlucro bruto/n10000.0" como o valor de 10.000 é igual ao lucro bruto, retorne: "CMV: 5000.0"
🚫 SE um título tiver dois valores possíveis e um deles for idêntico a ROB, Lucro Bruto, Receita Líquida ou Lucro Líquido, ignore esse valor e retorne o outro.

📌 Quebras de página:
- Ignore cabeçalhos/rodapés, carimbos e repetições.
- Continue o mesmo título mesmo que esteja em páginas diferentes.
- Se valor total aparecer só após a quebra, use-o.
Exemplo: Se aparecer no meio do texto informações como "Página 1 de 3", "Documento emitido por...", "Nome:", "Data de encerramento", "Demonstração de resultado do exercicio", "Folha:", "Insc.", ou outro nome do cabeçalho que se repete a cada página, ignore essas informações e continue a extração normalmente.

📅 Se o documento contiver dois anos (ex.: 2025 e 2024), os valores sempre aparecem em ordem decrescente de ano:
- o PRIMEIRO valor de cada linha/bloco corresponde ao ano mais recente (2025),
- o SEGUNDO valor corresponde ao ano anterior (2024).
Agrupe a saída em "DREs": {{{{ "2025": {{{{...}}}}, "2024": {{{{...}}}} }}}}.

📅 Datas e anos (REGRA FORTE):
- NUNCA use a data de emissão para inferir o ano dos valores.
- Use a data de encerramento/referência do período (ex.: “31/12/20xx”, “30/xx/20xx”) localizada no cabeçalho/início do relatório; se não houver dia/mês, use o ANO isolado visível (ex.: “2024”, “2023”).
- Em documentos com 2 anos, os valores aparecem em ordem decrescente de ano: o PRIMEIRO valor é do ano mais recente, o SEGUNDO é do ano anterior (ex.: “2024” depois “2023”).
- Agrupe a saída por ano: para DRE em "DREs": {{{{ "2024": {{{{...}}}}, "2023": {{{{...}}}} }}}}.
- Nunca retorne o mesmo valor para os dois anos, apenas se o valor estiver duplicado nos dois anos no documento, caso contrário, se não houver o mesmo valor duplicado para os dois anos, retorne o valor correspondente para cada ano.

────────────────────────────────────────────────────────────────

📦 Delimitação de bloco e Anti-duplicação (REGRA FORTE):
- O **bloco de um título** vai da **linha do título** até a **linha imediatamente anterior ao próximo título principal** (ou fim do documento).
- O **total de um título deve ser encontrado somente dentro do seu próprio bloco** (não pegar número do bloco vizinho).
- **Nunca** reutilize o mesmo token numérico para dois títulos diferentes.
  - Mantenha internamente uma **lista conceitual de valores usados** (posição/linha + número) e **não repita** o mesmo número em outro título.
- Se houver dois títulos em sequência com números idênticos, **cada um deve usar o número que está dentro do seu próprio bloco**. 
- Se um título não tem total explícito no seu bloco, **use os subtítulos do seu bloco** (ou total no fim do bloco). **Não busque fora do bloco**.

────────────────────────────────────────────────────────────────

📌 Detecção do total (formas comuns no OCR):
1) **Título + total na linha seguinte** (ou mesma linha) → esse número é o total do título.
2) **Título sem número** seguido de itens com valores e **um número ao fim do bloco** → esse número é o total do título.
3) **Título sem total explícito** e sem número ao fim → **some os subtítulos do MESMO bloco** (aplicando as regras de sinal por item).
4) DRE com dois anos lado a lado: -> Se o título não tiver número, e houver blocos com valores para dois anos (ex: 2024 e 2023), o total do ano mais recente será o antepenúltimo número do bloco, e o total do ano anterior será o último número.
📌 Regras adicionais:
- Nunca retorne um valor apenas por ser o maior valor daquele bloco, utilize a lógica dos exemplos para identificar o valor total, se houver valores com sinais invertidos no bloco, o valor total pode ser menor que um dos campos.
- Sempre retorne números como **float JSON**, ponto decimal e **sem** separador de milhar.
- Se existir total explícito do título, **use-o** (não some novamente).
- **Não confunda** total do título com o valor de um item individual.

🔍 Exemplos de extração:
{exemplos_dre}

⚠️ SAÍDA (JSON ESTRITO)
- Responda SOMENTE com um **único objeto JSON** (sem markdown).
- O primeiro caractere deve ser {{{{ e o último }}}}.
- Todas as chaves e strings em **aspas duplas**.
- Em "Totais por Título", "Valor:" deve ser **float** (ponto decimal, sem milhar).
- **Proibido** retornar valores que não estão no documento.
- **Obrigatório** que cada total retornado esteja no documento; caso contrário, não retorne esse total e retorne seus subtítulos.
- Não use vírgula final (trailing comma). Use true/false/null (minúsculas) quando necessário.

**Saída obrigatória adicional**:
- Inclua uma lista "Totais por Título" com objetos {{{{"Nome:": "<título>", "Valor:": <float>}}}}.
EXEMPLO DE SAIDA:
{{{{
  "DREs": {{{{
    "2024": {{{{
      "Nome:": "EMPRESA LTDA",
      "CNPJ:": "00.000.000/0001-00",
      "Data de Referência:": "31/12/2024",
      "Renda Operacional Bruta:": 1234567.89,
      "Lucro Líquido do Exercício:": 23456.78,
      "Totais por Título": [
        {{{{ "Nome:": "Deduções", "Valor:": -480526.92 }}}},
        {{{{ "Nome:": "Custo Produtos Vendidos", "Valor:": -16276885.73 }}}},
        ...
      ]
    }}}},
    "2023": {{{{
      "Nome:": "EMPRESA LTDA",
      "CNPJ:": "00.000.000/0001-00",
      "Data de Referência:": "31/12/2023",
      "Renda Operacional Bruta:": 1111111.11,
      "Lucro Líquido do Exercício:": 22222.22,
      "Totais por Título": [ ... ]
    }}}}
  }}}}
}}}}

---

{{number_of_items}}
{{format_instructions}}

Context:
{{context}}
"""