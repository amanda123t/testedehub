pf_prediction = """You are a document classifier for the following classes:
        [Address, SelfDeclarationAddress, Registration_Pj, Registration_Pf, IRPF, IRPF Receipt, Nota_Fiscal, Pricing, SelfDeclaration, Income, INSS, Paycheck, ProLabore, Crlv, PropertyRegistration].
        
        Here are some example documents for each class:
        
        Address examples:
        - Light document example: {address}
        - Bank document example: {address2}
        PAY ATTENTION: This second address model is similar to the Paycheck document. I would like you to be very careful not to confuse these two types of documents.
        - When classifying a document as 'Address', ONLY do so if the document explicity contains all keywords like: 'FATURA', 'VENCIMENTO', 'Endereço' .If these words are not found, DO NOT classify as 'Registration_Pj'. Respond with 'None' or the correct class.
        
        SelfDeclarationAddress:
        - self-declaration / self-proof of address, return 'SelfDeclarationAddress' only if it's a self-declaration of address; if it's a self-declaration of INCOME, return 'SelfDeclaration'.
        - SelfDeclarationAddress example: {self_declaration_address}
        - Other SelfDeclarationAddress example: {self_declaration_address2}

        Income examples:
        - Income document example: {income}
        - When classifying a document as 'Income', ONLY do so if the document explicitly contains keywords like: 'Consulta Renda Presumida', 'Bureau Sicredi'. If these words are not found, DO NOT classify as 'Income'. Respond with 'None' or the correct class.

        Pricing examples:
        - Pricing document example: {pricing}
        - When classifying a document as 'Pricing', ONLY do so if the document explicitly contains keywords like: 'Gerada em', 'Expira em'. If these words are not found, DO NOT classify as 'Pricing'. Respond with 'None' or the correct class.

        Registration_Pj examples:
        - Registration_Pj document example: {registration_pj}
        - When classifying a document as 'Registration_Pj', ONLY do so if the document explicity contains all keywords like: 'CADASTRO DE PESSOAS', 'Cooperativa'.If these words are not found, DO NOT classify as 'Registration_Pj'. Respond with 'None' or the correct class.
        
        Registration_Pf:
        - Registration_Pf document example: {registration_pf}
        - When classifying a document as 'Registration_Pf', ONLY do so if the document explicity contains all keywords like: 'CADASTRO DE PESSOAS', 'Cooperativa'.If these words are not found, DO NOT classify as 'Registration_Pf'. Respond with 'None' or the correct class.
       
        INSS examples:
        - INSS document example: {inss}
        - When Classifying a document as "INSS", ONLY do so if the document explicity contains keyboards like: "INSS" or "Instituto Nacional do Seguro Social"

        Nota_Fiscal examples:
        - Nota_Fiscal document example: {nota_fiscal}
        - When Classifying a document as "Nota_Fiscal", ONLY do so if the document explicity contains keyboards like: "DANFE", "VALOR TOTAL DA NOTA", "DESTINATARIO" or "REMETENTE"
        
        Paycheck examples:
        - Paycheck document example: {paycheck}
        
        ProLabore examples:
        - ProLabore document example: {prolabore}
        
        CRLV examples:
        - CRLV document example: {crlv}
        - When Classifying a document as "CRLV", ONLY do so if the document explicity contains keyboards like: "Renavam", "Chassi", "MARCA / MODELO / VERSÃO"
        
        Property Registration examples:
        - Property Registration document example: {property_registration}
        
        IRPF examples:
        - IRPF document example: {irpf}

        IRPF Receipt examples:
        - IRPF receipt example: {ir_receipt}
        
        SelfDeclaration examples:
        - SelfDeclaration example: {self_declaration}

        Now, classify the following document:
        {input_document}
        
        Only respond with the class name from the list above. If you can't classify it, respond with None.
        """
        
address_validation = """You are a document classifier for the following classes:
        [Address, Paycheck].
        
        Here are some example documents for each class:
        
        Address example: {address2}
        PAY ATTENTION: This second address model is similar to the Paycheck document. I would like you to be very careful not to confuse these two types of documents.
        
        Paycheck example: {paycheck}
        
        Now, classify the following document:
        {input_document}
        Pay attention in details, some address are very similar to paychecks. Do not mistake it.
        Only respond with the class name from the list above. If you can't classify it, respond with None.
        """
        
irpf_validation = """You are a document classifier for IRPF documents. Your classes are:
        [IRPF, IRPFReceipt].

        Here are examples:
        IRPF example (full declaration): {irpf}
        IRPFReceipt example (only the receipt page): {ir_receipt}
        Example with both in the same file: {ir_receipt_declaration}

        **Classification Rules:**
        1.  A document is 'IRPF' (full declaration) ONLY if it contains detailed sections like "RENDIMENTOS TRIBUTÁVEIS", "BENS E DIREITOS", or "DÍVIDAS E ÔNUS REAIS".
        2.  A document is 'IRPFReceipt' ONLY if it contains the phrase "NÚMERO DO RECIBO" and "Recibo de Entrega da Declaração" but LACKS the detailed sections mentioned above.
        Now, classify the following document based on these strict rules:
        {input_document}

        Only respond with 'IRPF' or 'IRPFReceipt'.
        """

        
pj_prediction = """You are a document classifier for the following classes:
        [Minute, Invoice, PresumedBilling, Simples, Contract, Balance, DRE, Nota_Fiscal,].
        
        Here are some example documents for each class:
        
        Minute examples:
        - Minute document example: {minute}
        
        Nota_Fiscal examples:
        - Nota_Fiscal document example: {nota_fiscal}
        - When Classifying a document as "Nota_Fiscal", ONLY do so if the document explicity contains keyboards like: "DANFE", "VALOR TOTAL DA NOTA", "DESTINATARIO" or "REMETENTE"
        
        Invoice Examples:
        - Invoice document example: {invoice}
        - Other Invoice document example: {invoice2}

        PresumedBilling examples:
        - PresumedBilling document example: {presumed_billing}
        - When classifying a document as 'PresumedBilling', ONLY do so if it contains words like 'Faturamento Presumido', 'Consulta Restritivos', 'Identificação', and 'CNPJ'. If these are not present, DO NOT classify as 'PresumedBilling'.

        Simple examples:
        - Example of the Simples Nacional: {simples}
        - When classifying a document as 'Simples,' ONLY do so if it contains words such as 'Simples nacional', 'SIMEI', 'informações do contribuente', 'entrega do PGDAS' ou 'Receita Bruta Total'. If these are not present, DO NOT classify it as 'Simples.'
        - IMPORTANT:
        1) If the document only mentions the 'regime tributário: Simples nacional' if it lacks the keywords for the Simples Nacional, DO NOT classify it as simple; return it as "Invoice."
        2) If the document contains terms related to the **IRPF** (such as "Declaração de Ajuste Anual", "Imposto de Renda da Pessoa Física", "IRPF"), classify it as 'IRPF.'
        
        Contract  examples:
        - Contract document example: {contract}
        
        Balance examples:
        - Balance document example: {balance}
        - When classifying a document as 'Balance', ONLY do so if the document explicity contains all keywords like: 'ATIVO', 'PASSIVO', 'PATRIMÔNIO LÍQUIDO'. If these words are not found, DO NOT classify as 'Balance'. Respond with 'None' or the correct class.
        
        DRE examples:
        - DRE document example: {dre}

        Now, classify the following document:
        {input_document}
        
        Only respond with the class name from the list above. If you can't classify it, respond with None.
        """


geral_prediction = """You are a document classifier for the following classes:
        [Address, SelfDeclarationAddress, SelfDeclaration, Income, INSS, Nota_Fiscal, Paycheck, ProLabore, PropertyRegistration, Minute, Invoice.].
                
        Address examples:
        PAY ATTENTION: This second address model is similar to the Paycheck document. I would like you to be very careful not to confuse these two types of documents.
        - When classifying a document as 'Address', ONLY do so if the document explicity contains all keywords like: 'FATURA', 'VENCIMENTO', 'Endereço' .If these words are not found, DO NOT classify as 'addres'. Respond with 'None' or the correct class.
        - Documents that prove an address, such as internet, electricity, water bills or credit card statements, should be classified as 'Address'.
        - Light document example: {address}
        - Bank document example: {address2}
        
        SelfDeclarationAddress:
        - self-declaration / self-proof of address, return 'SelfDeclarationAddress' only if it's a self-declaration of address; if it's a self-declaration of INCOME, return 'SelfDeclaration'.
        - SelfDeclarationAddress example: {self_declaration_address}
        - Other SelfDeclarationAddress example: {self_declaration_address2}
   
        SelfDeclaration examples:
        - SelfDeclaration example: {self_declaration}

        Income examples:
        - Income document example: {income}
        - When classifying a document as 'Income', ONLY do so if the document explicitly contains keywords like: 'Consulta Renda Presumida', 'Bureau Sicredi'. If these words are not found, DO NOT classify as 'Income'. Respond with 'None' or the correct class.

        INSS examples:
        - INSS document example: {inss}
        - When Classifying a document as "INSS", ONLY do so if the document explicity contains keyboards like: "INSS" or "Instituto Nacional do Seguro Social"

        Nota_Fiscal examples:
        - Nota_Fiscal document example: {nota_fiscal}
        - When Classifying a document as "Nota_Fiscal", ONLY do so if the document explicity contains keyboards like: "DANFE", "VALOR TOTAL DA NOTA", "DESTINATARIO" or "REMETENTE"
        
        Paycheck examples:
        - Paycheck document example: {paycheck}
        
        ProLabore examples:
        - ProLabore document example: {prolabore}
        
        Property Registration examples:
        - Property Registration document example: {property_registration}
        
        Minute examples:
        - Minute document example: {minute}
        
        Invoice Examples:
        - company's monthly revenue statement.
        - To be classified as an 'Invoice', it needs to contain the company's monthly or annual revenue figures.
        - Invoice document example: {invoice}
        - Other Invoice document example: {invoice2}
        - Other Invoice document example: {invoice3}

        Now, classify the following document:
        {input_document}
        
        Only respond with the class name from the list above. If you can't classify it, respond with None.
        """
