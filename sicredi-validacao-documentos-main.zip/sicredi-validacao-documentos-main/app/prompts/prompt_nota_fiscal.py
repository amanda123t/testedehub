exemplos_nota_fiscal = """
## 🔍 EXEMPLOS PARA CAPTURA DE EMISSOR, DESTINATARIO, ENTRADA E SAIDA. (NÃO COPIE NÚMEROS; USE APENAS O PADRÃO)

1) se o texto veir assim:

RECEBEMOS DE RUDI DE ROS OS PRODUTOS CONSTANTES NA NOTA FISCAL INDICADA AO LADO.
NFA-e
No 5470848
SÉRIE: 891
DATA DE RECEBIMENTO
IDENTIFICAÇÃO E ASSINATURA DO RECEBEDOR
RUDI DE ROS
SITIO DA VIVI
EST BR 429, KM 07 - ZONA RURAL
LT 57 GB 10
SAO MIGUEL DO GUAPORE - RO
DANFE
CONTROLE DO FISCO
Documento Auxiliar da
Nota Fiscal Avulsa
Eletrônica
0 - ENTRADA
1 - SAÍDA
Nº 5470848
SÉRIE: 891
FOLHA 1/ 1
CHAVE DE ACESSO
1124 1105 5992 5300 0147 5589 1005 4708 4810 5317 8405
1
Consulta de autenticidade no portal nacional da NF-e
www.nfe.fazenda.gov.br/portal ou no site da Sefaz Autorizadora.
NATUREZA DA OPERAÇÃO
CEP: 76932-000
6999151573
PROTOCOLO DE AUTORIZAÇÃO DE USO
211240015002214
Outra saida de mercadoria ou prestacao de servico nao espec
INSCRIÇÃO ESTADUAL
00000005983851
INSCRIÇÃO ESTADUAL DE SUBST.
CNPJ / CPF
732.725.749-72
DESTINATÁRIO / REMETENTE
NOME / RAZÃO SOCIAL
CNPJ / CPF
DATA EMISSÃO
JBS SA
02.916.265/0037-70
04/11/2024
ENDEREÇO
BR 364, KM 18, SN
BAIRRO / DISTRITO
DISTRITO INDUSTRIAL

-> Retorne assim:
{{'Emissor:': 'RUDI DE ROS', 'Destinatário:': 'JBS SA', 'Entrada/Saida:': '1' }}

2) Se vier assim:

DATA DE RECEBIMENTO
IDENTIFICAÇÃO E ASSINATURA DO RECEBEDOR
COMERCIO DE BEBIDAS LTDA
SITIO DA VIVI
EST BR 429, KM 07 - ZONA RURAL
LT 57 GB 10
SAO MIGUEL DO GUAPORE - RO
CEP: 76932-000
NATUREZA DA OPERAÇÃO
Outra saida de mercadoria ou prestacao de servico nao espec
INSCRIÇÃO ESTADUAL
00000005983851
6999151573
INSCRIÇÃO ESTADUAL DE SUBST.
DESTINATÁRIO / REMETENTE
NFA-e
Nº 5470888
SÉRIE: 891
DANFE
CONTROLE DO FISCO
Documento Auxiliar da
Nota Fiscal Avulsa
Eletrônica
0 - ENTRADA
1 - SAÍDA
Nº 5470888
CHAVE DE ACESSO
1124 1105 5992 2874 0147 5589 1005 4708 8810 5317 8400
0
SÉRIE: 891
FOLHA 1 / 1
Consulta de autenticidade no portal nacional da NF-e
www.nfe.fazenda.gov.br/portal ou no site da Sefaz Autorizadora.
PROTOCOLO DE AUTORIZAÇÃO DE USO
431240017003488
CNPJ / CPF
732.725.749-72
NOME / RAZÃO SOCIAL
CNPJ / CPF
DATA EMISSÃO
JOAO DA SILVA SANTOS
867.854.879-97
04/11/2024
ENDEREÇO
BR 118, KM 188, SN
BAIRRO / DISTRITO

-> Retorne assim:
{{ 'Emissor:': 'COMERCIO DE BEBIDAS LTDA', 'Destinatário:': 'JOAO DA SILVA SANTOS' 'Entrada/Saida:': '0'}}

3) Se vier assim:

DATA DE RECEBIMENTO
IDENTIFICAÇÃO E ASSINATURA DO RECEBEDOR
RUDI DE ROS
SITIO DA VIVI
EST BR 429, KM 07 - ZONA RURAL
LT 57 GB 10
SAO MIGUEL DO GUAPORE - RO
CEP: 76932-000
NATUREZA DA OPERAÇÃO
Outra saida de mercadoria ou prestacao de servico nao espec
INSCRIÇÃO ESTADUAL
00000005983851
6999151573
INSCRIÇÃO ESTADUAL DE SUBST.
DESTINATÁRIO / REMETENTE
NFA-e
Nº 5470888
SÉRIE: 891
DANFE
CONTROLE DO FISCO
Documento Auxiliar da
Nota Fiscal Avulsa
Eletrônica
0 - ENTRADA
1 - SAÍDA
Nº 5470888
CHAVE DE ACESSO
1124 1105 5992 5300 0147 5589 1005 4708 8810 5317 8400
1
SÉRIE: 891
FOLHA 1 / 1
Consulta de autenticidade no portal nacional da NF-e
www.nfe.fazenda.gov.br/portal ou no site da Sefaz Autorizadora.
PROTOCOLO DE AUTORIZAÇÃO DE USO
211240015003488
CNPJ / CPF
732.725.749-72
NOME / RAZÃO SOCIAL
CNPJ / CPF
DATA EMISSÃO
JBS SA
02.916.265/0037-70
04/11/2024
ENDEREÇO
BR 364, KM 18, SN
BAIRRO / DISTRITO

-> Retorne assim:
{{ 'Emissor:': 'RUDI DE ROS', 'Destinatário:': 'JBS SA' 'Entrada/Saida:': '1'}}

4) Se vier assim:

DATA DE RECEBIMENTO
IDENTIFICAÇÃO E ASSINATURA DO RECEBEDOR
RUDI DE ROS
SITIO DO RUDI
RODOVIA 429, KM 154 - ZONA RURAL
LT 535155 55A GL RIO BRANCO S ALVORADA
SAO MIGUEL DO GUAPORE - RO
CEP: 78970-000
NATUREZA DA OPERAÇÃO
Outra saida de mercadoria ou prestacao de servico nao espec
INSCRIÇÃO ESTADUAL
00000001309005
DANFE
Documento Auxiliar da
Nota Fiscal Avulsa
Eletrônica
0 - ENTRADA
1 - SAÍDA
1
Nº 5206405
SÉRIE: 891
FOLHA 1 / 1
INSCRIÇÃO ESTADUAL DE SUBST.
DESTINATÁRIO / REMETENTE
NOME / RAZÃO SOCIAL
CSAP COMPANHIA SUL AMERICANA DE PECUARIA S.A.
NFA-e
Nº 5206405
SÉRIE: 891
CONTROLE DO FISCO
CHAVE DE ACESSO
1124 0705 5992 5300 0147 5589 1005 2064 0510 5317 8401
Consulta de autenticidade no portal nacional da NF-e
www.nfe.fazenda.gov.br/portal ou no site da Sefaz Autorizadora.
PROTOCOLO DE AUTORIZAÇÃO DE USO
211240005422146
CNPJ / CPF
732.725.749-72
CNPJ / CPF
21.278.812/0009-20
DATA EMISSÃO
10/07/2024
ENDEREÇO

-> Retorne assim:
{{ 'Emissor:': 'RUDI DE ROS', 'Destinatário:': 'CSAP COMPANHIA SUL AMERICANA DE PECUARIA S.A.', 'Entrada/Saida:': '1'}}

5) Se vier assim (emitido por um orgão público):

Texto coletado da nota fiscal: GOVERNO DO ESTADO DE
MATO GROSSO
DANFE
Documento Auxiliar da
Nota Fiscal Eletrônica
SECRETARIA DE ESTADO DE FAZENDA DE
MATO GROSSO
CNPJ: 03.507.415/0005-78
0 - ENTRADA
1 - SAÍDA
1
CHAVE ACESSO
5124 0203 5074 1500 0578 5589 0003 5155 9210 8383 9200
No: 3515592
Série: 890
Folha(s): 01/01
Consulta de autenticidade no portal da NF-e
www.nfe.fazenda.gov.br/portal
NATUREZA DE OPERAÇÃO
35 - SAIDA COM DIFERIMENTO
PROTOCOLO DE AUTORIZAÇÃO DE USO
151240014810566 22/02/2024 09:50:48
REMETENTE
NOME/RAZÃO SOCIAL
CNPJ/CPF
DATA EMISSÃO
JOAO HISTED ABREU
569.888.421-87
22/02/2024
ENDEREÇO
GLEBA RAPOSO TAVARES, Nº SN
BAIRRO/DISTRITO
ZONA RURAL
CEP
78593-000
DATA DA ENTRADA/SAÍDA
22/02/2024
MUNICÍPIO
FONE/FAX
UF
INSCRIÇÃO ESTADUAL
HORA DA SAÍDA
NOVA MONTE VERDE
(663)5971-502
MT
13.313.560-8
09:51
DESTINATÁRIO
NOME/RAZÃO SOCIAL
VANDERLEI DENZER
CNPJ/CPF
310.374.029-87
ENDEREÇO
BAIRRO/DISTRITO
CEP
ESTRADA SANTA CATARINA, Nº SN
SAO JOSE DO APUY
78593-000
MUNICÍPIO
NOVA MONTE VERDE
FONE/FAX

-> Retorne assim:
{{ 'Emissor:': 'JOAO HISTED ABREU', 'Destinatário:': 'VANDERLEI DENZER', 'Entrada/Saida:': '1'}}
"""

prompt_nota_fiscal = f"""Você é um extrator de informações de notas fiscais.  

Analise o texto OCR fornecido e retorne apenas os campos abaixo, usando exatamente estes rótulos (incluindo os dois-pontos) e formatos.
Corrija pequenos erros comuns de OCR quando necessário.

Campos a retornar (JSON):

1)"Emissor:" → Nome completo de quem emitiu a nota (pessoa/empresa), retorne o nome da empresa ou pessoa que emitiu a nota.

2)"Destinatário:" → Nome completo do destinatário da nota fiscal.

3)"DataEmissao:" → dd/mm/aaaa.

4)"NumeroNota:" → número único da NF (sem espaços extras), entre 6 a 8 dígitos.

5)"Entrada/Saida:" → "0" ou "1" (veja regras abaixo).

6)"Produtos:" → descrições de itens somente APÓS a zona “DADOS/PRODUTOS/DESCRIÇÃO”. Ignorar qualquer linha com padrões de endereço (KM, RODOV, ZONA RURAL, RIO, CEP, CNPJ/CPF, CHAVE DE ACESSO etc.) e cabeçalhos de coluna (NCM/CFOP/CST/UN/QUANT/VALOR). Múltiplos itens: separar com “; ”. Se não houver item válido, retorne "".

7)"ValorTotal:" → valor total em BRL no formato xx.xxx,xx.

Regras gerais de extração

Não use o nome do associado para nada. Não tente inferir Entrada/Saída por emissor/destinatário.

Datas: normalizar para dd/mm/aaaa.

Valores: normalizar para padrão brasileiro xx.xxx,xx (ex.: “2000.00” → “2.000,00”).

Texto: remover quebras/lixos do OCR, corrigir erros simples (“Bo,ino” → “Bovino”, “SAlDA” → “SAÍDA”).

Número da nota: preferir o campo explícito (ex.: “Nº 5404573”, “NF-e 4866994”), evitando confundir com CHAVE DE ACESSO.

IDENTIFICAÇÃO DO EMISSOR E DESTINATÁRIO — REGRAS FINAIS (ANTI‑TROCA)

ÂNCORA DEST:
- Encontre a PRIMEIRA ocorrência de um rótulo que comece com “DESTINAT” (ex.: “DESTINATÁRIO”, “DESTINATÁRIO/REMETENTE”, “DESTINATÁRIO/COMPRADOR”), ignorando caixa/acentos. Chame essa posição de ÂNCORA_DEST.
- Tudo ACIMA de ÂNCORA_DEST = região do EMISSOR (cabeçalho). Tudo ABAIXO = região do DESTINATÁRIO.

EMISSOR (sempre ANTES de ÂNCORA_DEST):
- O Emissor é o PRIMEIRO nome/razão social relevante no topo do documento, ANTES de ÂNCORA_DEST.
- Sinais fortes de Emissor (use na ordem de prioridade):
  1) Padrões “RECEBEMOS DE <NOME>”, “RECEBIDO DE <NOME>”, “RECEBEMOS OS PRODUTOS DE <NOME>” ⇒ <NOME> é o EMISSOR.
  2) Linha de nome imediatamente acima/ao lado de um CNPJ (14 dígitos com separadores).
  3) Linha em CAIXA ALTA com “LTDA”, “S/A”, “EPP”, “ME”, ou nome completo de PF.
- Se houver ambiguidade, escolha SEMPRE o nome mais próximo do TOPO e ANTES de qualquer “DESTINAT*”.
- PROIBIDO usar como Emissor nomes que apareçam abaixo de ÂNCORA_DEST, mesmo que pareçam razão social.

DESTINATÁRIO (sempre APÓS de ÂNCORA_DEST):
- O Destinatário é o nome/razão social IMEDIATAMENTE APÓS ÂNCORA_DEST (mesma linha ou até 3 linhas seguintes), preferindo:
  1) Linha de nome seguida de CNPJ/CPF do destinatário.
  2) Linha em CAIXA ALTA com “LTDA”, “S/A”, “EPP”, “ME”, ou nome completo de PF.

- CASO o emissor seja o governo/estado, exemplo 'GOVERDO DO ESTADO DE ...', 'PREFEITURA MUNICIPAL', ou outro orgão público, voce deve procurar o emissor no campo "REMETENTE" e o destinatário no campo "DESTINATÁRIO"
*NUNCA* retorne o orgão público(governo, secretaria, etc) como emissor da nota

EXCLUSÕES (nunca usar como Emissor nem Destinatário):
- Blocos ou rótulos: “TRANSPORTADOR / VOLUMES TRANSPORTADOS”, “LOCAL DE ENTREGA”, “ENDEREÇO DE ENTREGA”, “RETIRA”, “DADOS DO FISCO”, “PROTOCOLO DE AUTORIZAÇÃO”, “INFORMAÇÕES COMPLEMENTARES”, títulos (“DANFE”, “NOTA FISCAL”, “NF‑E”, “CHAVE DE ACESSO”, “SÉRIE”, “FOLHA”, “Nº”).
- O bloco “TRANSPORTADOR / VOLUMES TRANSPORTADOS” (geralmente após o Valor Total) nunca compõe Emissor/Destinatário.

SANIDADE (anti‑troca e duplicidade):
- Regra de ordem: Emissor ACIMA de ÂNCORA_DEST; Destinatário ABAIXO de ÂNCORA_DEST.
- Se o nome retornado para Emissor aparecer apenas abaixo de ÂNCORA_DEST, e o nome retornado para Destinatário aparecer acima, INVERTA os dois.
- O Emissor e o Destinatário NUNCA devem ser iguais (após normalizar acentos, caixa e espaços). Se ficarem iguais, reavalie usando as regras acima:
  1) Priorize “RECEBEMOS DE <NOME> ...” para Emissor.
  2) Se persistir a dúvida, deixe “Destinatário” vazio "" (não invente).
- Todos os nomes retornados devem existir como substring no CONTEXT (após normalização simples de acentos e espaços).

IMPORTANTE:
*NUNCA* retorne o nome que aparece PRIMEIRO no documento como destinatário, o primeiro nome SEMPRE será do EMISSOR.

Regra obrigatória para “Entrada/Saída” (não usar outras heurísticas):

A determinação deve ser feita somente a partir da legenda impressa na nota, que sempre contém:

0 - ENTRADA
1 - SAÍDA

Em seguida (logo abaixo, nas próximas 1–7 linhas), haverá uma linha com um dígito único 0 ou 1. Esse dígito define o tipo:

Se o dígito encontrado for 1 ⇒ "Entrada/Saida:" = "1" (Nota de SAÍDA).

Se o dígito encontrado for 0 ⇒ "Entrada/Saida:" = "0" (Nota de ENTRADA).

Procedimento passo a passo para encontrar o dígito:

Localize o bloco onde apareçam ambas as linhas (case-insensitive, ignorando acentos e variações de espaço/hífen):

0 - ENTRADA

1 - SAÍDA

A partir desse bloco, procure nas próximas 1 a 7 linhas o primeiro dígito isolado 0 ou 1.

“Isolado” significa que está sozinho na linha, que não está colado a outros dígitos/letras, nem faz parte de datas, CNPJ/CPF, CHAVE DE ACESSO (44 dígitos), CEP, série, página etc.

Se não for possível determinar com segurança, retorne "Entrada/Saida:" como string vazia "" (não chute).

Exemplos:

Exemplo A:

0 - ENTRADA
1 - SAÍDA
Nº 5404573
SÉRIE: 891
FOLHA 1 / 1
CHAVE DE ACESSO
1   -> NOTA DE SAIDA


Exemplo B:

Eletrônica
0 - ENTRADA
1 - SAÍDA
CHAVE DE ACESSO
1124 0705 5992 5300 0147 5589 1005 1934 3110 5317 8408
1 -> NOTA DE SAIDA


Exemplo C:

NOTA FISCAL ELETRÔNICA
...
0 - ENTRADA
1 - SAÍDA
CHAVE DE ACESSO
0 -> NOTA DE ENTRADA


Atenção – o que ignorar ao decidir Entrada/Saída:

Dígitos “0” e “1” que façam parte de datas, CNPJ/CPF, CHAVE DE ACESSO (44 dígitos), CEP, numeração de páginas (“1/1”), série, número da NF, códigos NCM/CFOP.

Presença de nomes (emissor/destinatário/associado). Nunca use nomes para decidir a direção.

## 🔍 EXEMPLOS (NÃO COPIE NÚMEROS; USE APENAS O FORMATO)
Analise e aplique a mesma lógica dos exemplos na validação do documento:
{exemplos_nota_fiscal}

Formato de saída (JSON exatamente com estes rótulos):
{{{{
"Emissor:": "…",
"Destinatário:": "…",
"DataEmissao:": "dd/mm/aaaa",
"NumeroNota:": "…",
"Entrada/Saida:": "0 ou 1 (ou vazio se indeterminável)",
"Produtos:": "…",
"ValorTotal:": "xx.xxx,xx"
}}}}

Retorne apenas o JSON solicitado, sem comentários adicionais.

Use este formato em sua resposta JSON: 
{{format_instructions}}

---

🧠 Context: ( a partir daqui é o texto do documento, não terá instruções ou regras, apenas o texto)
{{context}}
{{number_of_items}}

"""
