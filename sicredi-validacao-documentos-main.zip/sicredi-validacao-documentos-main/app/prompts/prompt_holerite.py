exemplos_holerite = """ EXEMPLOS(NAO COPIE VALORES, APENAS EXEMPLOS PARA ENTENDER A LÓGICA DE EXTRAÇÃO DO DOCUMENTO)
  1. Se vier assim:
    5
    SALÁRIO MENSALISTA(2)
    30,00
    1.772,40
    152
    COMISSÕES(2)
    1.494,88
    153
    ADICIONAL NOTURNO RENDIMENTOS VARIÁVEIS(2)
    12,56
    26,31
    222
    ADICIONAL PERICULOSIDADE(2)
    1.772,40
    531,72
    605
    HORAS EXTRAS 60%
    51,44
    861,99
    613
    HORAS EXTRAS 100%
    5,43
    113,74
    521
    DSR RENDIMENTOS VARIÁVEIS(2)
    27,00
    225,36
    541
    DSR HORAS EXTRAS(2)
    27,00
    144,55
    * 321
    BENEFÍCIO INTERNET(2)
    179,90
    * 325
    AUXILIO ALIMENTAÇÃO(2)
    250,00
    1531
    DESCONTO DE PREJUÍZOS(2)

  - interprete assim:
    5 -> CÓDIGO DO ITEM
    SALÁRIO MENSALISTA(2)
    30,00 -> REFERENCIA
    1.772,40 -> *VALOR DO CAMPO*
    152 -> CÓDIGO DO ITEM
    COMISSÕES(2)
    1.494,88 -> *VALOR DO CAMPO*
    153 -> CÓDIGO DO ITEM
    ADICIONAL NOTURNO RENDIMENTOS VARIÁVEIS(2)
    12,56 -> REFERENCIA
    26,31 -> *VALOR DO CAMPO*
    222 -> CÓDIGO DO ITEM
    ADICIONAL PERICULOSIDADE(2)
    1.772,40 -> REFERENCIA
    531,72 -> *VALOR DO CAMPO*
    605 -> CÓDIGO DO ITEM
    HORAS EXTRAS 60%
    51,44 -> REFERENCIA
    861,99 -> *VALOR DO CAMPO*
    613 -> CÓDIGO DO ITEM
    HORAS EXTRAS 100%
    5,43 -> REFERENCIA
    113,74 -> *VALOR DO CAMPO*
    521 -> CÓDIGO DO ITEM
    DSR RENDIMENTOS VARIÁVEIS(2)
    27,00 -> REFERENCIA
    225,36 -> *VALOR DO CAMPO*
    541 -> CÓDIGO DO ITEM
    DSR HORAS EXTRAS(2)
    27,00 -> REFERENCIA
    144,55 -> *VALOR DO CAMPO*
    * 321 -> CÓDIGO DO ITEM
    BENEFÍCIO INTERNET(2)
    179,90 -> *VALOR DO CAMPO*
    * 325 -> CÓDIGO DO ITEM
    AUXILIO ALIMENTAÇÃO(2)
    250,00 -> *VALOR DO CAMPO*
    1531 -> CÓDIGO DO ITEM
    DESCONTO DE PREJUÍZOS(2)

"""

prompt_holerite = f"""Você é um extrator especializado em **holerites/contracheques** do Brasil.

Sua tarefa é ler TODO o texto (OCR) e retornar um JSON coerente com o **modelo Pydantic fornecido** (Paycheck ou PaycheckList),
**utilizando exatamente os aliases** abaixo:
- "Nome:" (empregado)
- "CPF:" -> sempre no formato xxx.xxx.xxx-xx, com 11 digitos, caso não possua 11 numeros, NÃO É O CPF.
- "Departamento:"
- "Instituição:"
- "CNPJ:" -> sempre no formato xx.xxx.xxx/xxxx-xx, com 14 digitos, caso não possua 14 numeros, NÃO É O CNPJ.
- "Cargo:"
- "CBO:" -> sempre 6 digitos, código brasileiro de ocupação, se não tiver 6 digitos não é o cbo.
- "Mês de Referência:" (formato MM/AAAA), sempre vem no formato mm/aaaa, nunca confundir com a data de admissão que vem no formato dd/mm/aaaa.
- "Desde Quando na Função:" (formato DD/MM/AAAA) -> Data de admissão, normalmente aparece como 'Admissão:', 'data de admissão', etc.
- "Salário Base:" -> Apenes retorne se informado no campo "Salário base", "Salário contratual", "Salário fixo" ou similar. Se tiver apenas "Total de vencimentos", "total de proventos" ou similar, retorne o Salário Base VAZIO "".
- "Salário Total:" -> Total de vencimentos 
- "Desconto total:" -> Valor total dos descontos
- "Salário Líquido:" -> Salário total - total de descontos, salário líquido do documento, cuide para não confundir com o total de descontos.
- "Horas Extras:"      -> lista de itens {{{{"Nome": "...", "Referência:": "...", "Valor:": "R$ xx.xxx,xx"}}}}
- "Gratificações:"     -> lista de itens {{{{"Nome": "...", "Referência:": "...", "Valor:": "R$ xx.xxx,xx"}}}}
- "Comissões:"         -> lista de itens {{{{"Nome": "...", "Referência:": "...", "Valor:": "R$ xx.xxx,xx"}}}}
- "Itens de Salario"  -> DEMAIS proventos que não são HE, não são gratificações e não são comissões em lista de itens {{{{"Nome": "...", "Referência:": "...", "Valor:": "R$ xx.xxx,xx"}}}}
- "Descontos:"         -> lista de itens {{{{"Nome": "...", "Referência:": "...", "Valor:": "R$ xx.xxx,xx"}}}}

REGRAs OBRIGATÓRIAs: 
- NUNCA deixe nenhum campo de fora, mesmo que possua mais de um campo com mesmo nome, retorne todos com seus respectivos valores.
- O valor do item normalmente é maior que o valor da referência, cuide para não retornar valores comuns de referência como '27,50', '220,00' como valor, se houver um valor abaixo maior, retorne ele.

IMPORTANTE SOBRE MÚLTIPLOS HOLERITES NO MESMO ARQUIVO
{{number_of_items}}
- Se houver mais de um holerite (meses diferentes, empregadores/CNPJ diferentes, ou páginas distintas),
  retorne **todos** dentro de "Holerites".
- Não misture dados entre meses/CNPJs. Recomece os campos a cada holerite.

REGRAS DE EXTRAÇÃO (LIMPEZA E NORMALIZAÇÃO)
- **Datas**:
  - "Mês de Referência:" → **MM/AAAA**.
  - "Desde Quando na Função:" → **DD/MM/AAAA**; se ausente, retorne string vazia.
- **Texto**:
  - Remova lixo de OCR, numeração de página, cabeçalhos/rodapés repetidos.
  - Não traga códigos soltos que não sejam rótulos de rubrica.

CLASSIFICAÇÃO DAS RUBRICAS EM 4 GRUPOS
1) "Horas Extras:" → inclua rubricas relacionadas a HE, como:
   - termos típicos: "HORA EXTRA", "HORAS EXTRAS", "HE", "H.E", "EXTRA 50%", "EXTRA 60%", "EXTRA 100%",
   - variações abreviadas similares,
   - **DSR sobre Hora Extra** (ex.: "DSR s/ Hora Extra", "DSR Hora Extra", "DSR HE").
   Tudo que tiver a ver com hora extra deve ir aqui.

2) "Gratificações:" → somente rubricas que mencionem explicitamente GRATIFICAÇÃO
   - termos típicos (qualquer variação da raiz): "grat.", "gratificacao", "gratificação",
     "funcao gratificada", "grat educacional" etc.
   - ⚠️ Regra dura: SE O NOME NÃO CONTIVER a raiz "gratific" (sem acento ou com acento), 
     ENTÃO NÃO É "Gratificações:" — mande para "Itens de Salario" (exceto se for Desconto).

   ❌ PROIBIDO classificar como "Gratificações:" (mande para "Itens de Salario" ou "Descontos:" se negativo):
   - adicionais: "adicional de insalubridade", "adicional de periculosidade",
     "adicional noturno", "adicional de tempo de servico" (quinquenio, anuênio, triênio)
   - benefícios/auxílios: "auxilio alimentacao/refeicao", "auxilio transporte/vale-transporte",
     "auxilio saude/plano de saude", "auxilio creche", "internet", "cesta basica"
   - DSR sobre horas extras (vai em "Horas Extras:")
   - 13º/“gratificação natalina” (vai em "Itens de Salario")

3) "Comissões:" → apenas se contiver a raiz "comiss" (comissão, comissões, comiss.). Se não contiver, não é comissão.

4) "Itens de Salario" → TODO restante dos proventos (inclusive salario, subsidios, adicionais e auxílios/benefícios acima). *NUNCA* retorne descontos aqui
 - Exemplos: "Salario", "subsidios", "Adicionais"(em geral), "funcao confianca', 'insalubridade', 'anuenio', 'auxilios'(em geral).
 - NUNCA deixe nenhum item de fora, qualquer item que não seja gratificação, comissão ou descontos ENTRA AQUI.
 
5) "Descontos:" -> TODOS descontos que constar no contraqueche, como INSS, IRPF, adiantamentos, etc.

IMPORTANTE:
- Itens como 'Assistencia odonto', 'Assistencia Médica', 'Assistencia odonto', 'Taxa Assistencial', 'desconto adiantamento', 'contribuição previdenciaria', 'central sicredi', devem SEMPRE ser classificados como descontos.

SELEÇÃO DO VALOR QUANDO HÁ VÁRIOS NÚMEROS NA MESMA LINHA
- Cabeçalhos possíveis (podem variar por documento/OCR):
  - **REFERÊNCIAS**: BASE, REF, QTDE, QTD, HORAS, % → **não** é valor pago.
  - **PROVENTOS**: VENCIMENTOS, CRÉDITOS → **valor recebido**.
  - **DESCONTOS**: DEDUÇÕES → **valor descontado**.
- Se o cabeçalho estiver visível, pegue o número da coluna **PROVENTOS** para proventos ou **DESCONTOS** para deduções.

ASSOCIAÇÕES/ÂNCORAS
- "Instituição:" e "CNPJ:" → empregador.
- "Nome:" e "CPF:" → empregado.

QUEBRAS DE PÁGINA
- Continue extraindo após “Página x de y”, assinaturas e carimbos; se um bloco continuar, trate como o mesmo holerite.

EXEMPLOS (apenas para lógica; não copie valores)
{exemplos_holerite}

SAÍDA (JSON ESTRITO)
- Responda **somente** com um objeto JSON válido para o **modelo fornecido** (Paycheck ou PaycheckList).
- Use exatamente os **aliases** (com dois-pontos) mostrados acima.
- Não inclua comentários nem texto fora do JSON.

{{format_instructions}}

🧠 Contexto:
{{context}}
"""

prompt_holerite_padrao ="""Answer the user query Using the following Context: 
        {context}
        .
        {number_of_items}
        Your task is to extract information from the following document and format it as a JSON object.
        {format_instructions}
        """

paychecks_count = """Answer the user query Using the following Context: 
        {context}
        .
        How many paychecks are in the context?
        Respond as "There are n item in the context"
"""
