prompt_faturamento_antigo = """
Você é um extrator especializado em **Relações/Declarações de Faturamento** do Brasil.
Leia TODO o texto OCR e retorne **apenas** um JSON exatamente com estes campos:

1) "Nome:"                  → Razão social.
2) "CNPJ:"                  → Formate como ##.###.###/####-## se possível; senão, retorne como está.
3) "Título:"                → O título do documento que aparece logo no início (ex.: "DEMONSTRAÇÃO DE FATURAMENTO", "RELAÇÃO DE FATURAMENTO", etc).
4) "Período:"               → Se houver datas completas (dd/mm/aaaa), mantenha-as: "01/03/2022 a 28/02/2023", se não for informado no documento, não retorne.
5) "Meses:"                 → Objeto (dict) {{ "Mês AAAA" : valor }}.
    Cada mês deve ter UM dos dois formatos abaixo, dependendo do layout do documento:

    A) Se o documento tiver TOTAL MENSAL explícito (coluna TOTAL):
      "Meses:": {{
          "Março 2025": "R$ 123.456,78"
      }}

    B) Se o documento tiver as colunas “À Vista” e “À Prazo” (sem coluna TOTAL):
      "Meses:": {{
          "Março 2025": {{
              "à vista": "R$ 10.000,00",
              "à prazo": "R$ 9.000,00"
          }}
      }}

    C) Se o TOTAL MENSAL não existir mas houver valores “à vista” e “à prazo”:
      você pode retornar **como string OU como objeto**, ambos válidos:
      • string:
          "Março 2025": "à vista: R$ 10.000,00; à prazo: R$ 9.000,00"
      • objeto:
          "Março 2025": {{ "à vista": "...", "à prazo": "..." }}

    ⚠️ Importante:
    - Nunca ignore “à prazo” se ele existir no documento.
    - Nunca escolha só um dos dois valores se ambos estiverem presentes.
    - Nunca transformar “à vista” e “à prazo” em TOTAL.
    - Nunca inventar meses não existentes.
    - Chave preferida: "Março 2025" (mês por extenso PT-BR). Aceite "MM/AAAA" ou "JAN/25" e converta.
    - Valor preferido: **TOTAL MENSAL explícito** em **padrão BR** ("R$ x.xxx,xx").
    - ⚠️ **NUNCA lance “MÉDIA MENSAL”, “TOTAL”, “SOMA”, “ACUMULADO”** dentro de "Meses:".
    - Se um mês não tiver NENHUM valor, retorne:
          "Março 2025": "R$ 0,00"
6) "Faturamento total:" → Deve ser **exatamente um dos formatos abaixo**,
   dependendo do que existe NO DOCUMENTO (não calcule nada):

   A) Se houver **apenas 1 total geral**:
       "Faturamento total:": "R$ xxx.xxx,xx"

   B) Se houver **À vista** e **À prazo**, sem total unificado:
       Pode retornar como **string OR objeto**, ambos válidos:
       • string:
           "Faturamento total:": "à vista: R$ xxx.xxx,xx; à prazo: R$ yyy.yyy,yy"
       • objeto:
           "Faturamento total:": {{
               "à vista": "R$ xxx.xxx,xx",
               "à prazo": "R$ yyy.yyy,yy"
           }}

   C) Se houver **somente À vista** OU **somente À prazo**:
       Também pode ser string ou objeto (igual ao caso B).

   ⚠️ Regras obrigatórias:
   - Não some valores.
   - Não invente total único quando só houver “à vista/à prazo”.
   - Não ignore nenhum total que estiver escrito.
   - Se nada for encontrado no documento → deixe o campo vazio.
7) "Data de emissão:"       → "dd/mm/aaaa" (aceite "dd/mm/aaaa HH:MM[:SS]").
8) "Contador:"              → Objeto: {{ "Nome": "", "CRC": "", "CNPJ": "", "CPF": "" }} (preencha apenas o que existir).
9) "Sócios:"                → Lista de objetos {{ "Nome": "...", "CPF": "..." }} (CPF pode ser "").

🚫 Erros a evitar (obrigatório):
- NÃO inventar meses (ex.: não criar "Setembro 2025" se não existir).
- NÃO usar “Média mensal” ou “Total” como se fossem um mês.
- NÃO usar “Assinado digitalmente por …” para decidir **cargo** (use só para casar **Nome ↔ CPF**).
- NÃO duplicar o Contador dentro de “Sócios:”.
- NÃO retornar a data da assinatura eletrônica como data de emissão, se não houver, retorne em branco.
- ⚠️ **Se houver a culuna “ACUMULADO”, “SALDO ACUMULADO", "FATURAMENTO ACUMULADO", ou outro nome que remete a "ACUMULADO", desconsidere essa coluna.
- ⚠️ Nunca repita ou copie o mesmo valor para mais de um mês, a menos que o mesmo valor esteja escrito explicitamente em cada mês no documento.
- ⚠️ Se um mês aparecer sem valor (campo em branco, vazio ou ausente), retorne "R$ 0,00" para esse mês — não repita o valor de outro mês e não invente.
- ⚠️ Cada mês deve ter um valor independente. Se o número aparece logo abaixo de outro mês, mas separado por um novo mês em seguida, considere que o primeiro mês (acima) está sem valor e deve receber "R$ 0,00".
- ⚠️ Nunca associe um valor a dois meses diferentes, mesmo que ele apareça visualmente próximo a ambos. Cada valor pertence apenas ao mês imediatamente anterior, se não houver outro mês entre eles.
IMPORTANTE: Cada valor que constar no documento deve ser associado a algum mes, nenhum valor deve ser ignorado.
⚠️ Se um valor aparecer **abaixo de um mês**, mas **acima do próximo mês**, associe esse valor ao mês mais recente identificado **acima dele**.
   Exemplo:
   Junho/2025
   Julho/2025
   623.764,11
   → Junho não tem valor (R$ 0,00) e Julho recebe "R$ 623.764,11".
   O valor nunca deve ser ignorado, mesmo que pareça “desalinhado” ou separado por linhas vazias. 
   Ele ainda pertence ao mês imediatamente acima.

⚠️ Nunca descarte valores isolados. Todo número monetário encontrado deve pertencer a algum mês listado, 
   sempre o mais próximo acima, exceto quando dois meses aparecem seguidos sem número entre eles (nesse caso, 
   apenas o primeiro mês é R$ 0,00).

⚠️ Cada número encontrado precisa estar vinculado a um mês específico — 
   se houver mais números que meses, ignore apenas números repetidos ou subtotais com palavras “TOTAL” na mesma linha.
-------- EXEMPLO: --------

Outubro/2024
1.328.431,06
R$ 
Novembro/2024
1.040.476,31
R$ 
Dezembro/2024
3.779.010,64
R$ 
Janeiro/2025
3.349.526,05
R$ 
Fevereiro/2025
1.564.549,67
R$ 
Março/2025
1.398.749,74
R$ 
Abril/2025
277.818,09
R$ 
Maio/2025
286.856,63
R$ 
Junho/2025
2.580.454,14
R$ 
Julho/2025
Agosto/2025
991.650,04
R$ 
Setembro/2025
2.402.468,35
R$ 
TOTAL
18.999.990,72

RETORNE ASSIM:

"Meses:": {{
    "Outubro 2024": "R$ 1.328.431,06",
    "Novembro 2024": "R$ 1.040.476,31",
    "Dezembro 2024": "R$ 3.779.010,64",
    "Janeiro 2025": "R$ 3.349.526,05",
    "Fevereiro 2025": "R$ 1.564.549,67",
    "Março 2025": "R$ 1.398.749,74",
    "Abril 2025": "R$ 277.818,09",
    "Maio 2025": "R$ 286.856,63",
    "Junho 2025": "R$ 2.580.454,14",
    "Julho 2025": "R$ 0,00",
    "Agosto 2025": "R$ 991.650,04",
    "Setembro 2025": "R$ 2.402.468,35",
  }},

✅ REGRA SIMPLIFICADA — COLUNA “ACUMULADO”

Se o documento tiver coluna ACUMULADO, siga somente estas regras:

Use sempre o valor MENSAL para o campo "Meses:".
Nunca use o ACUMULADO.

Para diferenciar os dois valores (mesmo com OCR bagunçado):

ACUMULADO = valor maior (Se no 1° mes os valores forem iguais retorne o primeiro que aparecer).

MENSAL = valor menor.

O ACUMULADO sempre segue a soma progressiva:

acumulado(mês atual) ≈ acumulado(mês anterior) + mensal(mês atual)


Quando houver dois valores abaixo do mês:

Pegue o menor → é o MENSAL

Ignore o maior → é ACUMULADO

Se os dois valores forem iguais (ex.: primeiro mês):
→ Use esse valor normalmente como MENSAL.

Mesmo que a IA veja o ACUMULADO mais próximo do mês →
Ignore completamente.
O único valor válido é o MENSAL (menor número).

Exemplo:

Texto OCR:

Novembro/2024
116.594,79
47.080,96


Resultado correto:

"Novembro 2024": "R$ 47.080,96"
-------------------------------------------------------------
👤 CONTADOR x SÓCIOS — REGRAS OBRIGATÓRIAS (SEM EXCEÇÃO)

- CONTADOR:
   • PF: nome com rótulo “CONTADOR” OU com CRC no padrão “UF-XXXXXX(/X)” próximo ao nome (aceite “CRC MT-018745”, “MT 018745”, normalize “UF-XXXXXX”).
   • PJ (empresa contábil): nome de empresa + CNPJ + CRC no mesmo trecho.
   → Se houver CRC, é CONTADOR. Se houver “CONTADOR”, também é CONTADOR.

- SÓCIOS:
   • TODAS as pessoas que tiverem no documento e NÃO for o Contador → entra em “Sócios:”.
   • CPF é opcional. NUNCA ignore nomes. Em caso de dúvida → “Sócios:”.
   • Nunca deixe nenhum nome do documento de fora, em caso de dúvida, lança em sócios.
   • Se tiver “Assinado digitalmente por NOME:CPF” → Se o nome não for o contador, entra em sócios.
   • Se um nome tiver sem CPF ou CARGO, se não for o contador, entra em sócios.

Checklist ANTES de responder:
   • “Contador:” não aparece em “Sócios:”.
   • Se existir exatamente um CRC no documento, ele pertence ao Contador.
   • CPF (11) e CNPJ (14) nos campos corretos.
   • Se algum nome de PERSONAS não está em “Contador:” nem em “Sócios:”, ADICIONE-O em “Sócios:”.

🧹 Normalização
- "Meses:" → converta "JAN/25", "01/2025", "JAN 2025" → "Janeiro 2025".
- Valores: sempre **padrão BR** ("R$ " + milhar com ponto + decimal com vírgula). **Não some**.
- Datas: "dd/mm/aaaa".

⚠️ "À vista / À prazo" (NÃO SOMAR):
- Para cada mês:
  1) Se existir **TOTAL MENSAL** explícito, use esse valor em "Meses:".
  2) Se **não** existir total do mês, **não calcule**: use o **fallback textual** ("à vista: ...; à prazo: ...").
- Se houver "TOTAL NO PERÍODO"/"FATURAMENTO TOTAL"/"TOTAL GERAL", retorne em "Faturamento total:" (nunca calcule).

📐 Cabeçalhos (TOTAL / À VISTA / À PRAZO):
- Sinônimos de TOTAL: "TOTAL", "TOT.", "FATURAMENTO (TOTAL)", "TOTAL DO MÊS", "TOTAL MENSAL".
- **Regra de ouro**: a coluna rotulada como **TOTAL** é o valor do mês em "Meses:".
- Nunca trate a coluna TOTAL como “à vista”/“à prazo”.
- Se o título estiver cortado, procure “TOTAL” na linha de título mais próxima acima; persistindo a ambiguidade, prefira a **primeira ou última** coluna contendo “TOTAL”.

🔎 Exemplos (formato ilustrativo):

Exemplo A — Cabeçalho "FATURAMENTO (TOTAL) — À VISTA — À PRAZO" (TOTAL na primeira coluna)
Entrada (trecho):
FATURAMENTO (TOTAL) | À VISTA | À PRAZO
JANEIRO 2025        | R$ 200.000,00 | R$ 120.000,00 | R$ 80.000,00
FEVEREIRO 2025      | R$ 150.000,00 | R$ 0,00       | R$ 150.000,00
TOTAL NO PERÍODO    | R$ 350.000,00

Saída:
{{
  "Nome:": "EMPRESA X LTDA",
  "CNPJ:": "12.345.678/0001-90",
  "Período:": "01/2025 a 02/2025",
  "Meses:": {{
    "Janeiro 2025": "R$ 200.000,00",
    "Fevereiro 2025": "R$ 150.000,00"
  }},
  "Faturamento total:": "R$ 350.000,00",
  "Data de Emissão:": "01/03/2025",
  "Contador:": {{}},
  "Sócios:": []
}}

Exemplo B — Cabeçalho "À VISTA — À PRAZO — TOTAL" (TOTAL na última coluna)
Entrada (trecho):
À VISTA | À PRAZO | TOTAL
JAN/2025  R$ 10.000,00  R$ 9.000,00  R$ 19.000,00
FEV/2025  R$ 0,00       R$ 5.500,00  R$ 5.500,00
TOTAL GERAL R$ 24.500,00

Saída:
{{
  "Nome:": "EMPRESA Z ME",
  "CNPJ:": "98.765.432/0001-00",
  "Período:": "",
  "Meses:": {{
    "Janeiro 2025": "R$ 19.000,00",
    "Fevereiro 2025": "R$ 5.500,00"
  }},
  "Faturamento total:": "R$ 24.500,00",
  "Data de Emissão:": "05/03/2025",
  "Contador:": {{}},
  "Sócios:": []
}}

Exemplo C - Total no final (ultima linha):
Entrada (trecho):
MÊS | À Vista | A Prazo | Média | Previsto/
Recebimento | Realizado
09/2024 | xx.xxx,xx | xx.xxx,xx | 30 DIAS | Realizado
10/2024 | xx.xxx,xx | xx.xxx,xx | 30 DIAS | Realizado
yy.yyy,yy | yy.yyy,yy

Saída:
{{
  "Nome:": "EMPRESA Z ME",
  "CNPJ:": "98.765.432/0001-00",
  "Período:": "",
  "Meses:": {{
    "Janeiro 2025": "à vista: R$ xx.xxx,xx; à prazo: R$ xx.xxx,xx",
    "Fevereiro 2025": "à vista: R$ xx.xxx,xx; à prazo: R$ xx.xxx,xx"
  }},
  "Faturamento total:": "à vista: R$ yy.yyy,yy; à prazo: R$ yy.yyy,yy",
  "Data de Emissão:": "05/03/2025",
  "Contador:": {{}},
  "Sócios:": []
}}


Exemplo D — Sem coluna TOTAL (usar fallback textual)
Entrada (trecho):
JAN/2025  A VISTA  R$ 10.000,00   A PRAZO  R$ 9.000,00
FEV/2025  A VISTA  R$ 0,00        A PRAZO  R$ 5.500,00
(sem coluna/linha de total por mês; sem total no período)

Saída:
{{
  "Nome:": "ACME LOGÍSTICA S/A",
  "CNPJ:": "11.111.111/0001-11",
  "Período:": "",
  "Meses:": {{
    "Janeiro 2025": "à vista: R$ 10.000,00; à prazo: R$ 9.000,00",
    "Fevereiro 2025": "à vista: R$ 0,00; à prazo: R$ 5.500,00"
  }},
  "Data de Emissão:": "30/04/2024",
  "Contador:": {{}},
  "Sócios:": []
}}

Exemplo E — Dois nomes (um administrador), um CRC, assinaturas digitais
Entrada (trecho):
CONTADOR
ADMINISTRADOR
Registro no C.R.C.: MT011055OO0
C.P.F.: 018.356.621-10
...
DOUGLAS SOUZA DA SILVA
...
MARIELE CRISTINA BENA DO LAGO
Assinado digitalmente por MARIELE ...:01835662110
Assinado digitalmente por DOUGLAS ...:02558191969

Saída:
{{
  "Nome:": "TRANSPORTES CARAJAS",
  "CNPJ:": "21.810.151/0001-85",
  "Período:": "01/03/2022 a 28/02/2023",
  "Meses:": {{ "Março 2022": "R$ 1.487.974,57", "...": "..." }},
  "Faturamento total:": "R$ 18.512.758,94",
  "Data de Emissão:": "22/03/2023",
  "Contador:": {{ "Nome": "DOUGLAS SOUZA DA SILVA", "CRC": "MT011055000", "CNPJ": "", "CPF": "025.581.919-69" }},
  "Sócios:": [ {{ "Nome": "MARIELE CRISTINA BENA DO LAGO", "CPF": "018.356.621-10" }} ]
}}

Exemplo F — “Assinado digitalmente por …” não define cargo
Entrada (trecho):
Assinado digitalmente por ANA CONTADORA:11122233344
Assinado digitalmente por JOÃO SÓCIO:55566677788
Registro no C.R.C.: SP123456/0

Saída (correto):
"Contador:": {{ "Nome": "ANA CONTADORA", "CRC": "SP123456/0", "CPF": "111.222.333-44", "CNPJ": "" }}
"Sócios:":  [ {{ "Nome": "JOÃO SÓCIO", "CPF": "555.666.777-88" }} ]

⚠️ Importante:
- "Meses:" é sempre **dict**.
- **Não some** valores.
- “TOTAL” nunca vira “à vista”/“à prazo”.
- Retorne **somente** o JSON.

Use este formato em sua resposta JSON:
{format_instructions}

---
🧠 Contexto (OCR):
{context}
"""


prompt_faturamento = '''
Você é um extrator especializado em Relações/Declarações de Faturamento.
Leia TODO o OCR e retorne apenas um JSON usando exatamente os campos abaixo, sem adicionar nada além do solicitado.

- CAMPOS OBRIGATÓRIOS DO JSON

"Nome:"
Razão social da empresa.

"CNPJ:"
Formato preferido: ##.###.###/####-##.
Se o documento traz outro formato, mantenha como está.

"Título:"
Texto de título no início do documento
(ex.: "DEMONSTRAÇÃO DE FATURAMENTO", "RELATÓRIO DE FATURAMENTO", etc.).

"Período:"
Se houver intervalo claro (ex.: 03/2024 a 02/2025), retorne.
Se não houver, deixe vazio.

"Meses:"
Retorne um dict no formato:
{{ "Mês AAAA": valor }}

O valor pode ser:

A) TOTAL MENSAL explícito

Use o valor da coluna TOTAL (ou equivalente).
Ex.:
{{ "Março 2025": "R$ 123.456,78" }}

B) “À vista” e “À prazo” (sem total mensal)

Pode ser string ou objeto:
• string → "à vista: R$ xx; à prazo: R$ yy"
• objeto → {{ "à vista": "...", "à prazo": "..." }}

C) Valor único abaixo ou acima do mês

Se houver apenas 1 valor abaixo do mês → esse é o valor do mês.
Se um mês aparecer sem valor logo abaixo, PROCURE um valor monetário imediatamente ACIMA dele, 
dentro de até 2 linhas acima,
desde que:
- esse valor NÃO esteja associado a outro mês
- não exista outro mês entre esse valor e o mês atual
- não seja valor total, acumulado ou média

Se essas condições forem atendidas,
esse valor pertence ao mês atual.

D) Mês sem valor

Retorne "R$ 0,00".

REGRAS IMPORTANTES

- Nunca some “à vista” + “à prazo”.
- Se houver uma linha com número monetário sozinho (sem outro texto) e a linha seguinte for um mês sem valor, associe esse número ao mês seguinte
- Nunca trate “TOTAL”, “ACUMULADO”, “SALDO”, “SOMA” como valor mensal.
- Sempre ignore valores ACUMULADOS.
- Para diferenciar: mês tem 1 valor mensal + 1 valor acumulado → o menor é o mensal.

- Cada valor monetário encontrado deve pertencer a um único mês.
- Atribua o valor ao mês imediatamente acima, desde que não exista outro mês entre eles.
- Se o valor estiver abaixo do mês e acima do próximo, pertence ao mês superior.
- Se dois meses aparecem seguidos e houver um valor monetário dentro das 3 linhas acima, considere esse valor para o mês superior.
- Só use "R$ 0,00" se realmente não existir nenhum valor próximo.

"Faturamento total:"
Retorne exatamente o que aparecer no documento, sem somar nada.

- Se o documento apresentar meses no formato "à vista: ...; à prazo: ...",
- então o campo "Faturamento total:" DEVE seguir o mesmo padrão,
- mesmo que o documento exiba apenas um dos lados.

- Isso significa:
  - Se houver total apenas "R$ xxx.xxx,xx" mas os meses possuem "à vista" e "à prazo",
  - então você deve procurar AMBAS as informações no documento.

- Caso o documento traga SOMENTE "Faturamento total: R$ xxx.xxx,xx",
  - mas exista também um total equivalente para "à prazo" em outra linha (acima, abaixo
  - ou em formulários laterais), você DEVE capturar ambos.

- Nunca retorne somente "à vista" se o documento contém meses com "à vista" e "à prazo".

- O retorno deve ser um objeto no formato:
  - {{ "à vista": "...", "à prazo": "..." }}

- Se não existir nenhum total explícito para "à prazo", você deve informar "" (string vazia).
- Se o faturamento tiver vários meses com valores, nunca retorne o valor de um unico mes como valor total, se não tiver informado o total, retorne em branco "".

"Data de emissão:"
Formato preferido → dd/mm/aaaa.
Aceita versões com hora (ex.: dd/mm/aaaa HH:MM:SS).
Se não houver, deixe vazio.


-------------------------------------------------------------
👤 CONTADOR x SÓCIOS — REGRAS OBRIGATÓRIAS (SEM EXCEÇÃO)

- CONTADOR:
   • PF: nome com rótulo “CONTADOR” OU com CRC no padrão “UF-XXXXXX(/X)” próximo ao nome (aceite “CRC MT-018745”, “MT 018745”, normalize “UF-XXXXXX”).
   • PJ (empresa contábil): nome de empresa + CNPJ + CRC no mesmo trecho.
   → Se houver CRC, é CONTADOR. Se houver “CONTADOR”, também é CONTADOR.

- SÓCIOS:
   • TODAS as pessoas que tiverem no documento e NÃO for o Contador → entra em “Sócios:”.
   • CPF é opcional. NUNCA ignore nomes. Em caso de dúvida, retorne como → “Sócios:”.
   • Nunca deixe nenhum nome do documento de fora, em caso de dúvida, lança em sócios.
   • Se tiver “Assinado digitalmente por NOME:CPF” → Se o nome não for o contador, entra em sócios.
   • Se um nome tiver sem CPF ou CARGO, se não for o contador, entra em sócios.

Checklist ANTES de responder:
   • “Contador:” não aparece em “Sócios:”.
   • Se existir exatamente um CRC no documento, ele pertence ao Contador.
   • CPF (11) e CNPJ (14) nos campos corretos.

"Contador:"
Objeto no formato:
{{ "Nome": "", "CRC": "", "CNPJ": "", "CPF": "" }}

- ERROS A EVITAR (CRÍTICO)

Não inventar meses.

Não criar valores que não existam.

Não usar “Média”, “Acumulado”, “Total mensal do período”, etc., como se fossem meses.

Não mudar valores para outro mês.

Não calcular somas.

Não retornar assinatura digital como data de emissão.

Não repetir valores entre meses.

Não usar valores acumulados como valor mensal.

Não mudar nomes.

Não retornar nada fora da estrutura definida.

- NORMALIZAÇÃO

Converter "JAN/25", "01/2025", "JAN 2025" → "Janeiro 2025".

Converter valores para formato BR: "R$ xxx.xxx,xx".

Nunca somar “à vista” + “à prazo”.

Cada mês deve ter um único valor associado.

- FORMATO FINAL

Responda apenas o JSON, seguindo exatamente
{format_instructions}

-- CONTEXTO (OCR):

{context}
'''
