extractor="""Answer the user query Using the following Context: 
        {context}
        .
        {number_of_items}
        Your task is to extract information from the following document and format it as a JSON object.
        {format_instructions}
        """
    