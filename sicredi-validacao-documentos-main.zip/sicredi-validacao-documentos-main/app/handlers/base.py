# app/handlers/base.py
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import TypedDict, Dict, Any, Optional, List
from importlib import import_module
import re
import json
from app.modules.document_processor import DocumentsProcessor
from app.utils.helpers import normalize
from app.utils.logger import LoggerManager

# -------------------------
# Utilidades locais
# -------------------------
from importlib import import_module
from app.utils.helpers import normalize


# -------------------------
# Tipagem padronizada
# -------------------------

class ResultadoHandler(TypedDict, total=False):
    """
    Estrutura padronizada que cada Handler devolve ao orquestrador.
    """
    modelo_extracao: Optional[str]
    sheet_ok: bool
    documentos: list = []

# -------------------------
# Base abstrata para Handlers
# -------------------------

class BaseHandlerABC(ABC):
    """
    Base abstrata para todos os handlers.
    - Define `self.resultado` com a estrutura padrão.
    - Oferece utilitários comuns: `_extrair` e `_add_saida_por_pessoa`.
    - NÃO cria validadores (cada handler decide como/onde chamar `criar_validador`).
    """

    def __init__(
        self,
        caminho_arquivo: str,
        *,
        texto_paginas: list | None = None,
        tipo_documento_pre: str | None = None,
    ) -> None:
        # Estado de saída compartilhado por todos os handlers
        self.resultado: ResultadoHandler = {
            "documentos": [],  # 🔹 lista padronizada para saída única
            "sheet_ok": False,
        }
        self.log = LoggerManager(__name__)
        self.documents_processor = DocumentsProcessor()
        self.caminho_arquivo = caminho_arquivo

        self.texto_paginas = texto_paginas 
        self.texto_preprocessado = " ".join(texto_paginas) if isinstance(texto_paginas,list) else texto_paginas

        self.tipo_documento_pre =  tipo_documento_pre

    @abstractmethod
    def processar(self) -> ResultadoHandler:
        """
        Contrato que todos os handlers devem implementar.
        """

    # ---------- utilitários comuns ----------

    def _extrair(self, texto: str, classe_modelo: type) -> dict:
        """
        Envia o texto para a IA, limpa e retorna o JSON de dados extraídos.
        """
        resp = self.documents_processor.extract_data(texto, classe_modelo)
        self.log.debug(f"Resposta bruta da IA: {resp}")
        return json.loads(self.documents_processor.extractor.clean_json(resp)) or {}
    
    def split_sections(self, context:str, start_text: str, end_text: str) -> str:
        start = context.find(start_text)
        end = context.find(end_text, start)
        return context[start:end].strip()