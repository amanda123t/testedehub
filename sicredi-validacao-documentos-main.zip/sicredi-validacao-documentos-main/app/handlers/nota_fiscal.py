from __future__ import annotations
from typing import Dict, Any, List, Tuple
import os, json
from concurrent.futures import ThreadPoolExecutor, as_completed

from app.handlers.base import ResultadoHandler, BaseHandlerABC
from app.modules.pipeline.model_mapping import obter_modelo_por_tipo

MAX_WORKERS_PAGINA_NF = int(os.getenv("MAX_WORKERS_PAGINA_NF", "6"))

class HandlerNotaFiscal(BaseHandlerABC):
    """
    NF:
      - Usa texto por página (preferencialmente vindo do by_process; se for amostra, re-extrai tudo).
      - Envia cada página ao LLM em paralelo.
      - Junta TODAS as notas em resultado["Documentos"] (sem agrupar por pessoa).
      - NÃO valida neste handler; validação ocorre depois (by_process).
    """

    def processar(self) -> ResultadoHandler:

        nome_arquivo = os.path.basename(self.caminho_arquivo)
        self.log.info(f"Iniciando Handler de Nota Fiscal para o arquivo: {nome_arquivo}")

        # 1) Modelo da NF
        try:
            classe_nf = obter_modelo_por_tipo("nota_fiscal")
        except Exception as e:
            self.log.error(f"Modelo de Nota Fiscal não encontrado: {e}")
            return self.resultado
        
        # 2) Fonte do texto por página
        pages_text: List[str] = []

        self.log.debug("NF: reutilizando texto por página do by_process.")
        pages_text = self.texto_paginas


        num_pages = len(pages_text)
        self.log.info(f"NF: páginas detectadas = {num_pages}")
        if num_pages == 0:
            return self.resultado

        # 3) LLM por página (paralelo)
        resultados_por_idx: dict[int, List[Dict[str, Any]]] = {}
        coletadas = 0

        def _llm_por_pagina(idx: int, texto: str) -> Tuple[int, List[Dict[str, Any]]]:
            if not (texto or "").strip():
                return idx, []
            try:
                resp = self.documents_processor.extract_data(texto, classe_nf)
                payload = json.loads(self.documents_processor.extractor.clean_json(resp))

                if isinstance(payload, dict):
                    notas = [payload]
                elif isinstance(payload, list):
                    notas = [d for d in payload if isinstance(d, dict)]
                else:
                    notas = []

                return idx, notas
            except Exception as e:
                self.log.error(f"⚠ LLM falhou na página {idx}: {e}")
                return idx, []

        indices_validos = [i for i, t in enumerate(pages_text) if (t or "").strip()]
        with ThreadPoolExecutor(max_workers=MAX_WORKERS_PAGINA_NF) as ex:
            futs = {ex.submit(_llm_por_pagina, i, pages_text[i]): i for i in indices_validos}
            for fut in as_completed(futs):
                idx = futs[fut]
                try:
                    i, notas = fut.result()
                except Exception:
                    i, notas = idx, []
                resultados_por_idx[i] = notas
                coletadas += len(notas)
        # 4) Agrega todas as notas
        contador = 1
        for i in sorted(resultados_por_idx):
            page_text = pages_text[i]
            page_num = i + 1
            for nota in resultados_por_idx[i]:
                self.resultado["documentos"].append({
                    "dados": nota,
                    "context": [page_text],
                    "pagina": page_num,
                    "nome_pessoa": "Notas fiscais",
                    "identificador": f"NOTA{contador}"
                })
                contador += 1

        self.log.info(f"NF: notas coletadas = {coletadas}")
        if coletadas:
            self.resultado["sheet_ok"] = True

        return self.resultado
