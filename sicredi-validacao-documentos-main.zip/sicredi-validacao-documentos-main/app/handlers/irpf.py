from __future__ import annotations
from typing import Dict, Any
import os
import atexit
from concurrent.futures import ThreadPoolExecutor, as_completed
from app.handlers.base import ResultadoHandler, BaseHandlerABC
from app.utils.helpers import normalize
from importlib import import_module

# Paralelismo
MAX_IR_POR_DOC = int(os.getenv("MAX_IR_POR_DOC", "10"))
POOL_DOCUMENTOS = ThreadPoolExecutor(max_workers=MAX_IR_POR_DOC)
atexit.register(lambda: POOL_DOCUMENTOS.shutdown(wait=False))

def import_class(doc_type: str, class_name: str) -> object:
    try:
        doc_type_lower = doc_type.lower()
        module_path = f'app.models.{doc_type_lower}.{doc_type_lower}_model'
        module = import_module(module_path)
        return getattr(module, class_name)
    except ModuleNotFoundError:
        module_path = f'app.models.irpf.irpf_model.{doc_type_lower}'
        module = import_module(module_path)
        return getattr(module, class_name)
    except AttributeError as e:
        raise ValueError(f"Class {class_name} not found in module {module_path}") 

class HandlerIRPFUnified(BaseHandlerABC):
    """
    Handler unificado para IRPF (Declaração OU Recibo).

    - Decide o subtipo pelo 'tipo_documento_pre' (irpf | ir_receipt).
    - Extrai os dados com o processor correspondente (IRPF / IRPFReceipt).
    - NÃO valida aqui. Apenas agrega em resultado["documentos"]
      no formato: { "<nome>": { "irpf": [ {...} ], "recibo": [ {...} ] } }.

    Observações:
    - Salvamos também 'context' e 'arquivo' em cada item do grupo, pois o by_process
      fará a validação posterior e precisa do texto bruto e do nome de arquivo.
    """

    def processar(self) -> ResultadoHandler:
        self.log.info("Iniciando handler do IRPF (unificado)...")
        # Obtém o nome bonito (type_name) do mapa_modelos

        # Garante que o grupo exista
        if not self.texto_preprocessado:
            return self.resultado
        tipo = (self.tipo_documento_pre or "").lower()
        dados: Dict[str, Any] = {}

        try:

            if "irpf" in tipo:
                self.log.debug("[IRPF] Extraindo dados com o tipo DECLARAÇÃO")
                dados = self.process_ir() or {}

            else:
                self.log.info(f"[IRPF] Tipo '{tipo}' não suportado por este handler.")
                return self.resultado

        except Exception as e:
            self.log.error(f"[IRPF] Falha no processor ({tipo}): {e}")
            return self.resultado

        if not dados:
            return self.resultado

        self.log.info(f"[IRPF] Dados extraídos da IA: {dados}")

        # 2️⃣ Nome da pessoa
        nome_pessoa = normalize(
            dados.get("Nome:") or dados.get("Nome") or dados.get("Nome do declarante") or "DESCONHECIDO"
        )

        item = {
            "dados": dados,
            "context": self.texto_paginas,
            "nome_pessoa": nome_pessoa,
            "identificador": f"{self.tipo_documento_pre.upper()}1"
        }
        # agrupa diretamente no nome da pessoa
        self.resultado["documentos"].append(item)

        # 5️⃣ Mantém metadados padronizados
        self.resultado["sheet_ok"] = True

        self.log.info("Finalizando handler do IRPF (unificado).")
        return self.resultado

    def get_sessions_ir(self):
        return [
            ("IMPOSTO SOBRE A RENDA", "DEPENDENTES", "taxpayer_informations"),
            (
                "RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA JURÍDICA PELO TITULAR",
                "TOTAL",
                "earnings",
            ),
            (
                "RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA FÍSICA E DO EXTERIOR PELO TITULAR",
                "RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA FÍSICA E DO EXTERIOR PELOS DEPENDENTES",
                "individual_foreign_earnings",
            ),
            (
                "RENDIMENTOS ISENTOS E NÃO TRIBUTÁVEIS",
                "RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA / DEFINITIVA",
                "non_taxable_income",
            ),
            (
                "RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA / DEFINITIVA",
                "RENDIMENTOS TRIBUTÁVEIS RECEBIDOS DE PESSOA JURÍDICA PELO TITULAR",
                "taxable_income",
            ),
            (
                "DECLARAÇÃO DE BENS E DIREITOS",
                "DÍVIDAS E ÔNUS REAIS",
                "goods",
            ),
            (
                "DEMONSTRATIVO DE ATIVIDADE RURAL - BRASIL",
                "DEMONSTRATIVO DE ATIVIDADE RURAL - EXTERIOR",
                "agricultural_income",
            ),
            (
                "RESUMO",
                "financeiras",
                "others",
            ),

        ]
    
    def model_mapping_ir(self, model):
        irpf_class = {
            "earnings": ("earnings", "Earnings"),
            "individual_foreign_earnings": (
                "individual_foreign_earnings",
                "IndividualForeignEarnings",
            ),
            "non_taxable_income": ("non_taxable_income", "NonTaxableIncome"),
            "taxable_income": ("taxable_income", "TaxableIncome"),
            "others": ("others", "IRPFOthers"),
            "agricultural_income": ("agricultural_income", "IRPFAgricultural"),
            "taxpayer_informations": ("taxpayer_informations", "IRPF"),
            "goods": ("goods", "IRPFBem"), 
        }
        return irpf_class[model]
    
    def process_ir(self):
        data = {}
        futures = []

        for session in self.get_sessions_ir():
            content = self.split_sections(self.texto_preprocessado, session[0], session[1])
            self.log.debug(f"Session do IR: {session} \n texto enviado: {content}")
            if content and len(content) > 300 or (
                str(session[0]).upper() in ["RENDIMENTOS SUJEITOS À TRIBUTAÇÃO EXCLUSIVA / DEFINITIVA", "RENDIMENTOS ISENTOS E NÃO TRIBUTÁVEIS"]
                and len(content) > 100
            ):
                model = self.model_mapping_ir(session[2])
                class_object = import_class(model[0], model[1])

                # Cria uma função interna que executa a extração dessa sessão
                def run_extract(session=session, content=content, class_object=class_object):
                    try:
                        try:
                            dados_extraidos = self._extrair(content, class_object)
                        except Exception as e:
                            self.log.error(f"[HandlerIRPF] Falha na extração: {e}")
                            dados_extraidos = {}

                        return dados_extraidos
                    except Exception as e:
                        self.log.error(f"❌ Erro ao processar sessão {session}: {e}")
                        return {}

                # Submete para execução paralela
                futures.append(POOL_DOCUMENTOS.submit(run_extract))

        # Aguarda as threads terminarem e junta tudo
        for future in as_completed(futures):
            try:
                result = future.result()
                if result:
                    data.update(result)
            except Exception as e:
                self.log.error(f"Erro ao coletar resultado do IRPF: {e}")

        return data
