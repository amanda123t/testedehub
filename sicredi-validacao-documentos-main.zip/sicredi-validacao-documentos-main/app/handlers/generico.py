# app/handlers/base.py
from __future__ import annotations
from typing import TypedDict, Dict, Any, Optional, List
import os
import re
from app.utils.helpers import normalize, normalize_no_space
from app.handlers.base import ResultadoHandler, BaseHandlerABC
from app.modules.pipeline.model_mapping import obter_modelo_por_tipo
from app.utils.APIs.api_certidoes import consultar_funarpen
from pathlib import Path

def recortar_context(context: str, tipo: str):
        original = context or ""
        if not original.strip():
            return original, False

        # Palavras-chave (dentro da função, para não poluir módulo)
        palavras_dre = [
            "DEMONSTRAÇÃO DO RESULTADO DO EXERCÍCIO","DEMONSTRACAO DO RESULTADO DO EXERCICIO",
            "DEMONSTRAÇÃO DE RESULTADOS","DEMONSTRACAO DE RESULTADOS",
            "DEMONSTRATIVO DE RESULTADOS","DEMONSTRATIVO DO RESULTADO",
            "RENDA OPERACIONAL BRUTA","RECEITA OPERACIONAL BRUTA","RECEITA BRUTA",
            "LUCRO LÍQUIDO DO EXERCÍCIO","LUCRO LIQUIDO DO EXERCICIO"
        ]
        palavras_balanco = [
            "BALANÇO PATRIMONIAL","BALANCO PATRIMONIAL","BALANÇO","BALANCO",
            "ATIVO CIRCULANTE","ATIVO NÃO CIRCULANTE","ATIVO NAO CIRCULANTE",
            "PASSIVO CIRCULANTE","PASSIVO NÃO CIRCULANTE","PASSIVO NAO CIRCULANTE",
            "PATRIMÔNIO LÍQUIDO","PATRIMONIO LIQUIDO","PATRIMÔNIO","PATRIMONIO"
        ]

        def tem_cabecalho(txt: str) -> bool:
            # aceita Empresa:, CNPJ, C.N.P.J, NIRE com ou sem dois pontos
            return bool(re.search(r"(EMPRESA\s*:|C\.?N\.?P\.?J\s*:?|NIRE\s*:?)", txt, flags=re.IGNORECASE))

        t = (tipo or "").lower()
        up = original.upper()

        try:
            # ============================================================
            # 1) COM \f: recorte por página (mais assertivo quando disponível)
            # ============================================================
            if "\f" in original:
                paginas_up = original.upper().split("\f")
                paginas    = original.split("\f")

                def encontra_pagina(palavras):
                    for i, pag in enumerate(paginas_up):
                        for p in palavras:
                            if re.search(rf"\b{re.escape(p)}\b", pag, flags=re.IGNORECASE):
                                return i
                    return -1

                if "balance" in t:
                    pag_dre = encontra_pagina(palavras_dre)
                    if pag_dre == -1:
                        return original, False
                    recorte = "\f".join(paginas[:pag_dre])
                    if tem_cabecalho(recorte):
                        return recorte, True
                    return original, False

                if "dre" in t:
                    pag_dre = encontra_pagina(palavras_dre)
                    if pag_dre == -1:
                        return original, False
                    pag_bal = encontra_pagina(palavras_balanco)
                    fim = pag_bal if (pag_bal != -1 and pag_bal > pag_dre) else len(paginas)
                    recorte = "\f".join(paginas[pag_dre:fim])
                    if tem_cabecalho(recorte):
                        return recorte, True
                    return original, False

                return original, False

            # ============================================================
            # 2) SEM \f: recorte por posição global + reforço de cabeçalho
            # ============================================================
            patt_dre = re.compile("|".join(rf"\b{re.escape(p)}\b" for p in palavras_dre), re.IGNORECASE)
            patt_bal = re.compile("|".join(rf"\b{re.escape(p)}\b" for p in palavras_balanco), re.IGNORECASE)

            m_dre = patt_dre.search(up)
            m_bal = patt_bal.search(up)

            if "balance" in t:
                if m_dre:
                    ini, fim = 0, m_dre.start()
                else:
                    ini, fim = 0, len(original)

            elif "dre" in t:
                if not m_dre:
                    return original, False
                ini = m_dre.start()
                fim = m_bal.start() if (m_bal and m_bal.start() > ini) else len(original)

            else:
                return original, False

            recorte = original[ini:fim]

            # Cabeçalho presente? ok
            if tem_cabecalho(recorte):
                return recorte, True

            # Cabeçalho ausente: procurar CNPJ antes do ponto de corte e puxar 5 linhas acima
            patt_cnpj = re.compile(r"C\.?N\.?P\.?J", re.IGNORECASE)
            ultimo = None
            for m in patt_cnpj.finditer(original, 0, max(0, ini)):
                ultimo = m

            if ultimo:
                pos = ultimo.start()
                # sobe 5 quebras de linha
                linhas = 0
                new_start = 0
                for i in range(pos - 1, -1, -1):
                    if original[i] == "\n":
                        linhas += 1
                        if linhas >= 5:
                            new_start = i + 1
                            break
                recorte2 = original[new_start:fim]
                if tem_cabecalho(recorte2):
                    return recorte2, True

            # Se nada deu certo, devolve o original
            return original, False

        except Exception:
            # Qualquer erro → texto original
            return original, False

def _extrair_nomes(bruto, chave_mae=None):
    """
    Extrai nomes junto com o nome da chave mãe (ex: Proprietario 1, Conjuge 2).
    Sempre retorna: [(nome, chave_mae), ...]
    """

    def _limpar_nome(n):
        if not n:
            return None
        n = str(n).replace("|", "").strip()
        n = normalize(n)
        return n if n else None

    nomes_final = []

    # --- STRING ---
    if isinstance(bruto, str):
        limpo = _limpar_nome(bruto)
        if limpo:
            nomes_final.append((limpo, chave_mae))
        return nomes_final

    # --- LISTA ---
    if isinstance(bruto, list):
        for item in bruto:
            if isinstance(item, dict):
                # nome direto
                nome_dict = (
                    item.get("Nome") or item.get("Nome:") or
                    item.get("nome") or item.get("nome:") or None
                )
                limpo = _limpar_nome(nome_dict)
                if limpo:
                    nomes_final.append((limpo, chave_mae))
                    continue

                # recursão
                for k, v in item.items():
                    nomes_final.extend(_extrair_nomes(v, chave_mae))
            else:
                limpo = _limpar_nome(item)
                if limpo:
                    nomes_final.append((limpo, chave_mae))
        return nomes_final

    # --- DICT ---
    if isinstance(bruto, dict):
        for k, v in bruto.items():

            k_norm = normalize(k)

            # Se o item é um subgrupo, atualiza chave_mae
            if isinstance(v, (dict, list)):
                novos_pais = chave_mae
                # se chave parece um grupo (ex: "Proprietario 1", "Conjuge 2")
                if any(x in k_norm for x in ["proprietario", "conjuge", "locatario", "arrendatario", "comodatario"]):
                    novos_pais = k  # ← mantém o nome EXATO da chave
                nomes_final.extend(_extrair_nomes(v, novos_pais))
                continue

            # captura apenas se chave é Nome
            if k_norm in ("nome", "nome:"):
                limpo = _limpar_nome(v)
                if limpo:
                    nomes_final.append((limpo, chave_mae))

        return nomes_final

    return nomes_final

def capturar_numero_matricula(texto: str) -> Optional[str]:
    # 2) procura uma sequência grande (25 a 35 dígitos)
    match = re.search(r"\d{25,35}", normalize_no_space(texto))

    if match:
        return match.group(0)

    return None

class HandlerGenerico(BaseHandlerABC):
    """
    Handler genérico padronizado.
    - Extrai dados via IA.
    - NÃO valida (validação agora é feita no pipeline).
    - Agrupa resultados por pessoa e salva no grupo do type_name.
    """

    def processar(self) -> ResultadoHandler:
        nome_arquivo = os.path.basename(self.caminho_arquivo)
        self.log.debug(f"Camiho do arquivo: {self.caminho_arquivo} | Nome do arquivo: {nome_arquivo}")
        texto_documento = self.texto_preprocessado or ""
        tipo_documento = (self.tipo_documento_pre or "").lower()
        if not tipo_documento:
            return self.resultado

        # === 1️⃣ Modelo e extração ===
        try:
            classe_modelo = obter_modelo_por_tipo(tipo_documento)
        except Exception as e:
            self.log.error(f"[HandlerGenérico] Modelo não encontrado para '{tipo_documento}': {e}")
            return self.resultado

        if tipo_documento in ("balance", "dre"):
            texto_documento, _ = recortar_context(texto_documento, tipo_documento)

        if 'receipt' in tipo_documento.lower():
            self.log.debug(f"Recibo de IR identificado, recortando documento...")
            content = self.split_sections(texto_documento, "MINISTÉRIO DA FAZENDA", "VALOR DA QUOTA")
            texto_documento = content if content and len(content) >100 else texto_documento
        
        try:
            dados_extraidos = self._extrair(texto_documento, classe_modelo)
        except Exception as e:
            self.log.error(f"[HandlerGenérico] Falha na extração: {e}")
            dados_extraidos = {}

        if not dados_extraidos:
            return self.resultado
        # === QR CODE automático ===
        try:
            from app.utils.qr_code import extrair_qr_code

            qr_codes = extrair_qr_code(self.caminho_arquivo)

            if qr_codes:
                # Se tiver apenas um → vira string
                dados_extraidos[f"Link QR Code({len(qr_codes)})"] = qr_codes[0]

                self.log.info(f"[HandlerGenérico] QR code detectado: {qr_codes}")

        except Exception as e_qr:
            self.log.error(f"[HandlerGenérico] Erro ao extrair QR code: {e_qr}")


        self.log.info(f"[HandlerGenérico] Dados extraídos: {dados_extraidos}")

        if dados_extraidos.get("Data, local e UF de nascimento:", ""):
            # campo completo existe → ocultar campo simples
            dados_extraidos['Data de nascimento:'] = ""

        if normalize_no_space("registro geral - cpf / personal number") in normalize_no_space(texto_documento):
            dados_extraidos['Registro Geral:'] = ''
        # === 2️⃣ Nome heurístico (para agrupamento) ===
        lista_itens = (
            dados_extraidos.get("Recibos:")
            or dados_extraidos.get("Recibos")
            or dados_extraidos.get("Holerites")
            or dados_extraidos.get("Holerites:")
            or dados_extraidos.get("DREs")
            or dados_extraidos.get("DREs:")
            or []
        )
        if (isinstance(lista_itens, list) and lista_itens):
            base = lista_itens[0] 
        elif (isinstance(lista_itens, dict) and lista_itens):
            for item in lista_itens:
                base = lista_itens[item]
                break
        else:
            base = dados_extraidos

        nome_encontrado = (
            (base or {}).get("Nome:") or (base or {}).get("Nome") or
            (base or {}).get("Nomes:") or (base or {}).get("Nomes") or
            (base or {}).get("proprietario") or (base or {}).get("proprietário") or
            (base or {}).get("Proprietários") or (base or {}).get("Proprietários:") or
            (base or {}).get("Proprietário") or (base or {}).get("Proprietario") or
            (base or {}).get("Emissor:") or (base or {}).get("Proprietário:") or
            (base or {}).get("Razão Social") or (base or {}).get("Outorgante:") or
            (base or {}).get("Arrendatários") or (base or {}).get("Arrendatários:") or
            (base or {}).get("Comodatários") or (base or {}).get("Comodatários:") or
            (base or {}).get("Locatários") or (base or {}).get("Locatários:") or
            (base or {}).get("Usuário:") or (base or {}).get("Usuário") or
            "DESCONHECIDO"
        )
        self.log.debug(f"Nome encontrado: {nome_encontrado}")
        # === Prioridade especial: Adquirentes → Proprietarios Abertura → Nome padrão ===
        adquirentes = dados_extraidos.get("Adquirentes") or dados_extraidos.get("Adquirentes:") or []
        proprietarios_abertura = dados_extraidos.get("Proprietarios_Abertura") or dados_extraidos.get("Proprietarios Abertura") or dados_extraidos.get("Primeiros Proprietarios:") or []

        if adquirentes:
            nome_encontrado = adquirentes   # lista → extrair_nomes resolve
        elif proprietarios_abertura:
            nome_encontrado = proprietarios_abertura

        nomes_extraidos = _extrair_nomes(nome_encontrado)

        if not nomes_extraidos:
            nomes_extraidos = [("DESCONHECIDO", None)]

        self.log.debug(f"Nomes extraídos: {nomes_extraidos}")

        # monta exibindo o nome + (CHAVE MAE)
        def formatar(n, chave):
            if not chave:
                return n
            chave_legivel = chave.title()
            return f"{n} ({chave_legivel})"


        nome_encontrado = " | ".join(
            formatar(n, chave) for (n, chave) in nomes_extraidos
        )

        nome_normalizado = normalize(nome_encontrado)


        self.log.debug(f"Nomes final: {nome_encontrado}")

        # ======================================================================
        # 🔍  FUNARPEN AUTOMÁTICO (NASCIMENTO / CASAMENTO / ÓBITO)
        # ======================================================================

        tipo_norm = normalize(tipo_documento)
        
        if tipo_norm in ("nascimento", "casamento", "obito", "certidaonascimento", "certidaocasamento", "certidaoobito"):
            self.log.info(f"[HandlerGenérico] Documento identificado como certidão ({tipo_norm}). Tentando consultar FUNARPEN...")
            CHAVES_MATRICULA = [
                "Matrícula:",
                "Matricula:",
                "Matricula",
                "Número da Matrícula:",
                "numero_matricula",
                "numero da matricula",
            ]
            # 1) Tenta encontrar campo "matrícula" vindo da IA
            matricula = None
            chave_matricula = None

            for k in CHAVES_MATRICULA:
                if k in dados_extraidos and dados_extraidos.get(k):
                    matricula = dados_extraidos.get(k)
                    chave_matricula = k
                    break
            
            # 2) fallback: regex no texto do documento
            mat_limpa = normalize_no_space(matricula) if isinstance(matricula, str) else ""
            nova_matricula = None
            if not mat_limpa or not mat_limpa.isdigit() or len(mat_limpa) < 20:
                self.log.debug("[HandlerGenérico] Matrícula inválida pela IA — tentando regex no texto.")
                try:
                    nova_matricula = capturar_numero_matricula(texto_documento)
                    mat_limpa = normalize_no_space(nova_matricula) if isinstance(nova_matricula, str) else ""
                except:
                    pass
            
            if isinstance(nova_matricula, str):
                nova_limpa = normalize_no_space(nova_matricula)

                if nova_limpa.isdigit() and len(nova_limpa) >= 20:
                    if chave_matricula and chave_matricula in dados_extraidos:
                        #grava a matrícula correta com chave PADRÃO
                        dados_extraidos[chave_matricula] = nova_matricula

                    matricula = nova_matricula
                    mat_limpa = nova_limpa

                    self.log.info(
                        f"[HandlerGenérico] Matrícula substituída por valor detectado via regex: {nova_matricula}"
                    )


            if isinstance(matricula, str) and mat_limpa:
                try:
                    output_path = str(Path(self.caminho_arquivo).parent)

                    funarpen_result = consultar_funarpen(
                        matricula=matricula,
                        output_path=output_path,
                        nome_arquivo=Path(self.caminho_arquivo).stem,
                        pdf=True,
                        png=False
                    )

                    dados_extraidos["__funarpen"] = funarpen_result
                    self.log.info(f"[HandlerGenérico] Consulta FUNARPEN concluída com sucesso ({matricula}).")

                except Exception as e_fun:
                    self.log.error(f"[HandlerGenérico] Erro ao consultar FUNARPEN ({matricula}): {e_fun}")
            else:
                self.log.warning("[HandlerGenérico] Matrícula não localizada no documento para FUNARPEN.")

    
        # === 4️⃣ Agrupamento padronizado ===
        self.resultado["documentos"].append({
            "dados": dados_extraidos,
            "context": self.texto_paginas,
            "nome_pessoa": nome_normalizado,
            "identificador": f"{self.tipo_documento_pre.upper()}1"
        })

        # === 5️⃣ Marcação ===
        self.resultado["sheet_ok"] = True

        self.log.info(f"[HandlerGenérico] Documento '{nome_arquivo}' agrupado para '{nome_normalizado}'.")
        return self.resultado
