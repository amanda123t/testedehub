# 🧠 Sicredi – Automação de Validação de Documentos

Sistema completo de **validação documental** com integração a **SharePoint**, **OCR (Azure)** e **IA para extração e conferência de dados**.  
O pipeline lê documentos de processos, identifica seus tipos, extrai informações, aplica regras de validação e gera relatórios consolidados em **PDF** e **JSON**.

---

## 🔗 Índice

- [Estrutura Geral de Pastas](#-estrutura-geral-de-pastas)
- [Funcionamento Geral do Código](#-funcionamento-geral-do-código)
  - [Coleta (SharePoint)](#1️⃣-coleta-sharepoint)
  - [Extração de Texto (OCR / PDF)](#-módulo-de-extração-de-texto-text_extraction)
  - [Classificação de Documentos](#3️⃣-classificação-de-documentos)
  - [Extração de Dados (Handlers)](#4️⃣-extração-de-dados-handlers)
  - [Validação (Validadores)](#-estrutura-de-entrada-e-saída-dos-validadores)
  - [Geração de Relatório e Upload](#6️⃣-geraçao-de-relatório-e-upload)
- [Logs e Monitoramento](#-logs-e-monitoramento)
- [Regras Operacionais Importantes](#-regras-operacionais-importantes)
- [Vantagens da Arquitetura](#-principais-vantagens-da-arquitetura)
- [Conclusão](#-conclusão)

---

## 🧩 Estrutura Geral de Pastas

```text
app/
│
├─ docs/                    # Exemplos de texto por documento (apoio à classificação com IA)
├─ models/                  # Modelos Pydantic com campos esperados por tipo
├─ Handlers/                # Processamento por tipo (separa holerite/pró-labore, IR/recibo, etc.)
│
├─ modules/                 # Orquestração do pipeline
│  ├─ pipeline/
│  │  ├─ by_process.py      # Pipeline principal por processo
│  │  ├─ validation_helper.py# Funções auxiliares de validação
│  │  ├─ error.py           # Marcação/propagação de erro (renomeia no SharePoint)
│  ├─ document_classifier.py # Classificador por IA (tipo do documento)
│  ├─ extractor.py           # Orquestrador de extração de texto (OCR/PDF)
│  ├─ sharepoint.py          # Integração SharePoint (download/upload/movimentações)
│  └─ ...
│
├─ utils/                   # Utilitários
│  ├─ format_br.py          # Formatação BR (datas, valores)
│  ├─ api_crc.py            # Integração CRC
│  ├─ api_receita.py        # Integração Receita Federal
│  ├─ helpers.py            # Helpers gerais
│  └─ ...
│
├─ validator/               # Validação (por tipo)
│  ├─ base_validator.py     # Base comum de validação
│  ├─ generico.py           # Validador genérico (fallback)
│  └─ documentos/
│     ├─ validator_holerite.py
│     ├─ validator_irpf.py
│     ├─ validator_balanco.py
│     └─ ...
│
└─ task.py                  # Entrada principal (execução do pipeline)

logs/                       # (fora de app/) – logs de execução
```

---

## ⚙️ Funcionamento Geral do Código

O pipeline é dividido em etapas independentes, com entradas e saídas padronizadas:

### 1️⃣ Coleta (SharePoint)

O `modules/sharepoint.py`:
- Monitora a **PASTA_MONITORADA**;
- Baixa novos **processos** (pasta, `.zip` ou arquivo único → **sempre 1 processo**);
- Garante estrutura/duplicidade;
- Sobe resultados (PDF + JSON) para **PASTA_RESULTADOS**;
- Move itens antigos para **PASTA_PROCESSADOS** (ver regras operacionais).

> 📦 **Regra de processo**  
> - **Pasta** → 1 PDF consolidado  
> - **.zip** → 1 PDF consolidado  
> - **Arquivo único** → 1 PDF  

---

## 🧩 Módulo de Extração de Texto (`text_extraction`)

Extrai conteúdo de PDFs/imagens combinando **texto nativo (PyMuPDF/fitz)** e **OCR (Azure)**, com fallback e paralelismo.

**Estrutura:**
```
text_extraction/
├─ base_extractor.py        # Base utilitária
├─ pdf_text_extractor.py    # Texto nativo (rápido / sem custo)
├─ azure_ocr_extractor.py   # OCR (Azure Document Intelligence)
├─ template_result.py       # Retorno unificado (TemplateResult)
└─ manager.py               # Orquestração/decisão
```

**Fluxo resumido:**
1. Tenta **PDFTextExtractor** primeiro; mede qualidade.
2. Se baixa, roda **OCR** nas páginas necessárias.
3. Junta tudo num **TemplateResult** único (páginas, métodos, qualidade, erros, meta).

**Concorrência:**
- `ThreadPoolExecutor` global (ex.: `MAX_OCR_POR_PROCESS`);
- `Semaphore` global (ex.: `MAX_AZURE_TRAVA`) para respeitar limites do Azure.

**Extensível:** novos OCRs (EasyOCR, Tesseract) podem ser plugados retornando `TemplateResult`.

---

### 3️⃣ Classificação de Documentos

`modules/document_classifier.py` recebe o texto e retorna algo como:
```json
{ "tipo_documento": "Holerite", "confianca": 0.94 }
```
Usa:
- Exemplos em `app/docs/`;
- Regras heurísticas (gatilhos por termos, CNPJ empregador, etc.);
- Cache/filtros para reclassificações.

O **tipo** decide **qual Handler** será usado.

---

### 4️⃣ Extração de Dados (Handlers)

Cada `Handler` entende o **layout** e extrai campos usando **IA + regex + heurísticas**.

Exemplos:
- `HoleriteHandler` → salário, descontos, empregador, CNPJ, competências…
- `NotaFiscalHandler` → emissor, destinatário, produtos, valores, impostos…
- `IRPFHandler` → base tributável, deduções, restituição…

**Ciclo do Handler:**
1. Recebe texto/contexto do extrator;
2. (Opcional) Prompt para IA;
3. Retorna **JSON** com campos padronizados → segue para **Validação**.

---

## 🧩 Estrutura de Entrada e Saída dos Validadores

Formato **unificado** que permite validação individual e cruzada (ex.: IRPF × recibo, Balanço × DRE).

### ✅ Entrada

```python
def __init__(
    self,
    *,
    doc_type: str,               
    data: Dict[str, Any],        
    type_name: str,              
    process_info: Dict[str, Any],
    numero_processo: Optional[str] = None,
    planilha_regras: Any = None,
) -> None:
```

**`data` (exemplo):**
```json
{
  "Holerite": [
    {"dados": {...}, "arquivo": "Holerite_Maio.pdf", "context": "..."},
    {"dados": {...}, "arquivo": "Holerite_Junho.pdf", "context": "..."}
  ],
  "Nota Fiscal": [
    {"dados": {...}, "arquivo": "NF_001.pdf", "context": "..."}
  ],
  "IRPF": [
    {"dados": {...}, "arquivo": "IR2024.pdf", "context": "..."},
    {"dados": {...}, "arquivo": "Recibo_IR2024.pdf", "context": "..."}
  ]
}
```

> 💡 Mesmo validando apenas um tipo, o validador **enxerga todo o processo**, permitindo **validações cruzadas**.

### ✅ Saída (formato padrão)

```json
{
  "tipo_documento": "Nota Fiscal",
  "status_geral": true,
  "mensagem": "Realizado a soma de todas notas fiscais enviadas!",
  "documentos": [
    {
      "arquivo": "NF_001.pdf",
      "status": true,
      "mensagem": "Validação concluída com sucesso.",
      "dados_extraidos": { ... },
      "context": "texto integral..."
    }
  ],
  "sections": [
    ["Resultados do Processamento:", ""],
    ["Soma total das notas:", "R$ 18.350,00"]
  ],
  "header_info": {},
  "campos_mua": {},
  "referencias": { "pessoa": "JOÃO DA SILVA", "cnpj": "12345678000190" }
}
```

---

### 6️⃣ Geraçao de Relatório e Upload

Após validação:
- Gera **PDF** consolidado por **processo**;
- Salva **JSON** com dados brutos;
- Envia ambos para **SharePoint/PASTA_RESULTADOS**;
- Movimenta itens antigos para **PASTA_PROCESSADOS**:
  - `ARQUIVOS/` → originais processados
  - `RESULTADOS.pdf/` → relatórios finais
  - `RESULTADOS.json/` → extrações brutas
  - `REGISTROS/` → planilha cumulativa com histórico de processos

---

## 🔒 Logs e Monitoramento

- Todos os eventos (download, OCR, IA, erros, tempos) são gravados em **`/logs/`**;
- Log por execução com identificação de **processo** e **arquivo**;
- Nível de detalhe configurável (ex.: `LOG_DETAIL`).

---

## 📏 Regras Operacionais Importantes

- **Unidade de processo**: pasta **ou** `.zip` **ou** arquivo único = **1 processo / 1 PDF**.
- **Erros com renomeação no SharePoint**:
  - `ERRO CLASSIFICAÇÃO` → comum enquanto nem todos os documentos estão mapeados.
  - `ERRO TOKENS` → arquivo com **> 30 páginas** (não Nota Fiscal).
  - Outros (`ERRO PROCESSO`, `ERRO VALIDAÇÃO`) → conferir PDF, ajustar entrada e reenviar.
- **Janela de funcionamento**: **Seg–Sáb, 07h–19h**.
- **Arquivamento automático** (≈ a cada 2h):
  - **PASTA_MONITORADA** → `PROCESSADOS/ARQUIVOS/`
  - **PASTA_RESULTADOS** → `PROCESSADOS/RESULTADOS.pdf/`
  - **PASTA_RESULTADOS** → `PROCESSADOS/RESULTADOS.json/`
  - **PROCESSADOS/REGISTROS** → planilha cumulativa (sempre baixar cópia local)

---

## 🚀 Principais Vantagens da Arquitetura

- **Padronização** entre módulos e etapas.
- **Escalabilidade** com threads e controle de APIs.
- **Tolerância a falhas** (processamento parcial).
- **Extensibilidade**: novo tipo = novo Handler + Validador.
- **Integração contínua** com SharePoint e regras MUA.

---

## 📘 Conclusão

Arquitetura pensada para:
- Alto volume de processos/documentos;
- Automação ponta a ponta (download → validação → upload);
- Evolução diária de regras e tipos, com governança controlada.

> **Manutenção**  
> Ajustes em planilha MUA e lógica de validação: somente **líder técnico + pontos focais**.  
> Comportamentos inesperados → verificar logs e comunicar ao time.
